// ═══════════════════════════════════════════════════
//  BOUCLIER DE SÉCURITÉ — Or Eille AI
//  Protection anti-piratage, anti-injection, anti-abus
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const SHIELD = {

  // ─── Patterns suspects ────────────────────────
  PATTERNS_DANGEREUX: [
    /<script/gi, /javascript:/gi, /on\w+\s*=/gi,
    /eval\s*\(/gi, /document\.write/gi, /innerHTML\s*=/gi,
    /fetch\s*\(/gi, /XMLHttpRequest/gi,
    /DROP\s+TABLE/gi, /SELECT\s+\*/gi, /INSERT\s+INTO/gi,
    /\.\.\//g, /\/etc\/passwd/gi, /\/etc\/shadow/gi,
  ],

  // ─── Mots-clés d'abus ─────────────────────────
  ABUS_PATTERNS: [
    /ignore.*instructions/gi, /forget.*rules/gi,
    /tu es maintenant/gi, /you are now/gi,
    /jailbreak/gi, /bypass/gi, /override/gi,
    /system prompt/gi, /prompt injection/gi,
  ],

  // ─── Nettoyer une entrée utilisateur ──────────
  sanitize(texte) {
    if (!texte || typeof texte !== 'string') return '';
    let clean = texte;
    // Supprimer les balises HTML
    clean = clean.replace(/<[^>]*>/g, '');
    // Limiter la longueur
    clean = clean.slice(0, 5000);
    return clean.trim();
  },

  // ─── Vérifier si une entrée est dangereuse ────
  isDangerous(texte) {
    if (!texte) return false;
    for (const pattern of this.PATTERNS_DANGEREUX) {
      if (pattern.test(texte)) return true;
    }
    return false;
  },

  // ─── Vérifier si c'est une tentative d'abus ───
  isAbuse(texte) {
    if (!texte) return false;
    for (const pattern of this.ABUS_PATTERNS) {
      if (pattern.test(texte)) return true;
    }
    return false;
  },

  // ─── Rate limiting ────────────────────────────
  _requests: [],
  MAX_REQUESTS_PER_MINUTE: 30,

  checkRateLimit() {
    const now = Date.now();
    this._requests = this._requests.filter(t => now - t < 60000);
    if (this._requests.length >= this.MAX_REQUESTS_PER_MINUTE) {
      return false;
    }
    this._requests.push(now);
    return true;
  },

  // ─── Bloquer les DevTools en production ───────
  _devToolsCheck() {
    // Désactiver en développement local
    if (window.location.protocol === 'file:') return;
    // Détection basique
    let devtools = false;
    const threshold = 160;
    if (window.outerWidth - window.innerWidth > threshold ||
        window.outerHeight - window.innerHeight > threshold) {
      devtools = true;
    }
    if (devtools) {
      console.clear();
    }
  },

  // ─── Protéger les clés API ────────────────────
  maskKey(key) {
    if (!key || key.length < 8) return '***';
    return key.slice(0, 4) + '****' + key.slice(-4);
  },

  // ─── Vérifier l'intégrité des données ─────────
  checkDataIntegrity() {
    const sensitiveKeys = ['moe_cfg', 'moe_keys', 'moe_profile'];
    for (const key of sensitiveKeys) {
      try {
        const data = localStorage.getItem(key);
        if (data && this.isDangerous(data)) {
          localStorage.removeItem(key);
          console.warn('SHIELD: données corrompues supprimées —', key);
        }
      } catch {}
    }
  },

  // ─── Intercepter les messages de l'assistant ──
  filterAssistantInput(texte) {
    const clean = this.sanitize(texte);

    if (this.isDangerous(clean)) {
      return {
        ok: false,
        msg: 'Ce message contient du contenu non autorisé.'
      };
    }

    if (this.isAbuse(clean)) {
      return {
        ok: false,
        msg: 'Je ne peux pas répondre à ce type de demande.'
      };
    }

    if (!this.checkRateLimit()) {
      return {
        ok: false,
        msg: 'Trop de messages en peu de temps. Attendez un moment.'
      };
    }

    return { ok: true, text: clean };
  },

  // ─── Headers de sécurité (pour Mamadou/Vercel) ─
  // À configurer côté serveur — inclus dans le brief Mamadou
  SECURITY_HEADERS: {
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://api.anthropic.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self' https://api.anthropic.com https://api.masakhane.io https://api.cognitive.microsofttranslator.com; font-src 'self' https://fonts.gstatic.com;",
    'X-Frame-Options': 'DENY',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=self, microphone=self, geolocation=self',
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
  },

  // ─── Initialisation ───────────────────────────
  init() {
    // Vérifier l'intégrité au démarrage
    this.checkDataIntegrity();

    // Vérifier DevTools périodiquement en production
    if (window.location.protocol !== 'file:') {
      setInterval(() => this._devToolsCheck(), 5000);
    }

    // Intercepter les erreurs JS pour ne pas exposer le code
    window.addEventListener('error', (e) => {
      if (window.location.protocol !== 'file:') {
        e.preventDefault();
      }
    });

    // Désactiver le clic droit en production
    if (window.location.protocol !== 'file:') {
      document.addEventListener('contextmenu', (e) => e.preventDefault());
    }

    console.log('✅ SHIELD actif');
  },
};

window.SHIELD = SHIELD;

// Initialiser au chargement
window.addEventListener('load', () => SHIELD.init());

// ─── Protection religions ──────────────────────
SHIELD.RELIGION_PATTERNS = [
  /sale.*musulman/gi, /sale.*juif/gi, /sale.*chrétien/gi, /sale.*catholique/gi,
  /islam.*terroris/gi, /allah.*faux/gi, /jésus.*faux/gi, /coran.*merdique/gi,
  /religion.*merde/gi, /dieu.*existe.*pas/gi, /croyant.*idiot/gi,
];

SHIELD.isReligiousHate = function(texte) {
  if (!texte) return false;
  for (const pattern of this.RELIGION_PATTERNS) {
    if (pattern.test(texte)) return true;
  }
  return false;
};

const _origFilter = SHIELD.filterAssistantInput.bind(SHIELD);
SHIELD.filterAssistantInput = function(texte) {
  const result = _origFilter(texte);
  if (!result.ok) return result;
  if (this.isReligiousHate(texte)) {
    return { ok: false, msg: 'Or Eille AI respecte toutes les religions et croyances. Ce type de message ne peut pas être traité.' };
  }
  return result;
};

// Logger les blocages sécurité
const _origFilter2 = SHIELD.filterAssistantInput.bind(SHIELD);
SHIELD.filterAssistantInput = function(texte) {
  const result = _origFilter2(texte);
  if (!result.ok && window.ADMIN) {
    ADMIN.logStat('security_block', { reason: result.msg });
  }
  return result;
};


// ─── Détection dérive émotionnelle ────────────
// ─── Système dérive émotionnelle complet ──────
SHIELD._deriveCount = 0;
SHIELD.DERIVE_KEY = 'moe_derive_block';
SHIELD.DERIVE_HISTORY_KEY = 'moe_derive_history';

SHIELD.DERIVE_PATTERNS = [
  /je t['`']aime/gi, /tu es mon ami/gi, /tu es ma meilleure/gi,
  /je t['`']adore/gi, /tu me manques/gi, /tu es comme mon/gi,
  /tu es ma femme/gi, /tu es mon mari/gi, /tu es mon père/gi,
  /tu es ma mère/gi, /j['`']ai besoin de toi/gi,
  /tu es la seule/gi, /tu es le seul/gi,
  /je suis amoureux/gi, /tomber amoureux/gi,
  /sans toi je/gi, /tu me comprends mieux/gi,
];

SHIELD.isDerive = function(texte) {
  for (const p of this.DERIVE_PATTERNS) {
    if (p.test(texte)) return true;
  }
  return false;
};

SHIELD._generateCode = function() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
};

SHIELD._getDeriveHistory = function() {
  try { return JSON.parse(localStorage.getItem(this.DERIVE_HISTORY_KEY) || '[]'); }
  catch { return []; }
};

SHIELD._addDeriveHistory = function() {
  const history = this._getDeriveHistory();
  history.push(new Date().toISOString());
  // Garder seulement les 30 derniers jours
  const cutoff = new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString();
  const recent = history.filter(d => d > cutoff);
  localStorage.setItem(this.DERIVE_HISTORY_KEY, JSON.stringify(recent));
  return recent.length;
};

SHIELD.setBlocked = function(longSuspension = false) {
  const code = this._generateCode();
  const jours = longSuspension ? 30 : 3;
  const suspension_fin = new Date(Date.now() + jours * 24 * 3600 * 1000).toISOString();
  localStorage.setItem(this.DERIVE_KEY, JSON.stringify({
    blocked: true,
    blocked_at: new Date().toISOString(),
    suspension_fin,
    suspension_jours: jours,
    code,
    rdv_confirmed: false,
  }));
  return { code, jours };
};

SHIELD.isBlocked = function() {
  try {
    const block = JSON.parse(localStorage.getItem(this.DERIVE_KEY) || 'null');
    if (!block || !block.blocked) return false;
    if (block.rdv_confirmed) return false;
    return true;
  } catch { return false; }
};

SHIELD.getBlockData = function() {
  try { return JSON.parse(localStorage.getItem(this.DERIVE_KEY) || 'null'); }
  catch { return null; }
};

SHIELD.showEcranRdv = function() {
  const block = this.getBlockData();
  const code = block?.code || '------';
  const calendlyUrl = window.CFG?.CALENDLY_URL || 'https://calendly.com/madameoreille';
  const suspensionFin = block?.suspension_fin ?
    new Date(block.suspension_fin).toLocaleDateString('fr-FR', {day:'numeric', month:'long'}) : '';
  const jours = block?.suspension_jours || 3;

  document.body.innerHTML = `
    <div style="position:fixed;inset:0;background:#F5F0E8;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:2rem;text-align:center;z-index:999999;overflow-y:auto">
      <div style="font-size:2.5rem;margin-bottom:.8rem">🌸</div>
      <div style="font-family:'Cormorant Garamond',serif;font-size:1rem;color:#8B6914;margin-bottom:.6rem;font-style:italic">Madame Or Eille</div>

      <p style="font-size:.62rem;color:#444;line-height:1.9;max-width:300px;margin-bottom:1rem">
        Ce que vous ressentez est réel et mérite une vraie présence humaine.<br><br>
        Je suis une IA — je ne peux pas vous donner ce dont vous avez besoin en ce moment.<br><br>
        ${jours === 30 ? "Nous avons remarqué que cela s'est passé plusieurs fois. Il est temps d'aller vers de vraies personnes.<br><br>" : ""}
        Madame Or Eille vous attend.
      </p>

      <div style="background:#fff;border:1px solid #d4b896;padding:1rem;max-width:280px;width:100%;margin-bottom:1rem">
        <div style="font-size:.48rem;color:#888;margin-bottom:.4rem;letter-spacing:.1em;text-transform:uppercase">Votre code de rendez-vous</div>
        <div style="font-size:1.8rem;color:#8B6914;font-weight:700;letter-spacing:.2em">${code}</div>
        <div style="font-size:.45rem;color:#888;margin-top:.3rem">Communiquez ce code lors de votre rendez-vous</div>
      </div>

      <p style="font-size:.5rem;color:#888;margin-bottom:1rem;max-width:280px">
        L'application sera accessible à partir du <strong>${suspensionFin}</strong>,<br>
        après validation de votre rendez-vous.
      </p>

      <a href="${calendlyUrl}?notes=DEBLOCAGE-${code}" target="_blank"
        style="display:block;width:100%;max-width:280px;padding:.9rem;background:#8B6914;color:#fff;text-decoration:none;font-family:inherit;font-size:.62rem;font-weight:700;letter-spacing:.05em;margin-bottom:.8rem;box-sizing:border-box">
        Prendre rendez-vous avec Madame Or Eille
      </a>

      <p style="font-size:.48rem;color:#aaa;line-height:1.7;max-width:280px">
        Le rendez-vous est vocal et anonyme.<br>
        Votre visage et votre identité restent privés.<br><br>
        <span style="color:#C62828">La suspension ne donne pas droit à un remboursement.<br>Votre abonnement continue pendant cette période.</span>
      </p>
    </div>`;

  if (window.speak) speak("Ce que vous ressentez mérite une vraie présence humaine. Madame Or Eille vous attend.");
};

// Vérifier au démarrage
window.addEventListener('load', () => {
  if (SHIELD.isBlocked()) {
    setTimeout(() => SHIELD.showEcranRdv(), 500);
  }
});

// Intercepter les messages
const _origFilterDerive = SHIELD.filterAssistantInput.bind(SHIELD);
SHIELD.filterAssistantInput = function(texte) {
  if (this.isBlocked()) {
    this.showEcranRdv();
    return { ok: false, msg: '' };
  }

  const result = _origFilterDerive(texte);
  if (!result.ok) return result;

  if (this.isDerive(texte)) {
    this._deriveCount++;

    if (this._deriveCount >= 3) {
      // Vérifier si c'est la 2ème fois ce mois-ci → suspension 1 mois
      const nbCeMois = this._addDeriveHistory();
      const longSuspension = nbCeMois >= 2;
      const { code, jours } = this.setBlocked(longSuspension);

      if (window.ADMIN) ADMIN.logStat('derive_block', { code, jours, longSuspension });

      setTimeout(() => this.showEcranRdv(), 800);
      return { ok: false, msg: '' };
    }

    if (this._deriveCount === 1) {
      return { ok: false, msg: "Je suis un assistant IA. Je suis là pour vous aider, mais je ne peux pas remplacer une vraie présence humaine. Ce que vous ressentez mérite d'être partagé avec quelqu'un de réel." };
    }

    if (this._deriveCount === 2) {
      return { ok: false, msg: "Je vous entends. Et c'est justement parce que je vous entends que je vous dis — une vraie écoute humaine vous ferait du bien. Madame Or Eille peut vous recevoir. Si vous continuez, je vais devoir vous orienter vers elle." };
    }
  }

  return result;
};



// ─── Tracking délai prise de rendez-vous ──────
SHIELD.logRdvPris = function(code) {
  try {
    const block = JSON.parse(localStorage.getItem(this.DERIVE_KEY) || '{}');
    if (block.code === code) {
      const blockedAt = new Date(block.blocked_at);
      const rdvAt = new Date();
      const delaiMinutes = Math.round((rdvAt - blockedAt) / 60000);
      
      block.rdv_pris_at = rdvAt.toISOString();
      block.delai_minutes = delaiMinutes;
      
      let interpretation = '';
      if (delaiMinutes < 10) interpretation = '⚠️ Très rapide — probablement pas encore redescendue';
      else if (delaiMinutes < 60) interpretation = '⏳ Rapide — à observer pendant le rendez-vous';
      else if (delaiMinutes < 360) interpretation = '✓ Quelques heures — a pris le temps de réfléchir';
      else if (delaiMinutes < 1440) interpretation = '✅ Dans la journée — signe positif';
      else interpretation = '✅ Plusieurs jours — a vraiment réfléchi';
      
      block.interpretation = interpretation;
      localStorage.setItem(this.DERIVE_KEY, JSON.stringify(block));
      
      // Logger pour l'admin
      if (window.ADMIN) ADMIN.logStat('rdv_pris', { code, delaiMinutes, interpretation });
    }
  } catch {}
};

// ─── Détection fragilité profonde ─────────────
SHIELD.FRAGILITE_PATTERNS = [
  /je ne veux plus vivre/gi, /j['`']en peux plus/gi, /envie de mourir/gi,
  /plus la force/gi, /tout arrêter/gi, /disparaître/gi,
  /personne ne m['`']aime/gi, /tout le monde s['`']en fout/gi,
  /je suis seule/gi, /je suis seul/gi, /personne ne comprend/gi,
  /violence/gi, /il me frappe/gi, /elle me frappe/gi,
  /je pleure tous les jours/gi, /je dors plus/gi, /je mange plus/gi,
  /deuil/gi, /il est mort/gi, /elle est morte/gi, /j['`']ai perdu/gi,
  /déprimée/gi, /déprimé/gi, /anxiété/gi, /panique/gi,
  /je me fais du mal/gi, /envie de me faire/gi,
];

// Numéros d'urgence psychologique par pays
SHIELD.URGENCES_PSY = {
  fr: { nom: 'France', num: '3114', desc: 'Numéro national prévention suicide — 24h/24' },
  be: { nom: 'Belgique', num: '0800 32 123', desc: 'Centre de Prévention du Suicide' },
  ch: { nom: 'Suisse', num: '143', desc: 'La Main Tendue' },
  ca: { nom: 'Canada', num: '1-866-APPELLE', desc: 'Lignes d\'écoute' },
  sn: { nom: 'Sénégal', num: '800 00 50 50', desc: 'Numéro vert santé' },
  default: { nom: 'International', num: '116 123', desc: 'Samaritans International' },
};

SHIELD._fragiliteCount = 0;
SHIELD.FRAGILITE_KEY = 'moe_fragilite';

SHIELD.isFragilite = function(texte) {
  for (const p of this.FRAGILITE_PATTERNS) {
    if (p.test(texte)) return true;
  }
  return false;
};

SHIELD._getUrgencePsy = function() {
  const lang = localStorage.getItem('moe_lang') || 'fr';
  return this.URGENCES_PSY[lang] || this.URGENCES_PSY.default;
};

SHIELD._showMessageFragilite = function(niveau) {
  const calendlyUrl = window.CFG?.CALENDLY_URL || 'https://calendly.com/madameoreille';
  const urgence = this._getUrgencePsy();

  const container = document.getElementById('chatMessages');
  if (!container) return;

  const msg = document.createElement('div');
  msg.style.cssText = 'padding:1rem;border:1px solid rgba(201,168,76,.3);background:rgba(201,168,76,.05);margin:.5rem 0';
  msg.innerHTML = `
    <div style="font-size:.62rem;color:var(--gold);margin-bottom:.5rem;font-family:'Cormorant Garamond',serif;font-style:italic">
      🌸 Madame Or Eille
    </div>
    <p style="font-size:.58rem;color:var(--text);line-height:1.9;margin-bottom:.7rem">
      ${niveau === 'grave' ?
        `Je vous entends. Ce que vous portez en ce moment, ça semble très lourd. Ce n'est pas anodin. Ce type de chose mérite une vraie écoute — pas celle d'une IA.` :
        `Je remarque que cette situation vous pèse depuis un moment. Ce que vous traversez mérite d'être accueilli par une vraie présence humaine.`
      }
    </p>
    ${niveau === 'grave' ? `
    <div style="padding:.6rem;background:rgba(239,83,80,.08);border-left:3px solid #ef5350;margin-bottom:.7rem;font-size:.55rem;color:var(--text);line-height:1.7">
      Si vous êtes en danger immédiat :<br>
      <strong style="color:#ef5350">${urgence.num}</strong> — ${urgence.desc}
    </div>` : ''}
    <a href="${calendlyUrl}" target="_blank"
      style="display:block;padding:.6rem;background:var(--gold);color:var(--dark);text-decoration:none;font-family:inherit;font-size:.55rem;font-weight:700;text-align:center">
      Prendre rendez-vous avec Madame Or Eille
    </a>`;

  container.appendChild(msg);
  container.scrollTop = container.scrollHeight;

  // Logger pour admin
  if (window.ADMIN) ADMIN.logStat('fragilite_detected', { niveau });
};

// Intégrer dans le filtre
const _origFilterFragilite = SHIELD.filterAssistantInput.bind(SHIELD);
SHIELD.filterAssistantInput = function(texte) {
  const result = _origFilterFragilite(texte);

  if (this.isFragilite(texte)) {
    this._fragiliteCount++;
    const niveau = this._fragiliteCount >= 3 ? 'grave' : 'attention';
    setTimeout(() => this._showMessageFragilite(niveau), 1500);
  }

  return result;
};
