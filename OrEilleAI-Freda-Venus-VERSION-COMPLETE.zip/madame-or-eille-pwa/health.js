// ═══════════════════════════════════════════════════
//  SANTÉ & URGENCE MÉDICALE — Or Eille AI v1.0
//  4 tapes = fiche médicale instantanée
//  SOS automatique — multilingue
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const HEALTH = {
  KEY: 'moe_health',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      name:'', age:'', bloodType:'',
      allergies:'', conditions:'', treatments:'',
      pacemaker:false, pregnant:false, pregnancyWeeks:'',
      emergencyContact:'', emergencyPhone:'',
      doctor:'', doctorPhone:'', additionalInfo:''
    }; } catch { return {}; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  LABELS: {
    fr:{ sos:'URGENCE MÉDICALE', card:'Fiche médicale', name:'Nom', age:'Âge', years:'ans', blood:'Groupe sanguin', pregnant:'Enceinte', weeks:'sem.', allergy:'⚠ ALLERGIES', conditions:'Antécédents', treatments:'Traitements en cours', pacemaker:'⚡ PACEMAKER', contact:'Contact urgence', call:'Appeler le 15 / 112', close:'Fermer' },
    en:{ sos:'MEDICAL EMERGENCY', card:'Medical card', name:'Name', age:'Age', years:'y.o.', blood:'Blood type', pregnant:'Pregnant', weeks:'wks', allergy:'⚠ ALLERGIES', conditions:'Medical history', treatments:'Current treatments', pacemaker:'⚡ PACEMAKER', contact:'Emergency contact', call:'Call 112', close:'Close' },
    es:{ sos:'EMERGENCIA MÉDICA', card:'Ficha médica', name:'Nombre', age:'Edad', years:'años', blood:'Grupo sanguíneo', pregnant:'Embarazada', weeks:'sem.', allergy:'⚠ ALERGIAS', conditions:'Antecedentes', treatments:'Tratamientos', pacemaker:'⚡ MARCAPASOS', contact:'Contacto emergencia', call:'Llamar 112', close:'Cerrar' },
    pt:{ sos:'EMERGÊNCIA MÉDICA', card:'Ficha médica', name:'Nome', age:'Idade', years:'anos', blood:'Tipo sanguíneo', pregnant:'Grávida', weeks:'sem.', allergy:'⚠ ALERGIAS', conditions:'Histórico médico', treatments:'Tratamentos', pacemaker:'⚡ MARCAPASSO', contact:'Contato emergência', call:'Ligar 192', close:'Fechar' },
    ar:{ sos:'طوارئ طبية', card:'بطاقة طبية', name:'الاسم', age:'العمر', years:'سنة', blood:'فصيلة الدم', pregnant:'حامل', weeks:'أسبوع', allergy:'⚠ حساسية', conditions:'السوابق الطبية', treatments:'العلاجات الحالية', pacemaker:'⚡ منظم القلب', contact:'جهة الطوارئ', call:'اتصال طوارئ', close:'إغلاق' },
    zh:{ sos:'医疗紧急', card:'医疗卡', name:'姓名', age:'年龄', years:'岁', blood:'血型', pregnant:'怀孕', weeks:'周', allergy:'⚠ 过敏', conditions:'病史', treatments:'当前治疗', pacemaker:'⚡ 心脏起搏器', contact:'紧急联系人', call:'拨打急救电话', close:'关闭' },
    ko:{ sos:'의료 응급', card:'의료 카드', name:'이름', age:'나이', years:'세', blood:'혈액형', pregnant:'임신', weeks:'주', allergy:'⚠ 알레르기', conditions:'병력', treatments:'현재 치료', pacemaker:'⚡ 심박조율기', contact:'비상연락처', call:'119 전화', close:'닫기' },
    ms:{ sos:'KECEMASAN PERUBATAN', card:'Kad perubatan', name:'Nama', age:'Umur', years:'thn', blood:'Kumpulan darah', pregnant:'Hamil', weeks:'minggu', allergy:'⚠ ALAHAN', conditions:'Sejarah perubatan', treatments:'Rawatan semasa', pacemaker:'⚡ PERENTAK JANTUNG', contact:'Kenalan kecemasan', call:'Hubungi 999', close:'Tutup' },
    sw:{ sos:'DHARURA YA MATIBABU', card:'Kadi ya matibabu', name:'Jina', age:'Umri', years:'miaka', blood:'Aina ya damu', pregnant:'Mjamzito', weeks:'wiki', allergy:'⚠ MZIO', conditions:'Historia ya matibabu', treatments:'Matibabu ya sasa', pacemaker:'⚡ KIFAA CHA MOYO', contact:'Mawasiliano ya dharura', call:'Piga simu 112', close:'Funga' },
  },

  getL() {
    const lang = navigator.language?.substring(0,2) || 'en';
    return this.LABELS[lang] || this.LABELS['en'];
  },

  // ─── 4 tapes = fiche d'urgence ─────────────────
  initTapDetection() {
    let taps = 0, timer = null;
    document.addEventListener('click', () => {
      taps++;
      clearTimeout(timer);
      if (taps >= 4) { taps = 0; this.showEmergencyCard(); }
      timer = setTimeout(() => { taps = 0; }, 800);
    });
  },

  // ─── Fiche médicale d'urgence ─────────────────
  showEmergencyCard() {
    const d = this.get();
    if (!d.name && !d.bloodType && !d.allergies) return;
    if (document.getElementById('emergency-card')) return;
    const L = this.getL();

    const modal = document.createElement('div');
    modal.id = 'emergency-card';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(180,0,0,.97);z-index:999999;display:flex;align-items:center;justify-content:center;padding:1rem;overflow-y:auto';
    modal.innerHTML = `
      <div style="max-width:380px;width:100%;background:#fff;color:#111;border-radius:6px;overflow:hidden;box-shadow:0 0 40px rgba(0,0,0,.5)">

        <!-- En-tête rouge -->
        <div style="background:#cc0000;color:#fff;padding:.8rem 1rem;text-align:center">
          <div style="font-size:1.8rem;margin-bottom:.2rem">🚨</div>
          <div style="font-weight:900;font-size:.9rem;letter-spacing:.15em">${L.sos}</div>
          <div style="font-size:.48rem;opacity:.85;margin-top:.2rem">${L.card}</div>
        </div>

        <div style="padding:1rem">
          <!-- Infos de base -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:.5rem;margin-bottom:.7rem">
            ${d.name?`<div><div style="font-size:.4rem;color:#888;text-transform:uppercase">${L.name}</div><div style="font-size:.75rem;font-weight:bold">${d.name}</div></div>`:''}
            ${d.age?`<div><div style="font-size:.4rem;color:#888;text-transform:uppercase">${L.age}</div><div style="font-size:.75rem;font-weight:bold">${d.age} ${L.years}</div></div>`:''}
            ${d.bloodType?`<div><div style="font-size:.4rem;color:#888;text-transform:uppercase">${L.blood}</div><div style="font-size:.9rem;font-weight:900;color:#cc0000">${d.bloodType}</div></div>`:''}
            ${d.pregnant?`<div><div style="font-size:.4rem;color:#888;text-transform:uppercase">${L.pregnant}</div><div style="font-size:.7rem;font-weight:bold;color:#cc0000">✓ ${d.pregnancyWeeks?d.pregnancyWeeks+' '+L.weeks:''}</div></div>`:''}
          </div>

          <!-- Pacemaker -->
          ${d.pacemaker?`<div style="background:#fff3cd;border:2px solid #ffc107;padding:.5rem;margin-bottom:.5rem;border-radius:3px;text-align:center"><div style="font-weight:900;font-size:.7rem;color:#856404">${L.pacemaker}</div></div>`:''}

          <!-- Allergies -->
          ${d.allergies?`<div style="background:#f8d7da;border:2px solid #cc0000;padding:.5rem;margin-bottom:.5rem;border-radius:3px"><div style="font-size:.42rem;font-weight:900;color:#cc0000;margin-bottom:.2rem">${L.allergy}</div><div style="font-size:.65rem;font-weight:bold;color:#721c24">${d.allergies}</div></div>`:''}

          <!-- Antécédents -->
          ${d.conditions?`<div style="margin-bottom:.5rem"><div style="font-size:.42rem;color:#666;text-transform:uppercase;margin-bottom:.2rem">${L.conditions}</div><div style="font-size:.6rem">${d.conditions}</div></div>`:''}

          <!-- Traitements -->
          ${d.treatments?`<div style="margin-bottom:.5rem"><div style="font-size:.42rem;color:#666;text-transform:uppercase;margin-bottom:.2rem">${L.treatments}</div><div style="font-size:.6rem">${d.treatments}</div></div>`:''}

          <!-- Contact urgence -->
          ${d.emergencyContact?`
          <div style="background:#e8f4f8;border:1px solid #1B4F8A;padding:.5rem;margin-bottom:.5rem;border-radius:3px">
            <div style="font-size:.42rem;color:#1B4F8A;text-transform:uppercase;margin-bottom:.2rem">${L.contact}</div>
            <div style="font-size:.65rem;font-weight:bold">${d.emergencyContact}</div>
            ${d.emergencyPhone?`<a href="tel:${d.emergencyPhone}" style="font-size:.65rem;color:#1B4F8A;font-weight:bold">${d.emergencyPhone}</a>`:''}
          </div>`:''}

          <!-- Info complémentaire -->
          ${d.additionalInfo?`<div style="font-size:.55rem;color:#444;margin-bottom:.5rem;padding:.4rem;background:#f8f9fa;border-radius:3px">${d.additionalInfo}</div>`:''}

          <!-- Boutons -->
          <div style="display:flex;gap:.4rem;margin-top:.6rem">
            <a href="tel:112" style="flex:2;padding:.7rem;background:#cc0000;color:#fff;text-decoration:none;text-align:center;font-weight:bold;font-size:.6rem;border-radius:3px">${L.call}</a>
            <button onclick="document.getElementById('emergency-card').remove()" style="flex:1;padding:.7rem;background:#eee;color:#333;border:none;font-size:.6rem;cursor:pointer;border-radius:3px">${L.close}</button>
          </div>
        </div>

        <div style="background:#f8f9fa;padding:.4rem;text-align:center;font-size:.38rem;color:#999">
          Or Eille AI — © Madame Or Eille Studios
        </div>
      </div>`;
    document.body.appendChild(modal);
  },

  // ─── Alerte SOS automatique ───────────────────
  async sendSOS() {
    const d = this.get();
    let position = null;
    try {
      position = await new Promise((res, rej) => {
        navigator.geolocation.getCurrentPosition(res, rej, { timeout: 5000 });
      });
    } catch {}

    const posText = position
      ? `Dernière position GPS : https://maps.google.com/?q=${position.coords.latitude},${position.coords.longitude}`
      : 'Position GPS non disponible';

    const message = `🚨 ALERTE SOS — Or Eille AI
      
${d.name || 'Personne'} a déclenché une alerte d'urgence.

${posText}

FICHE MÉDICALE :
${d.bloodType ? '🩸 Groupe sanguin : ' + d.bloodType : ''}
${d.allergies ? '⚠ Allergies : ' + d.allergies : ''}
${d.conditions ? '📋 Antécédents : ' + d.conditions : ''}
${d.treatments ? '💊 Traitements : ' + d.treatments : ''}
${d.pacemaker ? '⚡ PACEMAKER' : ''}
${d.pregnant ? '🤰 Enceinte ' + (d.pregnancyWeeks || '') : ''}

Médecin : ${d.doctor || 'Non renseigné'} ${d.doctorPhone || ''}

Envoyé par Or Eille AI — Madame Or Eille Studios`;

    // Ouvrir WhatsApp avec le message pré-rempli si contact disponible
    if (d.emergencyPhone) {
      const waUrl = `https://wa.me/${d.emergencyPhone.replace(/\D/g,'')}?text=${encodeURIComponent(message)}`;
      window.open(waUrl, '_blank');
    }

    // Copier dans le presse-papier
    navigator.clipboard?.writeText(message).catch(() => {});

    if (window.addChatMsg) addChatMsg('assistant', '🚨 Message SOS préparé et copié. Envoyez-le à vos contacts de confiance. Appelez le 15 ou le 112.');
  },

  // ─── Détection créatif isolé ──────────────────
  checkCreatorWellbeing(sessionHours, negativeKeywords) {
    if (sessionHours >= 6) {
      if (window.addChatMsg) addChatMsg('assistant', `Vous travaillez depuis ${Math.round(sessionHours)} heures. Avez-vous mangé ? Avez-vous vu la lumière du jour aujourd'hui ?\n\nVotre création a de la valeur. Et vous aussi — en dehors d'elle.\n\nSi vous avez besoin d'une vraie écoute — Madame Or Eille est là. Pas un outil. Une personne. Qui écoute vraiment.\n👉 ${window.CFG?.MADAME_OR_EILLE_URL || 'madame-or-eille.com'}`);
    }
    if (negativeKeywords >= 3) {
      if (window.addChatMsg) addChatMsg('assistant', `Je remarque que vous traversez un moment difficile. C'est normal — créer c'est aussi douter.\n\nVos mots ont de la valeur. Votre travail a de la valeur. Vous avez de la valeur.\n\nSi vous avez besoin d'une vraie présence humaine — Madame Or Eille est là pour vous écouter.\n👉 ${window.CFG?.MADAME_OR_EILLE_URL || 'madame-or-eille.com'}`);
    }
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <!-- Message Madame Or Eille -->
      <div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.4);padding:1rem;position:relative;overflow:hidden">
        <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>
        <div style="position:relative;z-index:1">
          <p style="font-size:.56rem;color:rgba(240,232,216,.85);line-height:1.8;margin-bottom:.5rem">
            Or Eille AI est un outil. Pour une vraie présence humaine, une vraie écoute — <strong style="color:#C4993A">Madame Or Eille est là</strong>. Vos vies ont de la valeur. Vous méritez d'être entendu(e).
          </p>
          <a href="${window.CFG?.MADAME_OR_EILLE_URL||'#'}" target="_blank" style="font-size:.52rem;color:#C4993A;text-decoration:none;border:1px solid rgba(196,153,58,.4);padding:.3rem .6rem;display:inline-block">Prendre rendez-vous →</a>
          <p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.5rem;font-style:italic">— Madame Or Eille Studios</p>
        </div>
      </div>

      <div class="sec-title">🏥 Fiche médicale d'urgence</div>
      <p class="note">4 tapes rapides sur l'écran — même téléphone verrouillé — affiche votre fiche au secouriste dans sa langue.</p>

      <div style="display:flex;gap:.4rem">
        <button class="btn btn-gold" style="flex:1" onclick="HEALTH.showEmergencyCard()">👁 Prévisualiser ma fiche</button>
        <button class="btn btn-ghost" style="flex:1;border-color:#ef5350;color:#ef5350" onclick="HEALTH.sendSOS()">🚨 SOS</button>
      </div>

      <input type="text" id="h-name" placeholder="Prénom et nom" value="${d.name}" onchange="HEALTH.field('name',this.value)"/>
      <div style="display:flex;gap:.4rem">
        <input type="number" id="h-age" placeholder="Âge" value="${d.age}" style="flex:1" onchange="HEALTH.field('age',this.value)"/>
        <select id="h-blood" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.58rem;padding:.45rem;outline:none" onchange="HEALTH.field('bloodType',this.value)">
          <option value="">Groupe sanguin</option>
          ${['A+','A-','B+','B-','AB+','AB-','O+','O-'].map(g=>`<option value="${g}" ${d.bloodType===g?'selected':''}>${g}</option>`).join('')}
        </select>
      </div>

      <textarea id="h-allergies" placeholder="Allergies — médicaments, aliments, latex..." style="min-height:60px" onchange="HEALTH.field('allergies',this.value)">${d.allergies}</textarea>
      <textarea id="h-conditions" placeholder="Antécédents — diabète, épilepsie, AVC, cardiaque..." style="min-height:60px" onchange="HEALTH.field('conditions',this.value)">${d.conditions}</textarea>
      <textarea id="h-treatments" placeholder="Traitements en cours..." style="min-height:50px" onchange="HEALTH.field('treatments',this.value)">${d.treatments}</textarea>

      <div style="display:flex;gap:.8rem;align-items:center">
        <label style="display:flex;align-items:center;gap:.4rem;font-size:.56rem;color:var(--muted);cursor:pointer">
          <input type="checkbox" ${d.pacemaker?'checked':''} onchange="HEALTH.field('pacemaker',this.checked)" style="accent-color:var(--gold)"/>
          ⚡ Pacemaker
        </label>
        <label style="display:flex;align-items:center;gap:.4rem;font-size:.56rem;color:var(--muted);cursor:pointer">
          <input type="checkbox" ${d.pregnant?'checked':''} onchange="HEALTH.field('pregnant',this.checked);document.getElementById('h-preg-weeks').style.display=this.checked?'block':'none'" style="accent-color:var(--gold)"/>
          🤰 Enceinte
        </label>
      </div>
      <input type="number" id="h-preg-weeks" placeholder="Semaines de grossesse" value="${d.pregnancyWeeks}" style="display:${d.pregnant?'block':'none'}" onchange="HEALTH.field('pregnancyWeeks',this.value)"/>

      <div class="sep"></div>
      <div class="sec-title">Contact d'urgence</div>
      <input type="text" placeholder="Prénom et nom" value="${d.emergencyContact}" onchange="HEALTH.field('emergencyContact',this.value)"/>
      <input type="tel" placeholder="Téléphone (WhatsApp si possible)" value="${d.emergencyPhone}" onchange="HEALTH.field('emergencyPhone',this.value)"/>

      <div class="sec-title">Médecin traitant</div>
      <input type="text" placeholder="Dr. Nom" value="${d.doctor}" onchange="HEALTH.field('doctor',this.value)"/>
      <input type="tel" placeholder="Téléphone" value="${d.doctorPhone}" onchange="HEALTH.field('doctorPhone',this.value)"/>

      <textarea placeholder="Informations complémentaires..." style="min-height:50px" onchange="HEALTH.field('additionalInfo',this.value)">${d.additionalInfo}</textarea>

      <button class="btn btn-gold" onclick="if(window.addChatMsg)addChatMsg('assistant','✅ Fiche médicale sauvegardée. 4 tapes rapides sur l\'écran pour l\'afficher en cas d\'urgence.')">✅ Sauvegarder la fiche</button>

      <div style="font-size:.48rem;color:var(--muted);line-height:1.7;padding:.5rem;border:1px solid var(--border)">
        🔒 Vos données médicales sont chiffrées sur votre appareil. Elles ne sont jamais envoyées ni vendues.<br/>
        En cas d'urgence — 15 (SAMU), 17 (Police), 18 (Pompiers), 112 (Europe), 911 (Amérique du Nord).
      </div>
    </div>`;
  },

  field(key, val) {
    const d = this.get();
    d[key] = val;
    this.save(d);
  }
};

window.HEALTH = HEALTH;
window.addEventListener('load', () => setTimeout(() => HEALTH.initTapDetection(), 2000));
