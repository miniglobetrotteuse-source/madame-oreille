// ═══════════════════════════════════════════════════
//  DÉTECTION TENDANCES — Or Eille AI v1.0
//  Voir venir les tendances avant tout le monde
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const TRENDS = {
  KEY: 'moe_trends',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { alerts: [], lastCheck: null }; }
    catch { return { alerts: [], lastCheck: null }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async detect(niche, region, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant', 'Cle API requise.'); return; }
    if (window.addChatMsg) addChatMsg('assistant', 'Detection des tendances emergentes pour "' + (niche||'creatif') + '"...');

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 1200,
          tools: [{ type: 'web_search_20250305', name: 'web_search' }],
          messages: [{
            role: 'user',
            content: 'Recherche les tendances emergentes sur les reseaux sociaux pour la niche "' + (niche||'contenu creatif') + '" en ' + (region||'France et Afrique francophone') + '.\n\nIdentifie :\n1. Les tendances qui commencent a emerger maintenant — avant qu elles explosent\n2. Les formats qui montent en ce moment\n3. Les sujets dont tout le monde va parler dans 2-3 semaines\n4. Les hashtags en croissance\n5. Une action concrete a faire cette semaine pour surfer sur ces tendances\n\nSois precis et actionnable.'
          }]
        })
      });
      const data = await r.json();
      const result = data.content.map(function(c) { return c.text || ''; }).filter(Boolean).join('\n');
      const d = this.get();
      d.alerts.unshift({ niche, region, result, at: new Date().toISOString() });
      d.alerts = d.alerts.slice(0, 20);
      d.lastCheck = new Date().toISOString();
      this.save(d);
      if (window.addChatMsg) addChatMsg('assistant', result);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant', 'Erreur. Verifiez votre connexion.'); }
  },

  renderPanel: function() {
    const d = this.get();
    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🎯 Tendances emergentes</div>' +
      '<p class="note">Voir venir les tendances 2-3 semaines avant tout le monde. Etre la premiere — pas la derniere.</p>' +
      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">Or Eille AI scanne le web et detecte ce qui commence a emerger maintenant. Avant que ca explose. Avant que tout le monde le fasse.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +
      (d.lastCheck ? '<div style="font-size:.46rem;color:var(--muted)">Derniere detection : ' + new Date(d.lastCheck).toLocaleString('fr-FR') + '</div>' : '') +
      '<input type="text" id="tr-niche" placeholder="Votre niche — ex: beaute afro, cuisine senegalaise, fitness..."/>' +
      '<input type="text" id="tr-region" placeholder="Region — ex: France, Afrique francophone, Belgique..."/>' +
      '<button class="btn btn-gold" onclick="TRENDS.detect(document.getElementById(\'tr-niche\').value,document.getElementById(\'tr-region\').value,window.CFG&&window.CFG.CLAUDE_KEY)">🎯 Detecter les tendances emergentes maintenant</button>' +
      (d.alerts.length > 0 ? '<div class="sec-title">Detections recentes</div>' + d.alerts.slice(0,3).map(function(a) { return '<div style="padding:.5rem;border:1px solid var(--border);margin-bottom:.3rem"><div style="font-size:.54rem;color:var(--text)">' + (a.niche||'General') + '</div><div style="font-size:.46rem;color:var(--muted)">' + new Date(a.at).toLocaleDateString('fr-FR') + '</div></div>'; }).join('') : '') +
    '</div>';
  }
};

window.TRENDS = TRENDS;
