// ═══════════════════════════════════════════════════
//  ÉVÉNEMENTS & DÉCORATIONS — Or Eille AI v1.0
//  Photo de ta pièce · Or Eille AI propose
//  Toutes les cultures · tous les budgets
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const EVENTS_DECO = {
  KEY: 'moe_events',

  EVENTS: {
    halloween:    { label:'Halloween',          icon:'🎃' },
    noel:         { label:'Noël',               icon:'🎄' },
    aid:          { label:'Aïd',                icon:'🌙' },
    anniversaire: { label:'Anniversaire',       icon:'🎂' },
    noel_congo:   { label:'Noël congolais',     icon:'🌍' },
    kwanzaa:      { label:'Kwanzaa',            icon:'🕯' },
    diwali:       { label:'Diwali',             icon:'🪔' },
    tamkharit:    { label:'Tamkharit',          icon:'🌙' },
    paques:       { label:'Pâques',             icon:'🐣' },
    saint_valentin:{ label:'Saint-Valentin',   icon:'💝' },
    carnaval:     { label:'Carnaval',           icon:'🎭' },
    hanoukka:     { label:'Hanoukka',          icon:'✡' },
  },

  BUDGETS: {
    zero:   'Avec ce que j ai déjà — zéro euro',
    petit:  'Petit budget — moins de 10€',
    moyen:  'Budget moyen — moins de 30€',
    libre:  'Pas de contrainte',
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { event:'halloween', budget:'petit' }; }
    catch { return { event:'halloween', budget:'petit' }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async getIdeas(imageData, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const d = this.get();
    const ev = this.EVENTS[d.event] || { label:d.event };
    const budget = this.BUDGETS[d.budget] || '';
    if (window.addChatMsg) addChatMsg('assistant','Ideas deco pour ' + ev.label + '...');
    try {
      const content = imageData ? [
        { type:'image', source:{ type:'base64', media_type:'image/jpeg', data:imageData } },
        { type:'text', text:'Voici ma piece ou ma table. Propose des idees de decoration DIY pour ' + ev.label + ' avec ce que je vois et ce que j ai probablement chez moi. Budget : ' + budget + '. Etapes simples et concretes. Inspirant.' }
      ] : [
        { type:'text', text:'Propose 5 idees de decoration DIY pour ' + ev.label + '. Budget : ' + budget + '. Avec des objets du quotidien. Etapes claires. Pas besoin d acheter des choses specifiques.' }
      ];

      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({ model:'claude-sonnet-4-20250514', max_tokens:600, messages:[{ role:'user', content }] })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  startWithPhoto: function() {
    var f = document.getElementById('event-room-photo');
    if (!f || !f.files[0]) {
      EVENTS_DECO.getIdeas(null, window.CFG && window.CFG.CLAUDE_KEY);
      return;
    }
    var reader = new FileReader();
    reader.onload = function(e) {
      EVENTS_DECO.getIdeas(e.target.result.split(',')[1], window.CFG && window.CFG.CLAUDE_KEY);
    };
    reader.readAsDataURL(f.files[0]);
  },

  renderPanel: function() {
    const d = this.get();
    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🎃 Événements & Décorations</div>' +
      '<p class="note">Tu prends une photo de ta pièce — Or Eille AI te propose comment la transformer pour l occasion. Avec ce que tu as.</p>' +

      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
        Object.entries(this.EVENTS).map(function(e) {
          var sel = d.event === e[0];
          return '<button onclick="var d2=EVENTS_DECO.get();d2.event=\'' + e[0] + '\';EVENTS_DECO.save(d2);document.getElementById(\'eventsDecoContent\').innerHTML=EVENTS_DECO.renderPanel()" style="padding:.3rem .5rem;background:' + (sel?'rgba(196,153,58,.15)':'var(--dark-mid)') + ';border:1px solid ' + (sel?'var(--gold)':'var(--border)') + ';color:' + (sel?'var(--gold)':'var(--muted)') + ';font-family:Josefin Sans,sans-serif;font-size:.48rem;cursor:pointer">' + e[1].icon + ' ' + e[1].label + '</button>';
        }).join('') +
      '</div>' +

      '<div><span class="klabel">Budget</span>' +
      '<select id="ev-budget" onchange="var d2=EVENTS_DECO.get();d2.budget=this.value;EVENTS_DECO.save(d2)" style="width:100%;margin-top:.3rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
        Object.entries(this.BUDGETS).map(function(e){return '<option value="'+e[0]+'" '+(d.budget===e[0]?'selected':'')+'>'+e[1]+'</option>';}).join('') +
      '</select></div>' +

      '<div class="sec-title">📸 Photo de ma pièce (optionnel)</div>' +
      '<p class="note">Si tu envoies une photo — Or Eille AI voit ce que tu as et adapte ses idées. Sinon il propose des idées générales.</p>' +
      '<input type="file" accept="image/*" id="event-room-photo" style="font-size:.5rem;color:var(--muted)"/>' +

      '<button class="btn btn-gold" onclick="EVENTS_DECO.startWithPhoto()">' +
        (this.EVENTS[d.event]?this.EVENTS[d.event].icon:'🎉') + ' Idées déco pour ' + (this.EVENTS[d.event]?this.EVENTS[d.event].label:'') +
      '</button>' +

    '</div>';
  }
};

window.EVENTS_DECO = EVENTS_DECO;
