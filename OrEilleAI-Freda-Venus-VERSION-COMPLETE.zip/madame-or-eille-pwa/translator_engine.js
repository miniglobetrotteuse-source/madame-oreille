// ═══════════════════════════════════════════════════
//  MOTEUR DE TRADUCTION UNIVERSEL — Or Eille AI
//  Masakhane (langues africaines) + Azure (100+ langues)
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const TRANSLATOR_ENGINE = {

  CACHE_KEY: 'moe_trans_engine',

  // ─── Langues Masakhane (africaines) ───────────
  MASAKHANE_LANGS: ['ln','wo','bm','sw','yo','ha','am','ig','tzm','gcf','mq','zu','lg','ff'],

  // ─── Langues Azure Translator ─────────────────
  // Clé configurée dans Paramètres → Clés API
  AZURE_ENDPOINT: 'https://api.cognitive.microsofttranslator.com/translate',

  // ─── Toutes les langues disponibles ───────────
  ALL_LANGUAGES: {
    // Certifiées
    'fr': '🇫🇷 Français', 'en': '🇬🇧 English', 'ar': '🇸🇦 العربية',
    // Masakhane — africaines
    'ln': '🇨🇩🇨🇬 Lingala', 'wo': '🇸🇳 Wolof', 'bm': '🇲🇱 Bambara',
    'sw': '🇰🇪🇹🇿 Swahili', 'yo': '🇳🇬 Yoruba', 'ha': '🇳🇬 Haoussa',
    'am': '🇪🇹 Amharique', 'ig': '🇳🇬 Igbo', 'tzm': '🇩🇿🇲🇦 Tamazight',
    'gcf': '🇬🇵 Kréyòl Gwadloup', 'mq': '🇲🇶 Kréyòl Matinik',
    'zu': '🇿🇦 Zulu', 'ff': '🌍 Peul/Fulfulde', 'lg': '🇺🇬 Luganda',
    // Azure — monde
    'es': '🇪🇸 Español', 'pt': '🇧🇷 Português', 'de': '🇩🇪 Deutsch',
    'it': '🇮🇹 Italiano', 'ru': '🇷🇺 Русский', 'zh': '🇨🇳 中文',
    'ja': '🇯🇵 日本語', 'ko': '🇰🇷 한국어', 'hi': '🇮🇳 हिंदी',
    'tr': '🇹🇷 Türkçe', 'vi': '🇻🇳 Tiếng Việt', 'th': '🇹🇭 ภาษาไทย',
    'fa': '🇮🇷 فارسی', 'ur': '🇵🇰 اردو', 'bn': '🇧🇩 বাংলা',
    'id': '🇮🇩 Bahasa Indonesia', 'ms': '🇲🇾 Bahasa Melayu',
    'nl': '🇳🇱 Nederlands', 'pl': '🇵🇱 Polski', 'uk': '🇺🇦 Українська',
    'ro': '🇷🇴 Română', 'el': '🇬🇷 Ελληνικά', 'cs': '🇨🇿 Čeština',
    'hu': '🇭🇺 Magyar', 'sv': '🇸🇪 Svenska', 'da': '🇩🇰 Dansk',
    'fi': '🇫🇮 Suomi', 'no': '🇳🇴 Norsk', 'he': '🇮🇱 עברית',
    'ta': '🇮🇳 தமிழ்', 'te': '🇮🇳 తెలుగు', 'ml': '🇮🇳 മലയാളം',
    'so': '🇸🇴 Soomaali', 'tl': '🇵🇭 Filipino', 'sk': '🇸🇰 Slovenčina',
  },

  getCache() {
    try { return JSON.parse(localStorage.getItem(this.CACHE_KEY)) || {}; }
    catch { return {}; }
  },

  saveCache(cache) {
    try { localStorage.setItem(this.CACHE_KEY, JSON.stringify(cache)); }
    catch {}
  },

  // ─── Traduire un texte dans la bonne langue ───
  async translate(text, targetLang, sourceLang = 'fr') {
    if (targetLang === sourceLang) return text;

    const cacheKey = `${sourceLang}:${targetLang}:${text.trim().slice(0,50)}`;
    const cache = this.getCache();
    if (cache[cacheKey]) return cache[cacheKey];

    let result = null;

    // Masakhane pour les langues africaines
    if (this.MASAKHANE_LANGS.includes(targetLang) && window.MASAKHANE) {
      const r = await MASAKHANE.translate(text, targetLang, sourceLang);
      if (r) result = r.text;
    }

    // Azure pour les autres langues
    if (!result) {
      const azureKey = window.CFG?.AZURE_TRANSLATE_KEY || window.getKey?.('azureTranslateKey');
      if (azureKey) {
        try {
          const r = await fetch(`${this.AZURE_ENDPOINT}?api-version=3.0&to=${targetLang}`, {
            method: 'POST',
            headers: {
              'Ocp-Apim-Subscription-Key': azureKey,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify([{ text }])
          });
          if (r.ok) {
            const data = await r.json();
            result = data[0]?.translations?.[0]?.text || null;
          }
        } catch(e) {
          console.warn('Azure Translator:', e.message);
        }
      }
    }

    if (result) {
      cache[cacheKey] = result;
      this.saveCache(cache);
    }

    return result || text; // Fallback texte original
  },

  // ─── Traduire toute l'interface ───────────────
  async translateInterface(targetLang) {
    if (['fr','en','ar'].includes(targetLang)) return; // Déjà certifiées
    if (!window.I18N?.fr) return;

    const results = {};
    const entries = Object.entries(window.I18N.fr);

    for (const [key, value] of entries) {
      if (typeof value !== 'string' || value.length < 2) continue;
      const translated = await this.translate(value, targetLang, 'fr');
      if (translated && translated !== value) results[key] = translated;
    }

    if (Object.keys(results).length > 5) {
      window.I18N[targetLang] = { ...(window.I18N[targetLang] || {}), ...results };
    }
  },

  // ─── Rendu du sélecteur de langue complet ─────
  renderFullLanguageSelector() {
    const certified = ['fr','en','ar'];
    const pending = Object.keys(this.ALL_LANGUAGES).filter(l => !certified.includes(l));

    return `
    <select onchange="TRANSLATOR_ENGINE.switchLanguage(this.value)"
      style="background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.55rem;padding:.4rem;outline:none;width:100%">
      <optgroup label="✅ Certifiées">
        ${certified.map(l => `<option value="${l}">${this.ALL_LANGUAGES[l]}</option>`).join('')}
      </optgroup>
      <optgroup label="⏳ En cours de validation (Masakhane)">
        ${this.MASAKHANE_LANGS.map(l => this.ALL_LANGUAGES[l] ? `<option value="${l}">${this.ALL_LANGUAGES[l]}</option>` : '').join('')}
      </optgroup>
      <optgroup label="🌍 Autres langues (Azure)">
        ${pending.filter(l => !this.MASAKHANE_LANGS.includes(l)).map(l => 
          `<option value="${l}">${this.ALL_LANGUAGES[l]}</option>`
        ).join('')}
      </optgroup>
    </select>`;
  },

  async switchLanguage(lang) {
    // Changer la langue dans l'app
    if (window.changeLang) changeLang(lang);
    // Traduire l'interface si nécessaire
    if (!['fr','en','ar'].includes(lang)) {
      await this.translateInterface(lang);
      if (window.setLang) setLang(lang);
    }
  },
};

window.TRANSLATOR_ENGINE = TRANSLATOR_ENGINE;
