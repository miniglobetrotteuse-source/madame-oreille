// ═══════════════════════════════════════════════════
//  FICHES PARENTS — Or Eille AI v1.0
//  Accompagner sans projeter · sans juger
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const PARENT_GUIDES = {
  KEY: 'moe_parent_guides',

  SITUATIONS: {
    comparison:   'Je compare mes enfants entre eux ou aux autres',
    colorisme:    'Je fais du colorisme avec mes enfants',
    competition:  'Je mets mes enfants en compétition',
    preference:   'J ai une préférence entre mes enfants',
    projection:   'Je projette mes rêves sur mon enfant',
    punition:     'Je punis corporellement',
    pipi_lit:     'Mon enfant fait pipi au lit',
    mange_pas:    'Mon enfant ne mange pas',
    colere:       'Mon enfant est en colère souvent',
    timide:       'Mon enfant est très timide',
    mensonge:     'Mon enfant ment',
    ecole:        'Mon enfant refuse l école',
    divorce:      'Je vis une séparation — comment protéger mon enfant',
    recomposee:   'Famille recomposée — comment gérer',
    seul:         'Je suis parent seul — comment tenir',
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { situation:'', sessions:0 }; }
    catch { return { situation:'', sessions:0 }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async getGuide(situation, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const label = this.SITUATIONS[situation] || situation;
    if (window.addChatMsg) addChatMsg('assistant','Fiche parent — ' + label + '...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:600,
          messages:[{ role:'user', content:
            'Fiche bienveillante pour un parent qui dit : "' + label + '".\n\n' +
            'Structure :\n' +
            '1. Ce que l enfant ressent dans cette situation — sans culpabiliser le parent\n' +
            '2. Pourquoi ca arrive — souvent transmis inconsciemment, pas par mauvaise volonte\n' +
            '3. Une chose concrete a essayer des aujourd hui — simple et realiste\n' +
            '4. Un mot d encouragement — tu fais de ton mieux avec ce que tu as recu\n\n' +
            'Jamais de jugement. Jamais de lecon de morale. Bienveillant et concret.\n' +
            'Le parent qui lit ca a deja fait un grand pas en le reconnaissant.'
          }]
        })
      });
      const data = await r.json();
      const d = this.get();
      d.sessions++;
      this.save(d);
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  renderPanel: function() {
    const situations = this.SITUATIONS;
    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">👨‍👩‍👧 Fiches parents</div>' +
      '<p class="note">Sans jugement. Sans leçon de morale. Juste — voilà ce qui peut aider. Tu fais de ton mieux.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem">' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">Reconnaître une situation difficile c est déjà un grand pas. Or Eille AI est là pour accompagner — pas pour juger.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;font-style:italic">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div style="display:flex;flex-direction:column;gap:.3rem">' +
        Object.entries(situations).map(function(e) {
          return '<button onclick="PARENT_GUIDES.getGuide(\'' + e[0] + '\',window.CFG&&window.CFG.CLAUDE_KEY)" style="padding:.6rem .8rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:Josefin Sans,sans-serif;font-size:.5rem;cursor:pointer;text-align:left">' + e[1] + '</button>';
        }).join('') +
      '</div>' +

      '<div class="sep"></div>' +
      '<input type="text" id="parent-custom" placeholder="Autre situation — décris en quelques mots..."/>' +
      '<button class="btn btn-ghost" onclick="var v=document.getElementById(\'parent-custom\').value;if(v)PARENT_GUIDES.getGuide(v,window.CFG&&window.CFG.CLAUDE_KEY)">→ Fiche pour ma situation</button>' +

    '</div>';
  }
};

window.PARENT_GUIDES = PARENT_GUIDES;
