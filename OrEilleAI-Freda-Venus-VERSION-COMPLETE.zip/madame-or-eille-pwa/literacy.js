// ═══════════════════════════════════════════════════
//  APPRENDRE À LIRE — Or Eille AI v1.0
//  Par ce qu'on aime · adapté à la culture locale
//  Sans étiquette · sans honte · à son rythme
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const LITERACY = {
  KEY: 'moe_literacy',

  DOMAINS: {
    sport:    { label:'Sport',        icon:'⚽', desc:'joueurs, equipes, scores locaux' },
    cuisine:  { label:'Cuisine',      icon:'🍳', desc:'recettes, ingredients du marche local' },
    musique:  { label:'Musique',      icon:'🎵', desc:'artistes locaux, paroles connues' },
    famille:  { label:'Famille',      icon:'👨‍👩‍👧', desc:'prenoms, mots du quotidien familial' },
    travail:  { label:'Mon metier',   icon:'🔧', desc:'outils, mots du metier, panneaux' },
    foi:      { label:'Foi & priere', icon:'🙏', desc:'textes et prieres deja connus a l oral' },
    marche:   { label:'Le marche',    icon:'🛒', desc:'produits, prix, enseignes du quartier' },
    nature:   { label:'Nature',       icon:'🌿', desc:'plantes, animaux, paysages locaux' },
  },

  LEVELS: {
    lettres:  'Je reconnais les lettres',
    syllabes: 'Je commence a assembler les syllabes',
    mots:     'Je lis des mots simples',
    phrases:  'Je lis des phrases courtes',
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      domain:'sport', level:'lettres', culture:'', country:'', sessions:0
    }; }
    catch { return { domain:'sport', level:'lettres', culture:'', country:'', sessions:0 }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async getLesson(claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const d = this.get();
    const domain = this.DOMAINS[d.domain];
    const level = this.LEVELS[d.level];
    const culture = d.culture || 'francophone';
    const country = d.country || '';

    if (window.addChatMsg) addChatMsg('assistant','Preparation de ta lecon de lecture...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:600,
          messages:[{ role:'user', content:
            'Cree un exercice de lecture de 5 minutes pour quelqu un qui est au niveau : ' + level + '.\n' +
            'Domaine qui l interesse : ' + domain.label + ' — ' + domain.desc + '.\n' +
            'Culture et contexte local : ' + culture + (country ? ', ' + country : '') + '.\n\n' +
            'IMPORTANT : utilise des references locales et culturelles — pas des stars internationales si ce n est pas dans son contexte. Des noms locaux, des mots du quotidien de sa region, des references qui lui parlent vraiment.\n\n' +
            'Format : lettres ou mots simples presents clairement. Exercice progressif. Bienveillant. Jamais de mention qu on apprend a lire — on travaille juste sur ce qu il aime.\n' +
            'Termine par un encouragement chaleureux.'
          }]
        })
      });
      const data = await r.json();
      d.sessions++;
      this.save(d);
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
      var self = this; setTimeout(function(){ self.celebrate(d.culture, d.sessions); }, 1000);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  nextLevel() {
    const d = this.get();
    const levels = Object.keys(this.LEVELS);
    const idx = levels.indexOf(d.level);
    if (idx < levels.length - 1) {
      d.level = levels[idx + 1];
      this.save(d);
      if (window.addChatMsg) addChatMsg('assistant','Bravo ! Tu passes au niveau suivant : ' + this.LEVELS[d.level]);
    } else {
      if (window.addChatMsg) addChatMsg('assistant','Tu as parcouru tous les niveaux. Tu lis maintenant. C est enorme.');
    }
    document.getElementById('literacyContent').innerHTML = LITERACY.renderPanel();
  },

  renderPanel: function() {
    const d = this.get();

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">📖 Apprendre à lire</div>' +
      '<p class="note">Par ce qu on aime. Avec les mots de son monde. A son rythme. Sans honte. Sans étiquette.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem">' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">Lire c est acceder a tout. Aux soins, aux droits, aux opportunites. Ce n est pas trop tard. Ce n est jamais trop tard.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;font-style:italic">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">' +
        '<div><span class="klabel">Ce qui m interesse</span>' +
        '<select id="lit-domain" onchange="const d2=LITERACY.get();d2.domain=this.value;LITERACY.save(d2)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.DOMAINS).map(function(e) { return '<option value="'+e[0]+'" '+(d.domain===e[0]?'selected':'')+'>'+e[1].icon+' '+e[1].label+'</option>'; }).join('') +
        '</select></div>' +

        '<div><span class="klabel">Mon niveau</span>' +
        '<select id="lit-level" onchange="const d2=LITERACY.get();d2.level=this.value;LITERACY.save(d2)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.LEVELS).map(function(e) { return '<option value="'+e[0]+'" '+(d.level===e[0]?'selected':'')+'>'+e[1]+'</option>'; }).join('') +
        '</select></div>' +

        '<div><span class="klabel">Ma culture</span>' +
        '<input type="text" id="lit-culture" value="'+d.culture+'" placeholder="Ex: Malien, Japonais, Breton..." onchange="const d2=LITERACY.get();d2.culture=this.value;LITERACY.save(d2)" style="margin-top:.2rem"/></div>' +

        '<div><span class="klabel">Mon pays ou ma ville</span>' +
        '<input type="text" id="lit-country" value="'+d.country+'" placeholder="Ex: Bamako, Osaka, Dakar..." onchange="const d2=LITERACY.get();d2.country=this.value;LITERACY.save(d2)" style="margin-top:.2rem"/></div>' +
      '</div>' +

      '<button class="btn btn-gold" onclick="LITERACY.getLesson(window.CFG&&window.CFG.CLAUDE_KEY)">📖 Ma lecon du jour — 5 minutes</button>' +

      (d.sessions > 0 ? (
        '<div style="display:flex;justify-content:space-between;align-items:center;padding:.5rem;border:1px solid rgba(196,153,58,.2)">' +
          '<div style="font-size:.5rem;color:var(--muted)">' + d.sessions + ' session(s) completee(s)</div>' +
          '<button onclick="LITERACY.nextLevel()" style="padding:.3rem .6rem;background:var(--gold);border:none;color:var(--dark);font-family:Josefin Sans,sans-serif;font-size:.46rem;cursor:pointer">Je passe au niveau suivant →</button>' +
        '</div>'
      ) : '') +

    '</div>';
  }
};


LITERACY.speak = function(text) {
  if (!window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  var u = new SpeechSynthesisUtterance(text);
  u.lang = 'fr-FR';
  u.rate = 0.85;
  window.speechSynthesis.speak(u);
};

LITERACY.speakWelcome = function() {
  LITERACY.speak('Bienvenue. Choisis ce que tu aimes puis appuie sur le grand bouton.');
};

LITERACY.selectDomain = function(domain, label) {
  var d = LITERACY.get();
  d.domain = domain;
  LITERACY.save(d);
  LITERACY.speak(label);
  document.getElementById('literacyContent').innerHTML = LITERACY.renderVocalPanel();
};

LITERACY.renderVocalPanel = function() {
  var d = this.get();
  var items = [
    { key:'sport',   icon:'⚽', label:'Sport'   },
    { key:'cuisine', icon:'🍳', label:'Cuisine' },
    { key:'musique', icon:'🎵', label:'Musique' },
    { key:'famille', icon:'👨‍👩‍👧', label:'Famille' },
    { key:'travail', icon:'🔧', label:'Metier'  },
    { key:'marche',  icon:'🛒', label:'Marche'  },
  ];

  var html = '<div style="padding:1.5rem;display:flex;flex-direction:column;align-items:center;gap:1rem">';
  html += '<div onclick="LITERACY.speakWelcome()" style="font-size:3rem;cursor:pointer">🔊</div>';
  html += '<div style="font-size:.48rem;color:rgba(240,232,216,.4);text-align:center">Appuie pour ecouter</div>';
  html += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.6rem;width:100%">';

  items.forEach(function(item) {
    var sel = d.domain === item.key;
    var bg = sel ? 'rgba(196,153,58,.2)' : 'var(--dark-mid)';
    var border = sel ? '#C4993A' : 'rgba(255,255,255,.08)';
    html += '<button onclick="LITERACY.selectDomain(&quot;' + item.key + '&quot;,&quot;' + item.label + '&quot;)" ';
    html += 'style="padding:1rem;background:' + bg + ';border:2px solid ' + border + ';cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:.3rem">';
    html += '<span style="font-size:2rem">' + item.icon + '</span>';
    html += '<span style="font-size:.44rem;color:rgba(240,232,216,.5)">' + item.label + '</span>';
    html += '</button>';
  });

  html += '</div>';
  html += '<button onclick="LITERACY.getLesson(window.CFG&&window.CFG.CLAUDE_KEY)" ';
  html += 'style="width:110px;height:110px;border-radius:50%;background:#C4993A;border:none;cursor:pointer;font-size:2.5rem;box-shadow:0 0 25px rgba(196,153,58,.4)">▶</button>';
  html += '<div style="font-size:.48rem;color:rgba(196,153,58,.6)">Appuie pour commencer</div>';
  if (d.sessions > 0) { html += '<div style="font-size:.5rem;color:#81c784">⭐ ' + d.sessions + ' lecon(s) — bravo !</div>'; }
  html += '</div>';
  return html;
};


LITERACY.analyzeWriting = async function(imageData, claudeKey) {
  if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
  var d = this.get();
  if (window.addChatMsg) addChatMsg('assistant','Je regarde ce que tu as ecrit...');
  try {
    var r = await fetch('https://api.anthropic.com/v1/messages', {
      method:'POST',
      headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
      body: JSON.stringify({
        model:'claude-sonnet-4-20250514', max_tokens:500,
        messages:[{ role:'user', content:[
          { type:'image', source:{ type:'base64', media_type:'image/jpeg', data:imageData } },
          { type:'text', text:
            'Regarde ce que cette personne a ecrit — que ce soit sur du papier, du sable, une ardoise, ou n importe quelle surface. ' +
            'Reconnais les lettres ou chiffres. ' +
            'Dis ce qui est bien forme — commence par les compliments. ' +
            'Indique doucement ce qui peut etre ameliore — une seule chose a la fois. ' +
            'Encourage chaleureusement. Jamais de jugement. ' +
            'Si c est illisible — dis que tu devines et demande de reessayer avec ce conseil precis.'
          }
        ]}]
      })
    });
    var data = await r.json();
    if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
  } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
};

LITERACY.startWritingAnalysis = function() {
  var f = document.getElementById('writing-photo');
  if (!f || !f.files[0]) { if (window.addChatMsg) addChatMsg('assistant','Prends une photo de ce que tu as ecrit.'); return; }
  var reader = new FileReader();
  reader.onload = function(e) {
    LITERACY.analyzeWriting(e.target.result.split(',')[1], window.CFG && window.CFG.CLAUDE_KEY);
  };
  reader.readAsDataURL(f.files[0]);
};


LITERACY.CELEBRATIONS = {
  afrique:   ['Bien joué !', 'Tu avances !', 'Continue comme ça !'],
  maghreb:   ['Mabrouk !', 'Tu progresses !', 'Excellent !'],
  europe:    ['Bravo !', 'Super travail !', 'Continue !'],
  asie:      ['Bien fait !', 'Tu y arrives !', 'Courage !'],
  universel: ['Bravo !', 'Tu l as fait !', 'Continue !'],
};

LITERACY.celebrate = function(culture, sessionsCount) {
  const cult = culture || 'universel';
  const msgs = this.CELEBRATIONS[cult] || this.CELEBRATIONS.universel;
  const msg = msgs[Math.floor(Math.random() * msgs.length)];

  var milestones = '';
  if (sessionsCount === 7)  milestones = ' Une semaine complete — tu es constant !';
  if (sessionsCount === 15) milestones = ' Quinze jours — tu lis des choses que tu ne lisais pas avant !';
  if (sessionsCount === 30) milestones = ' Un mois — regarde tout ce chemin parcouru !';

  if (window.addChatMsg) addChatMsg('assistant',
    msg + milestones + (milestones ? ' C est enorme.' : ' Continue comme ca.')
  );
};


window.LITERACY = LITERACY;
