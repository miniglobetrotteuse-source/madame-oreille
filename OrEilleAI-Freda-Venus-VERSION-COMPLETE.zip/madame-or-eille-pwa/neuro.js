// ═══════════════════════════════════════════════════
//  ACCOMPAGNEMENT NEURODIVERGENT
//  Or Eille AI — v1.0
//  TDAH, autisme, dyspraxie, anxiété, phobie sociale
//  Basé sur données scientifiques validées
// ═══════════════════════════════════════════════════

const NEURO = {
  KEY: 'moe_neuro',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      profiles: [], reminders: [], protocols: [], appointments: []
    }; } catch { return { profiles: [], reminders: [], protocols: [], appointments: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Profils neurodivergents ──────────────────
  PROFILES: {
    tdah: {
      label: 'TDAH',
      description: 'Trouble du déficit de l\'attention avec ou sans hyperactivité',
      strategies: [
        'Tâches découpées en micro-étapes de 5-10 minutes maximum',
        'Rappels visuels et sonores fréquents',
        'Pauses toutes les 20-25 minutes (technique Pomodoro adaptée)',
        'Environnement épuré — minimiser les distractions visuelles',
        'Instructions une par une — jamais plusieurs à la fois',
        'Récompenses immédiates après chaque micro-tâche accomplie',
      ],
      beforeOuting: [
        'Préparer mentalement — visualiser le trajet et le lieu',
        'Check-list visuelle simple (3 éléments maximum)',
        'Confirmer l\'heure 2 fois avant de partir',
        'Avoir un plan de sortie si overwhelm',
      ]
    },
    autism: {
      label: 'Autisme / Asperger',
      description: 'Trouble du spectre autistique',
      strategies: [
        'Routine stricte — prévisibilité maximale',
        'Prévenir les changements à l\'avance',
        'Règles sociales explicitées clairement',
        'Stimuli sensoriels réduits si possible',
        'Temps de décompression après interactions sociales',
        'Communication directe — pas de sous-entendus',
      ],
      beforeOuting: [
        'La veille : visualiser le lieu, le trajet, les personnes',
        'Prévoir une sortie de secours si surcharge sensorielle',
        'Choisir la tenue la veille pour réduire la charge cognitive',
        'Avoir des écouteurs pour se couper si besoin',
        'Définir une durée maximale acceptable',
      ]
    },
    anxiety: {
      label: 'Anxiété / Phobie sociale',
      description: 'Trouble anxieux généralisé ou phobie sociale',
      strategies: [
        'Exposition progressive — commencer par de petits défis',
        'Technique 5-4-3-2-1 : 5 choses vues, 4 entendues, 3 touchées, 2 senties, 1 goûtée',
        'Respiration cohérente cardiaque : 5 secondes inspiration, 5 secondes expiration',
        'Reformuler les pensées catastrophistes',
        'Planifier une récompense après chaque sortie réussie',
      ],
      beforeOuting: [
        'La veille : exercice de relaxation (yoga, méditation, musique douce)',
        'Le matin : 10 minutes de cohérence cardiaque',
        'Phrases de ancrage personnel — à définir soi-même',
        'Rappeler : une heure maximum, un seul lieu, retour possible à tout moment',
        'Contact de sécurité disponible pendant la sortie',
      ]
    },
    dyspraxia: {
      label: 'Dyspraxie',
      description: 'Trouble développemental de la coordination',
      strategies: [
        'Instructions très détaillées avec démonstration visuelle',
        'Décomposer chaque geste en étapes élémentaires',
        'Plus de temps pour les tâches physiques — sans pression',
        'Outils adaptés si possible (ouvre-boîte électrique, etc.)',
        'Répétition et pratique — la régularité compense',
      ],
      beforeOuting: [
        'Vêtements sans lacets ou lacets élastiques si possible',
        'Sac organisé la veille avec compartiments fixes',
        'Prévoir plus de temps que nécessaire',
        'Itinéraire simple et connu si possible',
      ]
    },
    social_anxiety: {
      label: 'Anxiété sociale sévère',
      description: 'Difficulté majeure dans les interactions sociales',
      strategies: [
        'Pas de préparation de sac la veille si c\'est source d\'angoisse — faire au moment',
        'Objectif minimal : sortir 5 minutes, pas plus',
        'Aucune pression de performance sociale',
        'Ok de ne pas regarder dans les yeux',
        'Ok de partir sans explication si surcharge',
        'Trouver un professionnel spécialisé TCC (Thérapie Cognitive et Comportementale)',
      ],
      beforeOuting: [
        'Respiration : inspirez 4 temps, bloquez 4 temps, expirez 4 temps (cohérence cardiaque)',
        'Une seule phrase d\'ancrage courte — la répéter mentalement',
        'Rappel : vous n\'avez pas à expliquer votre malaise à qui que ce soit',
        'Contact de confiance joignable pendant la sortie',
        'Permission de rentrer à tout moment sans culpabilité',
      ]
    }
  },

  // ─── Protocole personnalisé ───────────────────
  generateProtocol(profileIds, appointmentDate, appointmentTime) {
    const date = new Date(appointmentDate + 'T' + appointmentTime);
    const dayBefore = new Date(date.getTime() - 24 * 3600000);

    const allStrategies = profileIds.flatMap(id => this.PROFILES[id]?.beforeOuting || []);
    const uniqueStrategies = [...new Set(allStrategies)];

    return {
      appointment: { date: date.toISOString(), label: 'Rendez-vous' },
      dayBefore: { time: '20:00', tasks: uniqueStrategies.slice(0, 4) },
      morning: { time: date.getHours() > 14 ? '10:00' : '08:00', tasks: [
        'Prendre le temps — pas de précipitation',
        'Vérifier votre check-list personnelle',
        'Rappel : vous pouvez partir à tout moment',
      ]},
      twoHoursBefore: { tasks: [
        'Exercice de respiration cohérente cardiaque (5 min)',
        'Relire votre phrase d\'ancrage personnel',
        'Vérifier que votre contact de confiance est disponible',
      ]},
      reminders: [
        { when: dayBefore.toISOString(), msg: 'Demain vous avez votre rendez-vous. Voici votre protocole du soir.' },
        { when: new Date(date.getTime() - 2 * 3600000).toISOString(), msg: 'Dans 2 heures. Commencez votre protocole de préparation.' },
        { when: new Date(date.getTime() - 30 * 60000).toISOString(), msg: 'Dans 30 minutes. Dernière vérification de votre check-list.' },
      ]
    };
  },

  // ─── Rappels comportementaux ──────────────────
  BEHAVIORAL_TIPS: {
    talks_too_much: [
      'Avant de répondre : comptez mentalement 1... 2... 3...',
      'Laissez l\'autre finir sa phrase complètement avant de parler',
      'Si vous avez envie d\'interrompre — notez mentalement l\'idée et attendez',
    ],
    interrupts: [
      'Geste discret : posez la main sur votre genou quand vous avez envie d\'interrompre',
      'L\'idée sera toujours là dans 30 secondes',
    ],
    literal_thinking: [
      'Si quelque chose vous semble ambigu — demandez une clarification directement',
      'Exemple : "Quand tu dis X, tu veux dire Y ?" — c\'est tout à fait acceptable',
    ],
    apologizes_too_much: [
      'Remplacez "désolé d\'être en retard" par "merci d\'avoir attendu"',
      'Vous n\'avez pas à vous excuser de prendre de la place',
    ],
  },

  // ─── Ressources professionnelles ──────────────
  async findProfessional(type, location, claudeKey) {
    if (!claudeKey) return null;
    const queries = {
      tdah: `psychiatre psychologue spécialisé TDAH adulte ${location}`,
      autism: `centre diagnostic autisme adulte CRA ${location}`,
      anxiety: `psychologue TCC thérapie cognitive comportementale anxiété ${location}`,
      general: `psychologue CMP centre médico-psychologique ${location}`,
    };
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 500,
          tools: [{ type: 'web_search_20250305', name: 'web_search' }],
          system: 'Tu cherches des professionnels de santé mentale spécialisés. Tu donnes les coordonnées précises, les tarifs si disponibles, si conventionné, et si possible par email pour ceux qui ont du mal à téléphoner.',
          messages: [{ role: 'user', content: `Trouve 3 professionnels spécialisés pour "${type}" dans ou près de "${location}". Priorité aux praticiens conventionnés secteur 1 et à ceux acceptant les contacts par email.` }]
        })
      });
      const d = await r.json();
      return d.content.filter(b => b.type === 'text').map(b => b.text).join('');
    } catch { return null; }
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    const activeProfiles = d.profiles || [];

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">
      <div class="sec-title">🧠 Mon profil neurodivergent</div>
      <p class="note">Sélectionnez ce qui vous correspond. L'appli s'adapte et vous accompagne avec des stratégies validées scientifiquement.</p>

      ${Object.entries(NEURO.PROFILES).map(([id, p]) => `
        <label style="display:flex;align-items:flex-start;gap:.6rem;padding:.6rem;border:1px solid ${activeProfiles.includes(id)?'var(--gold)':'var(--border)'};cursor:pointer;background:${activeProfiles.includes(id)?'rgba(201,168,76,.08)':'transparent'}">
          <input type="checkbox" ${activeProfiles.includes(id)?'checked':''} onchange="NEURO.toggleProfile('${id}',this.checked)" style="accent-color:var(--gold);margin-top:.2rem"/>
          <div>
            <div style="font-size:.6rem;color:var(--text);margin-bottom:.2rem">${p.label}</div>
            <div style="font-size:.52rem;color:var(--muted)">${p.description}</div>
          </div>
        </label>
      `).join('')}

      ${activeProfiles.length > 0 ? `
        <div class="sep"></div>
        <div class="sec-title">Stratégies pour vous</div>
        ${activeProfiles.flatMap(id => NEURO.PROFILES[id]?.strategies || []).slice(0,6).map(s => `
          <div style="padding:.4rem .6rem;border-left:2px solid var(--gold);font-size:.56rem;color:var(--muted);line-height:1.5">• ${s}</div>
        `).join('')}

        <div class="sep"></div>
        <div class="sec-title">Planifier une sortie</div>
        <input type="date" id="neuroDate" style="background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.58rem;padding:.45rem;width:100%;outline:none"/>
        <input type="time" id="neuroTime" style="background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.58rem;padding:.45rem;width:100%;outline:none"/>
        <button class="btn btn-gold" onclick="NEURO.planOuting()">Générer mon protocole de préparation</button>
        <div id="neuroProtocol" style="display:none"></div>
      ` : ''}

      <div class="sep"></div>
      <div class="sec-title">Trouver un professionnel</div>
      <p class="note" style="font-size:.52rem">Pour les situations difficiles, un professionnel spécialisé fait la différence. L'appli cherche pour vous.</p>
      <button class="btn btn-ghost" onclick="NEURO.findPro()">🔍 Trouver un spécialiste près de moi</button>
      <div id="neuroPro" style="display:none;font-size:.56rem;color:var(--muted);line-height:1.7;padding:.6rem;border:1px solid var(--border)"></div>
    </div>`;
  },

  toggleProfile(id, checked) {
    const d = this.get();
    if (!d.profiles) d.profiles = [];
    if (checked) { if (!d.profiles.includes(id)) d.profiles.push(id); }
    else { d.profiles = d.profiles.filter(p => p !== id); }
    this.save(d);
    document.getElementById('neuroContent').innerHTML = this.renderPanel();
    if (checked) {
      const profile = this.PROFILES[id];
      if (window.addChatMsg) addChatMsg('assistant', `Profil "${profile.label}" activé. Voici des stratégies validées pour vous accompagner au quotidien.`);
    }
  },

  planOuting() {
    const date = document.getElementById('neuroDate')?.value;
    const time = document.getElementById('neuroTime')?.value;
    if (!date || !time) { if(window.speak) speak('Indiquez la date et l\'heure de votre sortie.'); return; }
    const d = this.get();
    const protocol = this.generateProtocol(d.profiles || [], date, time);
    const el = document.getElementById('neuroProtocol');
    if (el) {
      el.style.display = 'block';
      el.innerHTML = `
        <div style="border:1px solid var(--gold);padding:.7rem;margin-top:.5rem">
          <div style="font-size:.6rem;color:var(--gold);margin-bottom:.5rem">Votre protocole de préparation</div>
          <div style="font-size:.56rem;color:var(--muted);line-height:1.7">
            <strong style="color:var(--text)">La veille au soir (${protocol.dayBefore.time})</strong><br/>
            ${protocol.dayBefore.tasks.map(t => `• ${t}`).join('<br/>')}
            <br/><br/>
            <strong style="color:var(--text)">Le matin</strong><br/>
            ${protocol.morning.tasks.map(t => `• ${t}`).join('<br/>')}
            <br/><br/>
            <strong style="color:var(--text)">2 heures avant</strong><br/>
            ${protocol.twoHoursBefore.tasks.map(t => `• ${t}`).join('<br/>')}
          </div>
        </div>`;
    }
    if (window.addChatMsg) addChatMsg('assistant', 'Votre protocole de préparation est prêt. Les rappels sont programmés.');
    if (window.speak) speak('Protocole de préparation créé. Vous recevrez des rappels aux moments clés.');
  },

  async findPro() {
    const claudeKey = window.CFG?.CLAUDE_KEY || getKey?.('claudeKey');
    const el = document.getElementById('neuroPro');
    if (el) { el.style.display = 'block'; el.textContent = '🔍 Recherche en cours…'; }
    const d = this.get();
    const type = d.profiles?.[0] || 'general';
    // Utiliser la position approximative
    // Détection automatique de la position
    let location = 'France';
    try {
      if (navigator.geolocation) {
        await new Promise((resolve) => {
          navigator.geolocation.getCurrentPosition(
            async (pos) => {
              const r = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${pos.coords.latitude}&lon=${pos.coords.longitude}&format=json`);
              const d = await r.json();
              location = d.address?.city || d.address?.town || d.address?.country || 'France';
              resolve();
            },
            () => resolve(),
            { timeout: 5000 }
          );
        });
      }
    } catch {}
    const result = await this.findProfessional(type, location, claudeKey);
    if (el) el.innerHTML = result || 'Aucun résultat trouvé. Essayez de contacter votre médecin traitant pour une orientation.';
  }
};

window.NEURO = NEURO;
