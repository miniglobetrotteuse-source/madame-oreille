// ═══════════════════════════════════════════════════
//  MONTAGE INTELLIGENT — Or Eille AI v1.0
//  Analyse + coupe + ordre + instructions CapCut
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const EDITOR = {
  KEY: 'moe_editor',
  _clips: [],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { projects: [] }; }
    catch { return { projects: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  loadClips(files) {
    this._clips = [];
    const self = this;
    Array.from(files).forEach(function(file, i) {
      self._clips.push({
        id: 'clip_' + i,
        index: i + 1,
        name: file.name,
        file: file,
        url: URL.createObjectURL(file),
        size: (file.size / 1024 / 1024).toFixed(1) + ' Mo',
        duration: null,
        bestStart: 2,
        bestEnd: null,
        keep: true,
        cut: false,
        suggestedOrder: i + 1,
      });
    });

    self._clips.forEach(function(clip) {
      const v = document.createElement('video');
      v.src = clip.url;
      v.onloadedmetadata = function() {
        clip.duration = parseFloat(v.duration.toFixed(1));
        clip.bestEnd = parseFloat(Math.max(clip.duration - 1.5, clip.bestStart + 1).toFixed(1));
        document.getElementById('editorContent').innerHTML = EDITOR.renderPanel();
      };
    });

    if (window.addChatMsg) addChatMsg('assistant', self._clips.length + ' prise(s) chargee(s). Or Eille AI suggere les coupes de debut et de fin automatiquement. Lancez l analyse IA pour un ordre de montage suggere.');
    document.getElementById('editorContent').innerHTML = this.renderPanel();
  },

  moveUp(id) {
    const idx = this._clips.findIndex(function(c) { return c.id === id; });
    if (idx > 0) {
      const tmp = this._clips[idx]; this._clips[idx] = this._clips[idx-1]; this._clips[idx-1] = tmp;
      document.getElementById('editorContent').innerHTML = EDITOR.renderPanel();
    }
  },

  moveDown(id) {
    const idx = this._clips.findIndex(function(c) { return c.id === id; });
    if (idx < this._clips.length - 1) {
      const tmp = this._clips[idx]; this._clips[idx] = this._clips[idx+1]; this._clips[idx+1] = tmp;
      document.getElementById('editorContent').innerHTML = EDITOR.renderPanel();
    }
  },

  toggleKeep(id) {
    const c = this._clips.find(function(x) { return x.id === id; });
    if (c) { c.keep = !c.keep; document.getElementById('editorContent').innerHTML = EDITOR.renderPanel(); }
  },

  async cutClip(clipId) {
    const clip = this._clips.find(function(c) { return c.id === clipId; });
    if (!clip) return;

    const startEl = document.getElementById('s_' + clipId);
    const endEl = document.getElementById('e_' + clipId);
    const start = parseFloat(startEl ? startEl.value : clip.bestStart) || 0;
    const end = parseFloat(endEl ? endEl.value : clip.bestEnd) || clip.duration;

    if (window.addChatMsg) addChatMsg('assistant', 'Coupe de la prise ' + clip.index + ' de ' + start + 's a ' + end + 's (' + (end-start).toFixed(1) + 's gardees)...');

    try {
      const video = document.createElement('video');
      video.src = clip.url;
      await new Promise(function(res) { video.onloadedmetadata = res; });

      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      const ctx = canvas.getContext('2d');
      const stream = canvas.captureStream(30);

      if (video.captureStream) {
        video.captureStream().getAudioTracks().forEach(function(t) { stream.addTrack(t); });
      }

      const chunks = [];
      const rec = new MediaRecorder(stream, { mimeType: 'video/webm' });
      rec.ondataavailable = function(e) { if (e.data.size > 0) chunks.push(e.data); };
      rec.onstop = function() {
        const blob = new Blob(chunks, { type: 'video/webm' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'prise' + clip.index + '_coupe.webm';
        a.click();
        clip.cut = true;
        document.getElementById('editorContent').innerHTML = EDITOR.renderPanel();
        if (window.addChatMsg) addChatMsg('assistant', 'Prise ' + clip.index + ' coupee et telechargee.');
      };

      video.currentTime = start;
      await new Promise(function(res) { video.onseeked = res; });
      rec.start();
      video.play();

      const draw = function() {
        if (video.currentTime >= end) { video.pause(); rec.stop(); return; }
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        requestAnimationFrame(draw);
      };
      draw();

    } catch(e) {
      if (window.addChatMsg) addChatMsg('assistant', 'Coupe non supportee ici. Instructions pour CapCut generees ci-dessous.');
      this.generateCapCutInstructions();
    }
  },

  async analyzeWithAI(claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant', 'Cle API requise.'); return; }
    if (this._clips.length === 0) { if (window.addChatMsg) addChatMsg('assistant', 'Chargez des prises.'); return; }

    const info = this._clips.map(function(c) {
      return 'Prise ' + c.index + ' : ' + c.name + (c.duration ? ' — ' + c.duration + 's' : '');
    }).join('\n');

    if (window.addChatMsg) addChatMsg('assistant', 'Analyse IA de vos ' + this._clips.length + ' prises...');

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 800,
          messages: [{
            role: 'user',
            content: 'Voici ' + this._clips.length + ' prises video a monter :\n' + info + '\n\nSugge un ordre de montage logique. Par exemple : commencer par la prise la plus courte et percutante comme accroche, developper avec les prises longues, finir sur une note forte. Donne aussi des conseils de coupe specifiques pour chaque prise (debut a couper, fin a couper). Sois tres concret avec des chiffres en secondes.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant', 'Erreur. Verifiez votre connexion.'); }
  },

  generateCapCutInstructions() {
    const kept = this._clips.filter(function(c) { return c.keep; });
    if (kept.length === 0) { if (window.addChatMsg) addChatMsg('assistant', 'Aucune prise selectionnee.'); return; }

    let instructions = 'INSTRUCTIONS CAPCUT — copiez et suivez :\n\n';
    instructions += 'Dans CapCut — Nouveau projet\n\n';
    kept.forEach(function(c, i) {
      const startEl = document.getElementById('s_' + c.id);
      const endEl = document.getElementById('e_' + c.id);
      const start = parseFloat(startEl ? startEl.value : c.bestStart) || 0;
      const end = parseFloat(endEl ? endEl.value : c.bestEnd) || c.duration;
      instructions += (i+1) + '. Importer "' + c.name + '"\n';
      instructions += '   Couper le debut : ' + start + 's\n';
      instructions += '   Couper la fin a partir de : ' + end + 's\n';
      instructions += '   Duree gardee : ' + (end - start).toFixed(1) + 's\n\n';
    });
    instructions += 'Assembler dans cet ordre. Exporter en 1080p.';

    if (window.addChatMsg) addChatMsg('assistant', instructions);

    const blob = new Blob([instructions], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'instructions_montage.txt';
    a.click();
  },

  renderPanel: function() {
    const self = this;
    let clipsHtml = '';

    if (this._clips.length > 0) {
      this._clips.forEach(function(clip, i) {
        const isFirst = i === 0;
        const isLast = i === self._clips.length - 1;
        clipsHtml +=
          '<div style="border:1px solid ' + (clip.keep ? 'rgba(196,153,58,.4)' : 'var(--border)') + ';background:var(--dark-mid);padding:.6rem;margin-bottom:.4rem">' +
            '<div style="display:flex;align-items:center;gap:.4rem;margin-bottom:.4rem">' +
              '<span style="font-size:.5rem;color:var(--gold);min-width:20px">' + (i+1) + '</span>' +
              '<div style="flex:1">' +
                '<div style="font-size:.52rem;color:var(--text)">' + clip.name + '</div>' +
                '<div style="font-size:.44rem;color:var(--muted)">' + clip.size + (clip.duration ? ' — ' + clip.duration + 's' : '') + (clip.cut ? ' ✅ coupee' : '') + '</div>' +
              '</div>' +
              '<div style="display:flex;gap:.2rem">' +
                (!isFirst ? '<button onclick="EDITOR.moveUp(\'' + clip.id + '\')" style="background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);padding:.2rem .4rem;cursor:pointer;font-size:.6rem">↑</button>' : '') +
                (!isLast ? '<button onclick="EDITOR.moveDown(\'' + clip.id + '\')" style="background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);padding:.2rem .4rem;cursor:pointer;font-size:.6rem">↓</button>' : '') +
                '<button onclick="EDITOR.toggleKeep(\'' + clip.id + '\')" style="background:' + (clip.keep ? 'rgba(196,153,58,.2)' : 'rgba(239,83,80,.1)') + ';border:1px solid ' + (clip.keep ? 'var(--gold)' : '#ef5350') + ';color:' + (clip.keep ? 'var(--gold)' : '#ef5350') + ';padding:.2rem .4rem;cursor:pointer;font-size:.5rem">' + (clip.keep ? 'Garder' : 'Ignorer') + '</button>' +
              '</div>' +
            '</div>' +
            (clip.duration ? (
              '<div style="display:flex;gap:.4rem;align-items:center;margin-bottom:.4rem">' +
                '<span style="font-size:.44rem;color:var(--muted)">De</span>' +
                '<input type="number" id="s_' + clip.id + '" value="' + clip.bestStart + '" min="0" max="' + clip.duration + '" step="0.5" style="width:60px;font-size:.5rem"/>' +
                '<span style="font-size:.44rem;color:var(--muted)">s a</span>' +
                '<input type="number" id="e_' + clip.id + '" value="' + clip.bestEnd + '" min="0" max="' + clip.duration + '" step="0.5" style="width:60px;font-size:.5rem"/>' +
                '<span style="font-size:.44rem;color:var(--muted)">s</span>' +
                '<button onclick="EDITOR.cutClip(\'' + clip.id + '\')" style="flex:1;padding:.3rem;background:var(--gold);border:none;color:var(--dark);font-size:.46rem;cursor:pointer">✂ Couper</button>' +
              '</div>'
            ) : '') +
          '</div>';
      });
    }

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">✂ Montage intelligent</div>' +
      '<p class="note">Or Eille AI analyse vos prises, suggere les coupes, propose un ordre. Vous validez. Instructions CapCut generees automatiquement. Deux heures economisees.</p>' +
      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">Or Eille AI fait le travail de reflexion. CapCut fait le travail technique. Chacun fait ce qu il sait faire. Vous gagnez deux heures.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +
      '<div style="border:2px dashed var(--border);padding:.8rem;text-align:center">' +
        '<input type="file" multiple accept="video/*" onchange="EDITOR.loadClips(this.files)" style="font-size:.52rem;color:var(--muted)"/>' +
        '<p style="font-size:.48rem;color:var(--muted);margin-top:.3rem">Chargez vos prises video — autant que vous voulez</p>' +
      '</div>' +
      (this._clips.length > 0 ? (
        '<div style="display:flex;gap:.4rem">' +
          '<button class="btn btn-gold" style="flex:2" onclick="EDITOR.analyzeWithAI(window.CFG&&window.CFG.CLAUDE_KEY)">🧠 Analyser et suggerer un ordre</button>' +
          '<button class="btn btn-ghost" style="flex:1" onclick="EDITOR.generateCapCutInstructions()">📋 Instructions CapCut</button>' +
        '</div>' +
        '<div class="sec-title">Vos prises — reordonnez et coupez</div>' +
        clipsHtml
      ) : '') +
    '</div>';
  }
};

window.EDITOR = EDITOR;
