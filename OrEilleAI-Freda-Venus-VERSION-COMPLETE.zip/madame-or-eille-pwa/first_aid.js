// ═══════════════════════════════════════════════════
//  PREMIERS SECOURS — Or Eille AI
//  Guidage étape par étape, hors ligne, toujours accessible
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const FIRST_AID = {

  // ─── Situations d'urgence ──────────────────────
  SITUATIONS: {
    inconscient: {
      nom: 'Personne inconsciente',
      icone: '😵',
      couleur: '#ef5350',
      etapes: [
        { titre: 'Sécuriser', texte: 'Vérifiez que vous êtes en sécurité. Ne bougez pas la personne si accident de la route.', timer: null, action: null },
        { titre: 'Stimuler', texte: 'Tapotez les épaules et parlez fort : "Vous m\'entendez ?" — "Est-ce que ça va ?"', timer: null, action: null },
        { titre: 'Appeler les secours', texte: 'Demandez à quelqu\'un d\'appeler le 15 (SAMU), 18 (Pompiers) ou 112. En Afrique : numéro d\'urgence local.', timer: null, action: 'appel' },
        { titre: 'Vérifier la respiration', texte: 'Basculez doucement la tête en arrière. Regardez, écoutez, sentez pendant 10 secondes. Respire-t-elle ?', timer: 10, action: null },
        { titre: 'Si elle respire → PLS', texte: 'Mettez-la en Position Latérale de Sécurité. Genoux fléchis, bras sous la tête, bouche vers le bas. Surveillez jusqu\'aux secours.', timer: null, action: 'pls' },
        { titre: 'Si elle ne respire PAS → RCP', texte: 'Commencez la réanimation cardio-pulmonaire immédiatement.', timer: null, action: 'rcp' },
      ]
    },

    rcp: {
      nom: 'Réanimation (RCP)',
      icone: '❤️',
      couleur: '#ef5350',
      etapes: [
        { titre: 'Position des mains', texte: 'Mettez le talon de votre main au centre de la poitrine, sur le sternum. Posez l\'autre main dessus. Bras tendus.', timer: null, action: null },
        { titre: '30 compressions', texte: 'Appuyez fort et vite — 5 à 6 cm de profondeur. Rythme : 100 à 120 par minute. Comptez à voix haute.', timer: null, action: 'compressions' },
        { titre: '2 insufflations', texte: 'Pincez le nez, soufflez dans la bouche jusqu\'à voir la poitrine se soulever. 2 fois. Si vous ne pouvez pas — continuez les compressions sans insufflations.', timer: null, action: null },
        { titre: 'Répétez', texte: '30 compressions puis 2 insufflations. Sans arrêt jusqu\'à l\'arrivée des secours ou que la personne respire.', timer: null, action: 'cycle' },
      ]
    },

    etouffement: {
      nom: 'Étouffement / Corps étranger',
      icone: '🫁',
      couleur: '#F5A623',
      etapes: [
        { titre: 'La personne tousse ?', texte: 'Si elle tousse fort — encouragez-la à continuer. Ne frappez pas dans le dos. La toux est efficace.', timer: null, action: null },
        { titre: 'Si elle ne peut plus tousser', texte: 'Penchez-la en avant. Donnez 5 grandes claques dans le dos entre les omoplates avec le plat de la main.', timer: null, action: null },
        { titre: 'Si ça ne suffit pas — Heimlich', texte: 'Placez-vous derrière elle. Mettez vos bras autour de sa taille. Serrez fort vers vous et vers le haut, sous les côtes. 5 fois.', timer: null, action: null },
        { titre: 'Alternez', texte: '5 claques dans le dos, puis 5 compressions abdominales. Répétez jusqu\'à ce que l\'objet sorte ou les secours arrivent.', timer: null, action: null },
        { titre: 'Nourrisson', texte: 'Pour un bébé — 5 tapes dans le dos face vers le bas sur votre avant-bras. Puis 5 pressions sur le sternum avec 2 doigts. JAMAIS Heimlich sur un bébé.', timer: null, action: null },
      ]
    },

    malaise_cardiaque: {
      nom: 'Malaise cardiaque',
      icone: '💔',
      couleur: '#ef5350',
      etapes: [
        { titre: 'Appeler immédiatement', texte: '15 (SAMU) ou 112. Dites : "Je pense que quelqu\'un fait une crise cardiaque." Restez en ligne.', timer: null, action: 'appel' },
        { titre: 'Installer la personne', texte: 'Allongez-la ou asseyez-la en position semi-assise si elle a du mal à respirer. Ne la laissez pas marcher.', timer: null, action: null },
        { titre: 'Desserrer', texte: 'Desserrez col, cravate, ceinture. Tout ce qui comprime.', timer: null, action: null },
        { titre: 'Surveiller', texte: 'Parlez-lui. Rassurez-la. Surveillez sa respiration. Si elle perd conscience → RCP immédiat.', timer: null, action: null },
        { titre: 'Défibrillateur', texte: 'Si un défibrillateur (DAE) est disponible nearby — allez le chercher ou demandez à quelqu\'un. Suivez les instructions vocales de l\'appareil.', timer: null, action: null },
      ]
    },

    epilepsie: {
      nom: 'Crise d\'épilepsie',
      icone: '⚡',
      couleur: '#9C27B0',
      etapes: [
        { titre: 'Ne pas retenir', texte: 'NE retenez PAS la personne. NE mettez rien dans sa bouche. Laissez la crise se passer.', timer: null, action: null },
        { titre: 'Protéger la tête', texte: 'Mettez quelque chose de doux sous sa tête — veste, sac. Écartez les objets dangereux autour d\'elle.', timer: null, action: null },
        { titre: 'Chronométrer', texte: 'Notez l\'heure de début. Si la crise dure plus de 5 minutes → appelez le 15 ou 112.', timer: 300, action: null },
        { titre: 'Après la crise', texte: 'Mettez-la en PLS. Elle va être confuse, fatiguée. Restez avec elle. Parlez doucement. Ne lui donnez rien à boire.', timer: null, action: null },
        { titre: 'Appeler si', texte: 'Appelez les secours si : crise > 5 min, deuxième crise, blessure, femme enceinte, ou c\'est la première fois.', timer: null, action: null },
      ]
    },

    brulure: {
      nom: 'Brûlure',
      icone: '🔥',
      couleur: '#FF5722',
      etapes: [
        { titre: 'Eau froide immédiatement', texte: 'Passez la brûlure sous l\'eau froide (pas glacée) pendant 15 minutes minimum. Commencez MAINTENANT.', timer: 900, action: null },
        { titre: 'Retirer', texte: 'Retirez bijoux, vêtements autour de la brûlure — SAUF s\'ils collent à la peau.', timer: null, action: null },
        { titre: 'Ne pas mettre', texte: 'NE mettez pas de beurre, dentifrice, huile ou glace. Cela aggrave la brûlure.', timer: null, action: null },
        { titre: 'Couvrir', texte: 'Couvrez avec un film alimentaire propre ou un pansement non adhérent. Pas de coton.', timer: null, action: null },
        { titre: 'Consulter', texte: 'Consultez un médecin si la brûlure est > 3 cm, sur le visage/mains/organes génitaux, ou si la peau est blanche/noire.', timer: null, action: null },
      ]
    },

    hemorragie: {
      nom: 'Hémorragie / Saignement',
      icone: '🩸',
      couleur: '#ef5350',
      etapes: [
        { titre: 'Appuyer fort', texte: 'Appuyez directement sur la plaie avec un tissu propre, vêtement ou votre main. FORT. Sans lâcher.', timer: null, action: null },
        { titre: 'Maintenir la pression', texte: 'Maintenez la pression sans relâcher pendant 10 minutes minimum. Si le tissu est imbibé — ajoutez-en un autre par-dessus sans retirer le premier.', timer: 600, action: null },
        { titre: 'Allonger', texte: 'Allongez la personne. Surélevez le membre blessé si possible (jambe, bras).', timer: null, action: null },
        { titre: 'Appeler', texte: 'Si le saignement ne s\'arrête pas — appelez le 15 ou 112. Décrivez la blessure et sa localisation.', timer: null, action: 'appel' },
        { titre: 'Garrot en dernier recours', texte: 'UNIQUEMENT si le saignement est abondant et ne s\'arrête pas — serrez un lien au-dessus de la blessure. Notez l\'heure. Dites-le aux secours.', timer: null, action: null },
      ]
    },

    accouchement: {
      nom: 'Accouchement d\'urgence',
      icone: '👶',
      couleur: '#4CAF50',
      etapes: [
        { titre: 'Appeler immédiatement', texte: 'Appelez le 15 ou 112. Restez en ligne — ils vous guideront par téléphone.', timer: null, action: 'appel' },
        { titre: 'Installer la mère', texte: 'Allongez-la sur le dos, genoux fléchis et écartés. Mettez des serviettes propres sous elle.', timer: null, action: null },
        { titre: 'Ne pas pousser prématurément', texte: 'Dites-lui de respirer et de ne pas pousser jusqu\'à ce que vous voyez la tête du bébé.', timer: null, action: null },
        { titre: 'Accueillir le bébé', texte: 'Soutenez doucement la tête du bébé quand elle sort. Ne tirez pas. Laissez sortir naturellement.', timer: null, action: null },
        { titre: 'Le bébé ne pleure pas', texte: 'Séchez-le avec un tissu propre en frottant doucement le dos. S\'il ne respire pas → 2 petites insufflations douces et 30 compressions légères avec 2 doigts.', timer: null, action: null },
        { titre: 'Garder au chaud', texte: 'Couvrez mère et bébé. Ne coupez pas le cordon. Attendez les secours.', timer: null, action: null },
      ]
    },
  },

  // ─── Numéros d'urgence par région ─────────────

  // ─── Traductions des situations d'urgence ──────
  // Le contenu est traduit via Claude dans la langue de l'utilisateur
  // et mis en cache localement pour un accès hors ligne

  CACHE_KEY: 'moe_first_aid_translations',

  // Détecter la langue de l'app
  _getLang() {
    try {
      const profile = window.MEMORY_SYSTEM ? MEMORY_SYSTEM.getProfile() : null;
      if (profile?.langue) return profile.langue;
      const stored = localStorage.getItem('moe_lang');
      if (stored) return stored;
    } catch {}
    return 'fr';
  },

  // Récupérer les traductions en cache
  _getCachedTranslations(lang) {
    try {
      const cache = JSON.parse(localStorage.getItem(this.CACHE_KEY) || '{}');
      return cache[lang] || null;
    } catch { return null; }
  },

  // Sauvegarder les traductions
  _cacheTranslations(lang, data) {
    try {
      const cache = JSON.parse(localStorage.getItem(this.CACHE_KEY) || '{}');
      cache[lang] = data;
      localStorage.setItem(this.CACHE_KEY, JSON.stringify(cache));
    } catch {}
  },

  // Traduire via Claude si nécessaire
  async _getTranslatedSituation(situationKey, lang) {
    if (lang === 'fr') return this.SITUATIONS[situationKey]; // Déjà en français

    // Vérifier cache
    const cached = this._getCachedTranslations(lang);
    if (cached && cached[situationKey]) return cached[situationKey];

    // Traduire via Claude
    const claudeKey = window.getKey ? getKey('claudeKey') : '';
    if (!claudeKey) return this.SITUATIONS[situationKey]; // Fallback français

    const situation = this.SITUATIONS[situationKey];
    const langNames = {
      'yo': 'Yoruba', 'sw': 'Swahili', 'ha': 'Hausa', 'wo': 'Wolof',
      'ig': 'Igbo', 'am': 'Amharique', 'so': 'Somali', 'tw': 'Twi',
      'bm': 'Bambara', 'ff': 'Peul/Fulfulde', 'lg': 'Luganda',
      'ar': 'Arabe', 'en': 'Anglais', 'pt': 'Portugais', 'es': 'Espagnol',
      'tr': 'Turc', 'vi': 'Vietnamien', 'zh': 'Chinois', 'ja': 'Japonais',
    };
    const langName = langNames[lang] || lang;

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': claudeKey,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 2000,
          messages: [{
            role: 'user',
            content: `Translate this first aid emergency content into ${langName}. Keep medical terms accurate and clear. Return ONLY valid JSON, no other text.

Input JSON: ${JSON.stringify(situation)}

Translate only the values of: "nom", "etapes[].titre", "etapes[].texte"
Keep all other fields exactly as-is (icone, couleur, timer, action).`
          }]
        })
      });
      if (!r.ok) return situation;
      const data = await r.json();
      const text = data.content.filter(b => b.type === 'text').map(b => b.text).join('');
      const translated = JSON.parse(text.replace(/```json|```/g, '').trim());

      // Mettre en cache
      const cache = this._getCachedTranslations(lang) || {};
      cache[situationKey] = translated;
      this._cacheTranslations(lang, cache);

      return translated;
    } catch {
      return situation; // Fallback français en cas d'erreur
    }
  },

  URGENCES: {
    france: { samu: '15', pompiers: '18', europe: '112', police: '17' },
    belgique: { samu: '100', pompiers: '100', europe: '112', police: '101' },
    suisse: { samu: '144', pompiers: '118', europe: '112', police: '117' },
    canada: { urgences: '911' },
    senegal: { samu: '15', pompiers: '18', police: '17' },
    cote_ivoire: { samu: '185', pompiers: '180', police: '111' },
    cameroun: { urgences: '112', pompiers: '118' },
    maroc: { samu: '15', pompiers: '15', police: '19' },
    tunisie: { samu: '190', pompiers: '198', police: '197' },
    default: { europe: '112', international: '999 ou 112' },
  },

  // ─── État de l'interface ───────────────────────
  _situationActive: null,
  _etapeActive: 0,
  _timerInterval: null,
  _cprInterval: null,
  _cprCount: 0,

  // ─── Rendu principal ───────────────────────────
  renderPanel() {
    return `
    <div style="display:flex;flex-direction:column;height:100%;overflow:hidden" id="firstAidContent">
      <div style="padding:.8rem 1rem;background:#C62828;display:flex;align-items:center;gap:.6rem;flex-shrink:0">
        <span style="font-size:1.4rem">❤️‍🩹</span>
        <div>
          <div style="font-size:.7rem;color:#fff;font-weight:700;letter-spacing:.05em">PREMIERS SECOURS</div>
          <div style="font-size:.48rem;color:rgba(255,255,255,.8)">Disponible sans réseau · Toujours accessible</div>
        </div>
        <button onclick="FIRST_AID._appelerUrgences()" 
          style="margin-left:auto;background:#fff;color:#C62828;border:none;padding:.4rem .8rem;font-size:.55rem;font-weight:700;cursor:pointer;letter-spacing:.05em">
          🚨 APPELER
        </button>
      </div>

      <div style="padding:.8rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.5rem">
        
        <p style="font-size:.52rem;color:rgba(255,255,255,.6);text-align:center;line-height:1.5">
          Choisissez la situation. Suivez les étapes une par une.
        </p>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">
          ${Object.entries(this.SITUATIONS).map(([key, s]) => `
            <button onclick="FIRST_AID._demarrer('${key}')"
              style="padding:.7rem;background:rgba(255,255,255,.08);border:1px solid ${s.couleur};color:#fff;font-family:inherit;cursor:pointer;text-align:left;display:flex;align-items:center;gap:.5rem"
              onmouseover="this.style.background='rgba(255,255,255,.15)'"
              onmouseout="this.style.background='rgba(255,255,255,.08)'">
              <span style="font-size:1.3rem">${s.icone}</span>
              <span style="font-size:.55rem;line-height:1.4">${s.nom}</span>
            </button>
          `).join('')}
        </div>

        <div style="margin-top:.5rem;padding:.7rem;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1)">
          <div style="font-size:.5rem;color:rgba(255,255,255,.5);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.4rem">Numéros d'urgence</div>
          <div style="display:flex;gap:.8rem;flex-wrap:wrap">
            <span style="font-size:.6rem;color:#ef5350;font-weight:700">🇪🇺 112</span>
            <span style="font-size:.6rem;color:#fff">🇫🇷 15 · 18 · 17</span>
            <span style="font-size:.6rem;color:#fff">🇸🇳 15 · 18</span>
            <span style="font-size:.6rem;color:#fff">🌍 999</span>
          </div>
        </div>

      </div>
    </div>`;
  },

  _demarrer(situationKey) {
    this._situationActive = situationKey;
    this._etapeActive = 0;
    this._afficherEtape();
  },

  _afficherEtape() {
    const container = document.getElementById('firstAidContent');
    const situation = this.SITUATIONS[this._situationActive];
    const etape = situation.etapes[this._etapeActive];
    const total = situation.etapes.length;
    const isLast = this._etapeActive === total - 1;

    let actionHTML = '';
    if (etape.action === 'appel') {
      actionHTML = `<button onclick="FIRST_AID._appelerUrgences()" 
        style="width:100%;padding:.8rem;background:#ef5350;color:#fff;border:none;font-family:inherit;font-size:.65rem;font-weight:700;cursor:pointer;letter-spacing:.05em;margin-top:.5rem">
        🚨 APPELER LES SECOURS MAINTENANT
      </button>`;
    } else if (etape.action === 'rcp') {
      actionHTML = `<button onclick="FIRST_AID._demarrer('rcp')" 
        style="width:100%;padding:.8rem;background:#ef5350;color:#fff;border:none;font-family:inherit;font-size:.65rem;font-weight:700;cursor:pointer;margin-top:.5rem">
        ❤️ COMMENCER LA RCP
      </button>`;
    } else if (etape.action === 'compressions') {
      actionHTML = `<div id="cpr-metronome" style="margin-top:.5rem;text-align:center">
        <button onclick="FIRST_AID._startMetronome()" 
          style="width:100%;padding:.8rem;background:#C62828;color:#fff;border:none;font-family:inherit;font-size:.65rem;font-weight:700;cursor:pointer">
          ▶ DÉMARRER LE RYTHME (100/min)
        </button>
        <div id="cpr-count" style="font-size:2rem;color:#ef5350;margin-top:.5rem;display:none">0</div>
      </div>`;
    }

    let timerHTML = '';
    if (etape.timer) {
      timerHTML = `<div id="aid-timer" style="text-align:center;font-size:1.5rem;color:#ef5350;margin:.5rem 0">
        ⏱ ${this._formatTimer(etape.timer)}
      </div>
      <button onclick="FIRST_AID._startTimer(${etape.timer})"
        style="width:100%;padding:.5rem;background:rgba(255,255,255,.1);color:#fff;border:1px solid rgba(255,255,255,.2);font-family:inherit;font-size:.58rem;cursor:pointer;margin-bottom:.5rem">
        ▶ Démarrer le chronomètre
      </button>`;
    }

    container.innerHTML = `
    <div style="display:flex;flex-direction:column;height:100%;background:#1a0000">
      
      <div style="padding:.7rem 1rem;background:#C62828;display:flex;align-items:center;gap:.5rem;flex-shrink:0">
        <button onclick="FIRST_AID._retour()" style="background:transparent;border:none;color:#fff;font-size:1.1rem;cursor:pointer">←</button>
        <span style="font-size:.85rem">${situation.icone}</span>
        <span style="font-size:.6rem;color:#fff;font-weight:700">${situation.nom}</span>
        <button onclick="FIRST_AID._appelerUrgences()" 
          style="margin-left:auto;background:#fff;color:#C62828;border:none;padding:.3rem .6rem;font-size:.5rem;font-weight:700;cursor:pointer">
          🚨 APPELER
        </button>
      </div>

      <div style="background:rgba(255,255,255,.08);padding:.4rem 1rem">
        <div style="display:flex;gap:.2rem">
          ${situation.etapes.map((_, i) => `
            <div style="flex:1;height:3px;background:${i <= this._etapeActive ? '#ef5350' : 'rgba(255,255,255,.2)'}"></div>
          `).join('')}
        </div>
        <div style="font-size:.45rem;color:rgba(255,255,255,.5);margin-top:.3rem">Étape ${this._etapeActive + 1} sur ${total}</div>
      </div>

      <div style="padding:1.2rem 1rem;flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:.6rem">
        
        <div style="font-size:.85rem;color:#ef5350;font-weight:700;letter-spacing:.05em;text-transform:uppercase">
          ${etape.titre}
        </div>

        <div style="font-size:.75rem;color:#fff;line-height:1.8;font-weight:400">
          ${etape.texte}
        </div>

        ${timerHTML}
        ${actionHTML}

      </div>

      <div style="padding:.8rem 1rem;display:flex;gap:.4rem;flex-shrink:0;border-top:1px solid rgba(255,255,255,.1)">
        ${this._etapeActive > 0 ? `
          <button onclick="FIRST_AID._etapePrecedente()"
            style="flex:1;padding:.7rem;background:rgba(255,255,255,.1);color:#fff;border:none;font-family:inherit;font-size:.6rem;cursor:pointer">
            ← Précédent
          </button>
        ` : ''}
        ${!isLast ? `
          <button onclick="FIRST_AID._etapeSuivante()"
            style="flex:2;padding:.7rem;background:#ef5350;color:#fff;border:none;font-family:inherit;font-size:.65rem;font-weight:700;cursor:pointer">
            Étape suivante →
          </button>
        ` : `
          <button onclick="FIRST_AID._retour()"
            style="flex:2;padding:.7rem;background:#4CAF50;color:#fff;border:none;font-family:inherit;font-size:.65rem;font-weight:700;cursor:pointer">
            ✓ Terminé — Retour
          </button>
        `}
      </div>
    </div>`;

    if (etape.timer) this._startTimer(etape.timer);
  },

  _etapeSuivante() {
    clearInterval(this._timerInterval);
    clearInterval(this._cprInterval);
    this._etapeActive++;
    this._afficherEtape();
  },

  _etapePrecedente() {
    clearInterval(this._timerInterval);
    clearInterval(this._cprInterval);
    this._etapeActive--;
    this._afficherEtape();
  },

  _retour() {
    clearInterval(this._timerInterval);
    clearInterval(this._cprInterval);
    this._situationActive = null;
    this._etapeActive = 0;
    document.getElementById('firstAidContent').innerHTML = this.renderPanel().replace('<div style="display:flex;flex-direction:column;height:100%;overflow:hidden" id="firstAidContent">', '').slice(0, -6);
    document.getElementById('firstAidContent').innerHTML = this.renderPanel();
  },

  _startTimer(seconds) {
    clearInterval(this._timerInterval);
    let remaining = seconds;
    const el = document.getElementById('aid-timer');
    if (!el) return;
    this._timerInterval = setInterval(() => {
      remaining--;
      if (el) el.textContent = '⏱ ' + this._formatTimer(remaining);
      if (remaining <= 0) {
        clearInterval(this._timerInterval);
        if (el) { el.textContent = '✓ Terminé !'; el.style.color = '#4CAF50'; }
        if (window.speak) speak('Terminé.');
      }
    }, 1000);
  },

  _startMetronome() {
    clearInterval(this._cprInterval);
    this._cprCount = 0;
    const countEl = document.getElementById('cpr-count');
    if (countEl) countEl.style.display = 'block';
    // 100 compressions par minute = 1 toutes les 600ms
    this._cprInterval = setInterval(() => {
      this._cprCount++;
      if (countEl) countEl.textContent = this._cprCount;
      if (window.speak && this._cprCount % 5 === 0) speak(String(this._cprCount));
      if (this._cprCount >= 30) {
        clearInterval(this._cprInterval);
        if (countEl) { countEl.textContent = '✓ 30 — Insufflations !'; countEl.style.color = '#4CAF50'; }
        if (window.speak) speak('Trente. Faites les insufflations.');
      }
    }, 600);
  },

  _formatTimer(s) {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${String(sec).padStart(2,'0')}`;
  },

  _appelerUrgences() {
    // Sur mobile, lancer l'appel
    window.location.href = 'tel:112';
  },
};

window.FIRST_AID = FIRST_AID;

// ─── Démarrer avec traduction automatique ──────
const _demarrerOriginal = FIRST_AID._demarrer.bind(FIRST_AID);
FIRST_AID._demarrer = async function(situationKey) {
  this._situationActive = situationKey;
  this._etapeActive = 0;

  const lang = this._getLang();
  if (lang !== 'fr') {
    // Afficher message de chargement
    const container = document.getElementById('firstAidContent');
    if (container) {
      container.innerHTML = `<div style="padding:2rem;text-align:center;color:#fff;background:#1a0000;height:100%">
        <div style="font-size:1.5rem;margin-bottom:1rem">❤️‍🩹</div>
        <div style="font-size:.65rem">Traduction en cours…</div>
      </div>`;
    }
    // Traduire et mettre en cache
    const translated = await this._getTranslatedSituation(situationKey, lang);
    // Utiliser la version traduite
    this._situationActiveData = translated;
  } else {
    this._situationActiveData = this.SITUATIONS[situationKey];
  }

  this._afficherEtape();
};

// Adapter _afficherEtape pour utiliser _situationActiveData
const _afficherEtapeOriginal = FIRST_AID._afficherEtape.bind(FIRST_AID);
FIRST_AID._afficherEtape = function() {
  // Utiliser les données traduites si disponibles
  if (this._situationActiveData) {
    const origSituation = this.SITUATIONS[this._situationActive];
    // Merger: données traduites + données techniques originales (timer, action, couleur)
    const situation = {
      ...origSituation,
      nom: this._situationActiveData.nom || origSituation.nom,
      etapes: origSituation.etapes.map((e, i) => ({
        ...e,
        titre: (this._situationActiveData.etapes?.[i]?.titre) || e.titre,
        texte: (this._situationActiveData.etapes?.[i]?.texte) || e.texte,
      }))
    };
    // Temporairement remplacer dans SITUATIONS pour _afficherEtape
    const backup = this.SITUATIONS[this._situationActive];
    this.SITUATIONS[this._situationActive] = situation;
    _afficherEtapeOriginal.call(this);
    this.SITUATIONS[this._situationActive] = backup;
  } else {
    _afficherEtapeOriginal.call(this);
  }
};
