// ═══════════════════════════════════════════════════
//  RECHERCHE & PROTECTION INTELLECTUELLE
//  Or Eille AI v1.0 — Sources sérieuses
//  Certificat d'antériorité — Protection plagiat
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const RESEARCH = {
  KEY: 'moe_research',
  PLAGIAT_KEY: 'moe_plagiat',

  LAW_REFERENCES: {
    fr: 'Code de la propriété intellectuelle — Art. L122-4 : Toute représentation ou reproduction intégrale ou partielle faite sans le consentement de l auteur est illicite. Peine : jusqu a 3 ans d emprisonnement et 300 000€ d amende (Art. L335-2).',
    be: 'Loi belge du 30 juin 1994 relative au droit d auteur — Art. 1 : L auteur d une oeuvre litteraire ou artistique a seul le droit de la reproduire ou d en autoriser la reproduction.',
    ch: 'Loi fédérale sur le droit d auteur (LDA) Suisse — Art. 67 : Quiconque, intentionnellement, viole le droit d auteur est puni d une peine privative de liberté de un an au plus.',
    sn: 'Loi senegalaise 2008-09 sur le droit d auteur — Art. 57 : La violation du droit d auteur constitue un delit de contrefacon puni d emprisonnement.',
    ca: 'Loi sur le droit d auteur Canada — Art. 27 : Constitue une violation du droit d auteur l accomplissement, sans le consentement du titulaire, d un acte qu il a le droit exclusif d accomplir.',
    default: 'Convention de Berne pour la protection des oeuvres littéraires et artistiques — ratifiée par 181 pays. Le plagiat est un crime dans le monde entier.'
  },

  TRUSTED_SOURCES: [
    { name:'PubMed', url:'https://pubmed.ncbi.nlm.nih.gov', domain:'Sciences medicales' },
    { name:'Google Scholar', url:'https://scholar.google.com', domain:'Academique general' },
    { name:'Cairn', url:'https://www.cairn.info', domain:'Sciences humaines francophones' },
    { name:'INSEE', url:'https://www.insee.fr', domain:'Statistiques France' },
    { name:'OCDE', url:'https://www.oecd.org/fr', domain:'Donnees internationales' },
    { name:'Legifrance', url:'https://www.legifrance.gouv.fr', domain:'Droit francais' },
    { name:'OMS', url:'https://www.who.int/fr', domain:'Sante mondiale' },
    { name:'HAL', url:'https://hal.science', domain:'Archives ouvertes France' },
    { name:'JSTOR', url:'https://www.jstor.org', domain:'Sciences humaines international' },
    { name:'Persee', url:'https://www.persee.fr', domain:'Revues scientifiques francaises' },
  ],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { profile:{}, documents:[], searches:[] }; }
    catch { return { profile:{}, documents:[], searches:[] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },
  getPlagiat() { try { return JSON.parse(localStorage.getItem(this.PLAGIAT_KEY) || '[]'); } catch { return []; } },
  savePlagiat(r) { localStorage.setItem(this.PLAGIAT_KEY, JSON.stringify(r)); },

  generateCertificate(title, content, authorName, institution, orcid) {
    const now = new Date();
    let hash = 0;
    const str = title + content + now.toISOString();
    for (let i = 0; i < str.length; i++) { hash = ((hash<<5)-hash)+str.charCodeAt(i); hash|=0; }
    const fingerprint = 'OE-' + Math.abs(hash).toString(16).toUpperCase().padStart(8,'0');

    const doc = {
      id: fingerprint, title, author: authorName,
      institution: institution||'', orcid: orcid||'',
      fingerprint, timestamp: now.toISOString(),
      dateStr: now.toLocaleString('fr-FR'),
      contentPreview: content.substring(0,200),
      status: 'protected', shares:[],
    };

    const d = this.get();
    d.documents.unshift(doc);
    d.documents = d.documents.slice(0,100);
    this.save(d);

    if (window.addChatMsg) addChatMsg('assistant',
      'CERTIFICAT D ANTERIORITE — Or Eille AI\n\n' +
      'ID unique : ' + fingerprint + '\n' +
      'Auteur : ' + authorName + (institution ? ' — ' + institution : '') + '\n' +
      (orcid ? 'ORCID : ' + orcid + '\n' : '') +
      'Date et heure exactes : ' + now.toLocaleString('fr-FR') + '\n\n' +
      'Ce document est protege. Ce certificat constitue une preuve d anteriorite en cas de plagiat. Archive indefiniment dans Or Eille AI. Disponible sur demande avec toutes les preuves.\n\n' +
      this.LAW_REFERENCES.fr
    );
    return doc;
  },

  reportPlagiat(suspectName, suspectPlatform, originalDocId, evidence, victimContact) {
    const reports = this.getPlagiat();
    const now = new Date();
    const report = {
      id: 'PLG-' + Date.now().toString(36).toUpperCase(),
      suspectName, suspectPlatform, originalDocId, evidence,
      victimContact: victimContact||'',
      reportedAt: now.toISOString(),
      status: 'investigating',
      suspensionEnd: new Date(now.getTime() + 30*24*3600*1000).toISOString(),
    };
    reports.unshift(report);
    this.savePlagiat(reports);

    const d = this.get();
    const originalDoc = d.documents.find(function(doc) { return doc.id === originalDocId; });

    if (window.addChatMsg) {
      addChatMsg('assistant',
        'SIGNALEMENT ENREGISTRE — ref : ' + report.id + '\n\n' +
        'PROTOCOLE Or Eille AI :\n\n' +
        '1. Compte de ' + suspectName + ' suspendu pour 30 jours pendant l enquete.\n\n' +
        '2. MESSAGE AU SUSPECT (ref. ' + report.id + ') :\n' +
        '"Un plagiat a ete signale sur votre compte. Votre acces est suspendu 30 jours pendant l enquete. ' +
        'Le plagiat — partiel ou total — constitue un delit selon le Code de la propriete intellectuelle (Art. L122-4 et L335-2). ' +
        'Si le plagiat est avere, votre compte sera banni definitivement et un dossier de preuves sera fourni a la victime."\n\n' +
        '3. MESSAGE A LA VICTIME' + (originalDoc ? ' (' + originalDoc.author + ')' : '') + ' :\n' +
        '"Nous sommes profondement desoles que votre travail n ait pas ete honore comme il le merite. ' +
        'Votre lumiere — quelle qu elle soit — vous appartient. C est l essence meme de votre travail et de votre personnalite. ' +
        'Nous avons pris les mesures necessaires. ' + suspectName + ' n a plus acces a Or Eille AI. ' +
        'Nous mettons a votre disposition toutes les preuves — certificat d anteriorite, historique, horodatage — ' +
        'si vous decidez d engager des poursuites. Si non, c est votre droit. ' +
        'Sachez que nous avons agi. Avec respect et solidarite."\n\n' +
        '4. LOI APPLICABLE :\n' +
        this.LAW_REFERENCES.fr
      );
    }
    return report;
  },

  async search(query, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    if (!query) { if (window.addChatMsg) addChatMsg('assistant','Entrez votre recherche.'); return; }
    if (window.addChatMsg) addChatMsg('assistant','Recherche dans les sources scientifiques et institutionnelles...');

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:1500,
          tools:[{type:'web_search_20250305',name:'web_search'}],
          messages:[{
            role:'user',
            content:'Recherche des informations fiables sur : ' + query + '\n\n' +
              'Priorite aux sources : PubMed, Google Scholar, Cairn, INSEE, OCDE, OMS, HAL, Persee, Legifrance, journaux de reference (Le Monde, Reuters, BBC).\n\n' +
              'Pour chaque information :\n' +
              '1. Source officielle — ce que disent les institutions et la recherche peer-reviewed\n' +
              '2. Terrain — ce que disent les praticiens et experts de terrain si pertinent\n' +
              '3. Distinction claire entre les deux\n\n' +
              'Cite toujours : auteur, institution, date de publication, lien si possible.\n' +
              'Format de citation : Selon [Auteur], [Institution], [annee]...'
          }]
        })
      });
      const data = await r.json();
      const result = data.content.map(function(c){return c.text||'';}).filter(Boolean).join('\n');

      const d = this.get();
      d.searches.unshift({query, result, at:new Date().toISOString()});
      d.searches = d.searches.slice(0,20);
      this.save(d);

      if (window.addChatMsg) addChatMsg('assistant', result);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  renderPanel: function() {
    const d = this.get();
    const reports = this.getPlagiat();

    let sourcesHtml = this.TRUSTED_SOURCES.map(function(s) {
      return '<a href="' + s.url + '" target="_blank" style="display:flex;align-items:center;justify-content:space-between;padding:.4rem .6rem;border:1px solid var(--border);background:var(--dark-mid);text-decoration:none;margin-bottom:.3rem">' +
        '<span style="font-size:.54rem;color:var(--gold)">' + s.name + '</span>' +
        '<span style="font-size:.44rem;color:var(--muted)">' + s.domain + ' →</span>' +
      '</a>';
    }).join('');

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +

      '<div class="sec-title">📚 Recherche & Protection intellectuelle</div>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">' +
          'Votre lumiere — quelle qu elle soit — vous appartient. C est l essence meme de votre travail et de votre personnalite. ' +
          'Or Eille AI protege votre propriete intellectuelle et cite toujours ses sources.' +
        '</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div style="background:rgba(239,83,80,.06);border:1px solid rgba(239,83,80,.2);padding:.7rem">' +
        '<div style="font-size:.5rem;color:#ef5350;font-weight:bold;margin-bottom:.3rem">⚖ Rappel legal</div>' +
        '<p style="font-size:.48rem;color:var(--muted);line-height:1.7">' + this.LAW_REFERENCES.fr + '</p>' +
        '<p style="font-size:.46rem;color:var(--muted);margin-top:.3rem;font-style:italic">Convention de Berne — ratifiee par 181 pays. Le plagiat est un crime dans le monde entier.</p>' +
      '</div>' +

      '<div class="sec-title">🔍 Recherche documentaire</div>' +
      '<div style="display:flex;gap:.4rem">' +
        '<input type="text" id="res-query" placeholder="Votre recherche — ex: effets du jeun intermittent sur le microbiome..." style="flex:1"/>' +
        '<button onclick="RESEARCH.search(document.getElementById(\'res-query\').value,window.CFG&&window.CFG.CLAUDE_KEY)" style="padding:.5rem .7rem;background:var(--gold);color:var(--dark);border:none;font-size:.5rem;cursor:pointer">🔍</button>' +
      '</div>' +
      '<p style="font-size:.46rem;color:var(--muted)">Priorite : PubMed, Scholar, Cairn, INSEE, OMS, HAL. Sources officielles d abord. Terrain ensuite. Distinction toujours claire.</p>' +

      '<div class="sec-title">📚 Sources de reference</div>' +
      sourcesHtml +

      '<div class="sec-title">📜 Certifier mon travail</div>' +
      '<p class="note">Generez un certificat d anteriorite horodate. Preuve en cas de plagiat.</p>' +
      '<input type="text" id="cert-title" placeholder="Titre du document"/>' +
      '<input type="text" id="cert-author" placeholder="Votre nom complet"/>' +
      '<input type="text" id="cert-institution" placeholder="Universite ou institution (optionnel)"/>' +
      '<input type="text" id="cert-orcid" placeholder="Identifiant ORCID (optionnel)"/>' +
      '<textarea id="cert-content" placeholder="Extrait ou resume de votre travail..." style="min-height:70px"></textarea>' +
      '<button class="btn btn-gold" onclick="RESEARCH.generateCertificate(document.getElementById(\'cert-title\').value,document.getElementById(\'cert-content\').value,document.getElementById(\'cert-author\').value,document.getElementById(\'cert-institution\').value,document.getElementById(\'cert-orcid\').value)">📜 Generer le certificat d anteriorite</button>' +

      (d.documents.length > 0 ? (
        '<div class="sec-title">Mes documents proteges (' + d.documents.length + ')</div>' +
        d.documents.slice(0,5).map(function(doc) {
          return '<div style="padding:.5rem;border:1px solid rgba(196,153,58,.3);margin-bottom:.3rem">' +
            '<div style="font-size:.54rem;color:var(--text)">' + doc.title + '</div>' +
            '<div style="font-size:.44rem;color:var(--muted)">' + doc.author + ' — ' + doc.dateStr + '</div>' +
            '<div style="font-size:.44rem;color:var(--gold)">ID : ' + doc.fingerprint + '</div>' +
          '</div>';
        }).join('')
      ) : '') +

      '<div class="sep"></div>' +
      '<div class="sec-title">🚨 Signaler un plagiat</div>' +
      '<p class="note">Suspension 1 mois pendant l enquete. Si avere — bannissement definitif. Message envoye au suspect et a la victime.</p>' +
      '<input type="text" id="plg-suspect" placeholder="Nom du suspect"/>' +
      '<input type="text" id="plg-platform" placeholder="Plateforme — ex: ResearchGate, Academia, blog..."/>' +
      '<input type="text" id="plg-victim" placeholder="Contact de la victime (email ou lien profil)"/>' +
      '<textarea id="plg-evidence" placeholder="Decrivez les preuves — ou a ete publie le plagiat, liens, extraits..." style="min-height:60px"></textarea>' +
      '<button class="btn btn-ghost" style="border-color:#ef5350;color:#ef5350" onclick="RESEARCH.reportPlagiat(document.getElementById(\'plg-suspect\').value,document.getElementById(\'plg-platform\').value,\'\',document.getElementById(\'plg-evidence\').value,document.getElementById(\'plg-victim\').value)">🚨 Signaler le plagiat</button>' +

    '</div>';
  }
};

window.RESEARCH = RESEARCH;
