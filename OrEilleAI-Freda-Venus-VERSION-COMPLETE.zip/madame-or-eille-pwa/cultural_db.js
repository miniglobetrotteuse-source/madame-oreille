// ═══════════════════════════════════════════════════
//  BASE CULTURELLE PARTICIPATIVE — Or Eille AI v1.0
//  Documentation des cultures du monde par la communauté
//  Styles littéraires, contes, légendes, univers créatifs
// ═══════════════════════════════════════════════════

const CULTURAL_DB = {
  KEY: 'moe_cultural_db',

  KNOWN_STYLES: {
    alice: {
      name: 'Alice au Pays des Merveilles', author: 'Lewis Carroll',
      keywords: ['merveilles','curiosité','lapin blanc','Reine de Cœur','Chapelier fou','étrange','extraordinaire'],
      openings: ['Curiouser and curiouser','Comme Alice tombant dans le terrier','Bienvenue dans le merveilleux'],
      tone: 'surréaliste et poétique', documented: true
    },
    petit_prince: {
      name: 'Le Petit Prince', author: 'Antoine de Saint-Exupéry',
      keywords: ['étoiles','rose','renard','essentiel','invisible','planète','apprivoiser'],
      openings: ['L\'essentiel est invisible pour les yeux','Sur ma planète','Ce qui compte vraiment'],
      tone: 'philosophique et poétique', documented: true
    },
    mille_nuits: {
      name: 'Les Mille et Une Nuits',
      keywords: ['Shéhérazade','djinn','palais','tapis volant','magie','sultan','conte'],
      openings: ['Il était une fois','Dans les temps anciens','Une nuit entre les nuits'],
      tone: 'envoûtant et mystérieux', documented: true
    },
    afrofuturisme: {
      name: 'Afrofuturisme',
      keywords: ['futur africain','technologie','ancestralité','puissance','renaissance','cosmos','Ubuntu'],
      openings: ['Dans le futur que nos ancêtres ont rêvé','Là où la tradition rencontre le futur','Notre galaxie'],
      tone: 'puissant et visionnaire', documented: true
    },
    harry_potter: {
      name: 'Harry Potter', author: 'J.K. Rowling',
      keywords: ['magie','Poudlard','sorts','sorcier','baguette','monde parallèle','Moldue'],
      openings: ['Bienvenue à Poudlard','La magie opère','Le monde des sorciers'],
      tone: 'magique et aventureux', documented: true
    },
    starwars: {
      name: 'Star Wars',
      keywords: ['galaxie','Force','Jedi','côté obscur','étoile','aventure','destinée','Dark Vador'],
      openings: ['Il y a très longtemps dans une galaxie lointaine','Que la Force soit avec vous','Dans une galaxie'],
      tone: 'épique et dramatique', documented: true
    },
    contes_bretagne: {
      name: 'Contes de Bretagne',
      keywords: ['Korrigans','Brocéliande','Merlin','fées','dolmens','mer','brume','enchantement'],
      openings: ['Dans les forêts de Brocéliande','Par une nuit de Samhain','Les anciens disaient'],
      tone: 'mystérieux et celtique', documented: true
    },
    rumi: {
      name: 'Poésie de Rumi',
      keywords: ['âme','amour divin','derviche','roseau','séparation','Union','Bien-Aimé','lumière'],
      openings: ['Écoute le roseau','L\'amour est venu','Dans le silence de l\'âme'],
      tone: 'mystique et contemplatif', documented: true
    }
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      communityStyles: [], searchCache: {}, learningSessions: []
    }; } catch { return { communityStyles: [], searchCache: {}, learningSessions: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Chercher un style ────────────────────────
  find(name) {
    const key = name.toLowerCase().replace(/\s+/g, '_');
    // Base connue
    const known = this.KNOWN_STYLES[key];
    if (known) return { ...known, source: 'base_or_eille' };
    // Chercher dans les styles communautaires
    const d = this.get();
    const community = d.communityStyles.find(s =>
      s.name.toLowerCase().includes(name.toLowerCase()) ||
      name.toLowerCase().includes(s.name.toLowerCase())
    );
    if (community) return { ...community, source: 'communauté' };
    return null;
  },

  // ─── Apprendre un nouveau style ───────────────
  async learnStyle(cultureName, claudeKey) {
    if (!claudeKey) return null;
    // Vérifier le cache
    const d = this.get();
    if (d.searchCache[cultureName]) return d.searchCache[cultureName];

    if (window.addChatMsg) addChatMsg('assistant', `🔍 Je recherche des informations sur "${cultureName}"...`);

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 600,
          tools: [{ type: 'web_search_20250305', name: 'web_search' }],
          messages: [{
            role: 'user',
            content: `Recherche des informations sur "${cultureName}" comme style narratif, littéraire ou culturel.

Trouve si possible:
1. Les thèmes typiques
2. Les personnages ou figures emblématiques
3. Le style d'écriture caractéristique
4. Les expressions ou formules d'ouverture typiques
5. La tonalité émotionnelle
6. Des exemples de phrases dans ce style

Si c'est peu documenté sur le web, dis-le clairement et demande à l'utilisateur de partager ses connaissances.
Si tu trouves des informations, explique comment écrire dans ce style de façon respectueuse.`
          }]
        })
      });
      const data = await r.json();
      const text = data.content.filter(b => b.type === 'text').map(b => b.text).join('');

      // Mettre en cache
      d.searchCache[cultureName] = { name: cultureName, research: text, foundAt: new Date().toISOString() };
      this.save(d);

      if (window.addChatMsg) addChatMsg('assistant', `📚 Informations trouvées sur "${cultureName}" :\n\n${text}\n\nSi vous avez des connaissances personnelles sur ce style culturel, partagez-les — elles enrichiront la base Or Eille AI pour toute la communauté.`);
      return d.searchCache[cultureName];
    } catch { return null; }
  },

  // ─── Ajouter un style communautaire ───────────
  addCommunityStyle(style) {
    const d = this.get();
    const entry = {
      id: Date.now().toString(),
      ...style,
      addedAt: new Date().toISOString(),
      confirmedBy: 1,
      source: 'communauté_or_eille'
    };
    d.communityStyles.push(entry);
    this.save(d);
    if (window.addChatMsg) addChatMsg('assistant', `✅ Style "${style.name}" ajouté à la base culturelle. Merci pour votre contribution à la communauté !`);
    return entry;
  },

  // ─── Générer du contenu dans un style ─────────
  async generateInStyle(content, styleName, claudeKey) {
    if (!claudeKey) return null;
    let styleInfo = this.find(styleName);
    if (!styleInfo) {
      styleInfo = await this.learnStyle(styleName, claudeKey);
      if (!styleInfo) {
        if (window.addChatMsg) addChatMsg('assistant', `Je ne connais pas assez "${styleName}" pour écrire dans ce style. Pouvez-vous me donner quelques exemples ou références ?`);
        return null;
      }
    }

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 800,
          messages: [{
            role: 'user',
            content: `Réécris ou génère ce contenu dans le style de "${styleInfo.name}".

Style: ${styleInfo.tone || 'non défini'}
Thèmes: ${(styleInfo.keywords || []).join(', ')}
${styleInfo.openings ? 'Exemples d\'ouvertures: ' + styleInfo.openings.join(' / ') : ''}
${styleInfo.research ? 'Informations supplémentaires: ' + styleInfo.research.substring(0, 300) : ''}

Contenu à adapter: "${content}"

Important: Garde le message commercial/informatif mais habille-le dans l'univers de ce style. Sois respectueux et authentique.`
          }]
        })
      });
      const data = await r.json();
      return data.content[0].text;
    } catch { return null; }
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div class="sec-title">🌍 Base culturelle mondiale</div>
      <p class="note">Or Eille AI connaît ces styles culturels. Vous pouvez en demander d'autres — il cherche et apprend.</p>

      <!-- Styles connus -->
      <div style="display:flex;flex-wrap:wrap;gap:.3rem">
        ${Object.entries(this.KNOWN_STYLES).map(([k,s]) => `
          <button onclick="if(window.addChatMsg)addChatMsg('assistant','Style ${s.name} — Ton: ${s.tone}. Thèmes: ${(s.keywords||[]).slice(0,4).join(', ')}.')" 
            style="padding:.3rem .6rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:'Josefin Sans',sans-serif;font-size:.5rem;cursor:pointer">
            ${s.name}
          </button>
        `).join('')}
      </div>

      <div class="sep"></div>
      <div class="sec-title">🔍 Demander un nouveau style</div>
      <p class="note">Entrez le nom d'une culture, d'un conte, d'une tradition littéraire — Or Eille AI cherche et apprend.</p>
      <div style="display:flex;gap:.4rem">
        <input type="text" id="cd-style-name" placeholder="Ex: Contes Yoruba, Légendes bretonnes, Épopée de Soundiata..." style="flex:1"/>
        <button onclick="CULTURAL_DB.learnStyle(document.getElementById('cd-style-name').value,window.CFG?.CLAUDE_KEY)" class="btn btn-gold">Chercher</button>
      </div>
      <button class="voice-btn" onclick="WHISPER.start(t=>document.getElementById('cd-style-name').value=t)">🎙 Dicter</button>

      <div class="sep"></div>
      <div class="sec-title">✍ Générer dans un style culturel</div>
      <textarea id="cd-content" placeholder="Votre contenu à transformer..." style="min-height:80px"></textarea>
      <input type="text" id="cd-style-target" placeholder="Style souhaité (ex: Alice au Pays des Merveilles)"/>
      <button class="btn btn-ghost" onclick="CULTURAL_DB.generateInStyle(document.getElementById('cd-content').value,document.getElementById('cd-style-target').value,window.CFG?.CLAUDE_KEY).then(r=>{if(r&&window.addChatMsg)addChatMsg('assistant',r)})">✨ Transformer</button>

      <div class="sep"></div>
      <div class="sec-title">🤝 Contribuer à la base</div>
      <p class="note">Vous connaissez un style culturel peu documenté ? Partagez-le avec la communauté Or Eille AI.</p>
      <input type="text" id="cd-contrib-name" placeholder="Nom du style ou de la culture"/>
      <textarea id="cd-contrib-desc" placeholder="Description, thèmes, exemples de phrases, tonalité..." style="min-height:80px"></textarea>
      <button class="btn btn-ghost" onclick="CULTURAL_DB.addCommunityStyle({name:document.getElementById('cd-contrib-name').value,description:document.getElementById('cd-contrib-desc').value,keywords:[],tone:'non défini'});document.getElementById('culturaContent').innerHTML=CULTURAL_DB.renderPanel()">
        ✅ Partager avec la communauté
      </button>

      ${d.communityStyles.length > 0 ? `
        <div class="sep"></div>
        <div class="sec-title">Contributions de la communauté (${d.communityStyles.length})</div>
        ${d.communityStyles.map(s => `
          <div style="padding:.5rem;border:1px solid var(--border)">
            <div style="font-size:.56rem;color:var(--text)">${s.name}</div>
            <div style="font-size:.48rem;color:var(--muted);margin-top:.2rem">${s.description?.substring(0,100)}...</div>
          </div>
        `).join('')}
      ` : ''}
    </div>`;
  }
};

window.CULTURAL_DB = CULTURAL_DB;
