// ============================================================
// APPRENTISSAGE — Or Eille AI v20
// Apprendre autrement — par ce qu'on aime, pas par l'académique
// "La matière ne change pas. Le chemin pour y arriver change."
// © 2026 Madame Or Eille Studios
// ============================================================

const APPRENTISSAGE = {

  // ── DONNÉES DE BASE ────────────────────────────────────────

  matieres: [
    { id:'langues', label:'🗣️ Langues', exemples:['Anglais — Londres / New York / Lagos','Français — Paris / Abidjan / Montréal','Espagnol — Madrid / Mexico / Bogotá','Allemand — Berlin / Vienne / Zurich','Arabe — Le Caire / Casablanca / Dakar','Portugais — Lisbonne / Luanda / São Paulo','Lingala — Brazzaville, Congo 🇨🇬','Lingala — Kinshasa, RDC 🇨🇩','Wolof — Dakar, Sénégal 🇸🇳','Fon — Cotonou, Bénin 🇧🇯','Bambara — Bamako, Mali 🇲🇱','Mooré — Ouagadougou, Burkina Faso 🇧🇫','Ewé — Lomé, Togo 🇹🇬','Twi — Accra, Ghana 🇬🇭','Yoruba — Lagos, Nigeria 🇳🇬','Swahili — Nairobi, Kenya 🇰🇪'] },
    { id:'maths',       label:'📐 Maths',             exemples:['Fractions','Géométrie','Statistiques','Algèbre','Probabilités'] },
    { id:'histoire',    label:'📜 Histoire & Géo',    exemples:['Géographie mondiale','Histoire de France','Histoire d\'Afrique','Géopolitique'] },
    { id:'sciences',    label:'🔬 Sciences',          exemples:['Physique','Chimie','Biologie','Astronomie'] },
    { id:'droit',       label:'⚖️ Droit & Éco',       exemples:['Droit civil','Économie','Droit du travail','Gestion'] },
    { id:'code_route',  label:'🚗 Code de la route',  exemples:['Panneaux','Priorités','Conduite','Sécurité'] },
    { id:'numerique',   label:'💻 Numérique',         exemples:['Excel','Réseaux sociaux','Sécurité en ligne','Création de site'] },
    { id:'autre',       label:'📚 Autre matière',     exemples:['Philosophie','Musique','Art','Comptabilité'] },
  ],

  passions: [
    { id:'foot',      label:'⚽ Football',     icon:'⚽' },
    { id:'musique',   label:'🎵 Musique',       icon:'🎵' },
    { id:'cuisine',   label:'🍳 Cuisine',       icon:'🍳' },
    { id:'voyage',    label:'✈️ Voyage',        icon:'✈️' },
    { id:'mode',      label:'👗 Mode & Beauté', icon:'👗' },
    { id:'business',  label:'💼 Business',      icon:'💼' },
    { id:'cinema',    label:'🎬 Cinéma & Séries',icon:'🎬' },
    { id:'jeux',      label:'🎮 Jeux vidéo',    icon:'🎮' },
    { id:'nature',    label:'🌿 Nature',        icon:'🌿' },
    { id:'famille',   label:'👶 Famille & Enfants', icon:'👶' },
  ],

  objectifs: [
    { id:'3mois',  label:'3 mois',  desc:'Me débrouiller — commander, comprendre l\'essentiel' },
    { id:'6mois',  label:'6 mois',  desc:'Tenir une conversation, passer un exam' },
    { id:'1an',    label:'1 an',    desc:'Maîtrise solide, quasi-bilingue ou très à l\'aise' },
    { id:'custom', label:'Date précise', desc:'J\'ai un partiel, un entretien, un concours' },
  ],

  // ── PARALLÈLES PASSION × MATIÈRE ───────────────────────────
  // L'app utilise ces parallèles pour créer les exercices concrets

  paralleles: {
    'foot+langues':     'Les interviews de joueurs en VO, les commentaires de match, les termes tactiques en anglais. Tu connais déjà "offside", "penalty", "hat-trick" — tu parles déjà anglais sans le savoir.',
    'foot+maths':       'Les ratios de buts, les pourcentages de possession, les cotes de paris. Mbappe marque 7 buts en 10 matchs — quel est son ratio ? C\'est une division. Simple.',
    'foot+histoire':    'Pourquoi Zidane est algérien et français ? Pourquoi le foot africain monte ? Chaque transfert raconte une histoire de migration, de colonisation, d\'identité.',
    'foot+geographie':  'Placer les stades du monde c\'est placer les villes. Wembley → Londres → Angleterre → Europe du Nord. Le Maracanã → Rio → Brésil → Amérique du Sud. Tu places tes équipes, tu places le monde.',
    'foot+sciences':    'Pourquoi le ballon courbe quand Ronaldo tire ? L\'effet Magnus. La physique du coup franc. La trajectoire parabolique. La matière rentre parce qu\'elle explique ce que tu vois.',
    'foot+droit':       'Les contrats de transfert, les droits d\'image, les litiges FIFA. Le droit des affaires expliqué par le mercato.',

    'musique+langues':  'Une chanson que tu aimes — on la décortique ligne par ligne. La grammaire arrive sans qu\'on la voie venir. Le rythme ancre les mots dans la mémoire.',
    'musique+maths':    'La mesure musicale c\'est des fractions. 4/4, 3/4, 6/8. Le rap français est du alexandrin — 12 syllabes. Compter les syllabes c\'est compter.',
    'musique+histoire': 'Le blues est né de l\'esclavage. Le reggae est né de la résistance jamaïcaine. Chaque genre musical raconte une histoire politique et sociale.',
    'musique+sciences': 'Les ondes sonores, les fréquences, pourquoi certaines notes sonnent ensemble. La physique du son expliquée par ce qu\'on entend.',

    'cuisine+maths':    'Les proportions d\'une recette — diviser par deux, multiplier par trois. Les températures de cuisson. Les conversions grammes/millilitres. Les maths de tous les jours.',
    'cuisine+chimie':   'Pourquoi le blanc d\'œuf monte en neige ? Pourquoi le pain lève ? Pourquoi le caramel brunit ? La chimie se passe dans ta casserole.',
    'cuisine+geographie':'D\'où vient le cacao ? Le café ? Le piment ? Chaque ingrédient raconte un voyage, une culture, une histoire commerciale.',
    'cuisine+histoire': 'La cuisine est une mémoire. L\'acarajé brésilien vient du Nigeria. Le thiéboudienne sénégalais a voyagé avec les pêcheurs. La nourriture raconte les migrations.',

    'voyage+langues':   'Pas de grammaire — des situations réelles. Commander un café, demander son chemin, négocier un prix. 3 mois pour survivre, 6 mois pour vivre.',
    'voyage+geographie':'Les fuseaux horaires, les capitales, les monnaies. La géographie comme outil pratique pour organiser un voyage.',
    'voyage+histoire':  'Chaque destination a une histoire. Comprendre pourquoi cette ville est comme ça, pourquoi ces gens font ça. Le voyage devient 10 fois plus riche.',

    'cinema+langues':   'Les séries en VO avec sous-titres en langue cible. Pas de français. 10 minutes par jour. Le cerveau attrape les schémas naturellement.',
    'cinema+histoire':  'Les films historiques comme point d\'entrée. Vérifier ce qui est vrai, ce qui est romancé. Esprit critique et culture générale en même temps.',

    'business+maths':   'Les marges, les pourcentages, les tableaux de bord. Les maths du business sont les maths du quotidien.',
    'business+droit':   'Créer une entreprise, un contrat, une facture. Le droit des affaires expliqué par ce qu\'on veut vraiment faire.',
    'business+langues': 'L\'anglais des affaires — emails, présentations, négociations. 50 phrases qui suffisent pour 80% des situations professionnelles.',
  },

  // ── STATE ───────────────────────────────────────────────────
  state: {
    etape: 'accueil',       // accueil | profil | plan | session
    matiere: null,
    passion: null,
    objectif: null,
    dateObjectif: null,
    niveau: null,
    prenom: '',
    sessionEnCours: false,
  },

  // ── INIT ────────────────────────────────────────────────────
  init() {
    this.renderPanel();
    console.log('✅ Apprentissage — module chargé');
  },

  renderPanel() {
    const panel = document.getElementById('panel-apprentissage');
    if(!panel) return;
    panel.innerHTML = `<div class="appr-container" id="appr-root">${this.renderEtape()}</div>`;
    this.attachEvents();
  },

  renderEtape() {
    switch(this.state.etape) {
      case 'accueil':  return this.renderAccueil();
      case 'profil':   return this.renderProfil();
      case 'plan':     return this.renderPlan();
      case 'session':  return this.renderSession();
      default:         return this.renderAccueil();
    }
  },

  // ── ÉTAPE 1 : ACCUEIL ───────────────────────────────────────
  renderAccueil() {
    return `
    <div class="appr-header">
      <div class="appr-title">📚 APPRENTISSAGE</div>
      <div class="appr-subtitle">Apprendre autrement — par ce que tu aimes, pas par l'académique.</div>
      <div class="appr-devise">"La matière ne change pas. Le chemin pour y arriver change."</div>
    </div>

    <div class="appr-intro-bloc">
      <p>Tu as essayé l'école. Tu as peut-être essayé des cours. Ça n'a pas marché comme tu voulais.</p>
      <p>Ce n'est pas toi le problème. C'est la méthode.</p>
      <p>Ici on part de ce que <strong>tu aimes déjà</strong> — le foot, la musique, la cuisine, le voyage — et on fait rentrer ce que tu dois apprendre par cette porte-là. En 3 mois tu te débrouilles. En 6 mois tu tiens une conversation. En 1 an tu maîtrises.</p>
    </div>

    <div class="appr-engagements">
      <div class="appr-engagement">🚫 Zéro cours magistral</div>
      <div class="appr-engagement">🚫 Zéro honte si tu rates</div>
      <div class="appr-engagement">✅ Exercices de moins de 5 minutes</div>
      <div class="appr-engagement">✅ Par ce que tu aimes</div>
      <div class="appr-engagement">✅ À ton rythme, dans le bruit, dans la vraie vie</div>
    </div>

    <button class="appr-btn-principal" id="appr-start">Je commence →</button>
    `;
  },

  // ── ÉTAPE 2 : PROFIL ────────────────────────────────────────
  renderProfil() {
    return `
    <div class="appr-header">
      <div class="appr-title">📚 APPRENTISSAGE</div>
      <div class="appr-step-label">Étape 1 sur 3 — Dis-moi ce que tu veux</div>
    </div>

    <div class="appr-section">
      <div class="appr-section-titre">Ton prénom (optionnel)</div>
      <input class="appr-input" id="appr-prenom" type="text" placeholder="Pour qu'on s'adresse à toi directement..." maxlength="50"/>
    </div>

    <div class="appr-section">
      <div class="appr-section-titre">Qu'est-ce que tu veux apprendre ?</div>
      <div class="appr-grid-choix" id="appr-matieres">
        ${this.matieres.map(m=>`
          <div class="appr-choix ${this.state.matiere===m.id?'actif':''}" data-matiere="${m.id}">
            ${m.label}
          </div>`).join('')}
      </div>
      <div id="appr-sous-matieres" class="appr-sous-section" style="display:none"></div>
    </div>

    <div class="appr-section">
      <div class="appr-section-titre">Ton niveau actuel</div>
      <div class="appr-grid-choix" id="appr-niveaux">
        <div class="appr-choix ${this.state.niveau==='debutant'?'actif':''}" data-niveau="debutant">🌱 Débutant — je pars de zéro</div>
        <div class="appr-choix ${this.state.niveau==='intermediaire'?'actif':''}" data-niveau="intermediaire">🌿 Intermédiaire — j'ai des bases mais ça coince</div>
        <div class="appr-choix ${this.state.niveau==='avance'?'actif':''}" data-niveau="avance">🌳 Avancé — je veux aller plus loin</div>
      </div>
    </div>

    <div class="appr-section">
      <div class="appr-section-titre">Ce que tu aimes dans la vie</div>
      <div class="appr-section-hint">On va apprendre à travers ça — pas à côté.</div>
      <div class="appr-grid-passions" id="appr-passions">
        ${this.passions.map(p=>`
          <div class="appr-passion ${this.state.passion===p.id?'actif':''}" data-passion="${p.id}">
            <span class="appr-passion-icon">${p.icon}</span>
            <span>${p.label}</span>
          </div>`).join('')}
      </div>
    </div>

    <div class="appr-nav">
      <button class="appr-btn-retour" id="appr-retour-accueil">← Retour</button>
      <button class="appr-btn-principal" id="appr-vers-plan">Mon objectif →</button>
    </div>
    `;
  },

  // ── ÉTAPE 3 : PLAN ──────────────────────────────────────────
  renderPlan() {
    const m = this.matieres.find(x=>x.id===this.state.matiere);
    const p = this.passions.find(x=>x.id===this.state.passion);
    const cle = (this.state.passion && this.state.matiere)
      ? this.state.passion + '+' + (this.state.matiere==='histoire'?'geographie':this.state.matiere==='code_route'?'autre':this.state.matiere)
      : null;
    const parallele = cle && this.paralleles[cle]
      ? this.paralleles[cle]
      : 'On va construire ton parcours en partant de ce que tu vis au quotidien — pas de cours théorique, des situations réelles.';

    const prenom = this.state.prenom ? this.state.prenom : null;

    return `
    <div class="appr-header">
      <div class="appr-title">📚 APPRENTISSAGE</div>
      <div class="appr-step-label">Étape 2 sur 3 — Ton objectif</div>
    </div>

    ${m && p ? `
    <div class="appr-parallele-bloc">
      <div class="appr-parallele-titre">${p.icon} ${p.label} × ${m.label}</div>
      <div class="appr-parallele-texte">${parallele}</div>
    </div>` : ''}

    <div class="appr-section">
      <div class="appr-section-titre">${prenom?'Dans combien de temps '+prenom+' tu veux y être ?':'Dans combien de temps tu veux y être ?'}</div>
      <div class="appr-objectifs" id="appr-objectifs">
        ${this.objectifs.map(o=>`
          <div class="appr-objectif-carte ${this.state.objectif===o.id?'actif':''}" data-objectif="${o.id}">
            <div class="appr-objectif-label">${o.label}</div>
            <div class="appr-objectif-desc">${o.desc}</div>
          </div>`).join('')}
      </div>
      <div id="appr-date-custom" style="display:none;margin-top:12px">
        <input class="appr-input" id="appr-date-input" type="date" placeholder="Date de ton exam ou entretien"/>
        <div class="appr-input-hint">Partiel, concours, entretien — on calcule le plan sur cette date.</div>
      </div>
    </div>

    <div id="appr-plan-genere" style="display:none"></div>

    <div class="appr-nav">
      <button class="appr-btn-retour" id="appr-retour-profil">← Retour</button>
      <button class="appr-btn-principal" id="appr-generer-plan">Voir mon plan →</button>
    </div>
    `;
  },

  // ── GÉNÉRATION DU PLAN ──────────────────────────────────────
  genererPlan() {
    const m   = this.matieres.find(x=>x.id===this.state.matiere);
    const p   = this.passions.find(x=>x.id===this.state.passion);
    const obj = this.objectifs.find(x=>x.id===this.state.objectif);
    if(!m || !obj) return '<div class="appr-erreur">Merci de choisir une matière et un objectif.</div>';

    const durees = { '3mois':'3 mois', '6mois':'6 mois', '1an':'1 an', 'custom':'jusqu\'à ta date' };
    const duree  = durees[this.state.objectif] || '6 mois';

    const phases = this.state.objectif === '3mois' ? [
      { label:'Mois 1', titre:'Survie & Confiance', desc:'Les 50 mots et phrases qui couvrent 80% des situations. Zéro grammaire. On parle.' },
      { label:'Mois 2', titre:'Ancrage par la pratique', desc:'Les mêmes choses, dans des contextes différents. Le cerveau crée les circuits.' },
      { label:'Mois 3', titre:'Autonomie fonctionnelle', desc:'Commander, comprendre, se débrouiller. L\'objectif est atteint.' },
    ] : this.state.objectif === '6mois' ? [
      { label:'Mois 1-2', titre:'Fondations par la passion', desc:'Vocabulaire de base ancré dans ce que tu aimes. Pas de manuel — de la vraie vie.' },
      { label:'Mois 3-4', titre:'Expansion naturelle', desc:'Les structures s\'installent sans les apprendre par cœur. On commence à produire.' },
      { label:'Mois 5-6', titre:'Conversation & Confiance', desc:'Tenir une discussion, comprendre l\'essentiel, ne plus avoir peur de parler.' },
    ] : [
      { label:'Trimestre 1', titre:'Immersion fondatrice',    desc:'Les bases ancrées dans ce que tu vis. Zéro stress, beaucoup de répétition naturelle.' },
      { label:'Trimestre 2', titre:'Construction progressive', desc:'Les structures complexes arrivent sans qu\'on les cherche.' },
      { label:'Trimestre 3', titre:'Maîtrise & Fluidité',     desc:'On affine, on nuance, on s\'exprime avec précision.' },
      { label:'Trimestre 4', titre:'Quasi-bilingue',           desc:'La langue est un outil, plus un obstacle.' },
    ];

    return `
    <div class="appr-plan-bloc">
      <div class="appr-plan-titre">📋 Ton plan sur ${duree}</div>
      <div class="appr-plan-matiere">${m.label}${p?' — par le prisme '+p.icon+' '+p.label:''}</div>
      <div class="appr-phases">
        ${phases.map((ph,i)=>`
          <div class="appr-phase">
            <div class="appr-phase-num">${ph.label}</div>
            <div class="appr-phase-titre">${ph.titre}</div>
            <div class="appr-phase-desc">${ph.desc}</div>
          </div>`).join('')}
      </div>
      <div class="appr-plan-rythme">
        <strong>Rythme :</strong> 5 à 15 minutes par jour. Dans le bus, en cuisine, entre deux choses. Pas besoin de calme ni de bureau.
      </div>
      <button class="appr-btn-principal" id="appr-premiere-session" style="margin-top:20px">
        ✊ Commencer ma première session
      </button>
    </div>`;
  },

  // ── ÉTAPE 4 : SESSION ───────────────────────────────────────
  renderSession() {
    const m = this.matieres.find(x=>x.id===this.state.matiere);
    const p = this.passions.find(x=>x.id===this.state.passion);
    const cle = (this.state.passion && this.state.matiere)
      ? this.state.passion + '+' + this.state.matiere
      : null;

    return `
    <div class="appr-header">
      <div class="appr-title">📚 SESSION 1</div>
      <div class="appr-step-label">${m?m.label:''} ${p?'— par '+p.icon+' '+p.label:''}</div>
    </div>

    <div class="appr-session-bloc">
      <div class="appr-session-intro">
        Ta première session. Pas de cours. Pas de notes. Juste toi et ce que tu sais déjà.
      </div>

      <div class="appr-session-exercice">
        <div class="appr-exo-numero">Exercice 1 — Ancrage</div>
        <div class="appr-exo-consigne">
          ${this._getExercice1()}
        </div>
        <textarea class="appr-reponse" id="appr-rep1" rows="4" placeholder="Tape ta réponse ici — il n'y a pas de mauvaise réponse..."></textarea>
        <button class="appr-btn-valider" id="appr-valider1">Valider →</button>
        <div class="appr-feedback" id="appr-feedback1" style="display:none"></div>
      </div>

      <div class="appr-session-exercice" id="appr-exo2" style="display:none">
        <div class="appr-exo-numero">Exercice 2 — Mémorisation naturelle</div>
        <div class="appr-exo-consigne">${this._getExercice2()}</div>
        <textarea class="appr-reponse" id="appr-rep2" rows="4" placeholder="Prends le temps qu'il faut..."></textarea>
        <button class="appr-btn-valider" id="appr-valider2">Terminer la session ✓</button>
        <div class="appr-feedback" id="appr-feedback2" style="display:none"></div>
      </div>
    </div>

    <div class="appr-nav" style="margin-top:20px">
      <button class="appr-btn-retour" id="appr-retour-plan">← Mon plan</button>
    </div>
    `;
  },

  _getExercice1() {
    const combos = {
      'foot+langues':   'Nomme 5 termes de foot que tu connais déjà en anglais. Tu en sais plus que tu ne crois.',
      'foot+maths':     'Ton équipe préférée a joué 10 matchs. Elle en a gagné 7. Quel est son pourcentage de victoires ?',
      'foot+geographie':'Cite 5 pays où tu connais une équipe nationale. Place-les dans ta tête sur la carte du monde.',
      'musique+langues':'Prends une chanson que tu aimes. Copie le premier couplet. Qu\'est-ce que tu comprends déjà ?',
      'cuisine+maths':  'Prends une recette que tu fais souvent. Si tu dois la faire pour 6 personnes au lieu de 4, comment tu ajustes les quantités ?',
      'voyage+langues': 'Tu arrives dans un pays étranger. Quelles sont les 5 premières phrases dont tu as besoin ? Écris-les.',
    };
    const cle = this.state.passion + '+' + this.state.matiere;
    return combos[cle] || 'Décris en quelques lignes ce que tu sais déjà sur ce sujet. Même si c\'est peu — c\'est ta base de départ.';
  },

  _getExercice2() {
    const combos = {
      'foot+langues':   'Traduis ces 5 phrases simples comme si tu commentais un match : "Il tire. Il marque. Le gardien plonge. L\'arbitre siffle. Le public applaudit."',
      'foot+maths':     'Si un joueur est payé 150 000€ par semaine, combien gagne-t-il par an ? Par mois ? Par jour ?',
      'musique+langues':'Dans la chanson que tu as choisie — trouve 3 mots que tu ne connais pas. Cherche leur sens. Écris une phrase avec chacun.',
      'cuisine+maths':  'Une recette demande 250g de farine pour 4 personnes. Tu cuisines pour 7. De combien de farine as-tu besoin ?',
      'voyage+langues': 'Écris un mini-dialogue — tu arrives à l\'hôtel, tu te présentes, tu demandes ta chambre. En anglais, avec les mots que tu as.',
    };
    const cle = this.state.passion + '+' + this.state.matiere;
    return combos[cle] || 'Explique ce que tu viens d\'apprendre comme si tu l\'expliquais à un ami. Avec tes propres mots. Pas les mots du cours.';
  },

  // ── EVENTS ──────────────────────────────────────────────────
  attachEvents() {
    // Accueil
    document.getElementById('appr-start')?.addEventListener('click', ()=>{
      this.state.etape = 'profil'; this.update();
    });

    // Profil — matières
    document.querySelectorAll('[data-matiere]').forEach(el => {
      el.addEventListener('click', ()=>{
        this.state.matiere = el.dataset.matiere;
        document.querySelectorAll('[data-matiere]').forEach(x=>x.classList.remove('actif'));
        el.classList.add('actif');
        // Afficher sous-matières
        const m = this.matieres.find(x=>x.id===el.dataset.matiere);
        const sm = document.getElementById('appr-sous-matieres');
        if(m && sm) {
          sm.style.display = 'block';
          sm.innerHTML = '<div class="appr-input-hint">Par exemple : '+m.exemples.join(', ')+'</div>';
        }
      });
    });

    // Profil — niveaux
    document.querySelectorAll('[data-niveau]').forEach(el => {
      el.addEventListener('click', ()=>{
        this.state.niveau = el.dataset.niveau;
        document.querySelectorAll('[data-niveau]').forEach(x=>x.classList.remove('actif'));
        el.classList.add('actif');
      });
    });

    // Profil — passions
    document.querySelectorAll('[data-passion]').forEach(el => {
      el.addEventListener('click', ()=>{
        this.state.passion = el.dataset.passion;
        document.querySelectorAll('[data-passion]').forEach(x=>x.classList.remove('actif'));
        el.classList.add('actif');
      });
    });

    // Navigation profil → plan
    document.getElementById('appr-vers-plan')?.addEventListener('click', ()=>{
      const prenom = document.getElementById('appr-prenom')?.value?.trim();
      if(prenom) this.state.prenom = prenom;
      if(!this.state.matiere) { alert('Choisis ce que tu veux apprendre.'); return; }
      this.state.etape = 'plan'; this.update();
    });

    document.getElementById('appr-retour-accueil')?.addEventListener('click', ()=>{
      this.state.etape = 'accueil'; this.update();
    });

    // Plan — objectifs
    document.querySelectorAll('[data-objectif]').forEach(el => {
      el.addEventListener('click', ()=>{
        this.state.objectif = el.dataset.objectif;
        document.querySelectorAll('[data-objectif]').forEach(x=>x.classList.remove('actif'));
        el.classList.add('actif');
        const dateCustom = document.getElementById('appr-date-custom');
        if(dateCustom) dateCustom.style.display = el.dataset.objectif==='custom' ? 'block' : 'none';
      });
    });

    // Plan → générer
    document.getElementById('appr-generer-plan')?.addEventListener('click', ()=>{
      if(!this.state.objectif) { alert('Choisis un objectif.'); return; }
      const dateInput = document.getElementById('appr-date-input');
      if(this.state.objectif==='custom' && dateInput) this.state.dateObjectif = dateInput.value;
      const planDiv = document.getElementById('appr-plan-genere');
      if(planDiv) {
        planDiv.style.display = 'block';
        planDiv.innerHTML = this.genererPlan();
        planDiv.scrollIntoView({ behavior:'smooth' });
        this.attachPlanEvents();
      }
    });

    document.getElementById('appr-retour-profil')?.addEventListener('click', ()=>{
      this.state.etape = 'profil'; this.update();
    });

    // Session
    document.getElementById('appr-valider1')?.addEventListener('click', ()=>{
      const rep = document.getElementById('appr-rep1')?.value?.trim();
      if(!rep || rep.length < 5) { alert('Écris quelque chose — même si c\'est court.'); return; }
      const fb = document.getElementById('appr-feedback1');
      if(fb) { fb.style.display='block'; fb.innerHTML='✅ Bien. Tu as posé une base. C\'est tout ce dont on a besoin pour commencer.'; }
      const exo2 = document.getElementById('appr-exo2');
      if(exo2) { exo2.style.display='block'; exo2.scrollIntoView({behavior:'smooth'}); }
    });

    document.getElementById('appr-valider2')?.addEventListener('click', ()=>{
      const rep = document.getElementById('appr-rep2')?.value?.trim();
      if(!rep || rep.length < 5) { alert('Finis l\'exercice — prends le temps qu\'il faut.'); return; }
      const fb = document.getElementById('appr-feedback2');
      if(fb) { fb.style.display='block'; fb.innerHTML='✊ Session 1 terminée. Reviens demain — 5 minutes suffisent. Le cerveau travaille même quand tu dors.'; }
    });

    document.getElementById('appr-retour-plan')?.addEventListener('click', ()=>{
      this.state.etape = 'plan'; this.update();
    });
  },

  attachPlanEvents() {
    document.getElementById('appr-premiere-session')?.addEventListener('click', ()=>{
      this.state.etape = 'session'; this.update();
    });
  },

  update() {
    const root = document.getElementById('appr-root');
    if(root) { root.innerHTML = this.renderEtape(); this.attachEvents(); }
  },
};

// ── STYLES ──────────────────────────────────────────────────────
const as = document.createElement('style');
as.textContent = `
.appr-container{padding:20px;max-width:900px;margin:0 auto;color:#fff;font-family:inherit}
.appr-header{margin-bottom:24px}
.appr-title{font-size:1.5em;font-weight:700;color:#4fc3f7;letter-spacing:2px;margin-bottom:6px}
.appr-subtitle{font-size:.95em;color:#ddd;margin-bottom:4px}
.appr-devise{font-size:.82em;color:#4fc3f7;font-style:italic}
.appr-step-label{font-size:.8em;color:#aaa;text-transform:uppercase;letter-spacing:1px;margin-top:4px}

.appr-intro-bloc{background:rgba(79,195,247,.07);border-left:3px solid #4fc3f7;padding:16px 20px;border-radius:0 10px 10px 0;margin-bottom:20px;line-height:1.7;font-size:.92em;color:#ddd}
.appr-intro-bloc p{margin:0 0 10px}
.appr-intro-bloc p:last-child{margin:0}

.appr-engagements{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:28px}
.appr-engagement{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:20px;padding:7px 14px;font-size:.83em;color:#ccc}

.appr-btn-principal{background:linear-gradient(135deg,#0288d1,#026da3);color:#fff;border:none;padding:13px 28px;border-radius:8px;font-size:1em;font-weight:700;cursor:pointer;transition:opacity .2s}
.appr-btn-principal:hover{opacity:.85}
.appr-btn-retour{background:transparent;border:1px solid rgba(255,255,255,.2);color:#aaa;padding:10px 20px;border-radius:8px;cursor:pointer;font-size:.9em}
.appr-btn-retour:hover{border-color:#fff;color:#fff}
.appr-btn-valider{background:rgba(79,195,247,.2);border:1px solid #4fc3f7;color:#4fc3f7;padding:10px 20px;border-radius:8px;cursor:pointer;font-size:.9em;margin-top:10px;font-weight:600}
.appr-btn-valider:hover{background:rgba(79,195,247,.35)}

.appr-section{margin-bottom:28px}
.appr-section-titre{font-size:.95em;font-weight:600;color:#fff;margin-bottom:10px}
.appr-section-hint{font-size:.82em;color:#aaa;margin-bottom:10px}
.appr-sous-section{margin-top:10px}
.appr-input-hint{font-size:.8em;color:#888;font-style:italic;padding:8px 12px;background:rgba(255,255,255,.04);border-radius:6px}

.appr-input{width:100%;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);border-radius:8px;padding:11px 14px;color:#fff;font-size:.9em;font-family:inherit;box-sizing:border-box}
.appr-input:focus{outline:none;border-color:#4fc3f7}

.appr-grid-choix{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px}
.appr-choix{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:12px 16px;cursor:pointer;font-size:.88em;color:#ccc;transition:all .2s}
.appr-choix:hover{border-color:#4fc3f7;color:#fff}
.appr-choix.actif{background:rgba(79,195,247,.15);border-color:#4fc3f7;color:#4fc3f7;font-weight:600}

.appr-grid-passions{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px}
.appr-passion{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:12px;cursor:pointer;font-size:.85em;color:#ccc;text-align:center;transition:all .2s;display:flex;flex-direction:column;align-items:center;gap:6px}
.appr-passion:hover{border-color:#f0c040;color:#fff}
.appr-passion.actif{background:rgba(240,192,64,.15);border-color:#f0c040;color:#f0c040;font-weight:600}
.appr-passion-icon{font-size:1.5em}

.appr-parallele-bloc{background:rgba(240,192,64,.08);border:1px solid rgba(240,192,64,.2);border-left:3px solid #f0c040;border-radius:0 10px 10px 0;padding:16px 20px;margin-bottom:24px}
.appr-parallele-titre{font-size:.9em;font-weight:700;color:#f0c040;margin-bottom:8px}
.appr-parallele-texte{font-size:.88em;color:#ddd;line-height:1.6}

.appr-objectifs{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;margin-bottom:16px}
.appr-objectif-carte{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:14px;cursor:pointer;transition:all .2s}
.appr-objectif-carte:hover{border-color:#4fc3f7}
.appr-objectif-carte.actif{background:rgba(79,195,247,.12);border-color:#4fc3f7}
.appr-objectif-label{font-size:1em;font-weight:700;color:#fff;margin-bottom:6px}
.appr-objectif-desc{font-size:.8em;color:#aaa;line-height:1.4}

.appr-plan-bloc{background:rgba(255,255,255,.04);border:1px solid rgba(79,195,247,.2);border-radius:12px;padding:20px;margin-top:20px}
.appr-plan-titre{font-size:1.05em;font-weight:700;color:#4fc3f7;margin-bottom:4px}
.appr-plan-matiere{font-size:.85em;color:#aaa;margin-bottom:20px}
.appr-phases{display:flex;flex-direction:column;gap:12px;margin-bottom:16px}
.appr-phase{background:rgba(255,255,255,.04);border-left:3px solid #4fc3f7;padding:12px 16px;border-radius:0 8px 8px 0}
.appr-phase-num{font-size:.75em;color:#4fc3f7;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px}
.appr-phase-titre{font-size:.95em;font-weight:600;color:#fff;margin-bottom:4px}
.appr-phase-desc{font-size:.85em;color:#ccc;line-height:1.4}
.appr-plan-rythme{font-size:.85em;color:#aaa;background:rgba(255,255,255,.04);padding:12px 16px;border-radius:8px;line-height:1.5}

.appr-session-bloc{margin-bottom:20px}
.appr-session-intro{font-size:.92em;color:#ddd;line-height:1.6;margin-bottom:24px;background:rgba(79,195,247,.07);border-left:3px solid #4fc3f7;padding:14px 18px;border-radius:0 8px 8px 0}
.appr-session-exercice{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:20px;margin-bottom:16px}
.appr-exo-numero{font-size:.75em;color:#4fc3f7;text-transform:uppercase;letter-spacing:1px;margin-bottom:10px}
.appr-exo-consigne{font-size:.95em;color:#fff;line-height:1.6;margin-bottom:14px}
.appr-reponse{width:100%;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);border-radius:8px;padding:12px;color:#fff;font-size:.9em;font-family:inherit;resize:vertical;box-sizing:border-box}
.appr-reponse:focus{outline:none;border-color:#4fc3f7}
.appr-feedback{margin-top:12px;padding:12px 16px;background:rgba(79,195,247,.1);border-left:3px solid #4fc3f7;border-radius:0 8px 8px 0;font-size:.88em;color:#ddd;line-height:1.5}

.appr-nav{display:flex;gap:12px;align-items:center;margin-top:24px;flex-wrap:wrap}
.appr-erreur{color:#e74c3c;font-size:.9em;padding:12px}
`;
document.head.appendChild(as);
window.addEventListener('load', ()=>APPRENTISSAGE.init());
