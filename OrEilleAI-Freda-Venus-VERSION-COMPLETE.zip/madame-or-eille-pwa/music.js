// ═══════════════════════════════════════════════════
//  GÉNÉRATION MUSICALE IA
//  Or Eille AI — v1.0
//  Jeff : mettre CFG.SUNO_KEY ou CFG.UDIO_KEY
// ═══════════════════════════════════════════════════

const MUSIC = {
  KEY: 'moe_music',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { tracks: [], affirmations: [] }; }
    catch { return { tracks: [], affirmations: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Générer musique via Suno API ─────────────
  // Jeff : Suno API — https://suno.com/api
  // CFG.SUNO_KEY = votre clé API Suno
  async generateWithSuno(prompt, duration = 30) {
    const key = window.CFG?.SUNO_KEY;
    if (!key) {
      // Suno optionnel - affirmations et musique web audio fonctionnent sans
      return { error: 'Génération musicale IA non activée. Les affirmations vocales fonctionnent sans cette clé.' };
    }
    try {
      // Appel via proxy Vercel pour éviter CORS
      // Jeff: créer /api/suno.js sur Vercel qui proxifie vers api.suno.com
      const r = await fetch('/api/suno', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, duration, api_key: key })
      });
      const d = await r.json();
      return d;
    } catch(e) { return { error: e.message }; }
  },

  // ─── Générer via Claude (description → prompt musical) ─
  async describeToPrompt(description, claudeKey) {
    if (!claudeKey) return description;
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 200,
          messages: [{ role: 'user', content: `Transforme cette description en prompt musical optimisé pour Suno AI (en anglais, style, instruments, ambiance, tempo). Description: "${description}"` }]
        })
      });
      const d = await r.json();
      return d.content[0].text;
    } catch { return description; }
  },

  // ─── Mode affirmations personnelles ───────────
  createAffirmation(voiceText, musicStyle, loopMinutes) {
    const d = this.get();
    const affirmation = {
      id: Date.now().toString(),
      voiceText,
      musicStyle,
      loopMinutes: loopMinutes || 5,
      createdAt: new Date().toISOString(),
      private: true // Jamais partagé sans action explicite
    };
    d.affirmations.push(affirmation);
    this.save(d);
    return affirmation;
  },

  // Lire une affirmation en boucle avec la voix système
  playAffirmationLoop(affirmation) {
    if (!window.speechSynthesis) return;
    let playing = true;
    const totalMs = affirmation.loopMinutes * 60000;
    const startTime = Date.now();

    const loop = () => {
      if (!playing || Date.now() - startTime > totalMs) {
        window.speechSynthesis.cancel();
        return;
      }
      const utt = new SpeechSynthesisUtterance(affirmation.voiceText);
      utt.lang = 'fr-FR';
      utt.rate = 0.85;
      utt.onend = () => setTimeout(loop, 2000);
      window.speechSynthesis.speak(utt);
    };

    loop();
    return { stop: () => { playing = false; window.speechSynthesis.cancel(); } };
  },

  // ─── Rendu UI ─────────────────────────────────
  renderPanel() {
    const d = this.get();
    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">
      <div class="sec-title">🎵 Générer une musique</div>
      <p class="note">Décrivez l'ambiance souhaitée — l'IA génère une musique originale sans droits.</p>
      <textarea id="musicDesc" placeholder="Ex: Musique africaine chaleureuse avec kora et percussions légères, mélancolique et apaisante..." style="min-height:80px"></textarea>
      <button class="voice-btn" onclick="startMusicVoice()">🎙 Dicter la description</button>
      <div style="display:flex;gap:.4rem">
        <select id="musicDuration" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.58rem;padding:.45rem;outline:none">
          <option value="30">30 secondes</option>
          <option value="60">1 minute</option>
          <option value="120">2 minutes</option>
          <option value="180">3 minutes</option>
        </select>
        <button class="btn btn-gold" style="flex:2" onclick="generateMusic()">🎵 Générer</button>
      </div>
      <div id="musicResult" style="display:none;padding:.7rem;border:1px solid var(--border)">
        <audio id="musicPlayer" controls style="width:100%;margin-bottom:.5rem"></audio>
        <button class="btn btn-ghost" onclick="downloadMusic()">⬇ Télécharger</button>
        <button class="btn btn-ghost" onclick="useAsBackground()">🎬 Utiliser comme fond vidéo</button>
      </div>

      <div class="sep"></div>
      <div class="sec-title">🔄 Affirmations personnelles</div>
      <p class="note">Enregistrez votre voix avec une musique douce en boucle privée. Jamais partagé.</p>
      <textarea id="affirmText" placeholder="Votre affirmation personnelle — ex: Je suis capable, je suis en paix..." style="min-height:60px"></textarea>
      <div style="display:flex;gap:.4rem;align-items:center">
        <span style="font-size:.56rem;color:var(--muted)">Durée boucle :</span>
        <select id="affirmDuration" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.58rem;padding:.45rem;outline:none">
          <option value="5">5 minutes</option>
          <option value="10">10 minutes</option>
          <option value="20">20 minutes</option>
          <option value="30">30 minutes</option>
        </select>
      </div>
      <button class="btn btn-ghost" onclick="playAffirmation()">▶ Lancer la boucle</button>
      <button class="btn btn-ghost" onclick="stopAffirmation()" id="stopAffirmBtn" style="display:none">⏹ Arrêter</button>

      ${d.tracks.length > 0 ? `
        <div class="sep"></div>
        <div class="sec-title">Mes musiques</div>
        ${d.tracks.map(t => `
          <div style="display:flex;align-items:center;justify-content:space-between;padding:.5rem 0;border-bottom:1px solid var(--border)">
            <span style="font-size:.58rem;color:var(--text)">${t.name || 'Musique sans titre'}</span>
            <button onclick="playTrack('${t.id}')" style="background:transparent;border:none;color:var(--gold);cursor:pointer;font-size:.7rem">▶</button>
          </div>
        `).join('')}
      ` : ''}
    </div>`;
  }
};

window.MUSIC = MUSIC;
let currentAffirmLoop = null;

async function generateMusic() {
  const desc = document.getElementById('musicDesc')?.value;
  const duration = document.getElementById('musicDuration')?.value;
  if (!desc) { if(window.speak) speak('Décrivez d\'abord la musique souhaitée.'); return; }

  if (window.addChatMsg) addChatMsg('assistant', '🎵 Génération de la musique en cours…');
  if (window.speak) speak('Génération musicale en cours. Cela peut prendre quelques instants.');

  const claudeKey = window.CFG?.CLAUDE_KEY || getKey?.('claudeKey');
  const prompt = await MUSIC.describeToPrompt(desc, claudeKey);

  const result = await MUSIC.generateWithSuno(prompt, parseInt(duration));

  if (result?.error) {
    // Fallback — synthèse web audio simple
    if (window.addChatMsg) addChatMsg('assistant', `Note : ${result.error}. Jeff doit configurer CFG.SUNO_KEY pour la génération musicale IA. En attendant, utilisez une musique royalty-free.`);
    return;
  }

  if (result?.audio_url) {
    const player = document.getElementById('musicPlayer');
    if (player) { player.src = result.audio_url; document.getElementById('musicResult').style.display = 'block'; }
    if (window.addChatMsg) addChatMsg('assistant', '✓ Musique générée. Elle vous appartient — aucun droit d\'auteur.');
    if (window.speak) speak('Votre musique est prête.');
  }
}

function startMusicVoice() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return;
  const r = new SR(); r.lang = 'fr-FR'; r.continuous = false;
  r.onresult = e => { document.getElementById('musicDesc').value = e.results[0][0].transcript; };
  r.start();
}

function playAffirmation() {
  const text = document.getElementById('affirmText')?.value;
  const mins = parseInt(document.getElementById('affirmDuration')?.value || 5);
  if (!text) { if(window.speak) speak('Entrez votre affirmation.'); return; }

  const aff = MUSIC.createAffirmation(text, 'douce', mins);
  currentAffirmLoop = MUSIC.playAffirmationLoop(aff);
  document.getElementById('stopAffirmBtn').style.display = 'block';
  if (window.addChatMsg) addChatMsg('assistant', `▶ Affirmation en boucle pendant ${mins} minutes. Espace privé — jamais partagé.`);
}

function stopAffirmation() {
  if (currentAffirmLoop) { currentAffirmLoop.stop(); currentAffirmLoop = null; }
  document.getElementById('stopAffirmBtn').style.display = 'none';
  if (window.addChatMsg) addChatMsg('assistant', '⏹ Boucle arrêtée.');
}

function downloadMusic() {
  const player = document.getElementById('musicPlayer');
  if (!player?.src) return;
  const a = document.createElement('a'); a.href = player.src; a.download = 'or-eille-musique.mp3';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
}

function useAsBackground() {
  const player = document.getElementById('musicPlayer');
  if (!player?.src) return;
  window.backgroundMusicUrl = player.src;
  if (window.addChatMsg) addChatMsg('assistant', '✓ Musique sélectionnée comme fond pour vos vidéos.');
  showPanel('video');
}
