// ============================================================
// WEB STUDIO — Or Eille AI v20
// Module de création de sites et applis sans développeur
// © 2026 Madame Or Eille Studios
// ============================================================

const WEB_STUDIO = {

  // ─── État ───────────────────────────────────────────────
  state: {
    etape: 'accueil', // accueil | description | generation | resultat
    typeProjet: null,
    description: '',
    codeGenere: null,
    nomProjet: '',
    historique: []
  },

  // ─── Types de projets ───────────────────────────────────
  typesProjet: [
    {
      id: 'vitrine',
      emoji: '🏠',
      label: 'Site vitrine',
      description: 'Je me présente, je montre mon travail, les gens me contactent.',
      exemples: ['Artiste', 'Photographe', 'Coach', 'Artisan']
    },
    {
      id: 'boutique',
      emoji: '🛒',
      label: 'Boutique en ligne',
      description: 'Je vends mes produits directement.',
      exemples: ['Ebook', 'Bijoux', 'Vêtements', 'Produits faits main']
    },
    {
      id: 'ebook',
      emoji: '📖',
      label: 'Page de vente ebook',
      description: 'Une page simple pour vendre mon livre ou guide.',
      exemples: ['Recettes', 'Guide beauté', 'Conseils parentalité', 'Formation']
    },
    {
      id: 'appli',
      emoji: '📱',
      label: 'Mini appli',
      description: 'Un outil simple pour mes utilisateurs.',
      exemples: ['Quiz', 'Calculateur', 'Générateur', 'Agenda']
    },
    {
      id: 'jeu',
      emoji: '🎮',
      label: 'Petit jeu',
      description: 'Un jeu simple jouable dans le navigateur.',
      exemples: ['Quiz culture', 'Jeu de mots', 'Puzzle', 'Jeu éducatif']
    },
    {
      id: 'manga',
      emoji: '📚',
      label: 'Galerie / Manga',
      description: 'Je partage mes créations visuelles et histoires.',
      exemples: ['BD en ligne', 'Galerie photos', 'Portfolio illustrateur']
    },
    {
      id: 'communaute',
      emoji: '👥',
      label: 'Page communauté',
      description: 'Je crée un espace pour rassembler mes fans ou mon groupe.',
      exemples: ['Newsletter', 'Forum simple', 'Club privé', 'Groupe de soutien']
    },
    {
      id: 'autre',
      emoji: '✨',
      label: 'Autre projet',
      description: 'J\'ai une idée unique — je la décris à ma façon.',
      exemples: []
    }
  ],

  // ─── Initialisation ─────────────────────────────────────
  init() {
    this.renderPanel();
    console.log('✅ Web Studio initialisé');
  },

  // ─── Rendu principal ────────────────────────────────────
  renderPanel() {
    const panel = document.getElementById('panel-webstudio');
    if (!panel) return;

    panel.innerHTML = `
      <div class="ws-container">
        <div class="ws-header">
          <div class="ws-title">🌐 WEB STUDIO</div>
          <div class="ws-subtitle">Crée ton site, ton appli, ton projet — sans développeur.</div>
          <div class="ws-subtitle-small">Tu décris. Or Eille AI construit. Tu télécharges.</div>
        </div>

        <div class="ws-etapes" id="ws-etapes">
          ${this.renderEtapeActuelle()}
        </div>
      </div>
    `;

    this.attachEvents();
  },

  // ─── Rendu étape ────────────────────────────────────────
  renderEtapeActuelle() {
    switch (this.state.etape) {
      case 'accueil': return this.renderAccueil();
      case 'description': return this.renderDescription();
      case 'generation': return this.renderGeneration();
      case 'resultat': return this.renderResultat();
      default: return this.renderAccueil();
    }
  },

  // ─── Étape 1 : Choix du type de projet ──────────────────
  renderAccueil() {
    return `
      <div class="ws-section">
        <div class="ws-question">Qu'est-ce que tu veux créer ?</div>
        <div class="ws-types-grid">
          ${this.typesProjet.map(t => `
            <div class="ws-type-card" data-type="${t.id}">
              <div class="ws-type-emoji">${t.emoji}</div>
              <div class="ws-type-label">${t.label}</div>
              <div class="ws-type-desc">${t.description}</div>
              ${t.exemples.length > 0 ? `
                <div class="ws-type-exemples">
                  ${t.exemples.map(e => `<span class="ws-tag">${e}</span>`).join('')}
                </div>
              ` : ''}
            </div>
          `).join('')}
        </div>
      </div>
    `;
  },

  // ─── Étape 2 : Description du projet ────────────────────
  renderDescription() {
    const type = this.typesProjet.find(t => t.id === this.state.typeProjet);
    return `
      <div class="ws-section">
        <div class="ws-retour" id="ws-retour">← Changer de type</div>
        <div class="ws-question">
          ${type.emoji} ${type.label} — Décris ton projet
        </div>
        <div class="ws-hint">
          Parle naturellement. Dis-moi : ton nom, ce que tu fais, pour qui c'est, ce que tu veux vendre ou montrer, 
          tes couleurs préférées si tu en as. Pas besoin d'être technique.
        </div>

        <div class="ws-form">
          <div class="ws-field">
            <label>Nom de ton projet ou de toi</label>
            <input type="text" id="ws-nom" placeholder="Ex: Awa Couture, Les Recettes de Mamie, Studio Kongo..." />
          </div>

          <div class="ws-field">
            <label>Décris ton projet en quelques phrases</label>
            <textarea id="ws-description" rows="6" 
              placeholder="Ex: Je m'appelle Awa, je crée des robes traditionnelles modernisées. Je veux un site pour montrer mes créations et que les clients puissent me contacter directement. Mes couleurs préférées sont le doré et le bordeaux..."></textarea>
          </div>

          <div class="ws-field">
            <label>Langue principale du site</label>
            <div class="ws-langues">
              ${['Français', 'English', 'Español', 'Português', 'العربية', 'Lingala', 'Wolof', 'Bambara', 'Autre'].map(l => `
                <button class="ws-langue-btn ${l === 'Français' ? 'active' : ''}" data-langue="${l}">${l}</button>
              `).join('')}
            </div>
          </div>

          <button class="ws-btn-generate" id="ws-generer">
            ✨ Générer mon projet
          </button>
        </div>
      </div>
    `;
  },

  // ─── Étape 3 : Génération en cours ──────────────────────
  renderGeneration() {
    return `
      <div class="ws-section ws-generation">
        <div class="ws-loading-icon">🔨</div>
        <div class="ws-loading-title">Or Eille AI construit ton projet...</div>
        <div class="ws-loading-steps">
          <div class="ws-loading-step active" id="step1">📐 Conception de la structure</div>
          <div class="ws-loading-step" id="step2">🎨 Création du design</div>
          <div class="ws-loading-step" id="step3">✍️ Rédaction du contenu</div>
          <div class="ws-loading-step" id="step4">⚡ Optimisation du code</div>
          <div class="ws-loading-step" id="step5">📦 Préparation du téléchargement</div>
        </div>
        <div class="ws-loading-message">Ça prend environ 30 secondes...</div>
      </div>
    `;
  },

  // ─── Étape 4 : Résultat ─────────────────────────────────
  renderResultat() {
    return `
      <div class="ws-section">
        <div class="ws-succes">
          <div class="ws-succes-icon">🎉</div>
          <div class="ws-succes-titre">Ton projet est prêt !</div>
          <div class="ws-succes-nom">${this.state.nomProjet}</div>
        </div>

        <div class="ws-apercu-container">
          <div class="ws-apercu-label">Aperçu</div>
          <iframe id="ws-apercu" class="ws-apercu" sandbox="allow-scripts"></iframe>
        </div>

        <div class="ws-actions">
          <button class="ws-btn-primary" id="ws-telecharger">
            ⬇️ Télécharger mon site
          </button>
          <button class="ws-btn-secondary" id="ws-modifier">
            ✏️ Je veux modifier quelque chose
          </button>
          <button class="ws-btn-tertiary" id="ws-recommencer">
            🔄 Créer un autre projet
          </button>
        </div>

        <div class="ws-suite">
          <div class="ws-suite-titre">Et maintenant ?</div>
          <div class="ws-suite-item">📤 <strong>Mettre en ligne</strong> — Envoie le fichier à un hébergeur (Vercel, Netlify — gratuits) ou demande de l'aide dans la communauté Or Eille.</div>
          <div class="ws-suite-item">🔧 <strong>Un bug ?</strong> — Décris le problème, Or Eille AI le corrige.</div>
          <div class="ws-suite-item">💳 <strong>Vendre en ligne</strong> — Ajoute Stripe à ton site pour encaisser.</div>
        </div>
      </div>
    `;
  },

  // ─── Événements ─────────────────────────────────────────
  attachEvents() {
    // Choix du type de projet
    document.querySelectorAll('.ws-type-card').forEach(card => {
      card.addEventListener('click', () => {
        this.state.typeProjet = card.dataset.type;
        this.state.etape = 'description';
        this.updateEtapes();
      });
    });

    // Retour
    const retour = document.getElementById('ws-retour');
    if (retour) {
      retour.addEventListener('click', () => {
        this.state.etape = 'accueil';
        this.updateEtapes();
      });
    }

    // Langues
    document.querySelectorAll('.ws-langue-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.ws-langue-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.state.langue = btn.dataset.langue;
      });
    });

    // Générer
    const generer = document.getElementById('ws-generer');
    if (generer) {
      generer.addEventListener('click', () => this.lancerGeneration());
    }

    // Télécharger
    const telecharger = document.getElementById('ws-telecharger');
    if (telecharger) {
      telecharger.addEventListener('click', () => this.telecharger());
    }

    // Modifier
    const modifier = document.getElementById('ws-modifier');
    if (modifier) {
      modifier.addEventListener('click', () => {
        this.state.etape = 'description';
        this.updateEtapes();
      });
    }

    // Recommencer
    const recommencer = document.getElementById('ws-recommencer');
    if (recommencer) {
      recommencer.addEventListener('click', () => {
        this.state = { etape: 'accueil', typeProjet: null, description: '', codeGenere: null, nomProjet: '', historique: [] };
        this.updateEtapes();
      });
    }
  },

  // ─── Lancer la génération ────────────────────────────────
  async lancerGeneration() {
    const nom = document.getElementById('ws-nom')?.value?.trim();
    const description = document.getElementById('ws-description')?.value?.trim();
    const langue = document.querySelector('.ws-langue-btn.active')?.dataset?.langue || 'Français';

    if (!nom || !description) {
      alert('Merci de remplir ton nom et la description de ton projet.');
      return;
    }

    this.state.nomProjet = nom;
    this.state.description = description;
    this.state.langue = langue;
    this.state.etape = 'generation';
    this.updateEtapes();

    // Animation des étapes
    this.animerEtapesGeneration();

    try {
      const type = this.typesProjet.find(t => t.id === this.state.typeProjet);
      const prompt = this.construirePrompt(type, nom, description, langue);
      const code = await this.appelClaude(prompt);
      this.state.codeGenere = code;
      this.state.etape = 'resultat';
      this.updateEtapes();
      this.afficherApercu(code);
    } catch (err) {
      console.error('Erreur génération:', err);
      alert('Une erreur est survenue. Réessaie dans quelques secondes.');
      this.state.etape = 'description';
      this.updateEtapes();
    }
  },

  // ─── Animation étapes de génération ─────────────────────
  animerEtapesGeneration() {
    const steps = ['step1', 'step2', 'step3', 'step4', 'step5'];
    let i = 0;
    const interval = setInterval(() => {
      if (i > 0) {
        const prev = document.getElementById(steps[i - 1]);
        if (prev) { prev.classList.remove('active'); prev.classList.add('done'); }
      }
      const current = document.getElementById(steps[i]);
      if (current) current.classList.add('active');
      i++;
      if (i >= steps.length) clearInterval(interval);
    }, 5000);
  },

  // ─── Construction du prompt ──────────────────────────────
  construirePrompt(type, nom, description, langue) {
    return `Tu es un développeur web expert. Crée un fichier HTML complet, autonome, prêt à utiliser, pour le projet suivant.

TYPE DE PROJET: ${type.label}
NOM: ${nom}
DESCRIPTION: ${description}
LANGUE: ${langue}

RÈGLES ABSOLUES:
- Un seul fichier HTML avec CSS et JavaScript intégrés
- Design moderne, professionnel, adapté au mobile
- Contenu réel basé sur la description (pas de lorem ipsum)
- Couleurs harmonieuses, typographie lisible
- Toutes les sections pertinentes pour ce type de projet
- Si boutique: ajouter des exemples de produits avec prix
- Si jeu: le jeu doit fonctionner
- Si portfolio: galerie avec placeholders élégants

Réponds UNIQUEMENT avec le code HTML complet. Pas d'explication. Pas de markdown. Juste le code.`;
  },

  // ─── Appel Claude API ────────────────────────────────────
  async appelClaude(prompt) {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 8000,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    if (!response.ok) throw new Error('API error: ' + response.status);
    const data = await response.json();
    return data.content[0].text;
  },

  // ─── Afficher l'aperçu ───────────────────────────────────
  afficherApercu(code) {
    const iframe = document.getElementById('ws-apercu');
    if (!iframe) return;
    const blob = new Blob([code], { type: 'text/html' });
    iframe.src = URL.createObjectURL(blob);
  },

  // ─── Télécharger le fichier ──────────────────────────────
  telecharger() {
    if (!this.state.codeGenere) return;
    const blob = new Blob([this.state.codeGenere], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const nomFichier = this.state.nomProjet.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') || 'mon-projet';
    a.href = url;
    a.download = `${nomFichier}.html`;
    a.click();
    URL.revokeObjectURL(url);
  },

  // ─── Mise à jour de l'affichage ─────────────────────────
  updateEtapes() {
    const container = document.getElementById('ws-etapes');
    if (!container) return;
    container.innerHTML = this.renderEtapeActuelle();
    this.attachEvents();
  }
};

// ─── CSS du module ───────────────────────────────────────────
const wsStyle = document.createElement('style');
wsStyle.textContent = `
  .ws-container {
    padding: 20px;
    max-width: 900px;
    margin: 0 auto;
    font-family: inherit;
    color: #fff;
  }

  .ws-header {
    margin-bottom: 30px;
  }

  .ws-title {
    font-size: 1.4em;
    font-weight: 700;
    color: #f0c040;
    letter-spacing: 2px;
    margin-bottom: 6px;
  }

  .ws-subtitle {
    font-size: 1em;
    color: #fff;
    margin-bottom: 4px;
  }

  .ws-subtitle-small {
    font-size: 0.85em;
    color: #aaa;
  }

  .ws-question {
    font-size: 1.1em;
    font-weight: 600;
    color: #f0c040;
    margin-bottom: 20px;
  }

  .ws-types-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
  }

  .ws-type-card {
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 10px;
    padding: 16px;
    cursor: pointer;
    transition: all 0.2s;
  }

  .ws-type-card:hover {
    background: rgba(240,192,64,0.15);
    border-color: #f0c040;
    transform: translateY(-2px);
  }

  .ws-type-emoji {
    font-size: 2em;
    margin-bottom: 8px;
  }

  .ws-type-label {
    font-weight: 600;
    margin-bottom: 6px;
    color: #fff;
  }

  .ws-type-desc {
    font-size: 0.82em;
    color: #bbb;
    margin-bottom: 8px;
    line-height: 1.4;
  }

  .ws-type-exemples {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
  }

  .ws-tag {
    background: rgba(240,192,64,0.2);
    color: #f0c040;
    font-size: 0.72em;
    padding: 2px 7px;
    border-radius: 20px;
  }

  .ws-retour {
    color: #aaa;
    cursor: pointer;
    font-size: 0.85em;
    margin-bottom: 16px;
    display: inline-block;
  }

  .ws-retour:hover { color: #f0c040; }

  .ws-hint {
    background: rgba(240,192,64,0.1);
    border-left: 3px solid #f0c040;
    padding: 12px 16px;
    border-radius: 0 8px 8px 0;
    font-size: 0.88em;
    color: #ddd;
    margin-bottom: 20px;
    line-height: 1.5;
  }

  .ws-form { display: flex; flex-direction: column; gap: 16px; }

  .ws-field { display: flex; flex-direction: column; gap: 6px; }

  .ws-field label {
    font-size: 0.85em;
    color: #ccc;
    font-weight: 500;
  }

  .ws-field input, .ws-field textarea {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 8px;
    padding: 12px;
    color: #fff;
    font-size: 0.95em;
    font-family: inherit;
    resize: vertical;
    transition: border 0.2s;
  }

  .ws-field input:focus, .ws-field textarea:focus {
    outline: none;
    border-color: #f0c040;
  }

  .ws-langues {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .ws-langue-btn {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.15);
    color: #ccc;
    padding: 6px 12px;
    border-radius: 20px;
    cursor: pointer;
    font-size: 0.82em;
    transition: all 0.2s;
  }

  .ws-langue-btn:hover, .ws-langue-btn.active {
    background: rgba(240,192,64,0.2);
    border-color: #f0c040;
    color: #f0c040;
  }

  .ws-btn-generate {
    background: linear-gradient(135deg, #f0c040, #e08020);
    color: #111;
    border: none;
    padding: 14px 24px;
    border-radius: 8px;
    font-size: 1em;
    font-weight: 700;
    cursor: pointer;
    transition: opacity 0.2s;
    margin-top: 8px;
  }

  .ws-btn-generate:hover { opacity: 0.9; }

  /* Génération */
  .ws-generation {
    text-align: center;
    padding: 40px 20px;
  }

  .ws-loading-icon {
    font-size: 3em;
    animation: bounce 1s infinite;
    margin-bottom: 16px;
  }

  @keyframes bounce {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
  }

  .ws-loading-title {
    font-size: 1.2em;
    font-weight: 600;
    color: #f0c040;
    margin-bottom: 24px;
  }

  .ws-loading-steps {
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-width: 400px;
    margin: 0 auto 20px;
  }

  .ws-loading-step {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    padding: 10px 16px;
    border-radius: 8px;
    font-size: 0.88em;
    color: #666;
    transition: all 0.4s;
  }

  .ws-loading-step.active {
    background: rgba(240,192,64,0.15);
    border-color: #f0c040;
    color: #f0c040;
  }

  .ws-loading-step.done {
    background: rgba(0,200,100,0.1);
    border-color: rgba(0,200,100,0.3);
    color: #0c8;
  }

  .ws-loading-message {
    color: #888;
    font-size: 0.85em;
  }

  /* Résultat */
  .ws-succes {
    text-align: center;
    margin-bottom: 24px;
  }

  .ws-succes-icon { font-size: 2.5em; margin-bottom: 8px; }

  .ws-succes-titre {
    font-size: 1.2em;
    font-weight: 700;
    color: #0c8;
    margin-bottom: 4px;
  }

  .ws-succes-nom {
    font-size: 1em;
    color: #f0c040;
  }

  .ws-apercu-container {
    margin-bottom: 20px;
  }

  .ws-apercu-label {
    font-size: 0.82em;
    color: #aaa;
    margin-bottom: 8px;
  }

  .ws-apercu {
    width: 100%;
    height: 400px;
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 10px;
    background: #fff;
  }

  .ws-actions {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 24px;
  }

  .ws-btn-primary {
    background: linear-gradient(135deg, #f0c040, #e08020);
    color: #111;
    border: none;
    padding: 14px;
    border-radius: 8px;
    font-size: 1em;
    font-weight: 700;
    cursor: pointer;
  }

  .ws-btn-secondary {
    background: rgba(255,255,255,0.08);
    color: #fff;
    border: 1px solid rgba(255,255,255,0.2);
    padding: 12px;
    border-radius: 8px;
    font-size: 0.95em;
    cursor: pointer;
  }

  .ws-btn-tertiary {
    background: transparent;
    color: #aaa;
    border: none;
    padding: 10px;
    font-size: 0.88em;
    cursor: pointer;
  }

  .ws-suite {
    background: rgba(255,255,255,0.04);
    border-radius: 10px;
    padding: 16px;
  }

  .ws-suite-titre {
    font-weight: 600;
    color: #f0c040;
    margin-bottom: 12px;
    font-size: 0.9em;
  }

  .ws-suite-item {
    font-size: 0.85em;
    color: #ccc;
    margin-bottom: 8px;
    line-height: 1.5;
  }
`;
document.head.appendChild(wsStyle);

// ─── Initialisation au chargement ───────────────────────────
window.addEventListener('load', () => WEB_STUDIO.init());
