// ═══════════════════════════════════════════════════
//  TRACKER D'HABITUDES, CHALLENGES & BIEN-ÊTRE
//  Or Eille AI — v1.0
//  15 mai 2026
// ═══════════════════════════════════════════════════

const TRACKER = {
  KEY: 'moe_tracker',
  SESSION_START: Date.now(),
  PAUSE_TIMER: null,
  HEALTH_TIMER: null,

  // ─── Données ──────────────────────────────────
  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { habits: [], entries: [], challenges: [], sessions: [] }; }
    catch { return { habits: [], entries: [], challenges: [], sessions: [] }; }
  },
  save(data) { localStorage.setItem(this.KEY, JSON.stringify(data)); },

  // ─── Habitudes ────────────────────────────────
  addHabit(name, type, goal, unit) {
    const d = this.get();
    d.habits.push({
      id: Date.now().toString(),
      name, type, goal, unit,
      createdAt: new Date().toISOString(),
      active: true
    });
    this.save(d);
    return d.habits[d.habits.length - 1];
  },

  logEntry(habitId, value, note = '') {
    const d = this.get();
    d.entries.push({ habitId, value: parseFloat(value) || 0, note, at: new Date().toISOString() });
    this.save(d);
    return this.getEncouragement(habitId);
  },

  getStats(habitId, days = 30) {
    const d = this.get();
    const since = new Date(Date.now() - days * 86400000);
    const entries = d.entries.filter(e => e.habitId === habitId && new Date(e.at) > since);
    const total = entries.reduce((sum, e) => sum + e.value, 0);
    const avg = entries.length ? (total / entries.length).toFixed(1) : 0;
    return { total, avg, count: entries.length, entries };
  },

  getEncouragement(habitId) {
    const recent = this.getStats(habitId, 7);
    const prev = this.getStats(habitId, 14);
    const d = this.get();
    const habit = d.habits.find(h => h.id === habitId);
    if (!habit) return '';
    if (recent.count === 0) return `Commencez à suivre "${habit.name}" dès aujourd'hui.`;
    if (recent.avg < prev.avg * 0.85) return `📈 Progrès réel sur "${habit.name}" — cette semaine c'est mieux qu'il y a deux semaines. Continuez.`;
    if (recent.count >= 5) return `✓ Bonne régularité sur "${habit.name}" — ${recent.count} entrées cette semaine.`;
    return `"${habit.name}" — ${recent.count} fois notée cette semaine.`;
  },

  // ─── Challenges ───────────────────────────────
  addChallenge(name, description, durationDays, targetValue, unit) {
    const d = this.get();
    const startDate = new Date();
    const endDate = new Date(Date.now() + durationDays * 86400000);
    d.challenges.push({
      id: Date.now().toString(),
      name, description, durationDays, targetValue, unit,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      entries: [],
      active: true
    });
    this.save(d);
    return d.challenges[d.challenges.length - 1];
  },

  logChallenge(challengeId, value, note = '') {
    const d = this.get();
    const ch = d.challenges.find(c => c.id === challengeId);
    if (!ch) return;
    ch.entries.push({ value: parseFloat(value) || 0, note, at: new Date().toISOString() });
    const progress = ch.entries.reduce((sum, e) => sum + e.value, 0);
    const pct = Math.min(100, Math.round(progress / ch.targetValue * 100));
    this.save(d);
    if (pct >= 100) return `🎉 Challenge "${ch.name}" complété ! Bravo — vous avez atteint votre objectif.`;
    return `Challenge "${ch.name}" : ${pct}% accompli. ${ch.targetValue - progress} ${ch.unit} restants.`;
  },

  getChallengeProgress(challengeId) {
    const d = this.get();
    const ch = d.challenges.find(c => c.id === challengeId);
    if (!ch) return null;
    const total = ch.entries.reduce((sum, e) => sum + e.value, 0);
    const daysLeft = Math.ceil((new Date(ch.endDate) - new Date()) / 86400000);
    const pct = Math.min(100, Math.round(total / ch.targetValue * 100));
    return { total, pct, daysLeft, done: pct >= 100 };
  },

  // ─── Détection signaux de détresse ────────────
  DISTRESS_PATTERNS: [
    /je veux mourir/i, /envie de mourir/i, /plus envie de vivre/i,
    /me suicider/i, /mettre fin/i, /en finir/i, /plus la force/i,
    /je me fais du mal/i, /je me blesse/i, /automutilation/i,
    /je ne mange plus/i, /je ne mange pas/i, /je vomis/i,
    /je bois trop/i, /je ne peux plus m'arrêter/i, /addiction/i,
    /je suis seule/i, /personne ne m'aime/i, /personne s'en fiche/i,
    /tout est inutile/i, /ça ne sert à rien/i,
  ],

  HARMFUL_INTENT_PATTERNS: [
    /faire du mal à/i, /blesser/i, /me venger/i, /lui faire payer/i,
    /harceler/i, /surveiller/i, /espionner/i, /isoler/i,
    /manipuler/i, /contrôler/i,
  ],

  checkDistress(text) {
    if (this.DISTRESS_PATTERNS.some(p => p.test(text))) return 'distress';
    if (this.HARMFUL_INTENT_PATTERNS.some(p => p.test(text))) return 'harmful';
    return 'ok';
  },

  getDistressResponse(type) {
    if (type === 'distress') return `Je vous entends. Ce que vous traversez semble difficile et douloureux.

Vous n'avez pas à traverser ça seule. Des personnes formées pour écouter sont disponibles maintenant :

📞 **3114** — Numéro national prévention suicide (France, 24h/24)
📞 **3018** — Cyberharcèlement et mal-être numérique
💬 **suicide-ecoute.fr** — Chat en ligne

Et si vous souhaitez une vraie écoute humaine, **Madame Or Eille** est là pour ça.

Voulez-vous qu'on trouve ensemble un professionnel près de chez vous ?`;

    if (type === 'harmful') return `Je sens qu'il y a beaucoup de douleur derrière ce que vous décrivez. Vouloir blesser quelqu'un vient souvent d'une blessure profonde qu'on porte soi-même.

Blesser l'autre ne guérit pas cette douleur — souvent ça l'aggrave.

Voulez-vous qu'on parle de ce qui se passe vraiment ? Il existe des ressources pour traverser ça autrement.`;

    return '';
  },

  // ─── Gestion du temps & bien-être ─────────────
  startSessionTracking() {
    this.SESSION_START = Date.now();
    this.scheduleHealthReminders();
  },

  scheduleHealthReminders() {
    // Rappel toutes les 90 minutes
    clearInterval(this.PAUSE_TIMER);
    this.PAUSE_TIMER = setInterval(() => {
      const mins = Math.round((Date.now() - this.SESSION_START) / 60000);
      this.showHealthReminder(mins);
    }, 90 * 60 * 1000);

    // Règle 20-20-20 pour les yeux — toutes les 20 minutes
    clearInterval(this.HEALTH_TIMER);
    this.HEALTH_TIMER = setInterval(() => {
      this.showEyeReminder();
    }, 20 * 60 * 1000);
  },

  showHealthReminder(mins) {
    const hour = new Date().getHours();
    const isLate = hour >= 22 || hour < 6;
    const msg = isLate
      ? `Il est ${hour}h. Vous travaillez depuis ${mins} minutes. Il est tard — votre cerveau a besoin de repos. Fermez l'appli, tout sera là demain exactement où vous vous êtes arrêtée.`
      : `Vous travaillez depuis ${mins} minutes. Pause recommandée — un verre d'eau, deux minutes d'étirements de nuque et de mains. Votre créativité vous remerciera.`;

    // Afficher dans l'interface
    if (window.addChatMsg) {
      window.addChatMsg('assistant', msg);
      if (window.speak) window.speak(msg);
    }
  },

  showEyeReminder() {
    // Règle 20-20-20 — discrète, juste une notification
    if (window.addChatMsg) {
      const msg = '👁 Règle 20-20-20 : regardez quelque chose à 6 mètres pendant 20 secondes pour reposer vos yeux.';
      window.addChatMsg('assistant', msg);
    }
  },

  detectCompulsiveUsage() {
    const d = this.get();
    const now = new Date();
    const today = now.toDateString();
    const todaySessions = (d.sessions || []).filter(s => new Date(s.at).toDateString() === today);

    d.sessions = d.sessions || [];
    d.sessions.push({ at: now.toISOString() });
    this.save(d);

    if (todaySessions.length >= 5) {
      return `Je remarque que c'est votre ${todaySessions.length + 1}ème session aujourd'hui. Est-ce que vous cherchez quelque chose de précis, ou avez-vous besoin d'une vraie pause ?`;
    }
    return null;
  },

  // ─── Journal relationnel ───────────────────────
  logRelationalEntry(person, count, context) {
    const d = this.get();
    d.relational = d.relational || [];
    d.relational.push({ person, count, context, at: new Date().toISOString() });
    this.save(d);

    if (count > 50) {
      return `Vous avez mentionné ${count} messages envoyés à ${person}. C'est beaucoup — pour vous et pour cette personne. Comment vous sentez-vous par rapport à ça ?`;
    }
    return null;
  },

  // ─── Ressources locales ───────────────────────
  async findLocalResource(type, location) {
    // Via recherche web dans l'assistant Claude
    const queries = {
      'suicide': `professionnel santé mentale psychiatre ${location}`,
      'addiction': `centre addictologie soin ${location}`,
      'alimentation': `diététicien nutritionniste ${location}`,
      'violence': `association aide victimes violence ${location}`,
      'solitude': `association lien social bénévolat ${location}`,
    };
    return queries[type] || `professionnel aide psychologique ${location}`;
  },

  // ─── Mode accident créatif ────────────────────
  ANOMALY_PROMPT: `Analyse cette image générée et détecte les anomalies ou éléments inattendus.
Pour chaque anomalie trouvée, indique :
1. Sa localisation dans l'image (haut gauche, centre, etc.)
2. Ce que l'IA a probablement interprété
3. Si c'est une erreur probable ou un accident potentiellement créatif intéressant
Réponds en JSON : { anomalies: [{ location, description, type: "error"|"creative", suggestion }] }
Sois concis et précis.`,

  async detectAnomalies(imageUrl, claudeKey) {
    if (!claudeKey || !imageUrl) return null;
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 500,
          messages: [{
            role: 'user',
            content: [
              { type: 'image', source: { type: 'url', url: imageUrl } },
              { type: 'text', text: this.ANOMALY_PROMPT }
            ]
          }]
        })
      });
      const d = await r.json();
      const text = d.content[0].text;
      const clean = text.replace(/```json|```/g, '').trim();
      return JSON.parse(clean);
    } catch { return null; }
  },

  renderAnomalyUI(anomalies) {
    if (!anomalies || !anomalies.anomalies || anomalies.anomalies.length === 0) return '';
    return anomalies.anomalies.map(a => `
      <div style="border:1px solid ${a.type==='creative'?'var(--gold)':'var(--border)'};padding:.6rem;margin-bottom:.4rem;font-size:.58rem;line-height:1.6">
        <strong style="color:${a.type==='creative'?'var(--gold)':'var(--red)'}">
          ${a.type==='creative'?'✦ Accident créatif potentiel':'⚠ Anomalie détectée'}
        </strong> — ${a.location}<br/>
        ${a.description}<br/>
        <div style="display:flex;gap:.3rem;margin-top:.4rem">
          <button onclick="handleAnomaly('remove','${a.location}')" style="flex:1;padding:.3rem;background:transparent;border:1px solid var(--border);color:var(--muted);font-family:'Josefin Sans',sans-serif;font-size:.48rem;letter-spacing:.08em;text-transform:uppercase;cursor:pointer">✕ Supprimer</button>
          <button onclick="handleAnomaly('keep','${a.location}')" style="flex:1;padding:.3rem;background:transparent;border:1px solid var(--gold);color:var(--gold);font-family:'Josefin Sans',sans-serif;font-size:.48rem;letter-spacing:.08em;text-transform:uppercase;cursor:pointer">◎ Conserver</button>
          <button onclick="handleAnomaly('amplify','${a.location}')" style="flex:1;padding:.3rem;background:var(--gold);color:var(--dark);border:none;font-family:'Josefin Sans',sans-serif;font-size:.48rem;letter-spacing:.08em;text-transform:uppercase;cursor:pointer">↑ Amplifier</button>
        </div>
      </div>
    `).join('');
  },
};

// ─── Exposer globalement ──────────────────────────
window.TRACKER = TRACKER;

// ─── Démarrer le suivi de session ─────────────────
window.addEventListener('load', () => {
  setTimeout(() => {
    TRACKER.startSessionTracking();
    const compulsive = TRACKER.detectCompulsiveUsage();
    if (compulsive && window.addChatMsg) {
      window.addChatMsg('assistant', compulsive);
    }
  }, 2000);
});

// ─── Gestionnaire d'anomalie ──────────────────────
function handleAnomaly(action, location) {
  const messages = {
    remove: `Supprimer l'anomalie en ${location} — générez à nouveau en ajoutant au prompt : "corriger les anomalies en ${location}, rendu propre et cohérent."`,
    keep: `Anomalie conservée. Elle fait maintenant partie de votre création telle quelle.`,
    amplify: `Amplifier l'effet en ${location} — générez à nouveau en ajoutant au prompt : "amplifier et développer artistiquement l'effet inattendu en ${location}."`,
  };
  if (window.addChatMsg) window.addChatMsg('assistant', messages[action]);
  if (window.speak) window.speak(messages[action]);
}
