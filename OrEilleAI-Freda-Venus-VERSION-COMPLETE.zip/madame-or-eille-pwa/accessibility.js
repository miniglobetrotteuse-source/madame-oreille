// accessibility.js — Or Eille AI v1.0
const A11Y = {
  KEY: 'moe_a11y',
  get() { try { return JSON.parse(localStorage.getItem(this.KEY)) || { fontSize:'medium', fontFamily:'standard', highContrast:false, subtitles:true, vibration:true, flashAlerts:true, signLanguage:false, signLanguageType:'LSF', avatarSkin:'afro', simplifiedMode:false, tdahMode:false }; } catch { return {}; } },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },
  set(key, value) { const d = this.get(); d[key] = value; this.save(d); this.apply(); },
  apply() {
    const s = this.get();
    const sizes = { small:'13px', medium:'16px', large:'20px', xlarge:'24px' };
    document.documentElement.style.setProperty('--base-font', sizes[s.fontSize]||'16px');
    if (s.fontFamily==='dyslexic') { document.body.style.letterSpacing='0.1em'; document.body.style.lineHeight='1.8'; document.body.style.wordSpacing='0.2em'; }
    else { document.body.style.letterSpacing=''; document.body.style.lineHeight=''; document.body.style.wordSpacing=''; }
    if (s.highContrast) { document.documentElement.style.setProperty('--text','#ffffff'); document.documentElement.style.setProperty('--dark','#000000'); }
  },
  showSubtitle(text) {
    const s = this.get(); if (!s.subtitles) return;
    let el = document.getElementById('a11y-sub');
    if (!el) { el = document.createElement('div'); el.id='a11y-sub'; el.style.cssText='position:fixed;bottom:80px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.85);color:#fff;padding:.6rem 1.2rem;border-radius:4px;font-size:.7rem;max-width:80%;text-align:center;z-index:9000;font-family:"Josefin Sans",sans-serif;pointer-events:none;'; document.body.appendChild(el); }
    el.textContent = text.substring(0,150); el.style.display='block';
    clearTimeout(el._t); el._t = setTimeout(()=>el.style.display='none', 5000);
  },
  triggerAlert(msg, type='info') {
    const s = this.get();
    if (s.vibration && navigator.vibrate) navigator.vibrate(type==='urgent'?[200,100,200]:[ 100,50,100]);
    if (s.flashAlerts) { const f=document.createElement('div'); f.style.cssText=`position:fixed;inset:0;background:${type==='urgent'?'rgba(224,80,80,.3)':'rgba(201,168,76,.2)'};z-index:9999;pointer-events:none;`; document.body.appendChild(f); setTimeout(()=>f.remove(),300); }
    this.showSubtitle(msg);
  },
  AVATARS: { afro:{emoji:'🧑🏿',label:'Afro (défaut)'}, afro_f:{emoji:'👩🏿',label:'Afro féminin'}, medium:{emoji:'🧑🏽',label:'Méditerranéen'}, light:{emoji:'🧑🏼',label:'Clair'}, asian:{emoji:'🧑🏻',label:'Asiatique'} },
  SIGN_LANGUAGES: { LSF:{label:'LSF — Langue des Signes Française'}, ASL:{label:'ASL — American Sign Language'}, LSB:{label:'LIBRAS — Langue des Signes Brésilienne'} },
  showSignAvatar(text) {
    const s = this.get(); if (!s.signLanguage) return;
    const av = this.AVATARS[s.avatarSkin]||this.AVATARS.afro;
    let el = document.getElementById('a11y-avatar');
    if (!el) { el=document.createElement('div'); el.id='a11y-avatar'; el.style.cssText='position:fixed;bottom:80px;right:16px;width:70px;height:70px;background:var(--dark-mid);border:2px solid var(--gold);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:2rem;z-index:9001;'; document.body.appendChild(el); }
    el.textContent = av.emoji; el.style.display='flex';
    this.showSubtitle(`[${s.signLanguageType}] ${text.substring(0,100)}`);
  },
  TDAH_TIMER: null,
  startTDAHMode() { clearInterval(this.TDAH_TIMER); this.TDAH_TIMER = setInterval(()=>{ if(window.addChatMsg) addChatMsg('assistant','⏸ Pause de 2 minutes recommandée — étirez-vous, respirez.'); }, 20*60*1000); },
  VOICE_COMMANDS: { 'composition':()=>showPanel('compose'), 'assistant':()=>showPanel('assistant'), 'mise en page':()=>showPanel('layout'), 'rédaction':()=>showPanel('writing'), 'vidéo':()=>showPanel('video'), 'mémoire':()=>showPanel('profile'), 'tracker':()=>showPanel('tracker'), 'paramètres':()=>showPanel('settings'), 'finance':()=>showPanel('finance'), 'générer':()=>{if(window.generate)generate();}, 'aide':()=>A11Y.readHelp() },
  startVoiceNav() {
    const SR = window.SpeechRecognition||window.webkitSpeechRecognition; if(!SR) return;
    const r = new SR(); r.lang='fr-FR'; r.continuous=true; r.interimResults=false;
    r.onresult = e => { const cmd = e.results[e.results.length-1][0].transcript.toLowerCase();
      const h = Object.entries(this.VOICE_COMMANDS).find(([k])=>cmd.includes(k));
      if(h){h[1]();this.triggerAlert('Commande : '+h[0]);} };
    r.start(); if(window.addChatMsg) addChatMsg('assistant','🎙 Navigation vocale activée.');
  },
  readHelp() { const h='Panneaux : Composition, Assistant, Mise en page, Rédaction, Vidéo, Mémoire, Tracker, Paramètres, Finance. Dites Générer pour créer.'; if(window.speak)speak(h); this.showSubtitle(h); },
  renderPanel() {
    const s = this.get();
    return `<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">
      <div class="sec-title">👁 Vision & Lecture</div>
      <div><span class="klabel">Taille du texte</span><div style="display:flex;gap:.3rem;margin-top:.3rem">${['small','medium','large','xlarge'].map((sz,i)=>`<button onclick="A11Y.set('fontSize','${sz}')" class="${s.fontSize===sz?'tbtn active':'tbtn'}" style="flex:1;font-size:${['.6rem','.75rem','.9rem','1.1rem'][i]}">A</button>`).join('')}</div></div>
      <label style="display:flex;align-items:center;gap:.5rem;font-size:.58rem;color:var(--muted);cursor:pointer"><input type="checkbox" ${s.fontFamily==='dyslexic'?'checked':''} onchange="A11Y.set('fontFamily',this.checked?'dyslexic':'standard')" style="accent-color:var(--gold)"/> Police adaptée dyslexie</label>
      <label style="display:flex;align-items:center;gap:.5rem;font-size:.58rem;color:var(--muted);cursor:pointer"><input type="checkbox" ${s.highContrast?'checked':''} onchange="A11Y.set('highContrast',this.checked)" style="accent-color:var(--gold)"/> Contraste élevé</label>
      <div class="sep"></div>
      <div class="sec-title">👂 Malentendants</div>
      <label style="display:flex;align-items:center;gap:.5rem;font-size:.58rem;color:var(--muted);cursor:pointer"><input type="checkbox" ${s.subtitles?'checked':''} onchange="A11Y.set('subtitles',this.checked)" style="accent-color:var(--gold)"/> Sous-titres temps réel</label>
      <label style="display:flex;align-items:center;gap:.5rem;font-size:.58rem;color:var(--muted);cursor:pointer"><input type="checkbox" ${s.vibration?'checked':''} onchange="A11Y.set('vibration',this.checked)" style="accent-color:var(--gold)"/> Vibrations pour alertes</label>
      <label style="display:flex;align-items:center;gap:.5rem;font-size:.58rem;color:var(--muted);cursor:pointer"><input type="checkbox" ${s.flashAlerts?'checked':''} onchange="A11Y.set('flashAlerts',this.checked)" style="accent-color:var(--gold)"/> Flash visuel pour alertes</label>
      <label style="display:flex;align-items:center;gap:.5rem;font-size:.58rem;color:var(--muted);cursor:pointer"><input type="checkbox" ${s.signLanguage?'checked':''} onchange="A11Y.set('signLanguage',this.checked)" style="accent-color:var(--gold)"/> Avatar interprète langue des signes</label>
      ${s.signLanguage?`<div><span class="klabel">Langue des signes</span><select onchange="A11Y.set('signLanguageType',this.value)" style="width:100%;margin-top:.3rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.58rem;padding:.45rem;outline:none">${Object.entries(A11Y.SIGN_LANGUAGES).map(([k,l])=>`<option value="${k}" ${s.signLanguageType===k?'selected':''}>${l.label}</option>`).join('')}</select></div><div><span class="klabel">Avatar</span><div style="display:flex;gap:.4rem;margin-top:.3rem">${Object.entries(A11Y.AVATARS).map(([k,a])=>`<button onclick="A11Y.set('avatarSkin','${k}')" style="font-size:1.5rem;background:${s.avatarSkin===k?'var(--gold)':'var(--dark-mid)'};border:1px solid var(--border);padding:.3rem;cursor:pointer;border-radius:4px">${a.emoji}</button>`).join('')}</div><p style="font-size:.46rem;color:var(--muted);margin-top:.4rem">V2 — Langues des signes vernaculaires africaines à venir avec partenaires communautaires</p></div>`:''}
      <div class="sep"></div>
      <div class="sec-title">🧠 Cognitif & TDAH</div>
      <label style="display:flex;align-items:center;gap:.5rem;font-size:.58rem;color:var(--muted);cursor:pointer"><input type="checkbox" ${s.simplifiedMode?'checked':''} onchange="A11Y.set('simplifiedMode',this.checked)" style="accent-color:var(--gold)"/> Mode simplifié</label>
      <label style="display:flex;align-items:center;gap:.5rem;font-size:.58rem;color:var(--muted);cursor:pointer"><input type="checkbox" ${s.tdahMode?'checked':''} onchange="A11Y.set('tdahMode',this.checked);if(this.checked)A11Y.startTDAHMode()" style="accent-color:var(--gold)"/> Mode TDAH — pauses toutes les 20 min</label>
      <div class="sep"></div>
      <div class="sec-title">🎙 Navigation vocale</div>
      <button class="btn btn-ghost" onclick="A11Y.startVoiceNav()">🎙 Activer navigation vocale</button>
      <button class="btn btn-ghost" onclick="A11Y.readHelp()">📢 Lire les commandes</button>
    </div>`;
  }
};
window.A11Y = A11Y;
window.addEventListener('load',()=>{
  setTimeout(()=>{
    A11Y.apply();
    const orig = window.addChatMsg;
    if(orig) window.addChatMsg = function(role,text){ orig(role,text); if(role==='assistant'){A11Y.showSubtitle(text);A11Y.showSignAvatar(text);} };
  },1000);
});
