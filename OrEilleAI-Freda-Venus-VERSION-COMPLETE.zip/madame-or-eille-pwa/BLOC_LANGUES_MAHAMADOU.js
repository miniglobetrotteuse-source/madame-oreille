// ============================================================
// BLOC LANGUES — Or Eille AI v20
// À copier-coller dans le fichier de configuration des langues
// Toutes les langues avec ville et pays — version corrigée et vérifiée
// © 2026 Madame Or Eille Studios
// ============================================================

const LANGUES_DISPONIBLES = [

  // ── FRANÇAIS ET VARIANTES ──────────────────────────────────
  { code:'fr-FR', label:'Français', ville:'Paris',          pays:'🇫🇷 France' },
  { code:'fr-BE', label:'Français', ville:'Bruxelles',      pays:'🇧🇪 Belgique' },
  { code:'fr-CH', label:'Français', ville:'Genève',         pays:'🇨🇭 Suisse' },
  { code:'fr-CA', label:'Français', ville:'Montréal',       pays:'🇨🇦 Canada' },
  { code:'fr-CI', label:'Français', ville:'Abidjan',        pays:'🇨🇮 Côte d\'Ivoire' },
  { code:'fr-SN', label:'Français', ville:'Dakar',          pays:'🇸🇳 Sénégal' },
  { code:'fr-CM', label:'Français', ville:'Yaoundé',        pays:'🇨🇲 Cameroun' },
  { code:'fr-CG', label:'Français', ville:'Brazzaville',    pays:'🇨🇬 Congo' },
  { code:'fr-CD', label:'Français', ville:'Kinshasa',       pays:'🇨🇩 RDC' },
  { code:'fr-ML', label:'Français', ville:'Bamako',         pays:'🇲🇱 Mali' },
  { code:'fr-BF', label:'Français', ville:'Ouagadougou',    pays:'🇧🇫 Burkina Faso' },
  { code:'fr-TG', label:'Français', ville:'Lomé',           pays:'🇹🇬 Togo' },
  { code:'fr-BJ', label:'Français', ville:'Cotonou',        pays:'🇧🇯 Bénin' },
  { code:'fr-GN', label:'Français', ville:'Conakry',        pays:'🇬🇳 Guinée' },
  { code:'fr-MG', label:'Français', ville:'Antananarivo',   pays:'🇲🇬 Madagascar' },
  { code:'fr-HT', label:'Français', ville:'Port-au-Prince', pays:'🇭🇹 Haïti' },
  { code:'fr-GP', label:'Français', ville:'Pointe-à-Pitre', pays:'🇬🇵 Guadeloupe' },
  { code:'fr-MQ', label:'Français', ville:'Fort-de-France', pays:'🇲🇶 Martinique' },
  { code:'fr-GF', label:'Français', ville:'Cayenne',        pays:'🇬🇫 Guyane' },
  { code:'fr-RE', label:'Français', ville:'Saint-Denis',    pays:'🇷🇪 La Réunion' },

  // ── ANGLAIS ET VARIANTES ───────────────────────────────────
  { code:'en-GB', label:'Anglais', ville:'Londres',         pays:'🇬🇧 Royaume-Uni' },
  { code:'en-US', label:'Anglais', ville:'New York',        pays:'🇺🇸 États-Unis' },
  { code:'en-CA', label:'Anglais', ville:'Toronto',         pays:'🇨🇦 Canada' },
  { code:'en-AU', label:'Anglais', ville:'Sydney',          pays:'🇦🇺 Australie' },
  { code:'en-NG', label:'Anglais', ville:'Lagos',           pays:'🇳🇬 Nigeria' },
  { code:'en-GH', label:'Anglais', ville:'Accra',           pays:'🇬🇭 Ghana' },
  { code:'en-KE', label:'Anglais', ville:'Nairobi',         pays:'🇰🇪 Kenya' },
  { code:'en-ZA', label:'Anglais', ville:'Johannesburg',    pays:'🇿🇦 Afrique du Sud' },
  { code:'en-JM', label:'Anglais', ville:'Kingston',        pays:'🇯🇲 Jamaïque' },
  { code:'en-TT', label:'Anglais', ville:'Port of Spain',   pays:'🇹🇹 Trinité-et-Tobago' },

  // ── ESPAGNOL ET VARIANTES ──────────────────────────────────
  { code:'es-ES', label:'Espagnol', ville:'Madrid',         pays:'🇪🇸 Espagne' },
  { code:'es-MX', label:'Espagnol', ville:'Mexico',         pays:'🇲🇽 Mexique' },
  { code:'es-CO', label:'Espagnol', ville:'Bogotá',         pays:'🇨🇴 Colombie' },
  { code:'es-AR', label:'Espagnol', ville:'Buenos Aires',   pays:'🇦🇷 Argentine' },
  { code:'es-PE', label:'Espagnol', ville:'Lima',           pays:'🇵🇪 Pérou' },
  { code:'es-CU', label:'Espagnol', ville:'La Havane',      pays:'🇨🇺 Cuba' },
  { code:'es-DO', label:'Espagnol', ville:'Saint-Domingue', pays:'🇩🇴 Rép. Dominicaine' },

  // ── PORTUGAIS ET VARIANTES ─────────────────────────────────
  { code:'pt-PT', label:'Portugais', ville:'Lisbonne',      pays:'🇵🇹 Portugal' },
  { code:'pt-BR', label:'Portugais', ville:'São Paulo',     pays:'🇧🇷 Brésil' },
  { code:'pt-AO', label:'Portugais', ville:'Luanda',        pays:'🇦🇴 Angola' },
  { code:'pt-MZ', label:'Portugais', ville:'Maputo',        pays:'🇲🇿 Mozambique' },
  { code:'pt-CV', label:'Portugais', ville:'Praia',         pays:'🇨🇻 Cap-Vert' },

  // ── ALLEMAND ET VARIANTES ──────────────────────────────────
  { code:'de-DE', label:'Allemand', ville:'Berlin',         pays:'🇩🇪 Allemagne' },
  { code:'de-AT', label:'Allemand', ville:'Vienne',         pays:'🇦🇹 Autriche' },
  { code:'de-CH', label:'Allemand', ville:'Zurich',         pays:'🇨🇭 Suisse' },

  // ── ARABE ET VARIANTES ─────────────────────────────────────
  { code:'ar-EG', label:'Arabe', ville:'Le Caire',          pays:'🇪🇬 Égypte' },
  { code:'ar-MA', label:'Arabe', ville:'Casablanca',        pays:'🇲🇦 Maroc' },
  { code:'ar-DZ', label:'Arabe', ville:'Alger',             pays:'🇩🇿 Algérie' },
  { code:'ar-TN', label:'Arabe', ville:'Tunis',             pays:'🇹🇳 Tunisie' },
  { code:'ar-MR', label:'Arabe', ville:'Nouakchott',        pays:'🇲🇷 Mauritanie' },

  // ── CRÉOLES ────────────────────────────────────────────────
  { code:'ht',  label:'Kréyòl ayisyen',      ville:'Port-au-Prince', pays:'🇭🇹 Haïti' },
  { code:'gcf', label:'Kréyòl gwadloupéyen', ville:'Pointe-à-Pitre', pays:'🇬🇵 Guadeloupe' },
  { code:'mcf', label:'Kréyòl matinitjen',   ville:'Fort-de-France', pays:'🇲🇶 Martinique' },
  { code:'gcr', label:'Kréyòl guyanais',     ville:'Cayenne',        pays:'🇬🇫 Guyane' },
  { code:'rcf', label:'Kréyòl réyoné',       ville:'Saint-Denis',    pays:'🇷🇪 La Réunion' },

  // ── LANGUES AFRICAINES ─────────────────────────────────────
  // Congo & RDC
  { code:'ln-CG', label:'Lingala', ville:'Brazzaville',     pays:'🇨🇬 Congo' },
  { code:'ln-CD', label:'Lingala', ville:'Kinshasa',        pays:'🇨🇩 RDC' },
  { code:'lua',   label:'Tshiluba', ville:'Mbuji-Mayi',     pays:'🇨🇩 RDC' },
  { code:'kg',    label:'Kikongo',  ville:'Matadi',         pays:'🇨🇩 RDC / 🇨🇬 Congo' },
  { code:'sg',    label:'Sango',    ville:'Bangui',         pays:'🇨🇫 Centrafrique' },

  // Sénégal & Gambie
  { code:'wo',  label:'Wolof',    ville:'Dakar',            pays:'🇸🇳 Sénégal' },
  { code:'ff-SN', label:'Peul / Pulaar', ville:'Saint-Louis', pays:'🇸🇳 Sénégal' },

  // Bénin
  { code:'fon', label:'Fon',      ville:'Abomey / Cotonou', pays:'🇧🇯 Bénin' },
  { code:'yo-BJ', label:'Yoruba', ville:'Porto-Novo',       pays:'🇧🇯 Bénin' },

  // Burkina Faso
  { code:'mos', label:'Mooré',    ville:'Ouagadougou',      pays:'🇧🇫 Burkina Faso' },
  { code:'dyu', label:'Dioula',   ville:'Bobo-Dioulasso',   pays:'🇧🇫 Burkina Faso' },
  { code:'ff-BF', label:'Peul / Fulfuldé', ville:'Dori',    pays:'🇧🇫 Burkina Faso' },

  // Côte d'Ivoire
  { code:'dyu-CI', label:'Dioula / Jula', ville:'Abidjan',  pays:'🇨🇮 Côte d\'Ivoire' },
  { code:'bci',    label:'Baoulé',        ville:'Bouaké',   pays:'🇨🇮 Côte d\'Ivoire' },

  // Mali
  { code:'bam', label:'Bambara', ville:'Bamako',            pays:'🇲🇱 Mali' },
  { code:'ff-ML', label:'Peul / Fulfuldé', ville:'Mopti',   pays:'🇲🇱 Mali' },

  // Niger
  { code:'ha-NE', label:'Haoussa', ville:'Zinder',          pays:'🇳🇪 Niger' },
  { code:'dje',   label:'Zarma / Djerma', ville:'Niamey',   pays:'🇳🇪 Niger' },

  // Nigeria
  { code:'yo',  label:'Yoruba',  ville:'Lagos / Ibadan',    pays:'🇳🇬 Nigeria' },
  { code:'ig',  label:'Igbo',    ville:'Enugu / Onitsha',   pays:'🇳🇬 Nigeria' },
  { code:'ha',  label:'Haoussa', ville:'Kano',              pays:'🇳🇬 Nigeria' },
  { code:'ff-NG', label:'Peul / Fulfuldé', ville:'Yola',    pays:'🇳🇬 Nigeria' },

  // Ghana & Togo
  { code:'ak',  label:'Twi / Akan', ville:'Kumasi / Accra', pays:'🇬🇭 Ghana' },
  { code:'ee',  label:'Ewé',        ville:'Lomé',           pays:'🇹🇬 Togo / 🇬🇭 Ghana' },

  // Guinée & Sierra Leone
  { code:'ff-GN', label:'Peul / Pular', ville:'Labé / Conakry', pays:'🇬🇳 Guinée' },
  { code:'sus',   label:'Soussou',      ville:'Conakry',    pays:'🇬🇳 Guinée' },
  { code:'men',   label:'Mende',        ville:'Bo',         pays:'🇸🇱 Sierra Leone' },

  // Cameroun
  { code:'ff-CM', label:'Peul / Fulfuldé', ville:'Maroua',  pays:'🇨🇲 Cameroun' },
  { code:'bas',   label:'Bassa',           ville:'Douala',  pays:'🇨🇲 Cameroun' },
  { code:'dua',   label:'Douala',          ville:'Douala',  pays:'🇨🇲 Cameroun' },
  { code:'bum',   label:'Bulu / Beti',     ville:'Yaoundé', pays:'🇨🇲 Cameroun' },

  // Afrique de l'Est
  { code:'sw-KE', label:'Swahili', ville:'Nairobi / Mombasa', pays:'🇰🇪 Kenya' },
  { code:'sw-TZ', label:'Swahili', ville:'Dar es Salaam',     pays:'🇹🇿 Tanzanie' },
  { code:'rw',    label:'Kinyarwanda', ville:'Kigali',         pays:'🇷🇼 Rwanda' },
  { code:'rn',    label:'Kirundi',     ville:'Bujumbura',      pays:'🇧🇮 Burundi' },
  { code:'am',    label:'Amharique',   ville:'Addis-Abeba',    pays:'🇪🇹 Éthiopie' },
  { code:'om',    label:'Oromo',       ville:'Dire Dawa',      pays:'🇪🇹 Éthiopie' },
  { code:'ti',    label:'Tigrigna',    ville:'Asmara',         pays:'🇪🇷 Érythrée' },
  { code:'so',    label:'Somali',      ville:'Mogadiscio',     pays:'🇸🇴 Somalie' },

  // Afrique Australe
  { code:'mg',  label:'Malgache',  ville:'Antananarivo',    pays:'🇲🇬 Madagascar' },
  { code:'zu',  label:'Zulu',      ville:'Durban',          pays:'🇿🇦 Afrique du Sud' },
  { code:'xh',  label:'Xhosa',     ville:'Le Cap',          pays:'🇿🇦 Afrique du Sud' },
  { code:'st',  label:'Sotho',     ville:'Maseru',          pays:'🇱🇸 Lesotho' },
  { code:'sn',  label:'Shona',     ville:'Harare',          pays:'🇿🇼 Zimbabwe' },
  { code:'ny',  label:'Chichewa',  ville:'Lilongwe',        pays:'🇲🇼 Malawi' },
  { code:'bem', label:'Bemba',     ville:'Lusaka / Ndola',  pays:'🇿🇲 Zambie' },

  // ── AUTRES LANGUES INTERNATIONALES ────────────────────────
  { code:'nl',  label:'Néerlandais', ville:'Amsterdam',     pays:'🇳🇱 Pays-Bas / 🇸🇷 Suriname' },
  { code:'it',  label:'Italien',     ville:'Rome',          pays:'🇮🇹 Italie' },
  { code:'ru',  label:'Russe',       ville:'Moscou',        pays:'🇷🇺 Russie' },
  { code:'zh',  label:'Mandarin',    ville:'Pékin',         pays:'🇨🇳 Chine' },
  { code:'ja',  label:'Japonais',    ville:'Tokyo',         pays:'🇯🇵 Japon' },
  { code:'ko',  label:'Coréen',      ville:'Seoul',         pays:'🇰🇷 Corée du Sud' },
  { code:'hi',  label:'Hindi',       ville:'Mumbai',        pays:'🇮🇳 Inde' },
  { code:'tr',  label:'Turc',        ville:'Istanbul',      pays:'🇹🇷 Turquie' },
  { code:'sr',  label:'Serbe',       ville:'Belgrade',      pays:'🇷🇸 Serbie' },
  { code:'hr',  label:'Croate',      ville:'Zagreb',        pays:'🇭🇷 Croatie' },
  { code:'ro',  label:'Roumain',     ville:'Bucarest',      pays:'🇷🇴 Roumanie' },
  { code:'pl',  label:'Polonais',    ville:'Varsovie',      pays:'🇵🇱 Pologne' },
  { code:'uk',  label:'Ukrainien',   ville:'Kyiv',          pays:'🇺🇦 Ukraine' },

];

// Retourne le label formaté : "Français — Paris 🇫🇷 France"
function formatLangue(l) {
  return l.label + ' — ' + l.ville + ' ' + l.pays;
}

// Grouper par langue principale (pour un menu déroulant groupé)
function grouperParLangue() {
  const groupes = {};
  LANGUES_DISPONIBLES.forEach(function(l) {
    if(!groupes[l.label]) groupes[l.label] = [];
    groupes[l.label].push(l);
  });
  return groupes;
}
