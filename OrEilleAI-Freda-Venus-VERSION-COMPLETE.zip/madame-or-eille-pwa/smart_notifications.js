// ═══════════════════════════════════════════════════
//  NOTIFICATIONS INTELLIGENTES — Or Eille AI v1.0
//  Rappel publication — jamais trop — jamais oublier
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const NOTIF = {
  KEY: 'moe_notif',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { lastPublished: null, frequency: 3, enabled: true, ideas: [] }; }
    catch { return { lastPublished: null, frequency: 3, enabled: true, ideas: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  markPublished() {
    const d = this.get();
    d.lastPublished = new Date().toISOString();
    this.save(d);
    if (window.addChatMsg) addChatMsg('assistant','Publication enregistree. Or Eille AI vous rappellera dans ' + d.frequency + ' jours si vous n avez pas publie.');
  },

  async checkAndNotify(claudeKey) {
    const d = this.get();
    if (!d.enabled) return;
    if (!d.lastPublished) {
      if (window.addChatMsg) addChatMsg('assistant','Enregistrez vos publications pour que Or Eille AI vous rappelle au bon moment.');
      return;
    }

    const daysSince = (new Date() - new Date(d.lastPublished)) / (1000*60*60*24);
    if (daysSince < d.frequency) return;

    if (window.addChatMsg) addChatMsg('assistant',
      'Vous n avez pas publie depuis ' + Math.floor(daysSince) + ' jours.\n\n' +
      'Ce n est pas un reproche — peut-etre que vous en aviez besoin. Mais si vous etes pret(e)...'
    );

    if (claudeKey) {
      try {
        const r = await fetch('https://api.anthropic.com/v1/messages', {
          method:'POST',
          headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
          body: JSON.stringify({
            model:'claude-sonnet-4-20250514', max_tokens:400,
            messages:[{ role:'user', content:'Propose 3 idees de contenu rapides et concretes pour un createur qui n a pas publie depuis ' + Math.floor(daysSince) + ' jours. Courtes, actionnables, motivantes. Une par ligne avec un emoji.' }]
          })
        });
        const data = await r.json();
        if (window.addChatMsg) addChatMsg('assistant', 'Voici 3 idees pour vous relancer :\n\n' + data.content[0].text);
      } catch(e) {}
    }
  },

  init() {
    // Demander permission notifications
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
    // Vérifier toutes les heures
    setInterval(function() { NOTIF.checkAndNotify(window.CFG && window.CFG.CLAUDE_KEY); }, 3600000);
  },

  renderPanel: function() {
    const d = this.get();
    const daysSince = d.lastPublished ? Math.floor((new Date() - new Date(d.lastPublished)) / (1000*60*60*24)) : null;

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🔔 Rappels intelligents</div>' +
      '<p class="note">Or Eille AI vous rappelle gentiment quand vous n avez pas publie depuis un moment. Jamais culpabilisant. Toujours bienveillant.</p>' +
      (daysSince !== null ? '<div style="padding:.5rem;border:1px solid var(--border);font-size:.54rem;color:var(--text)">Derniere publication : il y a ' + daysSince + ' jour(s)</div>' : '') +
      '<div style="display:flex;gap:.4rem;align-items:center">' +
        '<span class="klabel">Me rappeler si je ne publie pas depuis</span>' +
        '<select id="notif-freq" onchange="const d2=NOTIF.get();d2.frequency=parseInt(this.value);NOTIF.save(d2)" style="background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.56rem;padding:.3rem;outline:none">' +
          [1,2,3,5,7,14].map(function(n) { return '<option value="' + n + '" ' + (d.frequency===n?'selected':'') + '>' + n + ' jour(s)</option>'; }).join('') +
        '</select>' +
      '</div>' +
      '<button class="btn btn-gold" onclick="NOTIF.markPublished()">✅ J ai publie aujourd hui</button>' +
      '<button class="btn btn-ghost" onclick="NOTIF.checkAndNotify(window.CFG&&window.CFG.CLAUDE_KEY)">💡 Donner-moi des idees maintenant</button>' +
    '</div>';
  }
};

window.NOTIF = NOTIF;
window.addEventListener('load', function() { setTimeout(function() { NOTIF.init(); }, 3000); });
