// ═══════════════════════════════════════════════════
//  PAGES D'ERREUR — Or Eille AI
//  Avec un peu d'humour et beaucoup d'oreilles
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const ERROR_PAGES = {

  // ─── Messages selon gravité ───────────────────
  MESSAGES: {
    leger: [
      { titre: "Petite otite en cours 🦻", texte: "On a les oreilles un peu bouchées. On va voir le médecin et on revient vous écouter encore mieux. Dans quelques minutes." },
      { titre: "Rhume de l'oreille 🤧", texte: "Rien de grave. Un peu de repos et on revient. Revenez dans un moment." },
      { titre: "L'oreille fait la sieste 😴", texte: "Elle se repose pour mieux vous écouter après. Revenez dans quelques instants." },
    ],
    moyen: [
      { titre: "L'ORL est en action 👨‍⚕️", texte: "L'oreilliste nous oblige à poser des drains. On vous entend dans quelques heures. Merci de votre patience." },
      { titre: "Consultation chez l'ORL 🏥", texte: "Diagnostic en cours. L'oreille a besoin d'un peu de soin. On revient dans quelques heures." },
      { titre: "Ordonnance en cours 📋", texte: "Le médecin nous a prescrit un peu de repos technique. On revient ce soir ou demain matin." },
    ],
    grave: [
      { titre: "Grosse otite 😷", texte: "L'ORL nous oblige au repos complet. On met des drains, on prend des antibiotiques, et on revient dans quelques jours pour vous écouter encore mieux qu'avant." },
      { titre: "Hospitalisation d'urgence 🚑", texte: "L'oreille est en soins intensifs. Le pronostic est bon — on revient bientôt, plus forte et plus à l'écoute que jamais." },
      { titre: "L'oreille est en convalescence 🛏️", texte: "Grosse otite. Repos forcé prescrit par l'ORL. On revient dans quelques jours. Promis." },
    ],
  },

  // ─── Afficher une page d'erreur ───────────────
  show(gravite = 'leger', duree = '', customMsg = null) {
    const msgs = this.MESSAGES[gravite] || this.MESSAGES.leger;
    const msg = customMsg || msgs[Math.floor(Math.random() * msgs.length)];

    const overlay = document.createElement('div');
    overlay.id = 'error-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:#F5F0E8;z-index:99997;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:2rem;text-align:center';
    overlay.innerHTML = `
      <div style="font-size:3rem;margin-bottom:1rem">👂</div>
      <div style="font-family:'Cormorant Garamond',serif;font-size:.8rem;color:#8B6914;margin-bottom:.3rem;font-style:italic">
        Or Eille AI
      </div>
      <h2 style="font-family:'Cormorant Garamond',serif;font-size:1.1rem;color:#333;margin-bottom:.8rem;font-weight:400">
        ${msg.titre}
      </h2>
      <p style="font-size:.6rem;color:#666;line-height:1.9;max-width:300px;margin-bottom:1.2rem">
        ${msg.texte}
      </p>
      ${duree ? `<p style="font-size:.5rem;color:#999;margin-bottom:1rem">Retour prévu : ${duree}</p>` : ''}
      <button onclick="location.reload()"
        style="padding:.6rem 1.2rem;background:#8B6914;color:#fff;border:none;font-family:inherit;font-size:.55rem;cursor:pointer;letter-spacing:.05em">
        Réessayer
      </button>
      <p style="font-size:.45rem;color:#bbb;margin-top:1.2rem;max-width:260px;line-height:1.7">
        Si le problème persiste, c'est que l'oreille est vraiment très malade.<br>
        Revenez demain. 🌸
      </p>`;
    document.body.appendChild(overlay);
  },

  // ─── Page 404 ─────────────────────────────────
  show404() {
    this.show('leger', '', {
      titre: "Cette oreille n'existe pas 🔍",
      texte: "On a cherché partout. Cette page n'est pas dans notre oreille. Retournez à l'accueil.",
    });
    // Ajouter bouton accueil
    setTimeout(() => {
      const overlay = document.getElementById('error-overlay');
      if (overlay) {
        const btn = document.createElement('button');
        btn.textContent = "← Retour à l'accueil";
        btn.style.cssText = 'margin-top:.5rem;padding:.5rem 1rem;background:transparent;border:1px solid #ccc;color:#888;font-family:inherit;font-size:.5rem;cursor:pointer';
        btn.onclick = () => { overlay.remove(); };
        overlay.querySelector('div:last-child')?.before(btn);
      }
    }, 100);
  },

  // ─── Maintenance programmée ───────────────────
  showMaintenance(duree) {
    this.show('moyen', duree);
  },

  // ─── Panne critique ───────────────────────────
  showCritical(duree) {
    this.show('grave', duree);
  },

  // ─── Masquer ──────────────────────────────────
  hide() {
    const overlay = document.getElementById('error-overlay');
    if (overlay) overlay.remove();
  },
};

window.ERROR_PAGES = ERROR_PAGES;

// Intercepter les erreurs critiques non gérées
window.addEventListener('unhandledrejection', (e) => {
  if (window.ADMIN) ADMIN.logError('unhandled_promise', e.reason?.message || 'Promise rejetée');
});
