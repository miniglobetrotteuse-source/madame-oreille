// ═══════════════════════════════════════════════════
//  COLLABORATION TEMPS RÉEL — Or Eille AI v1.0
//  Co-créer en direct — chacun voit tout
//  Historique horodaté — accord avant de commencer
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const COLLAB = {
  KEY: 'moe_collab',
  _channel: null,
  _sessionId: null,
  _myName: null,

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { sessions: [] }; }
    catch { return { sessions: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Créer une session ────────────────────────
  createSession(title, myName, collaborator, myShare) {
    if (!title || !myName || !collaborator) {
      if (window.addChatMsg) addChatMsg('assistant', 'Remplissez tous les champs.');
      return;
    }
    const sessionId = 'collab_' + Date.now().toString(36) + Math.random().toString(36).substr(2,4);
    const session = {
      id: sessionId,
      title,
      owner: myName,
      collaborator,
      ownerShare: myShare || 50,
      collaboratorShare: 100 - (myShare || 50),
      content: '',
      log: [],
      status: 'active',
      createdAt: new Date().toISOString(),
      agreement: {
        agreedAt: new Date().toISOString(),
        terms: myName + ' possede ' + (myShare||50) + '% et ' + collaborator + ' possede ' + (100-(myShare||50)) + '% de cette creation.',
      }
    };

    const d = this.get();
    d.sessions.unshift(session);
    this.save(d);

    this._sessionId = sessionId;
    this._myName = myName;

    const link = window.location.origin + '?collab=' + sessionId + '&name=' + encodeURIComponent(collaborator);
    navigator.clipboard && navigator.clipboard.writeText(link).catch(function(){});

    if (window.addChatMsg) addChatMsg('assistant', '✅ Session creee !\n\nLien copie — envoyez-le a ' + collaborator + ' via WhatsApp ou Telegram.\n\nAccord enregistre : ' + session.agreement.terms + '\n\nQuand ' + collaborator + ' ouvre le lien — vous travaillez ensemble en temps reel.');
    document.getElementById('collabContent').innerHTML = COLLAB.renderSession(sessionId);
  },

  // ─── Rejoindre une session ────────────────────
  joinSession(sessionId, myName) {
    this._sessionId = sessionId;
    this._myName = myName;
    this.syncContent(sessionId);
    document.getElementById('collabContent').innerHTML = COLLAB.renderSession(sessionId);
    if (window.addChatMsg) addChatMsg('assistant', '✅ Connecte a la session. Vous pouvez commencer a travailler ensemble.');
  },

  // ─── Sauvegarder une modification ────────────
  saveEdit(sessionId, content, author) {
    const d = this.get();
    const session = d.sessions.find(function(s) { return s.id === sessionId; });
    if (!session) return;

    session.content = content;
    session.log.push({
      author,
      preview: content.substring(0, 50),
      at: new Date().toISOString(),
      chars: content.length
    });
    session.log = session.log.slice(0, 100);
    session.updatedAt = new Date().toISOString();
    this.save(d);

    // Sync via Supabase si disponible
    this.pushToSupabase(session);
  },

  // ─── Sync Supabase ────────────────────────────
  async pushToSupabase(session) {
    const cfg = window.CFG;
    if (!cfg || !cfg.SUPABASE_URL || cfg.SUPABASE_URL.includes('METTRE')) return;
    try {
      await fetch(cfg.SUPABASE_URL + '/rest/v1/collab_sessions', {
        method: 'POST',
        headers: {
          'apikey': cfg.SUPABASE_KEY,
          'Authorization': 'Bearer ' + cfg.SUPABASE_KEY,
          'Content-Type': 'application/json',
          'Prefer': 'resolution=merge-duplicates'
        },
        body: JSON.stringify({ id: session.id, data: JSON.stringify(session), updated_at: new Date().toISOString() })
      });
    } catch(e) {}
  },

  async syncContent(sessionId) {
    const cfg = window.CFG;
    if (!cfg || !cfg.SUPABASE_URL || cfg.SUPABASE_URL.includes('METTRE')) return;
    try {
      const r = await fetch(cfg.SUPABASE_URL + '/rest/v1/collab_sessions?id=eq.' + sessionId, {
        headers: { 'apikey': cfg.SUPABASE_KEY, 'Authorization': 'Bearer ' + cfg.SUPABASE_KEY }
      });
      const data = await r.json();
      if (data && data[0]) {
        const remote = JSON.parse(data[0].data);
        const d = this.get();
        const local = d.sessions.find(function(s) { return s.id === sessionId; });
        if (local && remote.updatedAt > (local.updatedAt || '')) {
          Object.assign(local, remote);
          this.save(d);
          const el = document.getElementById('collab-editor');
          if (el && el.value !== remote.content) {
            el.value = remote.content;
            if (window.addChatMsg) addChatMsg('assistant', '🔄 Contenu mis a jour par ' + remote.log[remote.log.length-1]?.author + '.');
          }
        }
      }
    } catch(e) {}
  },

  // ─── Vérifier depuis l'URL ────────────────────
  checkUrlSession() {
    const params = new URLSearchParams(window.location.search);
    const collabId = params.get('collab');
    const name = params.get('name');
    if (collabId && name) {
      setTimeout(function() {
        if (window.showPanel) showPanel('collab');
        COLLAB.joinSession(collabId, name);
      }, 1000);
    }
  },

  renderSession: function(sessionId) {
    const d = this.get();
    const session = d.sessions.find(function(s) { return s.id === sessionId; });
    if (!session) return COLLAB.renderPanel();

    // Auto-sync toutes les 5 secondes
    clearInterval(COLLAB._syncInterval);
    COLLAB._syncInterval = setInterval(function() { COLLAB.syncContent(sessionId); }, 5000);

    return '<div style="padding:1.1rem;display:flex;flex-direction:column;gap:.6rem;flex:1;overflow:hidden">' +

      '<div style="display:flex;align-items:center;gap:.4rem">' +
        '<button onclick="clearInterval(COLLAB._syncInterval);document.getElementById(\'collabContent\').innerHTML=COLLAB.renderPanel()" style="background:transparent;border:none;color:var(--gold);font-size:.8rem;cursor:pointer">←</button>' +
        '<div style="flex:1">' +
          '<div style="font-size:.6rem;color:var(--text)">' + session.title + '</div>' +
          '<div style="font-size:.46rem;color:var(--muted)">' + session.owner + ' ' + session.ownerShare + '% — ' + session.collaborator + ' ' + session.collaboratorShare + '%</div>' +
        '</div>' +
        '<div style="width:8px;height:8px;border-radius:50%;background:#81c784;animation:pulse 2s infinite" title="En direct"></div>' +
      '</div>' +

      '<div style="font-size:.46rem;color:rgba(196,153,58,.6);padding:.3rem .5rem;border:1px solid rgba(196,153,58,.2);font-style:italic">' +
        '📋 ' + session.agreement.terms +
      '</div>' +

      '<textarea id="collab-editor" style="flex:1;min-height:200px;resize:none" placeholder="Ecrivez ici — votre collaborateur voit en temps reel..." oninput="COLLAB.saveEdit(\'' + sessionId + '\',this.value,\'' + (this._myName||session.owner) + '\')">' + (session.content || '') + '</textarea>' +

      '<div style="font-size:.46rem;color:var(--muted)">🔄 Synchronisation automatique toutes les 5 secondes</div>' +

      (session.log.length > 0 ? (
        '<div style="font-size:.46rem;color:var(--muted);border-top:1px solid var(--border);padding-top:.4rem">' +
          '<div style="margin-bottom:.2rem;color:var(--gold)">Historique des modifications</div>' +
          session.log.slice(-5).reverse().map(function(l) {
            return '<div>' + new Date(l.at).toLocaleTimeString('fr-FR') + ' — ' + l.author + ' — ' + l.chars + ' caracteres</div>';
          }).join('') +
        '</div>'
      ) : '') +

    '</div>';
  },

  renderPanel: function() {
    const d = this.get();
    const active = d.sessions.filter(function(s) { return s.status === 'active'; });

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +

      '<div class="sec-title">🤝 Collaboration temps reel</div>' +
      '<p class="note">On se cale. On travaille ensemble. Chacun voit tout en direct. Pas de mail. Pas d appel. Juste le travail qui avance.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">' +
          'Chaque modification est horodatee et attribuee. En cas de litige — la preuve est la. Qui a ecrit quoi, quand, combien de lignes. Archive 5 ans.' +
        '</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div class="sec-title">Nouvelle session</div>' +
      '<input type="text" id="col-title" placeholder="Titre du projet — ex: Podcast episode 3"/>' +
      '<input type="text" id="col-myname" placeholder="Votre prenom"/>' +
      '<input type="text" id="col-other" placeholder="Prenom de votre collaborateur"/>' +
      '<div style="display:flex;gap:.4rem;align-items:center">' +
        '<span class="klabel" style="white-space:nowrap">Ma part</span>' +
        '<input type="range" id="col-share" min="10" max="90" value="50" style="flex:1" oninput="document.getElementById(\'col-share-val\').textContent=this.value+\'%\'"/>' +
        '<span id="col-share-val" style="font-size:.56rem;color:var(--gold);min-width:35px">50%</span>' +
      '</div>' +
      '<button class="btn btn-gold" onclick="COLLAB.createSession(document.getElementById(\'col-title\').value,document.getElementById(\'col-myname\').value,document.getElementById(\'col-other\').value,parseInt(document.getElementById(\'col-share\').value))">🤝 Creer la session + envoyer le lien</button>' +

      (active.length > 0 ? (
        '<div class="sec-title">Sessions actives (' + active.length + ')</div>' +
        active.map(function(s) {
          return '<div onclick="document.getElementById(\'collabContent\').innerHTML=COLLAB.renderSession(\'' + s.id + '\')" style="cursor:pointer;padding:.6rem;border:1px solid var(--border);background:var(--dark-mid)">' +
            '<div style="font-size:.56rem;color:var(--text)">' + s.title + '</div>' +
            '<div style="font-size:.46rem;color:var(--muted);margin-top:.2rem">' + s.owner + ' + ' + s.collaborator + ' — ' + new Date(s.createdAt).toLocaleDateString('fr-FR') + '</div>' +
          '</div>';
        }).join('')
      ) : '') +

    '</div>';
  }
};

window.COLLAB = COLLAB;
window.addEventListener('load', function() {
  setTimeout(function() { COLLAB.checkUrlSession(); }, 1500);
});
