// ═══════════════════════════════════════════════════
//  PAGES D'INTRODUCTION — Or Eille AI v1.0
//  Uniformes · bienveillantes · même ton partout
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const INTRO = {

  // Template uniforme pour toutes les pages d'intro
  render: function(config) {
    return '<div style="padding:1.5rem;display:flex;flex-direction:column;gap:1.2rem;min-height:100%;justify-content:center">' +

      // Icône et titre
      '<div style="text-align:center">' +
        '<div style="font-size:3.5rem;margin-bottom:.8rem">' + (config.icon||'✦') + '</div>' +
        '<div style="font-family:\'Cormorant Garamond\',serif;font-style:italic;color:#C4993A;font-size:1.8rem">' + (config.title||'') + '</div>' +
        (config.subtitle ? '<div style="font-size:.5rem;letter-spacing:.15em;color:rgba(196,153,58,.4);text-transform:uppercase;margin-top:.3rem">' + config.subtitle + '</div>' : '') +
      '</div>' +

      // Description principale
      '<div style="background:rgba(196,153,58,.04);border:1px solid rgba(196,153,58,.15);padding:1rem">' +
        '<p style="font-size:.56rem;color:rgba(240,232,216,.8);line-height:2">' + (config.description||'') + '</p>' +
      '</div>' +

      // Ce que ça fait — points clés
      (config.points && config.points.length ? (
        '<div style="display:flex;flex-direction:column;gap:.4rem">' +
          config.points.map(function(p) {
            return '<div style="display:flex;gap:.6rem;align-items:flex-start">' +
              '<span style="color:#C4993A;font-size:.8rem;flex-shrink:0">✦</span>' +
              '<span style="font-size:.52rem;color:rgba(240,232,216,.6);line-height:1.7">' + p + '</span>' +
            '</div>';
          }).join('') +
        '</div>'
      ) : '') +

      // Note bienveillante
      (config.note ? (
        '<div style="font-size:.46rem;color:rgba(196,153,58,.4);font-style:italic;text-align:center;line-height:1.8">' + config.note + '</div>'
      ) : '') +

      // Bouton démarrer
      '<button onclick="' + (config.onStart||'') + '" style="padding:.9rem;background:#C4993A;border:none;color:#0F0F0F;font-family:\'Josefin Sans\',sans-serif;font-size:.56rem;font-weight:600;letter-spacing:.1em;cursor:pointer;text-transform:uppercase">' +
        (config.btnLabel||'Commencer') +
      '</button>' +

      '<div style="text-align:center;font-size:.42rem;color:rgba(196,153,58,.25);font-style:italic">© Madame Or Eille Studios</div>' +

    '</div>';
  },

  // Configurations par module
  CONFIGS: {

    creator: {
      icon: '🎙',
      title: 'Création de contenu',
      subtitle: 'Pour les créateurs francophones',
      description: 'Tu crées du contenu. Tu as une voix, une vision, une communauté à bâtir. Or Eille AI s occupe de tout ce qui te prend du temps — les images, les scripts, les vidéos, les droits musicaux — pour que toi tu te concentres sur l essentiel : ce que tu as à dire.',
      points: [
        'Images cinématographiques stables — pas de doigts à 6 mains',
        'Script sur ton écran pendant que tu filmes — écran verrouillé, zéro notification',
        'Droits musicaux vérifiés avant publication — plus jamais de vidéo coupée',
        'Ton calendrier éditorial préparé — tu valides, tu publies',
      ],
      note: 'Tes créations t appartiennent. Or Eille AI les protège.',
      btnLabel: 'Commencer à créer',
      onStart: "showPanel('creator_main')",
    },

    kids: {
      icon: '🌱',
      title: 'Mode enfants',
      subtitle: 'De 3 à 16 ans · toutes les cultures',
      description: 'Des contes de 50 cultures où l enfant est le héros. Des activités adaptées à son espace, sa famille, son budget. Une détection douce et silencieuse de sa façon d apprendre — sans étiquette, sans diagnostic. Juste ce qui fonctionne pour lui.',
      points: [
        'L enfant est toujours le héros de son histoire — avec son prénom, sa culture',
        'Adapté à sa situation réelle — appartement, maison, chez mamie, parent seul',
        'Détection silencieuse du style d apprentissage — il joue, Or Eille AI observe',
        'Pour les moins de 3 ans — ressources pour le parent, pas d écran pour l enfant',
      ],
      note: 'On ne pose pas de diagnostic. On accompagne.',
      btnLabel: 'Entrer dans le monde enfant',
      onStart: "showPanel('kids_main')",
    },

    literacy: {
      icon: '📖',
      title: 'Lire · Écrire · Compter',
      subtitle: 'Gratuit · pour tout le monde',
      description: 'Apprendre à lire avec les mots de ta vraie vie. Le Syrien à Paris apprend avec les rues de son quartier. Le Malien à Bamako apprend avec les noms des joueurs qu il connaît. Pas de méthode abstraite. Ta vie réelle comme point de départ.',
      points: [
        'Mode vocal et symboles — pas besoin de savoir lire pour naviguer',
        'Tu écris sur du papier, du sable, une ardoise — tu prends une photo — Or Eille AI corrige',
        'A ton rythme — 5 minutes par jour suffisent',
        'Adapté à ta culture d origine ET à ta ville actuelle',
      ],
      note: 'Lire c est accéder à tout. Ce n est jamais trop tard.',
      btnLabel: 'Commencer ma première leçon',
      onStart: "LITERACY.speak('Bienvenue. Appuie sur le grand bouton pour commencer.');document.getElementById('literacyContent').innerHTML=LITERACY.renderVocalPanel()",
    },

    sport: {
      icon: '💪',
      title: 'Sport à la maison',
      subtitle: 'Sans salle · sans matériel · réaliste',
      description: 'Bouger ce n est pas une punition. C est reprendre possession de son corps. À la maison, dans ton salon, dans ta chambre. Or Eille AI adapte la séance à ton espace, tes voisins, l heure qu il est. Silencieux si besoin. Efficace toujours.',
      points: [
        'Mode silencieux automatique le soir — pas de sauts pour les voisins en dessous',
        'Kata karaté seul, yoga, danse cardio, gainage — du vrai sport',
        'De 5 minutes à 30 minutes selon le temps que tu as',
        'Pour les femmes qui ne peuvent pas sortir — tout se fait à la maison',
      ],
      note: 'Ton corps t appartient. Tu en prends soin comme tu peux, quand tu peux.',
      btnLabel: 'Ma séance d aujourd hui',
      onStart: "SPORT.getSession(window.CFG&&window.CFG.CLAUDE_KEY)",
    },

    etiquette: {
      icon: '🤝',
      title: 'Bonnes manières',
      subtitle: '2 minutes par jour · toutes les cultures',
      description: 'Les bonnes manières ce n est pas de la snoberie. C est du respect — pour les autres et pour soi. Chaque culture a les siennes. Toutes sont valables. 2 minutes par jour, un code à la fois. Au bout d un mois — 30 codes qui font partie de toi.',
      points: [
        'Le pain qu on rompt, pas qu on coupe — France',
        'Saluer un ancien en s arrêtant vraiment — Sénégal',
        'Les deux mains pour offrir et recevoir — Japon',
        'La tenue assise, la marche, le regard — partout dans le monde',
      ],
      note: 'Ce qui rentre dans les 2 minutes rentre dans la vie.',
      btnLabel: 'Mon code du jour',
      onStart: "document.getElementById('etiquetteContent').innerHTML=ETIQUETTE.renderPanel()",
    },

    culture: {
      icon: '🌍',
      title: 'Culture générale',
      subtitle: 'Toutes les civilisations · même respect',
      description: 'L histoire de l Empire du Mali. Les mathématiques des Mayas. La philosophie Ubuntu. La première révolution noire en Haïti. 2 minutes par jour, une civilisation, un fait fascinant. La connaissance appartient à tout le monde — pas seulement à ceux qui ont eu les bonnes écoles.',
      points: [
        '25 civilisations — africaines, asiatiques, amérindiennes, européennes',
        'Sources sérieuses — universités, institutions de recherche',
        'Si une information est débattue — on le dit honnêtement',
        'Lien avec ta culture si tu le souhaites',
      ],
      note: 'Ce que tu sais, personne ne peut te le prendre.',
      btnLabel: 'Ma culture du jour',
      onStart: "CULTURE_GEN.getLesson(window.CFG&&window.CFG.CLAUDE_KEY)",
    },

    method: {
      icon: '⚡',
      title: 'La Méthode Or Eille AI',
      subtitle: 'Centrer · Exécuter · Ancrer',
      description: '2 minutes par module. Tous les jours. Pas 3 heures. Pas un quart d heure. 2 minutes — parce que la régularité bat l intensité. Ce qui rentre dans la session rentre dans la vie. La fourchette bien tenue à table. Le mot anglais reconnu dans la série. La posture dans la réunion.',
      points: [
        'Tu choisis tes modules — anglais, sport, manières, culture, lecture',
        '2 minutes chacun — 10 minutes pour 5 modules',
        'Basé sur des recherches scientifiques validées',
        'Semaine 1 — effort. Semaine 3 — automatique. Semaine 4 — c est toi.',
      ],
      note: 'La recette reste dans la cuisine.',
      btnLabel: 'Ma session du jour',
      onStart: "METHOD.getSession(window.CFG&&window.CFG.CLAUDE_KEY)",
    },

    events: {
      icon: '🎃',
      title: 'Événements & Décorations',
      subtitle: 'Toutes les cultures · tous les budgets',
      description: 'Halloween, Noël, Aïd, Kwanzaa, Diwali, Tamkharit, Hanoukka, anniversaire. Tu prends une photo de ta pièce. Or Eille AI voit ce que tu as. Il te propose comment la transformer pour l occasion — avec ce que tu as déjà. Budget zéro si besoin.',
      points: [
        'Photo de ta pièce — idées adaptées à ce que tu as vraiment',
        'Toutes les fêtes de toutes les cultures',
        'Budget zéro, petit budget ou libre — tu choisis',
        'DIY avec des objets du quotidien',
      ],
      note: 'Chaque fête mérite d être belle. Même avec peu.',
      btnLabel: 'Décorer pour mon événement',
      onStart: "document.getElementById('eventsDecoContent').innerHTML=EVENTS_DECO.renderPanel()",
    },

    recipes: {
      icon: '🍳',
      title: 'Cuisine & Recettes',
      subtitle: 'Toutes les cultures · tous les régimes',
      description: 'Des recettes de toutes les cultures du monde. Adaptées à ton régime — vegan, halal, casher, sans gluten. À ta cuisine — avec four, sans four, une seule plaque. À ton budget. Et si un ingrédient est introuvable dans ton pays — Or Eille AI propose un substitut local.',
      points: [
        'Scanner ton assiette — analyse nutritionnelle bienveillante, jamais de jugement',
        'Jamais "perdre du poids" — se réconcilier avec l alimentation',
        'Recettes adaptées aux enfants, aux ados, aux adultes',
        'Les ingrédients de ta culture disponibles partout dans le monde',
      ],
      note: 'La cuisine c est une langue. Or Eille AI la parle dans toutes les cultures.',
      btnLabel: 'Explorer les recettes',
      onStart: "document.getElementById('recipesContent').innerHTML=RECIPES.renderPanel()",
    },

  },

  // Afficher une page d'intro avant un panel
  showIntro: function(moduleKey, targetPanel) {
    const config = this.CONFIGS[moduleKey];
    if (!config) { showPanel(targetPanel); return; }
    config.onStart = config.onStart || "showPanel('" + targetPanel + "')";
    const container = document.getElementById(targetPanel.replace('_main','') + 'Content') ||
                     document.getElementById(targetPanel + 'Content');
    if (container) container.innerHTML = INTRO.render(config);
  },

};

window.INTRO = INTRO;
