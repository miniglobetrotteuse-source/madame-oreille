// ═══════════════════════════════════════════════════
//  FICHES SOS SANTÉ — Or Eille AI v1.0
//  Urgences · données médicales · contacts
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const SOS_HEALTH = {
  KEY: 'moe_sos_health',

  // Numéros d urgence par pays
  EMERGENCY_NUMBERS: {
    france:      { samu:'15', police:'17', pompiers:'18', european:'112' },
    belgique:    { samu:'100', police:'101', european:'112' },
    senegal:     { samu:'1515', police:'17', pompiers:'18' },
    canada:      { urgences:'911' },
    cotedivoire: { samu:'185', police:'170', pompiers:'180' },
    cameroun:    { urgences:'117' },
    maroc:       { samu:'15', police:'19', pompiers:'15' },
    uk:          { urgences:'999' },
    usa:         { urgences:'911' },
    universel:   { european:'112' },
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      country:'france',
      name:'', bloodType:'', allergies:'', medications:'',
      conditions:'', doctorName:'', doctorPhone:'',
      emergencyContact1Name:'', emergencyContact1Phone:'',
      emergencyContact2Name:'', emergencyContact2Phone:'',
    }; }
    catch { return { country:'france' }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // Envoyer fiche aux secours — ouvre SMS avec données
  sendToEmergency: function() {
    const d = this.get();
    const msg = 'URGENCE MEDICALE\n' +
      'Nom : ' + (d.name||'Non renseigne') + '\n' +
      'Groupe sanguin : ' + (d.bloodType||'Inconnu') + '\n' +
      'Allergies : ' + (d.allergies||'Aucune connue') + '\n' +
      'Medicaments : ' + (d.medications||'Aucun') + '\n' +
      'Antecedents : ' + (d.conditions||'Aucun') + '\n' +
      'Medecin : ' + (d.doctorName||'') + ' ' + (d.doctorPhone||'') + '\n' +
      'Contact urgence : ' + (d.emergencyContact1Name||'') + ' ' + (d.emergencyContact1Phone||'');
    window.open('sms:?body=' + encodeURIComponent(msg));
  },

  // Appel urgence selon pays
  callEmergency: function() {
    const d = this.get();
    const nums = this.EMERGENCY_NUMBERS[d.country] || this.EMERGENCY_NUMBERS.universel;
    const num = nums.samu || nums.urgences || nums.european || '112';
    window.open('tel:' + num);
  },

  async getHealthInfo(question, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    if (window.addChatMsg) addChatMsg('assistant','Information sante...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:500,
          messages:[{ role:'user', content:
            'Question sante : ' + question + '\n\n' +
            'Reponds de facon claire et accessible. Si c est urgent — dis-le immediatement et donne le numero d urgence. ' +
            'Jamais de diagnostic medical. Jamais de prescription. Orienter vers un professionnel de sante si necessaire. ' +
            'Information generale et bienveillante uniquement.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  saveField: function(field, value) {
    const d = this.get();
    d[field] = value;
    this.save(d);
  },

  renderPanel: function() {
    const d = this.get();
    const nums = this.EMERGENCY_NUMBERS[d.country] || this.EMERGENCY_NUMBERS.universel;
    const emergencyNum = nums.samu || nums.urgences || nums.european || '112';

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🆘 Fiches SOS Santé</div>' +
      '<p class="note">Ta fiche médicale. Tes contacts d urgence. Prête en un clic si tu en as besoin.</p>' +

      // Boutons urgence
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.5rem">' +
        '<button onclick="SOS_HEALTH.callEmergency()" style="padding:.8rem;background:rgba(220,50,50,.15);border:2px solid rgba(220,50,50,.4);color:#E07070;font-family:Josefin Sans,sans-serif;font-size:.54rem;cursor:pointer;font-weight:600">📞 Appeler les secours — ' + emergencyNum + '</button>' +
        '<button onclick="SOS_HEALTH.sendToEmergency()" style="padding:.8rem;background:rgba(107,163,214,.1);border:2px solid rgba(107,163,214,.3);color:#6BA3D6;font-family:Josefin Sans,sans-serif;font-size:.54rem;cursor:pointer;font-weight:600">📋 Envoyer ma fiche médicale</button>' +
      '</div>' +

      '<div><span class="klabel">Mon pays</span>' +
      '<select id="sos-country" onchange="SOS_HEALTH.saveField(\'country\',this.value);document.getElementById(\'sosContent\').innerHTML=SOS_HEALTH.renderPanel()" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
        Object.entries(this.EMERGENCY_NUMBERS).map(function(e){return '<option value="'+e[0]+'" '+(d.country===e[0]?'selected':'')+'>'+e[0].charAt(0).toUpperCase()+e[0].slice(1)+'</option>';}).join('') +
      '</select></div>' +

      '<div class="sec-title">Ma fiche médicale</div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">' +
        [
          ['name','Mon prénom et nom','text'],
          ['bloodType','Groupe sanguin','text'],
          ['allergies','Allergies connues','text'],
          ['medications','Médicaments en cours','text'],
          ['conditions','Antécédents médicaux','text'],
          ['doctorName','Mon médecin','text'],
          ['doctorPhone','Téléphone médecin','tel'],
          ['emergencyContact1Name','Contact urgence 1 — nom','text'],
          ['emergencyContact1Phone','Contact urgence 1 — tel','tel'],
          ['emergencyContact2Name','Contact urgence 2 — nom','text'],
          ['emergencyContact2Phone','Contact urgence 2 — tel','tel'],
        ].map(function(f) {
          return '<div><span class="klabel">' + f[1] + '</span>' +
            '<input type="' + f[2] + '" value="' + (d[f[0]]||'') + '" placeholder="' + f[1] + '" onchange="SOS_HEALTH.saveField(\'' + f[0] + '\',this.value)" style="margin-top:.2rem"/>' +
          '</div>';
        }).join('') +
      '</div>' +

      '<div class="sec-title">Question santé</div>' +
      '<p class="note">Or Eille AI ne pose pas de diagnostic. Si c est urgent — appelle les secours.</p>' +
      '<input type="text" id="sos-question" placeholder="Ta question — ex: j ai de la fièvre depuis 3 jours..."/>' +
      '<button class="btn btn-ghost" onclick="SOS_HEALTH.getHealthInfo(document.getElementById(\'sos-question\').value,window.CFG&&window.CFG.CLAUDE_KEY)">→ Information santé</button>' +

    '</div>';
  }
};

window.SOS_HEALTH = SOS_HEALTH;
