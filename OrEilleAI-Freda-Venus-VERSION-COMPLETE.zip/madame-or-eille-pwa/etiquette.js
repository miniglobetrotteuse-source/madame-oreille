// ═══════════════════════════════════════════════════
//  BONNES MANIÈRES & CULTURE GÉNÉRALE — Or Eille AI v1.0
//  2 minutes par jour · toutes les cultures
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const ETIQUETTE = {
  KEY: 'moe_etiquette',

  // Codes par culture — concrets et précis
  CODES: {
    france: [
      { title:'Le pain', rule:'On ne coupe jamais le pain. On le rompt avec les mains. Petit morceau par petit morceau.' },
      { title:'La salade', rule:'On ne coupe jamais la salade. On la plie avec la fourchette.' },
      { title:'Les fleurs', rule:'On n arrive pas avec un bouquet. On les envoie la veille ou le lendemain.' },
      { title:'Le retard de politesse', rule:'On arrive avec un quart d heure de retard chez quelqu un. Pas à l heure pile — l hôte n est pas prêt.' },
      { title:'Les couverts', rule:'On les tient avec délicatesse. Fourchette à gauche, couteau à droite. On ne les agite pas en parlant.' },
      { title:'À table', rule:'On attend que tout le monde soit servi avant de commencer. On ne parle pas la bouche pleine.' },
      { title:'Le vin', rule:'On attend que l hôte serve. On ne se ressert pas soi-même.' },
      { title:'La poignée de main', rule:'Ferme mais pas écrasante. Contact visuel. Pas trop longue.' },
    ],
    senegal: [
      { title:'Saluer un ancien', rule:'On prend le temps. On s arrête. On demande des nouvelles de la famille. Pas juste bonjour en passant.' },
      { title:'Manger en groupe', rule:'On attend l invitation de l aîné avant de commencer. On mange avec la main droite.' },
      { title:'La teranga', rule:'L hospitalité est sacrée. On offre ce qu on a. L invité ne repart jamais sans avoir mangé.' },
      { title:'Le respect des anciens', rule:'On ne contredit pas un ancien en public. Si désaccord, on en parle en privé avec respect.' },
    ],
    japon: [
      { title:'La révérence', rule:'Plus on s incline profondément, plus on montre du respect. 15 degrés pour une salutation normale.' },
      { title:'Les chaussures', rule:'On enlève ses chaussures à l entrée d une maison japonaise. Toujours.' },
      { title:'Les baguettes', rule:'On ne plante jamais les baguettes dans le riz — cela rappelle les funérailles.' },
      { title:'Les deux mains', rule:'On offre et reçoit toujours avec les deux mains. Une carte de visite, un cadeau, un verre.' },
    ],
    liban: [
      { title:'L hospitalité', rule:'On insiste pour que l invité mange. Un refus poli se surmonte avec bienveillance.' },
      { title:'Le café', rule:'On sert le café à l aîné en premier. Toujours.' },
      { title:'La famille', rule:'On demande des nouvelles de la famille avant tout business. Les relations avant l efficacité.' },
    ],
    universel: [
      { title:'Écouter vraiment', rule:'On ne regarde pas son téléphone quand quelqu un nous parle. On écoute pour comprendre, pas pour répondre.' },
      { title:'La ponctualité', rule:'Le temps des autres a de la valeur. Prévenir si on est en retard.' },
      { title:'La tenue assise', rule:'On s assoit avec assurance. Pas avachi. Pas les jambes écartées en public.' },
      { title:'La marche', rule:'On marche la tête haute, épaules droites, regard devant soi. Pas les pieds qui traînent.' },
      { title:'Serrer la main', rule:'Contact visuel. Sourire. Poignée ferme mais pas écrasante. Pas de poisson mort.' },
    ],
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { culture:'france', dayIndex:0, seen:[] }; }
    catch { return { culture:'france', dayIndex:0, seen:[] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // 2 minutes par jour — un code, bien compris
  getDailyCode() {
    const d = this.get();
    const codes = this.CODES[d.culture] || this.CODES.universel;
    const idx = d.dayIndex % codes.length;
    return codes[idx];
  },

  nextCode() {
    const d = this.get();
    d.dayIndex++;
    this.save(d);
    document.getElementById('etiquetteContent').innerHTML = ETIQUETTE.renderPanel();
  },

  async explainCode(code, culture, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    if (window.addChatMsg) addChatMsg('assistant','2 minutes sur "' + code.title + '"...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:400,
          messages:[{ role:'user', content:
            'Explique cette règle de bonne manière en 2 minutes de lecture : "' + code.title + '" — ' + code.rule + '. Culture : ' + culture + '. Donne le contexte historique ou culturel en une phrase. Donne un exemple concret de comment l appliquer aujourd hui. Bienveillant. Pas de jugement. Pas de condescendance.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  renderPanel: function() {
    const d = this.get();
    const code = this.getDailyCode();
    const cultures = Object.keys(this.CODES);

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🤝 Bonnes manières & Culture générale</div>' +
      '<p class="note">2 minutes par jour. Un code. Bien compris. Bien pratiqué. Au bout d un mois — 30 codes qui rentrent dans la vie.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem">' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">Les bonnes manières ce n est pas de la snoberie. C est du respect. Pour les autres et pour soi. Toutes les cultures ont les leurs — toutes sont valables.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;font-style:italic">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div class="sec-title">Ma culture</div>' +
      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
        cultures.map(function(c) {
          return '<button onclick="const d2=ETIQUETTE.get();d2.culture=\'' + c + '\';ETIQUETTE.save(d2);document.getElementById(\'etiquetteContent\').innerHTML=ETIQUETTE.renderPanel()" style="padding:.3rem .6rem;background:' + (d.culture===c?'rgba(196,153,58,.15)':'var(--dark-mid)') + ';border:1px solid ' + (d.culture===c?'var(--gold)':'var(--border)') + ';color:' + (d.culture===c?'var(--gold)':'var(--muted)') + ';font-family:Josefin Sans,sans-serif;font-size:.48rem;cursor:pointer">' + c.charAt(0).toUpperCase()+c.slice(1) + '</button>';
        }).join('') +
      '</div>' +

      '<div class="sec-title">Code du jour — 2 minutes</div>' +
      '<div style="border:1px solid rgba(196,153,58,.3);padding:1rem;background:rgba(196,153,58,.04)">' +
        '<div style="font-family:\'Cormorant Garamond\',serif;font-style:italic;color:#C4993A;font-size:1.1rem;margin-bottom:.5rem">' + code.title + '</div>' +
        '<div style="font-size:.56rem;color:rgba(240,232,216,.8);line-height:1.8">' + code.rule + '</div>' +
      '</div>' +

      '<div style="display:flex;gap:.4rem">' +
        '<button class="btn btn-gold" style="flex:2" onclick="ETIQUETTE.explainCode(ETIQUETTE.getDailyCode(),\'' + d.culture + '\',window.CFG&&window.CFG.CLAUDE_KEY)">📖 En savoir plus — 2 minutes</button>' +
        '<button class="btn btn-ghost" style="flex:1" onclick="ETIQUETTE.nextCode()">Suivant →</button>' +
      '</div>' +

      '<div class="sec-title">Tous les codes — ' + d.culture + '</div>' +
      (this.CODES[d.culture]||[]).map(function(c, i) {
        return '<div style="padding:.5rem;border:1px solid var(--border);margin-bottom:.3rem;cursor:pointer" onclick="if(window.addChatMsg)addChatMsg(\'assistant\',\'' + c.title + ' — ' + c.rule.replace(/'/g,'') + '\')">' +
          '<div style="font-size:.54rem;color:var(--text)">' + c.title + '</div>' +
          '<div style="font-size:.44rem;color:var(--muted);margin-top:.1rem">' + c.rule.substring(0,60) + '...</div>' +
        '</div>';
      }).join('') +

    '</div>';
  }
};

window.ETIQUETTE = ETIQUETTE;
