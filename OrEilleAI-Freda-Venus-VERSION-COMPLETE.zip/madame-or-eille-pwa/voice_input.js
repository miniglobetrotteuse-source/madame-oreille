// ═══════════════════════════════════════════════════
//  DICTÉE VOCALE UNIVERSELLE — Or Eille AI v1.0
//  Parler dans n'importe quel module
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const VOICE = {
  _recognition: null,
  _isListening: false,
  _targetId: null,
  _lang: 'fr-FR',

  LANGUAGES: {
    'fr-FR':'Français','en-US':'English','ar-SA':'العربية',
    'es-ES':'Español','pt-BR':'Português','de-DE':'Deutsch',
    'it-IT':'Italiano','sw-TZ':'Kiswahili','wo':'Wolof',
    'vi-VN':'Tiếng Việt','zh-CN':'中文','ja-JP':'日本語',
  },

  start(targetId, lang) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      if (window.addChatMsg) addChatMsg('assistant','Dictee vocale non disponible sur cet appareil.');
      return;
    }
    if (this._isListening) { this.stop(); return; }

    this._targetId = targetId;
    this._lang = lang || 'fr-FR';
    this._recognition = new SpeechRecognition();
    this._recognition.continuous = true;
    this._recognition.interimResults = true;
    this._recognition.lang = this._lang;

    const self = this;
    this._recognition.onresult = function(event) {
      const transcript = Array.from(event.results).map(function(r) { return r[0].transcript; }).join('');
      const target = document.getElementById(self._targetId);
      if (target) target.value = transcript;
    };

    this._recognition.onerror = function() { self.stop(); };
    this._recognition.start();
    this._isListening = true;

    const btn = document.getElementById('voice-btn-' + targetId);
    if (btn) { btn.style.background = 'rgba(239,83,80,.3)'; btn.innerHTML = '🔴 Dicter'; }
  },

  stop() {
    if (this._recognition) { this._recognition.stop(); this._recognition = null; }
    this._isListening = false;
    if (this._targetId) {
      const btn = document.getElementById('voice-btn-' + this._targetId);
      if (btn) { btn.style.background = 'var(--dark-mid)'; btn.innerHTML = '🎙 Dicter'; }
    }
  },

  // Bouton de dictée à insérer près de n'importe quel champ
  createButton(targetId, lang) {
    return '<button id="voice-btn-' + targetId + '" onclick="VOICE.start(\'' + targetId + '\',\'' + (lang||'fr-FR') + '\')" style="padding:.3rem .5rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:Josefin Sans,sans-serif;font-size:.46rem;cursor:pointer">🎙 Dicter</button>';
  },
};

window.VOICE = VOICE;
