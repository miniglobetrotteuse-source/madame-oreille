// ═══════════════════════════════════════════════════
//  NETTOYAGE — Or Eille AI v1.0
//  Galerie, Téléchargements, Documents, WhatsApp...
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const CLEANER = {
  KEY: 'moe_cleaner',
  _dirHandle: null,
  _files: [],
  _analysis: null,
  _toDelete: [],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { history: [] }; }
    catch { return { history: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async openFolder() {
    try {
      if (window.showDirectoryPicker) {
        this._dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
        if (window.addChatMsg) window.addChatMsg('assistant', '✅ Accès accordé. Lecture en cours...');
        await this.readAndAnalyze();
      } else {
        if (window.addChatMsg) window.addChatMsg('assistant', 'Sélectionnez vos fichiers manuellement.');
        const el = document.getElementById('cleaner-fallback');
        if (el) el.style.display = 'block';
      }
    } catch(e) {
      if (e.name !== 'AbortError') {
        const el = document.getElementById('cleaner-fallback');
        if (el) el.style.display = 'block';
      }
    }
  },

  async readAndAnalyze() {
    this._files = [];
    if (this._dirHandle) {
      for await (const entry of this._dirHandle.values()) {
        if (entry.kind === 'file') {
          try {
            const file = await entry.getFile();
            this._files.push({
              name: entry.name,
              handle: entry,
              size: file.size,
              lastModified: file.lastModified,
              type: file.type || '',
            });
          } catch(e) {}
        }
      }
    }
    if (this._files.length === 0) {
      if (window.addChatMsg) window.addChatMsg('assistant', 'Dossier vide.');
      return;
    }
    if (window.addChatMsg) window.addChatMsg('assistant', '📁 ' + this._files.length + ' fichiers trouvés. Analyse en cours...');
    await this.analyze();
  },

  async analyzeManual(files) {
    this._files = Array.from(files).map(function(f) {
      return { name: f.name, handle: null, size: f.size, lastModified: f.lastModified, type: f.type || '' };
    });
    if (window.addChatMsg) window.addChatMsg('assistant', '📁 ' + this._files.length + ' fichiers. Analyse en cours...');
    await this.analyze();
  },

  async analyze() {
    if (!window.CFG || !window.CFG.CLAUDE_KEY) {
      if (window.addChatMsg) window.addChatMsg('assistant', 'Clé API requise.');
      return;
    }

    const fileList = this._files.map(function(f, i) {
      const mb = f.size > 1048576 ? (f.size/1048576).toFixed(1)+'Mo' : (f.size/1024).toFixed(0)+'Ko';
      const date = new Date(f.lastModified).toLocaleDateString('fr-FR');
      const icon = f.type.startsWith('image') ? '🖼' : f.type.startsWith('video') ? '🎬' : f.name.match(/\.pdf$/i) ? '📄' : '📁';
      return (i+1)+'. '+icon+' '+f.name+' ('+mb+' — '+date+')';
    }).join('\n');

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': window.CFG.CLAUDE_KEY, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 2000,
          messages: [{
            role: 'user',
            content: 'Analyse ces ' + this._files.length + ' fichiers pour nettoyage :\n\n' + fileList + '\n\n' +
              'Regroupe-les en 4 catégories avec les numéros correspondants :\n\n' +
              '🔴 SUPPRIMER MAINTENANT — doublons évidents (fichier(1), fichier(2)...), captures inutiles, brouillons abandonnés, téléchargements inutiles\n' +
              '🟠 À VÉRIFIER — anciens fichiers, versions multiples, gros fichiers suspects\n' +
              '🟡 ARCHIVER — fichiers importants mais rarement utilisés\n' +
              '🟢 GARDER — fichiers récents et utiles\n\n' +
              'Indique les numéros dans chaque catégorie. Estime combien d\'espace libéré. Sois direct.'
          }]
        })
      });
      const data = await r.json();
      this._analysis = data.content[0].text;
      if (window.addChatMsg) window.addChatMsg('assistant', '✅ Analyse terminée !\n\n' + this._analysis);
      document.getElementById('cleanerContent').innerHTML = CLEANER.renderPanel();
    } catch(e) {
      if (window.addChatMsg) window.addChatMsg('assistant', 'Erreur. Vérifiez votre connexion.');
    }
  },

  async deleteSelected() {
    if (!this._dirHandle) {
      if (window.addChatMsg) window.addChatMsg('assistant', 'Suppression possible uniquement via accès dossier direct. Sélectionnez les fichiers à supprimer manuellement dans votre gestionnaire de fichiers.');
      return;
    }
    const checked = document.querySelectorAll('.cleaner-check:checked');
    if (checked.length === 0) {
      if (window.addChatMsg) window.addChatMsg('assistant', 'Cochez les fichiers à supprimer.');
      return;
    }
    let deleted = 0;
    for (const cb of checked) {
      const name = cb.dataset.name;
      try {
        await this._dirHandle.removeEntry(name);
        deleted++;
      } catch(e) {}
    }
    if (window.addChatMsg) window.addChatMsg('assistant', '🗑 ' + deleted + ' fichier(s) supprimé(s). Espace libéré !');
    await this.readAndAnalyze();
  },

  renderPanel: function() {
    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +

      '<div class="sec-title">🧹 Nettoyage</div>' +
      '<p class="note">Galerie, Téléchargements, WhatsApp, Documents — choisissez le dossier. Or Eille AI analyse et vous dit quoi supprimer.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">' +
          'Un bouton. Or Eille AI entre dans le dossier. Il analyse tout. Il regroupe — à supprimer, à vérifier, à archiver, à garder. Vous validez. C\'est nettoyé.' +
        '</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<button class="btn btn-gold" onclick="CLEANER.openFolder()" style="font-size:.6rem;padding:.8rem">📁 Choisir un dossier à nettoyer</button>' +

      '<div id="cleaner-fallback" style="display:none">' +
        '<span class="klabel">Ou sélectionnez vos fichiers manuellement</span>' +
        '<input type="file" multiple id="cleaner-files" style="font-size:.52rem;color:var(--muted);margin-top:.3rem;display:block" onchange="CLEANER.analyzeManual(this.files)"/>' +
      '</div>' +

      (this._files.length > 0 ? (
        '<div style="background:var(--dark-mid);border:1px solid var(--border);padding:.6rem">' +
          '<div style="font-size:.52rem;color:var(--muted)">' + this._files.length + ' fichiers analysés</div>' +
          '<div style="display:flex;gap:.3rem;flex-wrap:wrap;margin-top:.4rem">' +
            this._files.map(function(f) {
              const mb = f.size > 1048576 ? (f.size/1048576).toFixed(1)+'Mo' : (f.size/1024).toFixed(0)+'Ko';
              const icon = f.type.startsWith('image') ? '🖼' : f.type.startsWith('video') ? '🎬' : '📄';
              return '<label style="display:flex;align-items:center;gap:.2rem;font-size:.46rem;color:var(--muted);cursor:pointer">' +
                '<input type="checkbox" class="cleaner-check" data-name="' + f.name + '" style="accent-color:var(--gold)"/>' +
                icon + ' ' + f.name.substring(0,20) + (f.name.length>20?'...':'') + ' ' + mb +
              '</label>';
            }).join('') +
          '</div>' +
          '<button class="btn btn-ghost" style="margin-top:.5rem;border-color:#ef5350;color:#ef5350" onclick="CLEANER.deleteSelected()">🗑 Supprimer les fichiers cochés</button>' +
        '</div>'
      ) : '') +

      (this._analysis ? (
        '<div style="background:var(--dark-mid);border:1px solid var(--gold);padding:.8rem">' +
          '<div class="sec-title">Résultat de l\'analyse</div>' +
          '<pre style="font-size:.5rem;color:var(--muted);line-height:1.8;white-space:pre-wrap;font-family:\'Josefin Sans\',sans-serif">' + this._analysis + '</pre>' +
        '</div>'
      ) : '') +

    '</div>';
  }
};

window.CLEANER = CLEANER;
