// ═══════════════════════════════════════════════════
//  OUTILS VIDÉO — Or Eille AI v1.0
//  Compression, recadrage, sync audio/vidéo
//  Alerte batterie/température, check pré-enregistrement
// ═══════════════════════════════════════════════════

const VIDEO_TOOLS = {
  KEY: 'moe_video_tools',

  PLATFORM_RATIOS: {
    instagram_reel: { w: 9, h: 16, label: 'Instagram Reel/Story', maxSizeMB: 100, maxDuration: 90 },
    instagram_feed: { w: 4, h: 5, label: 'Instagram Feed', maxSizeMB: 100, maxDuration: null },
    instagram_square: { w: 1, h: 1, label: 'Instagram Carré', maxSizeMB: 100, maxDuration: null },
    tiktok: { w: 9, h: 16, label: 'TikTok', maxSizeMB: 287, maxDuration: null, safeZoneTop: 15, safeZoneBottom: 20 },
    youtube: { w: 16, h: 9, label: 'YouTube', maxSizeMB: 128000, maxDuration: null },
    youtube_shorts: { w: 9, h: 16, label: 'YouTube Shorts', maxSizeMB: 256, maxDuration: null },
    snapchat: { w: 9, h: 16, label: 'Snapchat', maxSizeMB: 32, maxDuration: null, safeZoneTop: 10, safeZoneBottom: 15 },
    pinterest: { w: 2, h: 3, label: 'Pinterest', maxSizeMB: 2000, maxDuration: 900 },
    linkedin: { w: 1, h: 1, label: 'LinkedIn', maxSizeMB: 5000, maxDuration: null },
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { preferredPlatforms: [], lastCheck: null }; }
    catch { return { preferredPlatforms: [], lastCheck: null }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Check pré-enregistrement complet ─────────
  async fullPreCheck() {
    const checks = [];

    // Batterie
    if (navigator.getBattery) {
      try {
        const battery = await navigator.getBattery();
        const pct = Math.round(battery.level * 100);
        checks.push({
          id: 'battery', icon: '🔋', label: 'Batterie',
          ok: pct > 20, value: `${pct}%`,
          warning: pct <= 10 ? `CRITIQUE — ${pct}% — Branchez maintenant` : pct <= 20 ? `Faible — ${pct}% — Recommandez de brancher` : null,
          autoFixed: false
        });
        // Surveiller la batterie pendant l'enregistrement
        battery.addEventListener('levelchange', () => {
          const newPct = Math.round(battery.level * 100);
          if (newPct <= 15 && window.addChatMsg) {
            addChatMsg('assistant', `⚡ Batterie à ${newPct}% — Sauvegarde automatique en cours. Branchez le chargeur.`);
            if (window.A11Y) A11Y.triggerAlert(`Batterie faible ${newPct}%`, 'urgent');
          }
        });
      } catch {}
    }

    // Stockage
    if (navigator.storage?.estimate) {
      try {
        const est = await navigator.storage.estimate();
        const freeGB = ((est.quota - est.usage) / 1e9).toFixed(2);
        checks.push({
          id: 'storage', icon: '💾', label: 'Stockage',
          ok: parseFloat(freeGB) > 0.5, value: `${freeGB} Go libres`,
          warning: parseFloat(freeGB) <= 0.5 ? 'Stockage insuffisant — libérez de l\'espace' : null,
          autoFixed: false
        });
      } catch {}
    }

    // Microphone
    let micOk = false;
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      s.getTracks().forEach(t => t.stop()); micOk = true;
    } catch {}
    checks.push({ id: 'mic', icon: '🎙', label: 'Microphone', ok: micOk, value: micOk ? 'Accessible' : 'Non accessible', warning: !micOk ? 'Autorisation microphone requise' : null, autoFixed: false });

    // Notifications — sera coupé automatiquement
    checks.push({ id: 'notifs', icon: '🔕', label: 'Notifications', ok: true, value: 'Coupées automatiquement', warning: null, autoFixed: true });

    // Écran allumé — sera géré automatiquement
    checks.push({ id: 'screen', icon: '📱', label: 'Écran allumé', ok: true, value: 'Activé automatiquement (Wake Lock)', warning: null, autoFixed: true });

    // Sauvegarde automatique
    checks.push({ id: 'autosave', icon: '💾', label: 'Sauvegarde auto', ok: true, value: 'Toutes les 2 minutes', warning: null, autoFixed: true });

    return checks;
  },

  // ─── Afficher le check modal ──────────────────
  async showPreCheckModal(onStart) {
    const checks = await this.fullPreCheck();
    const warnings = checks.filter(c => !c.ok && !c.autoFixed);

    const modal = document.createElement('div');
    modal.id = 'video-precheck';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.96);z-index:99999;display:flex;align-items:center;justify-content:center;padding:1.5rem';
    modal.innerHTML = `
      <div style="max-width:380px;width:100%;background:#1a1610;border:1px solid var(--gold);padding:1.2rem">
        <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.8rem">Prêt à créer ?</h3>
        <div style="display:flex;flex-direction:column;gap:.4rem;margin-bottom:.8rem">
          ${checks.map(c => `
            <div style="display:flex;align-items:center;gap:.5rem;padding:.35rem .5rem;background:rgba(255,255,255,.03)">
              <span>${c.icon}</span>
              <div style="flex:1">
                <span style="font-size:.56rem;color:${c.ok?'var(--text)':'#ef5350'}">${c.label}</span>
                <span style="font-size:.5rem;color:${c.ok?'#81c784':'#ef5350'};margin-left:.4rem">${c.value}</span>
                ${c.autoFixed ? '<span style="font-size:.44rem;color:var(--muted);margin-left:.3rem">automatique</span>' : ''}
              </div>
              <span style="font-size:.7rem">${c.ok ? '✅' : '⚠️'}</span>
            </div>
            ${c.warning ? `<div style="font-size:.48rem;color:#ef5350;padding-left:1.5rem">${c.warning}</div>` : ''}
          `).join('')}
        </div>
        <div style="font-size:.5rem;color:var(--muted);padding:.5rem;border:1px solid var(--border);margin-bottom:.8rem;line-height:1.7">
          □ Mode avion — <button onclick="if(window.addChatMsg)addChatMsg('assistant','Activez le mode avion dans les paramètres de votre téléphone pour éviter les interruptions.')" style="background:transparent;border:none;color:var(--gold);font-size:.5rem;cursor:pointer;text-decoration:underline">Comment faire ?</button>
        </div>
        <div style="display:flex;gap:.4rem">
          <button onclick="document.getElementById('video-precheck').remove()" style="flex:1;padding:.6rem;background:transparent;border:1px solid var(--border);color:var(--muted);font-family:'Josefin Sans',sans-serif;font-size:.52rem;cursor:pointer">Annuler</button>
          <button onclick="document.getElementById('video-precheck').remove();${onStart ? onStart+'()' : ''}" style="flex:2;padding:.6rem;background:var(--gold);color:var(--dark);border:none;font-family:'Josefin Sans',sans-serif;font-size:.52rem;cursor:pointer">${warnings.length > 0 ? '⚠ Continuer quand même' : '🎬 C\'est parti !'}</button>
        </div>
      </div>`;
    document.body.appendChild(modal);
  },

  // ─── Vérifier compatibilité vidéo avec plateforme ─
  checkVideoCompatibility(fileSizeMB, durationSeconds, platform) {
    const spec = this.PLATFORM_RATIOS[platform];
    if (!spec) return { ok: true };
    const issues = [];
    if (spec.maxSizeMB && fileSizeMB > spec.maxSizeMB) issues.push(`Taille trop élevée (${fileSizeMB}Mo > ${spec.maxSizeMB}Mo max)`);
    if (spec.maxDuration && durationSeconds > spec.maxDuration) issues.push(`Durée trop longue (${durationSeconds}s > ${spec.maxDuration}s max)`);
    return { ok: issues.length === 0, issues };
  },

  // ─── Indicateur temps réel pendant enregistrement ─
  startRealtimeMonitor() {
    let indicator = document.getElementById('realtime-monitor');
    if (!indicator) {
      indicator = document.createElement('div');
      indicator.id = 'realtime-monitor';
      indicator.style.cssText = 'position:fixed;top:8px;right:8px;background:rgba(0,0,0,.8);border:1px solid var(--border);padding:.3rem .5rem;border-radius:4px;font-family:\'Josefin Sans\',sans-serif;font-size:.44rem;color:var(--text);z-index:9000;display:flex;gap:.5rem;align-items:center';
      document.body.appendChild(indicator);
    }

    const update = async () => {
      let batteryText = '🔋 --';
      let storageText = '💾 --';
      if (navigator.getBattery) {
        try { const b = await navigator.getBattery(); batteryText = `🔋 ${Math.round(b.level*100)}%`; } catch {}
      }
      if (navigator.storage?.estimate) {
        try { const e = await navigator.storage.estimate(); storageText = `💾 ${((e.quota-e.usage)/1e9).toFixed(1)}Go`; } catch {}
      }
      const batteryPct = parseInt(batteryText.replace(/\D/g,''));
      indicator.innerHTML = `<span style="color:${batteryPct<20?'#ef5350':'#81c784'}">${batteryText}</span><span style="color:var(--muted)">|</span><span>${storageText}</span>`;
    };

    update();
    return setInterval(update, 30000); // Update toutes les 30 secondes
  },

  stopRealtimeMonitor(intervalId) {
    if (intervalId) clearInterval(intervalId);
    document.getElementById('realtime-monitor')?.remove();
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div class="sec-title">🎬 Outils vidéo</div>

      <!-- Check pré-enregistrement -->
      <button class="btn btn-gold" onclick="VIDEO_TOOLS.showPreCheckModal()">
        ✅ Check avant enregistrement
      </button>
      <p class="note">Vérifie batterie, stockage, microphone. Active automatiquement l'écran allumé et coupe les notifications.</p>

      <div class="sep"></div>
      <div class="sec-title">📐 Formats par plateforme</div>
      <p class="note">Vérifiez si votre vidéo est compatible avec la plateforme cible.</p>

      <div style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;font-size:.5rem">
          <tr style="border-bottom:1px solid var(--border)">
            <th style="text-align:left;padding:.3rem;color:var(--gold)">Plateforme</th>
            <th style="text-align:center;padding:.3rem;color:var(--gold)">Ratio</th>
            <th style="text-align:center;padding:.3rem;color:var(--gold)">Taille max</th>
            <th style="text-align:center;padding:.3rem;color:var(--gold)">Durée max</th>
          </tr>
          ${Object.entries(this.PLATFORM_RATIOS).map(([k,v]) => `
            <tr style="border-bottom:1px solid rgba(255,255,255,.05)">
              <td style="padding:.3rem;color:var(--text)">${v.label}</td>
              <td style="text-align:center;padding:.3rem;color:var(--muted)">${v.w}:${v.h}</td>
              <td style="text-align:center;padding:.3rem;color:var(--muted)">${v.maxSizeMB>=1000?`${(v.maxSizeMB/1000).toFixed(0)}Go`:`${v.maxSizeMB}Mo`}</td>
              <td style="text-align:center;padding:.3rem;color:var(--muted)">${v.maxDuration?`${v.maxDuration}s`:'∞'}</td>
            </tr>
          `).join('')}
        </table>
      </div>

      <div class="sep"></div>
      <div class="sec-title">🔍 Vérifier ma vidéo</div>
      <div style="display:flex;gap:.4rem">
        <input type="number" id="vt-size" placeholder="Taille (Mo)" style="flex:1"/>
        <input type="number" id="vt-duration" placeholder="Durée (sec)" style="flex:1"/>
      </div>
      <select id="vt-platform" style="width:100%;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.58rem;padding:.45rem;outline:none">
        ${Object.entries(this.PLATFORM_RATIOS).map(([k,v]) => `<option value="${k}">${v.label}</option>`).join('')}
      </select>
      <button class="btn btn-ghost" onclick="
        const r=VIDEO_TOOLS.checkVideoCompatibility(parseFloat(document.getElementById('vt-size').value),parseInt(document.getElementById('vt-duration').value),document.getElementById('vt-platform').value);
        if(window.addChatMsg)addChatMsg('assistant',r.ok?'✅ Votre vidéo est compatible avec cette plateforme.':'⚠ Problèmes détectés:\\n'+r.issues.join('\\n'))
      ">Vérifier</button>
    </div>`;
  },

  // ─── Message mode avion ───────────────────────
  showAirplaneMessage(onConfirm) {
    const modal = document.createElement('div');
    modal.id = 'airplane-modal';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.97);z-index:99999;display:flex;align-items:center;justify-content:center;padding:1.5rem';
    modal.innerHTML =
      '<div style="max-width:360px;width:100%;text-align:center">' +
        '<img src="/logo.png" style="width:90px;height:90px;object-fit:contain;filter:drop-shadow(0 0 20px rgba(196,153,58,.7));animation:pulse 1.5s infinite;margin-bottom:1rem"/>' +
        '<div style="font-size:2rem;margin-bottom:.8rem">✈</div>' +
        '<div style="font-family:Cormorant Garamond,serif;font-style:italic;color:#C4993A;font-size:1.2rem;margin-bottom:.8rem">Activez le mode avion</div>' +
        '<p style="font-size:.56rem;color:rgba(240,232,216,.8);line-height:1.9;margin-bottom:1.2rem">' +
          'Pour enregistrer sans interruption — aucun appel, aucune notification.<br/><br/>' +
          'Faites glisser depuis le haut de votre écran et activez ✈<br/>' +
          'Puis revenez ici.' +
        '</p>' +
        '<button onclick="document.getElementById(&quot;airplane-modal&quot;).remove();VIDEO_TOOLS.confirmStart()" style="padding:.8rem 2rem;background:#C4993A;color:#0F0F0F;border:none;font-family:Josefin Sans,sans-serif;font-size:.58rem;letter-spacing:.15em;cursor:pointer;width:100%;margin-bottom:.5rem">✅ Mode avion activé — Enregistrer</button>' +
        '<button onclick="document.getElementById(&quot;airplane-modal&quot;).remove()" style="padding:.6rem 2rem;background:transparent;color:rgba(255,255,255,.4);border:1px solid rgba(255,255,255,.2);font-family:Josefin Sans,sans-serif;font-size:.5rem;cursor:pointer;width:100%">Continuer sans mode avion</button>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);margin-top:.8rem;font-style:italic">N oubliez pas de le désactiver après l enregistrement.</p>' +
      '</div>';
    document.body.appendChild(modal);
  },

  showAirplaneOffMessage() {
    const modal = document.createElement('div');
    modal.id = 'airplane-off-modal';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.95);z-index:99999;display:flex;align-items:center;justify-content:center;padding:1.5rem';
    modal.innerHTML =
      '<div style="max-width:360px;width:100%;text-align:center">' +
        '<img src="/logo.png" style="width:80px;height:80px;object-fit:contain;filter:drop-shadow(0 0 15px rgba(196,153,58,.5));margin-bottom:1rem"/>' +
        '<div style="font-family:Cormorant Garamond,serif;font-style:italic;color:#C4993A;font-size:1.1rem;margin-bottom:.8rem">Enregistrement terminé ✅</div>' +
        '<p style="font-size:.56rem;color:rgba(240,232,216,.8);line-height:1.9;margin-bottom:1.2rem">' +
          'N oubliez pas de désactiver le mode avion ✈<br/>' +
          'Faites glisser depuis le haut et désactivez.' +
        '</p>' +
        '<button onclick="document.getElementById(&quot;airplane-off-modal&quot;).remove()" style="padding:.8rem 2rem;background:#C4993A;color:#0F0F0F;border:none;font-family:Josefin Sans,sans-serif;font-size:.58rem;letter-spacing:.15em;cursor:pointer;width:100%">✅ Mode avion désactivé</button>' +
      '</div>';
    document.body.appendChild(modal);
    setTimeout(function() { const m = document.getElementById('airplane-off-modal'); if(m) m.remove(); }, 15000);
  },

};



// ─── Booster de qualité universel ─────────────
// S'applique à TOUTE image générée dans Or Eille AI
// Peu importe le sujet, la culture, le style

VIDEO_TOOLS.QUALITY_BOOSTER = {
  // Qualite de base — appliquee sur TOUT
  base: 'ultra sharp focus, high resolution, rich color grading, perfect exposure, professional quality output',

  // Photo — salon sombre, portrait, paysage, tout
  photo: 'photorealistic, DSLR quality, natural light or available light rendered accurately, true-to-life colors, sharp details even in shadows, noise-free, magazine quality',

  // Film — basket au quartier, match de foot, scene de vie
  film: 'cinematic 4k quality, dynamic composition, natural motion, film grain texture, color graded like a feature film, authentic atmosphere, every detail visible',

  // Art et avatar — toutes cultures toutes civilisations
  art: 'digital art masterpiece quality, clean crisp lines, vibrant accurate colors, balanced composition, professional illustration, artstation and behance quality, culturally authentic and dignified',

  // Dessin enfant — carte invitation, gribouillage voiture
  kid: 'children drawing style preserved but rendered beautifully, clean scan quality, vivid crayon or marker colors, charming naive style honored, print-ready quality, warm and joyful',
};

VIDEO_TOOLS.boostPrompt = function(userPrompt, mode) {
  const boost = this.QUALITY_BOOSTER[mode||'photo'] || this.QUALITY_BOOSTER.photo;
  return userPrompt + ', ' + this.QUALITY_BOOSTER.base + ', ' + boost;
};

VIDEO_TOOLS.detectMode = function(prompt) {
  const p = prompt.toLowerCase();
  if (p.includes('enfant') || p.includes('gamin') || p.includes('dessin') || p.includes('carte') || p.includes('invitation')) return 'kid';
  if (p.includes('film') || p.includes('video') || p.includes('match') || p.includes('basket') || p.includes('foot') || p.includes('scene')) return 'film';
  if (p.includes('avatar') || p.includes('personnage') || p.includes('illustration') || p.includes('art') || p.includes('civilisation') || p.includes('culture')) return 'art';
  return 'photo';
};


window.VIDEO_TOOLS = VIDEO_TOOLS;
