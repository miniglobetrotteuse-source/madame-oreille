// ═══════════════════════════════════════════════════
//  INTELLIGENCE CULTURELLE & RÉFÉRENTIEL ARTISTIQUE
//  Or Eille AI — v1.0
// ═══════════════════════════════════════════════════

const CULTURAL = {

  // ─── Styles visuels et cinématographiques ────────
  STYLES: {
    // Afrique
    afrofuturisme: {
      label: 'Afrofuturisme / Wakanda',
      description: 'Esthétique afrofuturiste inspirée de Black Panther — directrice artistique Hannah Beachler. Technologie avancée mariée aux motifs africains traditionnels, métaux dorés et violet royal.',
      prompt: 'afrofuturist aesthetic, Wakanda inspired, golden technology merged with African tribal patterns, purple and gold palette, Ryan Coogler visual style',
      culture: 'Afrique subsaharienne',
      reference: 'Hannah Beachler, Ryan Coogler — Black Panther (2018)'
    },
    kente_aesthetic: {
      label: 'Esthétique Kente',
      description: 'Inspiré du tissu Kente du Ghana — motifs géométriques en bandes, or, vert, rouge et noir. Richesse royale Ashanti.',
      prompt: 'Kente cloth inspired aesthetic, geometric bands of gold green red black, Ashanti royal textile patterns',
      culture: 'Ghana, Côte d\'Ivoire, Togo',
      reference: 'Tradition Ashanti — tissu réservé à la royauté'
    },
    dogon_art: {
      label: 'Art Dogon',
      description: 'Sculptures et masques Dogon du Mali — formes géométriques épurées, bois sombre, symboles cosmologiques.',
      prompt: 'Dogon art style Mali, geometric carved wood, dark tones, cosmological symbols, minimalist African sculpture',
      culture: 'Mali',
      reference: 'Art Dogon — musée du quai Branly'
    },
    // Asie
    ukiyo_e: {
      label: 'Ukiyo-e japonais',
      description: 'Estampes japonaises de la période Edo — traits fins, aplats de couleur, perspectives stylisées. Hokusai, Hiroshige.',
      prompt: 'ukiyo-e Japanese woodblock print style, flat colors, fine outlines, Hokusai inspired, Edo period aesthetic',
      culture: 'Japon',
      reference: 'Katsushika Hokusai, Utagawa Hiroshige — 17-19ème siècle'
    },
    miniature_persane: {
      label: 'Miniature persane',
      description: 'Enluminures persanes — détails infinis, or et lapis-lazuli, jardins paradisiaques, figures stylisées.',
      prompt: 'Persian miniature painting style, intricate gold details, lapis lazuli blues, paradise garden, stylized figures, Safavid era',
      culture: 'Iran, Perse',
      reference: 'École de Tabriz, Behzad — 15-17ème siècle'
    },
    opera_beijing: {
      label: 'Opéra de Pékin',
      description: 'Esthétique de l\'opéra de Pékin — maquillages symboliques colorés, costumes brodés, gestes codifiés.',
      prompt: 'Beijing opera aesthetic, symbolic colorful face paint, embroidered silk costumes, theatrical gestures, vibrant colors',
      culture: 'Chine',
      reference: 'Jingju — opéra traditionnel chinois'
    },
    // Cinéma
    noir_americain: {
      label: 'Film Noir américain',
      description: 'Film noir des années 40-50 — ombres dures, contrastes extrêmes, fumée, néons dans la pluie. Humphrey Bogart.',
      prompt: 'film noir aesthetic 1940s, harsh shadows, high contrast black white, smoke, rain on neon signs, Casablanca lighting',
      culture: 'États-Unis',
      reference: 'Michael Curtiz, Billy Wilder — Hollywood 1940-1955'
    },
    blade_runner: {
      label: 'Blade Runner / Neo-noir',
      description: 'Cyberpunk pluvieux de Ridley Scott — néons colorés dans la pluie, mégapole dystopique, brume et nuit perpétuelle.',
      prompt: 'Blade Runner neo-noir aesthetic, colored neons in rain, dystopian megacity, perpetual night, Syd Mead concept art style',
      culture: 'Cinéma SF',
      reference: 'Ridley Scott, Syd Mead — Blade Runner (1982)'
    },
    nouvelle_vague: {
      label: 'Nouvelle Vague française',
      description: 'Cinéma français des années 60 — noir et blanc contrasté, spontanéité, rues de Paris, liberté formelle.',
      prompt: 'French New Wave cinema aesthetic, high contrast black and white, Paris streets, spontaneous composition, Godard style',
      culture: 'France',
      reference: 'Jean-Luc Godard, François Truffaut — 1958-1968'
    },
    sembene: {
      label: 'Cinéma africain — Sembène',
      description: 'Esthétique du cinéma d\'Ousmane Sembène — lumière africaine crue, couleurs saturées, dignité des personnages ordinaires.',
      prompt: 'Ousmane Sembene cinema style, harsh African sunlight, saturated natural colors, dignified ordinary people, Senegalese neorealism',
      culture: 'Afrique de l\'Ouest',
      reference: 'Ousmane Sembène — père du cinéma africain'
    },
    // Peinture
    renaissance_flamande: {
      label: 'Renaissance flamande',
      description: 'Peinture flamande du 15-17ème — lumière divine, détails extrêmes, drapés somptueux, profondeur atmosphérique.',
      prompt: 'Flemish Renaissance painting style, divine light, extreme detail, sumptuous drapery, atmospheric depth, Jan van Eyck inspired',
      culture: 'Belgique, Pays-Bas',
      reference: 'Jan van Eyck, Vermeer — 15-17ème siècle'
    },
    art_rupestre_sahara: {
      label: 'Art rupestre saharien',
      description: 'Peintures rupestres du Sahara — formes schématiques, ocre et rouge, animaux et figures humaines en mouvement.',
      prompt: 'Saharan rock art style, schematic forms, ochre red earth tones, animals and human figures in motion, prehistoric African art',
      culture: 'Algérie, Libye, Niger',
      reference: 'Tassili n\'Ajjer — 10 000 ans avant J-C'
    },
    // Années
    annees_20: {
      label: 'Années 20 — Art Déco',
      description: 'Art Déco des années folles — géométrie dorée, élégance angulaire, noir et or, jazz age.',
      prompt: 'Art Deco 1920s aesthetic, geometric golden patterns, angular elegance, black and gold, jazz age glamour',
      culture: 'International',
      reference: 'Exposition internationale 1925, Tamara de Lempicka'
    },
    annees_70: {
      label: 'Années 70 — Funk & Soul',
      description: 'Esthétique des seventies — couleurs chaudes, motifs géométriques bold, afros, velours, disco.',
      prompt: '1970s funk soul aesthetic, warm earth tones, bold geometric patterns, afro fashion, velvet textures, disco era',
      culture: 'International, Afrique-Amérique',
      reference: 'Blaxploitation, Soul Train era'
    },
  },

  // ─── Objets culturels à reconnaître ──────────────
  OBJECTS: {
    canari: {
      name: 'Canari',
      culture: 'Afrique subsaharienne, Antilles',
      description: 'Jarre en argile utilisée pour conserver l\'eau fraîche. Poreuse, elle maintient l\'eau à température ambiante par évaporation. Très différent du canari oiseau.',
      visual: 'Clay terracotta jar, round bottom, narrow neck, earthy brown tones'
    },
    cory: {
      name: 'Collier de cory',
      culture: 'Afrique de l\'Ouest',
      description: 'Collier de perles cauris — symbole de richesse, fertilité et protection. Les cauris étaient la monnaie de l\'Afrique précoloniale.',
      visual: 'Cowrie shell necklace, white shells strung together, traditional West African jewelry'
    },
    kora: {
      name: 'Kora',
      culture: 'Afrique de l\'Ouest — Mandingue',
      description: 'Instrument à 21 cordes des griots mandingues. Calebasse tendue de peau de vache, manche en bois, cordes de pêche. Son cristallin.',
      visual: 'Kora instrument, large gourd resonator, long wooden neck, 21 strings, West African harp-lute'
    },
    bogolan: {
      name: 'Bogolan / Bògòlanfini',
      culture: 'Mali',
      description: 'Tissu traditionnel malien teint à la boue fermentée. Motifs géométriques blancs sur fond ocre ou noir. Chaque motif raconte une histoire.',
      visual: 'Bogolan mudcloth, geometric white patterns on dark brown, Mali traditional textile'
    },
    baobab: {
      name: 'Baobab',
      culture: 'Afrique subsaharienne, Madagascar',
      description: 'L\'arbre de vie africain. Tronc immense pouvant stocker 100 000 litres d\'eau. Peut vivre 3000 ans. Symbole de résilience.',
      visual: 'Baobab tree, massive trunk, sparse branches at top, African savanna, silhouette against sunset'
    },
    hammam: {
      name: 'Hammam',
      culture: 'Monde arabe, Turquie, Maghreb',
      description: 'Bain public traditionnel — architecture en dôme, vapeur, carrelage de zellige, bassins en cuivre. Rituel social millénaire.',
      visual: 'Traditional hammam, marble slabs, steam, zellige tiles, copper basins, star-shaped skylights'
    },
  },

  // ─── Alertes culturelles ──────────────────────────
  CULTURAL_ALERTS: [
    {
      trigger: /semelle|chaussure|pied.*person|person.*pied/i,
      cultures: ['arabe', 'moyen-orient', 'maghreb', 'islam'],
      alert: 'Dans la culture arabe et moyen-orientale, montrer la semelle de sa chaussure à quelqu\'un est considéré comme très irrespectueux. Si votre création inclut des personnages dans ce contexte culturel, assurez-vous que cette posture est intentionnelle.'
    },
    {
      trigger: /blanc.*robe|robe.*blanche|blanc.*vêtement/i,
      cultures: ['asie', 'chine', 'japon', 'corée', 'inde'],
      alert: 'Le blanc est la couleur du deuil dans de nombreuses cultures asiatiques (Chine, Japon, Corée, Inde). Si votre création représente une célébration dans ce contexte, privilégiez le rouge (bonheur) ou d\'autres couleurs vives.'
    },
    {
      trigger: /pouce.*levé|thumbs.up/i,
      cultures: ['moyen-orient', 'grèce', 'italie', 'australie'],
      alert: 'Le pouce levé signifie "bien" en Occident, mais est un geste offensant dans certaines cultures du Moyen-Orient, en Grèce et en Australie.'
    },
    {
      trigger: /main.*gauche|gauche.*main|left.*hand/i,
      cultures: ['afrique', 'inde', 'islam'],
      alert: 'Dans de nombreuses cultures africaines, indiennes et dans l\'islam, la main gauche est considérée comme impure. Offrir quelque chose de la main gauche ou montrer la main gauche peut être perçu comme irrespectueux.'
    },
    {
      trigger: /tête.*sacré|personnage.*religieux|bouddha|ganesh|allah/i,
      cultures: ['toutes'],
      alert: 'La représentation de figures religieuses ou sacrées est très sensible dans toutes les cultures. Assurez-vous que votre traitement est respectueux et non caricatural.'
    },
  ],

  // Vérifier les alertes culturelles
  checkCulturalAlerts(prompt, context) {
    const alerts = [];
    this.CULTURAL_ALERTS.forEach(a => {
      if (a.trigger.test(prompt) || a.trigger.test(context)) {
        alerts.push(a.alert);
      }
    });
    return alerts;
  },

  // Proposer 3 directions culturelles
  suggestDirections(request) {
    const styles = Object.values(this.STYLES);
    // Sélectionner 3 styles de cultures différentes
    const selected = [];
    const cultures = new Set();
    for (const s of styles) {
      if (!cultures.has(s.culture) && selected.length < 3) {
        selected.push(s);
        cultures.add(s.culture);
      }
    }
    return selected;
  },

  // Bulle culturelle post-génération
  getCulturalBubble(styleName) {
    const style = this.STYLES[styleName];
    if (!style) return null;
    return `✦ ${style.label} — ${style.description} | Référence : ${style.reference}`;
  },

  // Identifier un objet culturel
  identifyObject(name) {
    const key = name.toLowerCase().replace(/\s+/g, '_');
    return this.OBJECTS[key] || null;
  }
};

window.CULTURAL = CULTURAL;
