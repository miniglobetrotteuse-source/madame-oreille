// ═══════════════════════════════════════════════════
//  MASAKHANE — Traduction langues africaines
//  API open source — "We build together"
//  Or Eille AI v1.0
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const MASAKHANE = {

  // API endpoint Masakhane
  API_URL: 'https://api.masakhane.io/translate',

  // Langues supportées par Masakhane
  LANGUES_SUPPORTEES: {
    'ln': 'lin_Latn',   // Lingala
    'wo': 'wol_Latn',   // Wolof
    'bm': 'bam_Latn',   // Bambara
    'sw': 'swh_Latn',   // Swahili
    'yo': 'yor_Latn',   // Yoruba
    'ha': 'hau_Latn',   // Haoussa
    'am': 'amh_Ethi',   // Amharique
    'ig': 'ibo_Latn',   // Igbo
    'tzm': 'tzm_Tfng', // Tamazight/Amazighe
    'gcf': 'gcf_Latn', // Kréyòl Guadeloupéen
    'mq': 'mq_Latn',   // Kréyòl Matinik
  },

  // Cache local des traductions validées
  CACHE_KEY: 'moe_masakhane_cache',

  getCache() {
    try { return JSON.parse(localStorage.getItem(this.CACHE_KEY)) || {}; }
    catch { return {}; }
  },

  saveCache(cache) {
    try { localStorage.setItem(this.CACHE_KEY, JSON.stringify(cache)); }
    catch {}
  },

  // ─── Traduire un texte ────────────────────────
  async translate(text, targetLang, sourceLang = 'fr') {
    const masakhane_code = this.LANGUES_SUPPORTEES[targetLang];
    if (!masakhane_code) return null;

    // Vérifier cache
    const cache = this.getCache();
    const cacheKey = `${sourceLang}:${targetLang}:${text.trim()}`;
    if (cache[cacheKey]) return cache[cacheKey];

    try {
      const r = await fetch(this.API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          src: text,
          src_lang: sourceLang === 'fr' ? 'fra_Latn' : 'eng_Latn',
          tgt_lang: masakhane_code,
        })
      });
      if (!r.ok) throw new Error('Masakhane API ' + r.status);
      const data = await r.json();
      const translated = data.translation || data.result || null;

      if (translated) {
        // Mettre en cache
        cache[cacheKey] = { text: translated, validated: false, source: 'masakhane' };
        this.saveCache(cache);
        return cache[cacheKey];
      }
      return null;
    } catch(e) {
      console.warn('Masakhane:', e.message);
      return null;
    }
  },

  // ─── Marquer une traduction comme validée ─────
  validateTranslation(cacheKey) {
    const cache = this.getCache();
    if (cache[cacheKey]) {
      cache[cacheKey].validated = true;
      cache[cacheKey].validated_at = new Date().toISOString();
      this.saveCache(cache);
    }
  },

  // ─── Traduire tout i18n pour une langue ───────
  async translateI18N(targetLang) {
    if (!this.LANGUES_SUPPORTEES[targetLang]) return false;

    const frStrings = window.I18N?.fr;
    if (!frStrings) return false;

    const results = {};
    for (const [key, value] of Object.entries(frStrings)) {
      if (typeof value !== 'string') continue;
      const translated = await this.translate(value, targetLang, 'fr');
      if (translated) results[key] = translated.text;
    }

    // Stocker dans I18N si suffisamment traduit
    if (Object.keys(results).length > 10) {
      if (!window.I18N) window.I18N = {};
      // Merger avec traductions existantes — ne pas écraser les validées
      window.I18N[targetLang] = { ...results, ...(window.I18N[targetLang] || {}) };
      return true;
    }
    return false;
  },

  // ─── Interface de validation pour locuteurs natifs ─
  renderValidationPanel(lang) {
    const cache = this.getCache();
    const langEntries = Object.entries(cache).filter(([k]) => k.startsWith(`fr:${lang}:`));
    const pending = langEntries.filter(([, v]) => !v.validated);
    const validated = langEntries.filter(([, v]) => v.validated);

    return `
    <div style="padding:1rem;display:flex;flex-direction:column;gap:.7rem">
      <div class="sec-title">✅ Validation des traductions — ${lang.toUpperCase()}</div>
      <p style="font-size:.52rem;color:var(--muted);line-height:1.6">
        Ces traductions ont été générées automatiquement par Masakhane. 
        Un locuteur natif doit les valider avant qu'elles soient certifiées dans l'app.
      </p>

      <div style="display:flex;gap:.5rem;font-size:.5rem;color:var(--muted)">
        <span>⏳ En attente : ${pending.length}</span>
        <span>✅ Validées : ${validated.length}</span>
      </div>

      ${pending.slice(0, 10).map(([key, val]) => `
        <div style="padding:.6rem;border:1px solid var(--border);display:flex;flex-direction:column;gap:.3rem">
          <div style="font-size:.5rem;color:var(--muted)">${key.split(':')[2]}</div>
          <div style="font-size:.6rem;color:var(--text)">${val.text}</div>
          <div style="display:flex;gap:.3rem;margin-top:.2rem">
            <input type="text" placeholder="Corriger si nécessaire..." 
              id="corr_${btoa(key).slice(0,10)}"
              style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.5rem;padding:.3rem;outline:none"/>
            <button onclick="MASAKHANE.validateTranslation('${key}')"
              style="padding:.3rem .6rem;background:var(--gold);color:var(--dark);border:none;font-family:inherit;font-size:.48rem;cursor:pointer">
              ✓ Valider
            </button>
          </div>
        </div>
      `).join('')}

      ${pending.length === 0 ? `
        <div style="text-align:center;padding:1rem;color:var(--gold);font-size:.6rem">
          ✅ Toutes les traductions sont validées pour cette langue !
        </div>
      ` : ''}
    </div>`;
  },
};

window.MASAKHANE = MASAKHANE;
