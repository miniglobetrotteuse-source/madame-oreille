// ═══════════════════════════════════════════════════
//  MODE VALISE NUMÉRIQUE — Or Eille AI v1.0
//  Préparer des projets avant de partir sans WiFi
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const OFFLINE = {
  KEY: 'moe_offline',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { projects: [] }; }
    catch { return { projects: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  isOnline() { return navigator.onLine; },

  addProject() {
    const input = document.getElementById('offline-title');
    if (!input || !input.value.trim()) return;
    const title = input.value.trim();
    const d = this.get();
    d.projects.push({ id: Date.now().toString(), title: title, status: 'pending', createdAt: new Date().toISOString() });
    this.save(d);
    input.value = '';
    if (window.addChatMsg) addChatMsg('assistant', '✅ "' + title + '" ajouté à la valise.');
    document.getElementById('offlineContent').innerHTML = OFFLINE.renderPanel();
  },

  removeProject(id) {
    const d = this.get();
    d.projects = d.projects.filter(function(p) { return p.id !== id; });
    this.save(d);
    document.getElementById('offlineContent').innerHTML = OFFLINE.renderPanel();
  },

  async prepareAll() {
    if (!this.isOnline()) {
      if (window.addChatMsg) addChatMsg('assistant', 'Vous êtes hors ligne. Impossible de préparer maintenant.');
      return;
    }
    const d = this.get();
    if (d.projects.length === 0) {
      if (window.addChatMsg) addChatMsg('assistant', 'Ajoutez des projets avant de préparer.');
      return;
    }
    if (window.addChatMsg) addChatMsg('assistant', '🧳 Préparation de ' + d.projects.length + ' projet(s)...');
    try {
      const cache = await caches.open('or-eille-offline-v1');
      await cache.addAll(['/', '/index.html', '/logo.png', '/manifest.json']);
      d.projects = d.projects.map(function(p) { p.status = 'ready'; return p; });
      d.preparedAt = new Date().toISOString();
      this.save(d);
      if (window.addChatMsg) addChatMsg('assistant', '✅ Valise prête ! ' + d.projects.length + ' projet(s) disponibles hors ligne. Vous pouvez partir.');
      document.getElementById('offlineContent').innerHTML = OFFLINE.renderPanel();
    } catch(e) {
      if (window.addChatMsg) addChatMsg('assistant', 'Erreur de préparation. Vérifiez votre connexion.');
    }
  },

  clearAll() {
    const d = this.get();
    d.projects = [];
    this.save(d);
    if (window.addChatMsg) addChatMsg('assistant', '🧹 Valise vidée.');
    document.getElementById('offlineContent').innerHTML = OFFLINE.renderPanel();
  },

  initConnectionMonitor() {
    window.addEventListener('online', function() {
      if (window.addChatMsg) addChatMsg('assistant', '✅ WiFi retrouvé. Synchronisation en cours...');
      if (window.SYNC) SYNC.pushToCloud().catch(function(){});
    });
    window.addEventListener('offline', function() {
      if (window.addChatMsg) addChatMsg('assistant', '📴 Hors ligne. Mode valise numérique activé. Vos projets préparés sont disponibles.');
    });
  },

  renderPanel() {
    const d = this.get();
    const online = this.isOnline();
    const statusColor = online ? '#81c784' : '#ef5350';
    const statusBg = online ? 'rgba(129,199,132,.1)' : 'rgba(239,83,80,.1)';
    const statusBorder = online ? 'rgba(129,199,132,.3)' : 'rgba(239,83,80,.3)';
    const statusText = online ? '✅ En ligne — préparez vos projets maintenant' : '📴 Hors ligne — utilisez vos projets préparés';

    let projectsHtml = '';
    if (d.projects.length > 0) {
      d.projects.forEach(function(p) {
        const icon = p.status === 'ready' ? '✅' : '⏳';
        const statusLabel = p.status === 'ready' ? 'Prêt' : 'En attente';
        const borderColor = p.status === 'ready' ? 'rgba(129,199,132,.3)' : 'var(--border)';
        projectsHtml += '<div style="display:flex;align-items:center;gap:.4rem;padding:.5rem;border:1px solid ' + borderColor + ';background:var(--dark-mid);margin-bottom:.3rem">';
        projectsHtml += '<span style="font-size:.7rem">' + icon + '</span>';
        projectsHtml += '<span style="flex:1;font-size:.54rem;color:var(--text)">' + p.title + '</span>';
        projectsHtml += '<span style="font-size:.44rem;color:var(--muted)">' + statusLabel + '</span>';
        projectsHtml += '<button onclick="OFFLINE.removeProject(this.getAttribute(&quot;data-id&quot;))" data-id="' + p.id + '" style="background:transparent;border:none;color:#ef5350;font-size:.8rem;cursor:pointer">×</button>';
        projectsHtml += '</div>';
      });
    } else {
      projectsHtml = '<div style="text-align:center;padding:1.5rem;color:var(--muted);font-size:.54rem">Aucun projet dans la valise.<br/>Ajoutez des projets avant de partir sans WiFi.</div>';
    }

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🧳 Valise numérique</div>' +
      '<div style="display:flex;align-items:center;gap:.5rem;padding:.5rem;background:' + statusBg + ';border:1px solid ' + statusBorder + '">' +
        '<div style="width:8px;height:8px;border-radius:50%;background:' + statusColor + '"></div>' +
        '<span style="font-size:.54rem;color:var(--text)">' + statusText + '</span>' +
      '</div>' +
      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem">' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">' +
          'Avant de partir sans WiFi — ajoutez vos projets et cliquez sur Préparer. Or Eille AI met tout en cache. Vous travaillez sans connexion. Quand vous retrouvez du WiFi — tout se synchronise.' +
        '</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic">— Madame Or Eille Studios</p>' +
      '</div>' +
      (online ? '<div style="display:flex;gap:.4rem"><input type="text" id="offline-title" placeholder="Ex: Newsletter mai, Carte anniversaire..." style="flex:1"/><button onclick="OFFLINE.addProject()" style="padding:.5rem .8rem;background:var(--gold);color:var(--dark);border:none;font-size:.7rem;cursor:pointer">+</button></div>' : '') +
      (d.projects.length > 0 ? '<div class="sec-title">Projets dans la valise (' + d.projects.length + ')</div>' : '') +
      projectsHtml +
      (d.projects.length > 0 ? '<div style="display:flex;gap:.4rem">' + (online ? '<button class="btn btn-gold" style="flex:2" onclick="OFFLINE.prepareAll()">🧳 Préparer pour partir sans WiFi</button>' : '') + '<button class="btn btn-ghost" style="flex:1" onclick="OFFLINE.clearAll()">🗑 Vider</button></div>' : '') +
      '<div style="font-size:.48rem;color:var(--muted);line-height:1.7;padding:.5rem;border:1px solid var(--border)">' +
        '📴 Disponible hors ligne : projets préparés, fiche médicale, paramètres, documents en cache.<br/>' +
        '📶 Nécessite WiFi : génération images/vidéos, traductions, IA, synchronisation.' +
      '</div>' +
    '</div>';
  }
};

window.OFFLINE = OFFLINE;
window.addEventListener('load', function() {
  setTimeout(function() { OFFLINE.initConnectionMonitor(); }, 1000);
});
