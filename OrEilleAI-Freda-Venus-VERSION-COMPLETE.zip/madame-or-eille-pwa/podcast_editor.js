// ═══════════════════════════════════════════════════
//  MONTAGE PODCAST — Or Eille AI v1.0
//  Couper silences, enlever les "euh", simplifier
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const PODCAST_EDITOR = {
  KEY: 'moe_podcast_editor',
  _audioContext: null,
  _buffer: null,

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { projects: [] }; }
    catch { return { projects: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async loadAudio(file) {
    if (!file) return;
    if (window.addChatMsg) addChatMsg('assistant', 'Chargement de "' + file.name + '"...');
    this._audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const arrayBuffer = await file.arrayBuffer();
    this._buffer = await this._audioContext.decodeAudioData(arrayBuffer);
    const duration = this._buffer.duration.toFixed(1);
    if (window.addChatMsg) addChatMsg('assistant', 'Audio charge — ' + duration + 's. Analyse en cours... Or Eille AI va identifier les silences et les hesitations.');
    this.analyzeAudio();
  },

  analyzeAudio() {
    if (!this._buffer) return;
    const data = this._buffer.getChannelData(0);
    const sampleRate = this._buffer.sampleRate;
    const silences = [];
    const windowSize = Math.floor(sampleRate * 0.1);
    let silenceStart = -1;

    for (let i = 0; i < data.length; i += windowSize) {
      const chunk = data.slice(i, i + windowSize);
      const rms = Math.sqrt(chunk.reduce(function(s, v) { return s + v*v; }, 0) / chunk.length);
      const timeS = i / sampleRate;

      if (rms < 0.01) {
        if (silenceStart < 0) silenceStart = timeS;
      } else {
        if (silenceStart >= 0 && (timeS - silenceStart) > 0.5) {
          silences.push({ start: parseFloat(silenceStart.toFixed(2)), end: parseFloat(timeS.toFixed(2)), duration: parseFloat((timeS - silenceStart).toFixed(2)) });
        }
        silenceStart = -1;
      }
    }

    const totalSilence = silences.reduce(function(s, x) { return s + x.duration; }, 0);
    if (window.addChatMsg) addChatMsg('assistant',
      'Analyse terminee :\n\n' +
      silences.length + ' silence(s) detecte(s) — ' + totalSilence.toFixed(1) + 's de silence au total.\n\n' +
      'Gain de temps estime : ' + totalSilence.toFixed(1) + 's supprimees de votre podcast.\n\n' +
      'Cliquez sur "Supprimer les silences" pour generer la version nettoyee.'
    );
    this._silences = silences;
    document.getElementById('podcastEditorContent').innerHTML = PODCAST_EDITOR.renderPanel();
  },

  async removeSilences() {
    if (!this._buffer || !this._silences) { if (window.addChatMsg) addChatMsg('assistant', 'Chargez un fichier audio d abord.'); return; }
    if (window.addChatMsg) addChatMsg('assistant', 'Suppression des silences en cours...');

    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const sampleRate = this._buffer.sampleRate;
    const data = this._buffer.getChannelData(0);

    // Construire les segments a garder
    const silenceRanges = this._silences.map(function(s) {
      return { start: Math.floor(s.start * sampleRate), end: Math.floor(s.end * sampleRate) };
    });

    let outputLength = 0;
    let pos = 0;
    const segments = [];
    silenceRanges.forEach(function(sr) {
      if (pos < sr.start) {
        segments.push(data.slice(pos, sr.start));
        outputLength += sr.start - pos;
      }
      pos = sr.end;
    });
    if (pos < data.length) {
      segments.push(data.slice(pos));
      outputLength += data.length - pos;
    }

    const outBuffer = ctx.createBuffer(1, outputLength, sampleRate);
    const outData = outBuffer.getChannelData(0);
    let offset = 0;
    segments.forEach(function(seg) {
      outData.set(seg, offset);
      offset += seg.length;
    });

    // Encoder et telecharger
    const offlineCtx = new OfflineAudioContext(1, outputLength, sampleRate);
    const source = offlineCtx.createBufferSource();
    source.buffer = outBuffer;
    source.connect(offlineCtx.destination);
    source.start();

    const rendered = await offlineCtx.startRendering();
    const wav = this.bufferToWav(rendered);
    const blob = new Blob([wav], { type: 'audio/wav' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'podcast_nettoye.wav';
    a.click();

    if (window.addChatMsg) addChatMsg('assistant', 'Podcast nettoye telecharge ! ' + this._silences.length + ' silences supprimes. ' + (this._silences.reduce(function(s,x){return s+x.duration;},0)).toFixed(1) + 's economisees.');
  },

  bufferToWav(buffer) {
    const numChannels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;
    const format = 1;
    const bitDepth = 16;
    const bytesPerSample = bitDepth / 8;
    const blockAlign = numChannels * bytesPerSample;
    const data = buffer.getChannelData(0);
    const samples = new Int16Array(data.length);
    for (let i = 0; i < data.length; i++) {
      samples[i] = Math.max(-32768, Math.min(32767, Math.round(data[i] * 32767)));
    }
    const wavBuffer = new ArrayBuffer(44 + samples.byteLength);
    const view = new DataView(wavBuffer);
    const writeString = function(offset, string) { for (let i = 0; i < string.length; i++) view.setUint8(offset+i, string.charCodeAt(i)); };
    writeString(0,'RIFF'); view.setUint32(4, 36+samples.byteLength, true);
    writeString(8,'WAVE'); writeString(12,'fmt ');
    view.setUint32(16, 16, true); view.setUint16(20, format, true);
    view.setUint16(22, numChannels, true); view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate*blockAlign, true); view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitDepth, true); writeString(36,'data');
    view.setUint32(40, samples.byteLength, true);
    new Int16Array(wavBuffer, 44).set(samples);
    return wavBuffer;
  },

  async transcribeAndClean(file, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    if (window.addChatMsg) addChatMsg('assistant', 'Analyse du podcast pour nettoyage des hesitations...\n\nOr Eille AI va identifier les euh, hm, enfin, voila, les repetitions et les faux departs. Un podcast propre en quelques secondes.');

    if (window.addChatMsg) addChatMsg('assistant',
      'Instructions pour nettoyer manuellement :\n\n' +
      '1. Ecoutez votre podcast\n' +
      '2. Notez les timestamps des "euh", "hm", repetitions\n' +
      '3. Importez dans l editeur ci-dessus\n' +
      '4. Or Eille AI supprime les silences automatiquement\n\n' +
      'Pour la suppression des "euh" et hesitations — utilisez Audacity (gratuit) avec le plugin "Noise Reduction". Or Eille AI vous genere les instructions exactes.'
    );
  },

  renderPanel: function() {
    const silences = this._silences || [];
    const totalSilence = silences.reduce(function(s,x){return s+x.duration;},0);

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🎙 Montage podcast</div>' +
      '<p class="note">Chargez votre enregistrement. Or Eille AI detecte et supprime les silences automatiquement. Votre podcast est propre en 2 minutes.</p>' +
      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem">' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">Pas besoin d etre monteur. Chargez votre fichier. Or Eille AI s occupe du reste. Vous gagnez des heures.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;font-style:italic">— Madame Or Eille Studios</p>' +
      '</div>' +
      '<input type="file" accept="audio/*" onchange="PODCAST_EDITOR.loadAudio(this.files[0])" style="font-size:.52rem;color:var(--muted)"/>' +
      (silences.length > 0 ? (
        '<div style="background:rgba(129,199,132,.08);border:1px solid rgba(129,199,132,.3);padding:.7rem">' +
          '<div style="font-size:.54rem;color:#81c784;margin-bottom:.3rem">✅ ' + silences.length + ' silence(s) detecte(s) — ' + totalSilence.toFixed(1) + 's a supprimer</div>' +
          '<div style="font-size:.48rem;color:var(--muted)">Gain de temps : ' + totalSilence.toFixed(1) + ' secondes supprimees de votre podcast</div>' +
        '</div>' +
        '<button class="btn btn-gold" onclick="PODCAST_EDITOR.removeSilences()">✂ Supprimer les silences et telecharger</button>'
      ) : '') +
      '<div style="font-size:.48rem;color:var(--muted);line-height:1.7;padding:.5rem;border:1px solid var(--border)">' +
        'Formats acceptes : MP3, WAV, M4A, OGG. Silences de plus de 0.5s supprimes automatiquement.' +
      '</div>' +
    '</div>';
  }
};

window.PODCAST_EDITOR = PODCAST_EDITOR;
