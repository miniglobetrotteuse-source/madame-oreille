// ═══════════════════════════════════════════════════
//  PARTAGE VERS RÉSEAUX SOCIAUX — Or Eille AI v1.0
//  Contenu pret a coller — un clic vers Instagram
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const SOCIAL = {
  KEY: 'moe_social',

  PLATFORMS: {
    instagram: { label: 'Instagram', icon: '📸', color: '#E1306C', url: 'https://www.instagram.com', tip: 'Nouveau post > coller la legende > ajouter media > publier' },
    tiktok: { label: 'TikTok', icon: '🎵', color: '#69C9D0', url: 'https://www.tiktok.com', tip: 'Bouton + > importer video > coller la legende > publier' },
    youtube: { label: 'YouTube', icon: '▶', color: '#FF0000', url: 'https://studio.youtube.com', tip: 'Creer > importer > coller description > publier' },
    facebook: { label: 'Facebook', icon: '👥', color: '#1877F2', url: 'https://www.facebook.com', tip: 'Creer publication > coller texte > ajouter media > publier' },
    linkedin: { label: 'LinkedIn', icon: '💼', color: '#0077B5', url: 'https://www.linkedin.com', tip: 'Creer un post > coller texte > ajouter media > publier' },
    twitter: { label: 'X', icon: '𝕏', color: '#000000', url: 'https://twitter.com', tip: 'Nouveau tweet > coller > ajouter media > publier' },
    whatsapp: { label: 'WhatsApp', icon: '💬', color: '#25D366', url: 'https://web.whatsapp.com', tip: 'Choisir contact > coller message > envoyer' },
    threads: { label: 'Threads', icon: '🧵', color: '#000000', url: 'https://www.threads.net', tip: 'Nouveau thread > coller > ajouter media > publier' },
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { history: [] }; }
    catch { return { history: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async copyAndOpen(platform) {
    const caption = document.getElementById('ss-caption') ? document.getElementById('ss-caption').value : '';
    const hashtags = document.getElementById('ss-hashtags') ? document.getElementById('ss-hashtags').value : '';
    const p = this.PLATFORMS[platform];
    if (!p) return;

    const full = caption + (hashtags ? '\n\n' + hashtags : '');

    try { await navigator.clipboard.writeText(full); } catch(e) {}

    const d = this.get();
    d.history.unshift({ platform, caption: caption.substring(0,80), at: new Date().toISOString() });
    d.history = d.history.slice(0, 20);
    this.save(d);

    if (window.addChatMsg) addChatMsg('assistant', '✅ Copie ! ' + p.tip + '\n\nOuverture de ' + p.label + '...');
    setTimeout(function() { window.open(p.url, '_blank'); }, 800);
  },

  async generateCaption(platform, topic, style, claudeKey) {
    if (!topic) { if (window.addChatMsg) addChatMsg('assistant', 'Decrivez votre contenu.'); return; }
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant', 'Cle API requise.'); return; }

    const styles = {
      instagram: 'Instagram — accroche forte premiere ligne, 3-5 paragraphes courts, emojis, call to action, 15 hashtags pertinents en fin',
      tiktok: 'TikTok — tres court, percutant, 1-2 phrases maximum, 5-8 hashtags tendance',
      youtube: 'YouTube — description SEO optimisee, 150-300 mots, mots-cles importants au debut, timestamps si possible',
      linkedin: 'LinkedIn — professionnel mais humain, storytelling, 3-5 paragraphes, pas de hashtags en exces',
      twitter: 'X/Twitter — maximum 280 caracteres, percutant, hashtags integres naturellement',
    };

    const prompt = styles[platform] || styles.instagram;
    if (window.addChatMsg) addChatMsg('assistant', 'Generation de la legende pour ' + platform + '...');

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 600,
          messages: [{
            role: 'user',
            content: 'Ecris une legende ' + prompt + ' pour ce contenu : ' + topic + (style ? '\nStyle/ton : ' + style : '') + '\n\nReponds UNIQUEMENT avec la legende prete a coller. Pas d explication.'
          }]
        })
      });
      const data = await r.json();
      const result = data.content[0].text;
      const el = document.getElementById('ss-caption');
      if (el) el.value = result;
      if (window.addChatMsg) addChatMsg('assistant', '✅ Legende generee et prete a coller.');
    } catch(e) {
      if (window.addChatMsg) addChatMsg('assistant', 'Erreur. Verifiez votre connexion.');
    }
  },

  renderPanel: function() {
    const d = this.get();

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +

      '<div class="sec-title">🚀 Publier sur mes reseaux</div>' +
      '<p class="note">Legende generee et copiee en un clic. Vous n avez plus qu a coller et publier.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">' +
          'En attendant la connexion directe aux plateformes — Or Eille AI copie votre legende et ouvre le reseau. Vous collez. Vous publiez. Trois secondes.' +
        '</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<input type="text" id="ss-topic" placeholder="Decrivez votre contenu — ex: Reel sur les soins cheveux naturels"/>' +
      '<input type="text" id="ss-style" placeholder="Ton souhaite — ex: chaleureux, humoristique, educatif..."/>' +

      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
        ['instagram','tiktok','youtube','linkedin','twitter'].map(function(p) {
          const pl = SOCIAL.PLATFORMS[p];
          return '<button onclick="SOCIAL.generateCaption(\'' + p + '\', document.getElementById(\'ss-topic\').value, document.getElementById(\'ss-style\').value, window.CFG&&window.CFG.CLAUDE_KEY)" style="flex:1;padding:.35rem .2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:\'Josefin Sans\',sans-serif;font-size:.44rem;cursor:pointer">' + pl.icon + ' ' + pl.label + '</button>';
        }).join('') +
      '</div>' +

      '<textarea id="ss-caption" placeholder="Votre legende — generee ou ecrite ici..." style="min-height:100px"></textarea>' +
      '<input type="text" id="ss-hashtags" placeholder="Hashtags — ex: #createur #contenu #madameoreille"/>' +

      '<div class="sec-title">Copier et ouvrir</div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">' +
        Object.keys(this.PLATFORMS).map(function(key) {
          const p = SOCIAL.PLATFORMS[key];
          return '<button onclick="SOCIAL.copyAndOpen(\'' + key + '\')" style="padding:.5rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:\'Josefin Sans\',sans-serif;font-size:.5rem;cursor:pointer;display:flex;align-items:center;gap:.3rem">' +
            '<span>' + p.icon + '</span><span>' + p.label + '</span>' +
          '</button>';
        }).join('') +
      '</div>' +

      (d.history.length > 0 ? (
        '<div class="sec-title">Publications recentes</div>' +
        d.history.slice(0,5).map(function(h) {
          return '<div style="padding:.4rem;border:1px solid var(--border);font-size:.48rem;color:var(--muted)">' +
            SOCIAL.PLATFORMS[h.platform]?.icon + ' ' + h.platform + ' — ' + h.caption + '... — ' + new Date(h.at).toLocaleDateString('fr-FR') +
          '</div>';
        }).join('')
      ) : '') +

    '</div>';
  },

  renderPanel: function() {
    const d = this.get();
    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +

      '<div class="sec-title">🚀 Publier sur mes reseaux</div>' +
      '<p class="note">Verifiez, generez votre legende, copiez en un clic. Vous n avez plus qu a coller et publier.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">' +
          'Avant de publier — Or Eille AI verifie tout. Legende, hashtags, droits musicaux, format, police des sous-titres. Si la musique est coupee par la plateforme — remplacement automatique par une version similaire libre de droits.' +
        '</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<input type="text" id="ss-topic" placeholder="Decrivez votre contenu — ex: Reel soins cheveux naturels"/>' +
      '<input type="text" id="ss-style" placeholder="Ton — ex: chaleureux, educatif, humoristique..."/>' +
      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
        ['instagram','tiktok','youtube','linkedin','twitter'].map(function(p) {
          const pl = SOCIAL.PLATFORMS[p];
          return '<button onclick="SOCIAL.generateCaption(\'' + p + '\',document.getElementById(\'ss-topic\').value,document.getElementById(\'ss-style\').value,window.CFG&&window.CFG.CLAUDE_KEY)" style="flex:1;padding:.35rem .2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:\'Josefin Sans\',sans-serif;font-size:.44rem;cursor:pointer">' + pl.icon + ' ' + pl.label + '</button>';
        }).join('') +
      '</div>' +

      '<textarea id="ss-caption" placeholder="Votre legende — generee ou ecrite ici..." style="min-height:100px"></textarea>' +
      '<input type="text" id="ss-hashtags" placeholder="#hashtags #createur #madameoreille"/>' +
      '<input type="text" id="ss-music" placeholder="Musique utilisee — ex: titre + artiste"/>' +

      '<div class="sec-title">Check avant publication</div>' +
      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
        ['instagram','tiktok','youtube','facebook'].map(function(p) {
          const pl = SOCIAL.PLATFORMS[p];
          return '<button onclick="SOCIAL.preCheck(\'' + p + '\',window.CFG&&window.CFG.CLAUDE_KEY)" style="flex:1;padding:.35rem .2rem;background:rgba(196,153,58,.1);border:1px solid rgba(196,153,58,.3);color:var(--gold);font-family:\'Josefin Sans\',sans-serif;font-size:.44rem;cursor:pointer">✓ ' + pl.label + '</button>';
        }).join('') +
      '</div>' +

      '<div class="sec-title">Copier et ouvrir</div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">' +
        Object.keys(this.PLATFORMS).map(function(key) {
          const p = SOCIAL.PLATFORMS[key];
          return '<button onclick="SOCIAL.copyAndOpen(\'' + key + '\')" style="padding:.5rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:\'Josefin Sans\',sans-serif;font-size:.5rem;cursor:pointer;display:flex;align-items:center;gap:.3rem">' +
            p.icon + ' ' + p.label +
          '</button>';
        }).join('') +
      '</div>' +

      (d.history.length > 0 ? (
        '<div class="sec-title">Recemment publie</div>' +
        d.history.slice(0,3).map(function(h) {
          return '<div style="padding:.4rem;border:1px solid var(--border);font-size:.48rem;color:var(--muted)">' +
            (SOCIAL.PLATFORMS[h.platform]?SOCIAL.PLATFORMS[h.platform].icon:'') + ' ' + h.platform + ' — ' + h.caption + '... — ' + new Date(h.at).toLocaleDateString('fr-FR') +
          '</div>';
        }).join('')
      ) : '') +

    '</div>';
  }
};

window.SOCIAL = SOCIAL;
