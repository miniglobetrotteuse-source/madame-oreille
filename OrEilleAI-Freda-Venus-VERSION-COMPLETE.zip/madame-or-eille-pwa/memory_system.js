// ═══════════════════════════════════════════════════
//  SYSTÈME DE MÉMOIRE PERSISTANTE — Or Eille AI v1.0
//  Mémoire Profil + Mémoire Projet
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const MEMORY_SYSTEM = {

  // ─── CLÉS DE STOCKAGE ─────────────────────────
  KEYS: {
    PROFILE: 'moe_memory_profile',
    PROJECTS: 'moe_memory_projects',
    ACTIVE_PROJECT: 'moe_memory_active_project',
  },

  // ═══════════════════════════════════════════════
  //  MÉMOIRE PROFIL
  //  Tout ce qui ne doit être demandé qu'une seule fois
  // ═══════════════════════════════════════════════

  getProfile() {
    try {
      return JSON.parse(localStorage.getItem(this.KEYS.PROFILE)) || this._defaultProfile();
    } catch { return this._defaultProfile(); }
  },

  _defaultProfile() {
    return {
      // Identité
      prenom: '',
      langue: 'fr',
      style_communication: '', // visuel, analytique, créatif, direct

      // Accessibilité — configuré une fois, appliqué partout
      accessibilite: {
        taille_police: 'normal',    // petit, normal, grand, tres_grand
        espacement: 'normal',
        police_dyslexie: false,
        contraste: 'normal',        // normal, renforce, maximum
        guide_vocal: false,
        vibrations: false,
        neurodivergent: false,
        malvoyant: false,
        malentendant: false,
        profil_neuro: '',           // tdah, tsa, dys, autre
      },

      // Projets connus
      projets: [],

      // Équipe — qui fait quoi
      equipe: [],
      // ex: [{ nom: 'Mamadou', role: 'développeur, mise en ligne', actif: true }]

      // Préférences contenu
      plateformes: [],             // instagram, tiktok, youtube...
      ton_editorial: '',
      audience: '',

      // Meta
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
  },

  saveProfile(updates) {
    const current = this.getProfile();
    const updated = this._deepMerge(current, updates);
    updated.updated_at = new Date().toISOString();
    try {
      localStorage.setItem(this.KEYS.PROFILE, JSON.stringify(updated));
      return true;
    } catch { return false; }
  },

  // ═══════════════════════════════════════════════
  //  MÉMOIRE PROJET
  //  Historique complet par projet
  // ═══════════════════════════════════════════════

  getAllProjects() {
    try {
      return JSON.parse(localStorage.getItem(this.KEYS.PROJECTS)) || [];
    } catch { return []; }
  },

  getProject(projectId) {
    const projects = this.getAllProjects();
    return projects.find(p => p.id === projectId) || null;
  },

  getActiveProject() {
    const id = localStorage.getItem(this.KEYS.ACTIVE_PROJECT);
    if (!id) return null;
    return this.getProject(id);
  },

  setActiveProject(projectId) {
    localStorage.setItem(this.KEYS.ACTIVE_PROJECT, projectId);
  },

  createProject(name) {
    const project = {
      id: 'proj_' + Date.now(),
      nom: name,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),

      // Contexte
      description: '',
      statut: 'en_cours',          // en_cours, pause, termine

      // Équipe sur CE projet
      equipe: [],
      // ex: [{ nom: 'Mamadou', role: 'hébergement et mise en ligne', actif: true }]

      // Décisions prises — ne plus reposer ces questions
      decisions: [],
      // ex: [{ date, contenu: 'Jeff a quitté le projet' }]

      // Tâches
      taches: {
        faites: [],
        en_cours: [],
        a_faire: [],
      },

      // Historique des conversations importantes
      historique: [],
      // ex: [{ date, resume: 'Session de test des modules - tout fonctionne sauf Avatar' }]

      // Fichiers et liens associés
      fichiers: [],
      // ex: [{ nom: 'OrEilleAI-v20-FINAL.zip', date, note: 'Version corrigée avec Bodoni Moda' }]
    };

    const projects = this.getAllProjects();
    projects.push(project);
    this._saveAllProjects(projects);
    return project;
  },

  updateProject(projectId, updates) {
    const projects = this.getAllProjects();
    const idx = projects.findIndex(p => p.id === projectId);
    if (idx === -1) return false;
    projects[idx] = this._deepMerge(projects[idx], updates);
    projects[idx].updated_at = new Date().toISOString();
    this._saveAllProjects(projects);
    return true;
  },

  // Ajouter une décision à un projet
  addDecision(projectId, contenu) {
    const projects = this.getAllProjects();
    const idx = projects.findIndex(p => p.id === projectId);
    if (idx === -1) return false;
    projects[idx].decisions.push({
      id: 'dec_' + Date.now(),
      date: new Date().toISOString(),
      contenu,
    });
    projects[idx].updated_at = new Date().toISOString();
    this._saveAllProjects(projects);
    return true;
  },

  // Ajouter une note d'historique
  addHistorique(projectId, resume) {
    const projects = this.getAllProjects();
    const idx = projects.findIndex(p => p.id === projectId);
    if (idx === -1) return false;
    projects[idx].historique.push({
      id: 'hist_' + Date.now(),
      date: new Date().toISOString(),
      resume,
    });
    projects[idx].updated_at = new Date().toISOString();
    this._saveAllProjects(projects);
    return true;
  },

  // Ajouter/mettre à jour un membre d'équipe sur un projet
  updateEquipeMembre(projectId, nom, role, actif = true) {
    const projects = this.getAllProjects();
    const idx = projects.findIndex(p => p.id === projectId);
    if (idx === -1) return false;
    const equipe = projects[idx].equipe;
    const memberIdx = equipe.findIndex(m => m.nom.toLowerCase() === nom.toLowerCase());
    if (memberIdx >= 0) {
      equipe[memberIdx] = { nom, role, actif, updated_at: new Date().toISOString() };
    } else {
      equipe.push({ nom, role, actif, added_at: new Date().toISOString() });
    }
    projects[idx].updated_at = new Date().toISOString();
    this._saveAllProjects(projects);
    return true;
  },

  // ═══════════════════════════════════════════════
  //  CONTEXTE POUR L'ASSISTANT IA
  //  Génère le contexte à injecter dans chaque prompt
  // ═══════════════════════════════════════════════

  buildAssistantContext() {
    const profile = this.getProfile();
    const activeProject = this.getActiveProject();
    let context = '';

    // Profil utilisateur
    if (profile.prenom) {
      context += `L'utilisatrice s'appelle ${profile.prenom}. `;
    }
    if (profile.accessibilite.malvoyant) {
      context += `Elle est malvoyante — adapter les réponses : texte clair, pas de références visuelles. `;
    }
    if (profile.accessibilite.neurodivergent && profile.accessibilite.profil_neuro) {
      context += `Elle est neurodivergente (${profile.accessibilite.profil_neuro}) — réponses courtes, structurées, sans surcharge. `;
    }
    if (profile.accessibilite.malentendant) {
      context += `Elle est malentendante — privilégier le texte au son. `;
    }
    if (profile.style_communication) {
      context += `Son style de communication préféré : ${profile.style_communication}. `;
    }

    // Projet actif
    if (activeProject) {
      context += `\n\nPROJET ACTIF : "${activeProject.nom}"\n`;

      // Équipe
      if (activeProject.equipe.length > 0) {
        const actifs = activeProject.equipe.filter(m => m.actif);
        const inactifs = activeProject.equipe.filter(m => !m.actif);
        if (actifs.length > 0) {
          context += `Équipe active : ${actifs.map(m => `${m.nom} (${m.role})`).join(', ')}. `;
        }
        if (inactifs.length > 0) {
          context += `Ne font plus partie du projet : ${inactifs.map(m => m.nom).join(', ')}. Ne pas les mentionner comme collaborateurs actifs. `;
        }
      }

      // Décisions importantes
      if (activeProject.decisions.length > 0) {
        context += `\nDécisions prises (ne pas remettre en question) :\n`;
        activeProject.decisions.slice(-10).forEach(d => {
          context += `- ${d.contenu}\n`;
        });
      }

      // Historique récent
      if (activeProject.historique.length > 0) {
        context += `\nHistorique récent :\n`;
        activeProject.historique.slice(-5).forEach(h => {
          const date = new Date(h.date).toLocaleDateString('fr-FR');
          context += `- ${date} : ${h.resume}\n`;
        });
      }
    }

    return context.trim();
  },

  // ═══════════════════════════════════════════════
  //  UTILITAIRES
  // ═══════════════════════════════════════════════

  _saveAllProjects(projects) {
    try {
      localStorage.setItem(this.KEYS.PROJECTS, JSON.stringify(projects));
      return true;
    } catch { return false; }
  },

  _deepMerge(target, source) {
    const result = { ...target };
    for (const key in source) {
      if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
        result[key] = this._deepMerge(target[key] || {}, source[key]);
      } else {
        result[key] = source[key];
      }
    }
    return result;
  },

  // ─── Interface panneau Mémoire ─────────────────
  renderPanel() {
    const profile = this.getProfile();
    const projects = this.getAllProjects();
    const activeProject = this.getActiveProject();

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div class="sec-title">👤 Mémoire Profil</div>

      <div style="display:flex;flex-direction:column;gap:.4rem">
        <label style="font-size:.5rem;color:var(--muted);letter-spacing:.1em;text-transform:uppercase">Prénom</label>
        <input type="text" id="mem_prenom" value="${profile.prenom || ''}"
          placeholder="Votre prénom"
          style="background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.62rem;padding:.5rem .65rem;outline:none"
          oninput="MEMORY_SYSTEM.saveProfile({prenom: this.value})"/>
      </div>

      <div style="display:flex;flex-direction:column;gap:.4rem">
        <label style="font-size:.5rem;color:var(--muted);letter-spacing:.1em;text-transform:uppercase">Style de communication</label>
        <select id="mem_style" onchange="MEMORY_SYSTEM.saveProfile({style_communication: this.value})"
          style="background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.58rem;padding:.45rem;outline:none">
          <option value="" ${!profile.style_communication ? 'selected' : ''}>— Choisir —</option>
          <option value="direct" ${profile.style_communication==='direct' ? 'selected' : ''}>Direct et concis</option>
          <option value="visuel" ${profile.style_communication==='visuel' ? 'selected' : ''}>Visuel et créatif</option>
          <option value="analytique" ${profile.style_communication==='analytique' ? 'selected' : ''}>Analytique et structuré</option>
          <option value="narratif" ${profile.style_communication==='narratif' ? 'selected' : ''}>Narratif et oral</option>
        </select>
      </div>

      <div class="sep"></div>
      <div class="sec-title">🧠 Accessibilité mémorisée</div>
      <p style="font-size:.52rem;color:var(--muted);line-height:1.6">Ces paramètres sont appliqués automatiquement. Vous ne les reconfigurez qu'une seule fois.</p>

      <div style="display:flex;gap:.4rem;flex-wrap:wrap">
        <label style="display:flex;align-items:center;gap:.3rem;font-size:.55rem;color:var(--text);cursor:pointer">
          <input type="checkbox" ${profile.accessibilite.neurodivergent ? 'checked' : ''}
            onchange="MEMORY_SYSTEM.saveProfile({accessibilite:{neurodivergent:this.checked}})"/>
          Neurodivergent(e)
        </label>
        <label style="display:flex;align-items:center;gap:.3rem;font-size:.55rem;color:var(--text);cursor:pointer">
          <input type="checkbox" ${profile.accessibilite.malvoyant ? 'checked' : ''}
            onchange="MEMORY_SYSTEM.saveProfile({accessibilite:{malvoyant:this.checked}})"/>
          Malvoyant(e)
        </label>
        <label style="display:flex;align-items:center;gap:.3rem;font-size:.55rem;color:var(--text);cursor:pointer">
          <input type="checkbox" ${profile.accessibilite.malentendant ? 'checked' : ''}
            onchange="MEMORY_SYSTEM.saveProfile({accessibilite:{malentendant:this.checked}})"/>
          Malentendant(e)
        </label>
      </div>

      <div class="sep"></div>
      <div class="sec-title">📁 Projets</div>

      <div style="display:flex;gap:.4rem">
        <input type="text" id="new_project_name" placeholder="Nom du nouveau projet"
          style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.58rem;padding:.45rem;outline:none"/>
        <button class="btn btn-gold" style="white-space:nowrap" onclick="
          const name = document.getElementById('new_project_name').value.trim();
          if(name) {
            const p = MEMORY_SYSTEM.createProject(name);
            MEMORY_SYSTEM.setActiveProject(p.id);
            document.getElementById('memorySystemContent').innerHTML = MEMORY_SYSTEM.renderPanel();
          }
        ">+ Créer</button>
      </div>

      ${projects.length === 0 ? `
        <p style="font-size:.55rem;color:var(--muted);text-align:center;padding:1rem">Aucun projet. Créez votre premier projet ci-dessus.</p>
      ` : projects.map(p => `
        <div style="padding:.7rem;border:1px solid ${activeProject?.id === p.id ? 'var(--gold)' : 'var(--border)'};cursor:pointer;transition:all .15s"
          onclick="MEMORY_SYSTEM.setActiveProject('${p.id}');document.getElementById('memorySystemContent').innerHTML = MEMORY_SYSTEM.renderPanel()">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.3rem">
            <span style="font-size:.6rem;color:${activeProject?.id === p.id ? 'var(--gold)' : 'var(--text)'};font-weight:700">${p.nom}</span>
            ${activeProject?.id === p.id ? '<span style="font-size:.45rem;color:var(--gold);letter-spacing:.1em;text-transform:uppercase">ACTIF</span>' : ''}
          </div>
          <div style="font-size:.5rem;color:var(--muted)">${p.decisions.length} décision(s) · ${p.historique.length} note(s) · ${p.equipe.length} personne(s)</div>
          ${p.statut === 'termine' ? '<div style="font-size:.45rem;color:#4CAF50;margin-top:.2rem">✅ Projet terminé</div>' : ''}
        </div>
      `).join('')}

      ${activeProject ? `
        <div class="sep"></div>
        <div class="sec-title">📌 Projet actif : ${activeProject.nom}</div>

        <div style="display:flex;flex-direction:column;gap:.4rem">
          <label style="font-size:.5rem;color:var(--muted);letter-spacing:.1em;text-transform:uppercase">Ajouter une décision</label>
          <div style="display:flex;gap:.4rem">
            <input type="text" id="new_decision" placeholder="Ex: Mamadou s'occupe de l'hébergement"
              style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.58rem;padding:.45rem;outline:none"/>
            <button class="btn btn-gold" onclick="
              const d = document.getElementById('new_decision').value.trim();
              if(d) { MEMORY_SYSTEM.addDecision('${activeProject.id}', d); document.getElementById('new_decision').value=''; document.getElementById('memorySystemContent').innerHTML = MEMORY_SYSTEM.renderPanel(); }
            ">+ Ajouter</button>
          </div>
        </div>

        ${activeProject.decisions.length > 0 ? `
          <div style="display:flex;flex-direction:column;gap:.25rem">
            ${activeProject.decisions.slice(-5).map(d => `
              <div style="padding:.4rem .6rem;background:var(--dark-mid);border-left:2px solid var(--gold);font-size:.55rem;color:var(--text)">
                ${d.contenu}
              </div>
            `).join('')}
          </div>
        ` : ''}

        <div style="display:flex;flex-direction:column;gap:.4rem">
          <label style="font-size:.5rem;color:var(--muted);letter-spacing:.1em;text-transform:uppercase">Ajouter une note de session</label>
          <div style="display:flex;gap:.4rem">
            <input type="text" id="new_historique" placeholder="Ex: Test complet des modules, Avatar à corriger"
              style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.58rem;padding:.45rem;outline:none"/>
            <button class="btn btn-gold" onclick="
              const h = document.getElementById('new_historique').value.trim();
              if(h) { MEMORY_SYSTEM.addHistorique('${activeProject.id}', h); document.getElementById('new_historique').value=''; document.getElementById('memorySystemContent').innerHTML = MEMORY_SYSTEM.renderPanel(); }
            ">+ Ajouter</button>
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:.4rem">
          <label style="font-size:.5rem;color:var(--muted);letter-spacing:.1em;text-transform:uppercase">Équipe sur ce projet</label>
          <div style="display:flex;gap:.3rem">
            <input type="text" id="eq_nom" placeholder="Prénom" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.55rem;padding:.4rem;outline:none"/>
            <input type="text" id="eq_role" placeholder="Rôle" style="flex:2;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.55rem;padding:.4rem;outline:none"/>
            <button class="btn btn-gold" style="white-space:nowrap" onclick="
              const nom = document.getElementById('eq_nom').value.trim();
              const role = document.getElementById('eq_role').value.trim();
              if(nom && role) { MEMORY_SYSTEM.updateEquipeMembre('${activeProject.id}', nom, role); document.getElementById('eq_nom').value=''; document.getElementById('eq_role').value=''; document.getElementById('memorySystemContent').innerHTML = MEMORY_SYSTEM.renderPanel(); }
            ">+ Ajouter</button>
          </div>
          ${activeProject.equipe.map(m => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:.35rem .5rem;border:1px solid var(--border);font-size:.55rem">
              <span style="color:${m.actif ? 'var(--text)' : 'var(--muted)'}${m.actif ? '' : ';text-decoration:line-through'}">${m.nom} — ${m.role}</span>
              <button onclick="MEMORY_SYSTEM.updateEquipeMembre('${activeProject.id}', '${m.nom}', '${m.role}', ${!m.actif}); document.getElementById('memorySystemContent').innerHTML = MEMORY_SYSTEM.renderPanel();"
                style="background:transparent;border:1px solid var(--border);color:var(--muted);font-size:.45rem;padding:.2rem .4rem;cursor:pointer">
                ${m.actif ? 'Désactiver' : 'Réactiver'}
              </button>
            </div>
          `).join('')}
        </div>
      ` : ''}

    </div>`;
  },
};

window.MEMORY_SYSTEM = MEMORY_SYSTEM;

// ─── Célébration fin de projet ─────────────────
MEMORY_SYSTEM.celebrerFinProjet = function(projectId) {
  const project = this.getProject(projectId);
  if (!project) return;

  const prenom = this.getProfile().prenom || '';
  const duree = this._calculerDuree(project.created_at);

  const messages = [
    `🎉 Félicitations ${prenom} ! Le projet "${project.nom}" est terminé. Vous avez mis de l'énergie, du temps, de vous-même dans ce travail. C'est une vraie réussite. Prenez le temps de l'accueillir.`,
    `✨ C'est fait ${prenom} ! "${project.nom}" est bouclé. ${duree} de travail. Chaque étape compte, chaque effort compte. Soyez fier(e) de ce que vous avez accompli.`,
    `🌟 Bravo ${prenom} ! Le projet "${project.nom}" est prêt. Il peut être envoyé, imprimé, partagé — il vous appartient. Heureux d'avoir été là pour vous accompagner. À la prochaine aventure !`,
  ];

  const message = messages[Math.floor(Math.random() * messages.length)];

  // Afficher le message de célébration
  const modal = document.createElement('div');
  modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.95);z-index:99999;display:flex;align-items:center;justify-content:center;padding:1.5rem';
  modal.innerHTML = `
    <div style="max-width:340px;width:100%;text-align:center;display:flex;flex-direction:column;gap:1rem;align-items:center">
      <div style="font-size:3rem">🎉</div>
      <div style="font-size:.9rem;color:var(--gold);font-family:'Cormorant Garamond',serif;font-style:italic">
        Projet terminé
      </div>
      <p style="font-size:.62rem;color:#fff;line-height:1.9">${message}</p>
      <div style="font-size:.52rem;color:var(--muted);line-height:1.7">
        Durée du projet : ${duree}<br>
        ${project.decisions.length} décision(s) prise(s)<br>
        ${project.historique.length} session(s) de travail
      </div>
      <button onclick="this.closest('div').closest('div').remove()"
        style="width:100%;padding:.8rem;background:var(--gold);color:var(--dark);border:none;font-family:inherit;font-size:.62rem;font-weight:700;cursor:pointer;margin-top:.5rem">
        ✓ Merci, à bientôt !
      </button>
    </div>`;
  document.body.appendChild(modal);

  // Parler si vocal activé
  if (window.speak) speak(message);

  // Marquer le projet comme terminé
  this.updateProject(projectId, { statut: 'termine' });
};

MEMORY_SYSTEM._calculerDuree = function(dateDebut) {
  const debut = new Date(dateDebut);
  const maintenant = new Date();
  const jours = Math.floor((maintenant - debut) / (1000 * 3600 * 24));
  if (jours === 0) return 'moins d\'un jour';
  if (jours === 1) return '1 jour';
  if (jours < 7) return `${jours} jours`;
  if (jours < 30) return `${Math.floor(jours/7)} semaine(s)`;
  return `${Math.floor(jours/30)} mois`;
};

// ─── Patch bouton terminer dans renderPanel ────
const _renderPanelOrig = MEMORY_SYSTEM.renderPanel.bind(MEMORY_SYSTEM);
MEMORY_SYSTEM.renderPanel = function() {
  let html = _renderPanelOrig();
  const activeProject = this.getActiveProject();
  if (activeProject && activeProject.statut !== 'termine') {
    const btnTerminer = `
      <div style="padding:.5rem;border-top:1px solid var(--border);margin-top:.5rem">
        <button onclick="MEMORY_SYSTEM.celebrerFinProjet('${activeProject.id}')"
          style="width:100%;padding:.8rem;background:linear-gradient(135deg,#2E7D32,#4CAF50);color:#fff;border:none;font-family:inherit;font-size:.62rem;font-weight:700;cursor:pointer">
          🎉 Ce projet est terminé !
        </button>
      </div>`;
    html = html.replace('</div>', btnTerminer + '</div>');
  }
  return html;
};
