// ============================================================
// CV BUILDER — Or Eille AI v20
// CV et lettres de motivation adaptés par pays
// © 2026 Madame Or Eille Studios
// ============================================================

const CV_BUILDER = {

  pays: [
    // EUROPE FRANCOPHONE
    { id:'france', flag:'🇫🇷', nom:'France', region:'Europe francophone',
      photo:'optionnelle', age:'inclus', longueur:'1 page', lettre:'obligatoire',
      style:'Chronologique inversé, formel, accent sur diplômes et compétences',
      pieges:'Pas de fautes. Ne pas dépasser 1 page pour les juniors. Lettre personnalisée.',
      templates:['Classique français','Moderne minimaliste','Créatif élégant'] },

    { id:'belgique', flag:'🇧🇪', nom:'Belgique', region:'Europe francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'recommandée',
      style:'Similaire France, légèrement plus souple. Mentionner le bilinguisme.',
      pieges:'Préciser la région si bilingue FR/NL.',
      templates:['Classique belge','Bilingue','Moderne'] },

    { id:'suisse', flag:'🇨🇭', nom:'Suisse', region:'Europe francophone',
      photo:'obligatoire', age:'inclus', longueur:'2 pages', lettre:'obligatoire',
      style:'Très structuré, précis, références professionnelles importantes.',
      pieges:'Toujours inclure une photo professionnelle. Très formel.',
      templates:['Suisse classique','Précision suisse','Bilingue FR/DE'] },

    { id:'luxembourg', flag:'🇱🇺', nom:'Luxembourg', region:'Europe francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'recommandée',
      style:'Multilingue apprécié. Formel mais ouvert.',
      pieges:'Mentionner toutes les langues maîtrisées — très valorisé.',
      templates:['Classique Luxembourg','Multilingue','Moderne'] },

    // EUROPE ANGLOPHONE
    { id:'uk', flag:'🇬🇧', nom:'Royaume-Uni', region:'Europe anglophone',
      photo:'interdite', age:'ne pas mentionner', longueur:'2 pages max', lettre:'courte et directe',
      style:'Orienté compétences et résultats chiffrés. Pas de vie privée.',
      pieges:'Jamais de photo, âge, situation familiale. On appelle ça un CV pas un résumé.',
      templates:['UK Professional','UK Creative','UK Graduate'] },

    { id:'irlande', flag:'🇮🇪', nom:'Irlande', region:'Europe anglophone',
      photo:'déconseillée', age:'optionnel', longueur:'2 pages', lettre:'recommandée',
      style:'Proche UK, un peu plus chaleureux.',
      pieges:'Mentionner le droit de travailler en Irlande si applicable.',
      templates:['Ireland Classic','Ireland Modern','Ireland Graduate'] },

    // EUROPE AUTRES
    { id:'allemagne', flag:'🇩🇪', nom:'Allemagne', region:'Europe',
      photo:'obligatoire', age:'inclus', longueur:'2-3 pages', lettre:'obligatoire',
      style:'Lebenslauf très structuré. Photo professionnelle obligatoire.',
      pieges:'Format Lebenslauf strict. Lettre appelée Anschreiben, très formelle.',
      templates:['Lebenslauf classique','Lebenslauf moderne','Lebenslauf créatif'] },

    { id:'espagne', flag:'🇪🇸', nom:'Espagne', region:'Europe',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'optionnelle',
      style:'Curriculum Vitae, formel, relations personnelles importantes.',
      pieges:'Le réseau compte beaucoup. Lettre appelée Carta de presentación.',
      templates:['CV España clásico','CV España moderno','CV España creativo'] },

    { id:'italie', flag:'🇮🇹', nom:'Italie', region:'Europe',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'recommandée',
      style:'Format Europass souvent utilisé. Relations et recommandations importantes.',
      pieges:'Le format Europass est très accepté en Italie.',
      templates:['CV Italia classico','Europass Italia','CV Italia moderno'] },

    { id:'portugal', flag:'🇵🇹', nom:'Portugal', region:'Europe',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'recommandée',
      style:'Formel, chronologique. Relations personnelles valorisées.',
      pieges:'Curriculum Vitae — mentionner les langues, très apprécié.',
      templates:['CV Portugal clássico','CV Portugal moderno','Europass Portugal'] },

    { id:'paysbas', flag:'🇳🇱', nom:'Pays-Bas', region:'Europe',
      photo:'optionnelle', age:'optionnel', longueur:'1-2 pages', lettre:'recommandée',
      style:'Direct, orienté compétences, culture très égalitaire.',
      pieges:'Très direct — pas de fioriture. Valoriser l\'initiative personnelle.',
      templates:['NL Classic','NL Modern','NL Creative'] },

    // AMÉRIQUE DU NORD
    { id:'usa', flag:'🇺🇸', nom:'États-Unis', region:'Amérique du Nord',
      photo:'interdite', age:'ne pas mentionner', longueur:'1 page stricte', lettre:'cover letter courte',
      style:'Résumé orienté résultats chiffrés. Action verbs. Très concis.',
      pieges:'Jamais de photo, âge, nationalité, situation familiale. 1 page maximum.',
      templates:['US Resume Classic','US Resume Modern','US Resume Tech'] },

    { id:'canada_en', flag:'🇨🇦', nom:'Canada (anglophone)', region:'Amérique du Nord',
      photo:'déconseillée', age:'ne pas mentionner', longueur:'2 pages', lettre:'recommandée',
      style:'Proche USA mais légèrement plus souple. Résultats chiffrés.',
      pieges:'Mentionner le droit de travailler au Canada si applicable.',
      templates:['Canada EN Classic','Canada EN Modern','Canada EN Tech'] },

    { id:'canada_fr', flag:'🇨🇦', nom:'Canada (Québec)', region:'Amérique du Nord',
      photo:'déconseillée', age:'ne pas mentionner', longueur:'2 pages', lettre:'recommandée',
      style:'Mélange culture française et nord-américaine. CV en français.',
      pieges:'Ne pas faire un CV à la française trop formel — adapter au style nord-américain.',
      templates:['Québec classique','Québec moderne','Québec bilingue'] },

    // AFRIQUE FRANCOPHONE
    { id:'senegal', flag:'🇸🇳', nom:'Sénégal', region:'Afrique francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'obligatoire',
      style:'Très formel, respectueux des titres et hiérarchies. Lettre très soignée.',
      pieges:'Toujours mentionner les titres académiques. Lettre très personnalisée et respectueuse.',
      templates:['CV Sénégal classique','CV Sénégal moderne','CV Sénégal international'] },

    { id:'cote_ivoire', flag:'🇨🇮', nom:"Côte d'Ivoire", region:'Afrique francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'obligatoire',
      style:'Formel, titres importants, lettre très soignée.',
      pieges:'Mentionner clairement les diplômes et leur équivalence si étrangers.',
      templates:["CV Côte d'Ivoire classique","CV Côte d'Ivoire moderne","CV international"] },

    { id:'cameroun', flag:'🇨🇲', nom:'Cameroun', region:'Afrique francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'obligatoire',
      style:'Bilingue FR/EN apprécié. Formel. Diplômes très importants.',
      pieges:'Préciser la maîtrise du français ET de l\'anglais si applicable — très valorisé.',
      templates:['CV Cameroun classique','CV Cameroun bilingue','CV Cameroun moderne'] },

    { id:'congo', flag:'🇨🇬', nom:'Congo', region:'Afrique francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'obligatoire',
      style:'Très formel. Respect de la hiérarchie. Diplômes centraux.',
      pieges:'Lettre très respectueuse. Mentionner toutes les formations.',
      templates:['CV Congo classique','CV Congo moderne','CV Congo international'] },

    { id:'rdc', flag:'🇨🇩', nom:'RD Congo', region:'Afrique francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'obligatoire',
      style:'Formel, titres académiques très importants.',
      pieges:'Préciser les équivalences de diplômes si études à l\'étranger.',
      templates:['CV RDC classique','CV RDC moderne','CV RDC international'] },

    { id:'mali', flag:'🇲🇱', nom:'Mali', region:'Afrique francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'obligatoire',
      style:'Formel, respectueux. Diplômes et expériences locales valorisés.',
      pieges:'Lettre de motivation très formelle et personnalisée.',
      templates:['CV Mali classique','CV Mali moderne','CV Mali international'] },

    { id:'benin', flag:'🇧🇯', nom:'Bénin', region:'Afrique francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'obligatoire',
      style:'Formel. Diplômes français ou locaux bien acceptés.',
      pieges:'Toujours inclure une lettre de motivation soignée.',
      templates:['CV Bénin classique','CV Bénin moderne','CV Bénin international'] },

    { id:'togo', flag:'🇹🇬', nom:'Togo', region:'Afrique francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'obligatoire',
      style:'Formel, hiérarchique. Diplômes et références importants.',
      pieges:'Lettre très respectueuse, mentionner les références si possible.',
      templates:['CV Togo classique','CV Togo moderne','CV Togo international'] },

    { id:'burkina', flag:'🇧🇫', nom:'Burkina Faso', region:'Afrique francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'obligatoire',
      style:'Formel. Expériences locales très valorisées.',
      pieges:'Mentionner l\'engagement communautaire si applicable.',
      templates:['CV Burkina classique','CV Burkina moderne','CV Burkina international'] },

    { id:'gabon', flag:'🇬🇦', nom:'Gabon', region:'Afrique francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'obligatoire',
      style:'Formel. Secteur pétrolier et international bien représenté.',
      pieges:'Langues étrangères très valorisées au Gabon.',
      templates:['CV Gabon classique','CV Gabon moderne','CV Gabon international'] },

    { id:'madagascar', flag:'🇲🇬', nom:'Madagascar', region:'Afrique francophone',
      photo:'recommandée', age:'inclus', longueur:'1-2 pages', lettre:'obligatoire',
      style:'Formel, bilingue FR/malgache. Diplômes français bien reconnus.',
      pieges:'Préciser les langues maîtrisées — très apprécié.',
      templates:['CV Madagascar classique','CV Madagascar moderne','CV Madagascar bilingue'] },

    // AFRIQUE ANGLOPHONE
    { id:'nigeria', flag:'🇳🇬', nom:'Nigeria', region:'Afrique anglophone',
      photo:'recommandée', age:'inclus', longueur:'2-3 pages', lettre:'recommandée',
      style:'Formel, diplômes très importants. Secteur privé dynamique.',
      pieges:'Mentionner clairement les diplômes et leurs institutions.',
      templates:['CV Nigeria classic','CV Nigeria modern','CV Nigeria international'] },

    { id:'ghana', flag:'🇬🇭', nom:'Ghana', region:'Afrique anglophone',
      photo:'recommandée', age:'inclus', longueur:'2 pages', lettre:'recommandée',
      style:'Proche UK. Formel mais chaleureux. Diplômes importants.',
      pieges:'Format proche du CV britannique mais légèrement plus souple sur la photo.',
      templates:['CV Ghana classic','CV Ghana modern','CV Ghana international'] },

    { id:'kenya', flag:'🇰🇪', nom:'Kenya', region:'Afrique anglophone',
      photo:'recommandée', age:'inclus', longueur:'2 pages', lettre:'recommandée',
      style:'Dynamique, orienté résultats. Secteur tech en pleine croissance.',
      pieges:'Mentionner les compétences numériques — très valorisé à Nairobi.',
      templates:['CV Kenya classic','CV Kenya modern','CV Kenya tech'] },

    { id:'afrique_sud', flag:'🇿🇦', nom:'Afrique du Sud', region:'Afrique anglophone',
      photo:'optionnelle', age:'inclus', longueur:'2-3 pages', lettre:'recommandée',
      style:'Multiculturel. Compétences en langues locales appréciées.',
      pieges:'Mentionner les langues — 11 langues officielles, la diversité est valorisée.',
      templates:['CV SA classic','CV SA modern','CV SA multilingual'] },

    { id:'ouganda', flag:'🇺🇬', nom:'Ouganda', region:'Afrique anglophone',
      photo:'recommandée', age:'inclus', longueur:'2 pages', lettre:'recommandée',
      style:'Formel, références importantes. ONG et secteur public dominants.',
      pieges:'Les références personnelles et professionnelles comptent beaucoup.',
      templates:['CV Uganda classic','CV Uganda modern','CV Uganda NGO'] },

    { id:'tanzanie', flag:'🇹🇿', nom:'Tanzanie', region:'Afrique anglophone',
      photo:'recommandée', age:'inclus', longueur:'2 pages', lettre:'recommandée',
      style:'Formel. Swahili et anglais. Secteur touristique et ONG importants.',
      pieges:'Mentionner le swahili si maîtrisé — très apprécié.',
      templates:['CV Tanzania classic','CV Tanzania modern','CV Tanzania international'] },

    // MOYEN-ORIENT
    { id:'emirats', flag:'🇦🇪', nom:'Émirats Arabes Unis', region:'Moyen-Orient',
      photo:'obligatoire', age:'inclus', longueur:'2-3 pages', lettre:'recommandée',
      style:'Très professionnel, photo obligatoire, nationalité à mentionner.',
      pieges:'Mentionner le visa/statut de résidence. Secteurs : finance, tech, luxe, construction.',
      templates:['CV UAE classic','CV UAE executive','CV UAE modern'] },

    { id:'qatar', flag:'🇶🇦', nom:'Qatar', region:'Moyen-Orient',
      photo:'obligatoire', age:'inclus', longueur:'2-3 pages', lettre:'recommandée',
      style:'Très formel, photo obligatoire. Secteurs : énergie, construction, sport.',
      pieges:'Mentionner les certifications professionnelles internationales.',
      templates:['CV Qatar classic','CV Qatar executive','CV Qatar modern'] },

    { id:'arabie', flag:'🇸🇦', nom:'Arabie Saoudite', region:'Moyen-Orient',
      photo:'obligatoire', age:'inclus', longueur:'2-3 pages', lettre:'recommandée',
      style:'Très formel. Vision 2030 ouvre de nouveaux secteurs.',
      pieges:'Respecter les codes culturels. Mentionner les certifications.',
      templates:['CV KSA classic','CV KSA executive','CV KSA Vision2030'] },

    // ASIE
    { id:'japon', flag:'🇯🇵', nom:'Japon', region:'Asie',
      photo:'obligatoire', age:'inclus', longueur:'1 page format Rirekisho', lettre:'optionnelle',
      style:'Format Rirekisho très standardisé. Photo obligatoire. Manuscrit traditionnel encore utilisé.',
      pieges:'Le format Rirekisho est quasi-obligatoire. Très codifié. Ponctualité et loyauté valorisées.',
      templates:['Rirekisho traditionnel','Rirekisho moderne','CV international Japon'] },

    { id:'chine', flag:'🇨🇳', nom:'Chine', region:'Asie',
      photo:'obligatoire', age:'inclus', longueur:'1-2 pages', lettre:'recommandée',
      style:'Photo obligatoire, âge et situation familiale inclus. Diplômes très importants.',
      pieges:'Les diplômes des grandes universités pèsent beaucoup. Réseau (Guanxi) essentiel.',
      templates:['CV Chine classique','CV Chine moderne','CV Chine international'] },

    { id:'coree', flag:'🇰🇷', nom:'Corée du Sud', region:'Asie',
      photo:'obligatoire', age:'inclus', longueur:'1-2 pages', lettre:'recommandée',
      style:'Photo obligatoire, très structuré. Entreprises familiales (chaebols) dominantes.',
      pieges:'L\'université d\'origine compte énormément. Compétences en anglais très valorisées.',
      templates:['CV Corée classique','CV Corée moderne','CV Corée international'] },
  ],

  // ─── État ───────────────────────────────────────────────
  state: {
    etape: 'choix_pays',
    paysChoisi: null,
    templateChoisi: null,
    typeDoc: 'cv', // cv | lettre | les_deux
    donnees: {},
    resultat: null
  },

  // ─── Init ────────────────────────────────────────────────
  init() {
    this.renderPanel();
    console.log('✅ CV Builder initialisé — ' + this.pays.length + ' pays');
  },

  // ─── Rendu principal ─────────────────────────────────────
  renderPanel() {
    const panel = document.getElementById('panel-cvbuilder');
    if (!panel) return;
    panel.innerHTML = `
      <div class="cvb-container">
        <div class="cvb-header">
          <div class="cvb-title">📄 CV BUILDER</div>
          <div class="cvb-subtitle">CV et lettres de motivation adaptés aux codes de chaque pays.</div>
          <div class="cvb-subtitle-small">Tu décris ton parcours. Or Eille AI génère un CV professionnel prêt à envoyer.</div>
        </div>
        <div id="cvb-content">${this.renderEtape()}</div>
      </div>
    `;
    this.attachEvents();
  },

  renderEtape() {
    switch(this.state.etape) {
      case 'choix_pays': return this.renderChoixPays();
      case 'choix_doc': return this.renderChoixDoc();
      case 'formulaire': return this.renderFormulaire();
      case 'generation': return this.renderGeneration();
      case 'resultat': return this.renderResultat();
      default: return this.renderChoixPays();
    }
  },

  // ─── Étape 1 : Choix du pays ─────────────────────────────
  renderChoixPays() {
    const regions = [...new Set(this.pays.map(p => p.region))];
    return `
      <div class="cvb-section">
        <div class="cvb-question">Pour quel pays tu cherches du travail ?</div>
        <input type="text" id="cvb-search" class="cvb-search" placeholder="🔍 Rechercher un pays..." />
        ${regions.map(region => `
          <div class="cvb-region-titre">${region}</div>
          <div class="cvb-pays-grid" data-region="${region}">
            ${this.pays.filter(p => p.region === region).map(p => `
              <div class="cvb-pays-card" data-pays="${p.id}">
                <span class="cvb-flag">${p.flag}</span>
                <span class="cvb-pays-nom">${p.nom}</span>
              </div>
            `).join('')}
          </div>
        `).join('')}
      </div>
    `;
  },

  // ─── Étape 2 : Choix du document ─────────────────────────
  renderChoixDoc() {
    const p = this.state.paysChoisi;
    return `
      <div class="cvb-section">
        <div class="cvb-retour" id="cvb-retour">← Changer de pays</div>
        <div class="cvb-pays-selectionne">${p.flag} ${p.nom}</div>
        
        <div class="cvb-regles">
          <div class="cvb-regle-item">📸 Photo : <strong>${p.photo}</strong></div>
          <div class="cvb-regle-item">📏 Longueur : <strong>${p.longueur}</strong></div>
          <div class="cvb-regle-item">✉️ Lettre : <strong>${p.lettre}</strong></div>
          <div class="cvb-regle-item">⚠️ À savoir : ${p.pieges}</div>
        </div>

        <div class="cvb-question">Qu'est-ce que tu veux générer ?</div>
        <div class="cvb-doc-choix">
          <div class="cvb-doc-card" data-doc="cv">
            <div class="cvb-doc-emoji">📄</div>
            <div class="cvb-doc-label">CV seulement</div>
          </div>
          <div class="cvb-doc-card" data-doc="lettre">
            <div class="cvb-doc-emoji">✉️</div>
            <div class="cvb-doc-label">Lettre de motivation seulement</div>
          </div>
          <div class="cvb-doc-card" data-doc="les_deux">
            <div class="cvb-doc-emoji">📦</div>
            <div class="cvb-doc-label">CV + Lettre de motivation</div>
          </div>
        </div>

        <div class="cvb-question" style="margin-top:20px">Choisis ton template</div>
        <div class="cvb-templates">
          ${p.templates.map((t, i) => `
            <div class="cvb-template-card ${i===0?'active':''}" data-template="${t}">
              ${t}
            </div>
          `).join('')}
        </div>
      </div>
    `;
  },

  // ─── Étape 3 : Formulaire ────────────────────────────────
  renderFormulaire() {
    const p = this.state.paysChoisi;
    return `
      <div class="cvb-section">
        <div class="cvb-retour" id="cvb-retour">← Retour</div>
        <div class="cvb-pays-selectionne">${p.flag} ${p.nom} — ${this.state.templateChoisi}</div>
        
        <div class="cvb-hint">
          Remplis ce que tu peux. Tu n'as pas tout ? Laisse vide — Or Eille AI adaptera.
        </div>

        <div class="cvb-form">
          <div class="cvb-form-section-titre">👤 Informations personnelles</div>
          <div class="cvb-field"><label>Prénom et nom</label><input id="cvb-nom" type="text" placeholder="Ex: Awa Diallo" /></div>
          <div class="cvb-field"><label>Poste recherché</label><input id="cvb-poste" type="text" placeholder="Ex: Comptable, Développeur web, Infirmière..." /></div>
          <div class="cvb-field"><label>Email</label><input id="cvb-email" type="text" placeholder="ton@email.com" /></div>
          <div class="cvb-field"><label>Téléphone</label><input id="cvb-tel" type="text" placeholder="+33 6 00 00 00 00" /></div>
          <div class="cvb-field"><label>Ville / Pays</label><input id="cvb-ville" type="text" placeholder="Ex: Paris, France" /></div>

          <div class="cvb-form-section-titre">🎓 Formation</div>
          <div class="cvb-field"><label>Décris ta formation (diplômes, écoles, années)</label>
            <textarea id="cvb-formation" rows="4" placeholder="Ex: Licence en Gestion, Université de Dakar, 2018-2021. BTS Commerce, Lycée technique d'Abidjan, 2016-2018..."></textarea></div>

          <div class="cvb-form-section-titre">💼 Expériences professionnelles</div>
          <div class="cvb-field"><label>Décris tes expériences (postes, entreprises, dates, missions)</label>
            <textarea id="cvb-experience" rows="5" placeholder="Ex: Assistante comptable chez Orange Sénégal (2021-2023) — gestion de la facturation, rapprochements bancaires, reporting mensuel..."></textarea></div>

          <div class="cvb-form-section-titre">🛠️ Compétences</div>
          <div class="cvb-field"><label>Tes compétences clés</label>
            <textarea id="cvb-competences" rows="3" placeholder="Ex: Excel avancé, comptabilité générale, anglais professionnel, permis B..."></textarea></div>

          <div class="cvb-form-section-titre">🌍 Langues</div>
          <div class="cvb-field"><label>Langues parlées et niveau</label>
            <input id="cvb-langues" type="text" placeholder="Ex: Français (natif), Anglais (courant), Wolof (natif), Arabe (notions)" /></div>

          ${this.state.typeDoc !== 'cv' ? `
            <div class="cvb-form-section-titre">✉️ Pour la lettre de motivation</div>
            <div class="cvb-field"><label>Nom de l'entreprise visée (si connu)</label>
              <input id="cvb-entreprise" type="text" placeholder="Ex: Société Générale, Orange, Google..." /></div>
            <div class="cvb-field"><label>Pourquoi ce poste / cette entreprise ?</label>
              <textarea id="cvb-motivation" rows="3" placeholder="Dis-le à ta façon — Or Eille AI reformulera selon les codes du pays..."></textarea></div>
          ` : ''}

          <button class="cvb-btn-generate" id="cvb-generer">
            ✨ Générer mon ${this.state.typeDoc === 'les_deux' ? 'CV + Lettre' : this.state.typeDoc === 'cv' ? 'CV' : 'Lettre de motivation'}
          </button>
        </div>
      </div>
    `;
  },

  // ─── Étape 4 : Génération ────────────────────────────────
  renderGeneration() {
    return `
      <div class="cvb-section cvb-generation">
        <div class="cvb-loading-icon">📝</div>
        <div class="cvb-loading-title">Génération en cours...</div>
        <div class="cvb-loading-sub">Or Eille AI adapte ton parcours aux codes de ${this.state.paysChoisi.nom}</div>
        <div class="cvb-loading-bar"><div class="cvb-loading-fill"></div></div>
      </div>
    `;
  },

  // ─── Étape 5 : Résultat ──────────────────────────────────
  renderResultat() {
    return `
      <div class="cvb-section">
        <div class="cvb-succes">
          <div class="cvb-succes-icon">🎉</div>
          <div class="cvb-succes-titre">Ton document est prêt !</div>
        </div>
        <div class="cvb-apercu-label">Aperçu</div>
        <div class="cvb-apercu" id="cvb-apercu"></div>
        <div class="cvb-actions">
          <button class="cvb-btn-primary" id="cvb-telecharger">⬇️ Télécharger</button>
          <button class="cvb-btn-secondary" id="cvb-modifier">✏️ Modifier</button>
          <button class="cvb-btn-tertiary" id="cvb-nouveau">🔄 Nouveau document</button>
        </div>
        <div class="cvb-conseil">
          <strong>💡 Conseil ${this.state.paysChoisi.flag}</strong><br>
          ${this.state.paysChoisi.style}
        </div>
      </div>
    `;
  },

  // ─── Événements ─────────────────────────────────────────
  attachEvents() {
    // Recherche pays
    const search = document.getElementById('cvb-search');
    if (search) {
      search.addEventListener('input', () => {
        const q = search.value.toLowerCase();
        document.querySelectorAll('.cvb-pays-card').forEach(card => {
          card.style.display = card.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
      });
    }

    // Choix pays
    document.querySelectorAll('.cvb-pays-card').forEach(card => {
      card.addEventListener('click', () => {
        const pays = this.pays.find(p => p.id === card.dataset.pays);
        this.state.paysChoisi = pays;
        this.state.templateChoisi = pays.templates[0];
        this.state.etape = 'choix_doc';
        this.update();
      });
    });

    // Retour
    const retour = document.getElementById('cvb-retour');
    if (retour) {
      retour.addEventListener('click', () => {
        this.state.etape = this.state.etape === 'choix_doc' ? 'choix_pays' : 'choix_doc';
        this.update();
      });
    }

    // Choix document
    document.querySelectorAll('.cvb-doc-card').forEach(card => {
      card.addEventListener('click', () => {
        document.querySelectorAll('.cvb-doc-card').forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        this.state.typeDoc = card.dataset.doc;
      });
    });

    // Choix template
    document.querySelectorAll('.cvb-template-card').forEach(card => {
      card.addEventListener('click', () => {
        document.querySelectorAll('.cvb-template-card').forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        this.state.templateChoisi = card.dataset.template;
      });
    });

    // Continuer vers formulaire
    document.querySelectorAll('.cvb-doc-card').forEach(card => {
      card.addEventListener('dblclick', () => {
        this.state.etape = 'formulaire';
        this.update();
      });
    });

    // Bouton suivant depuis choix_doc
    const btnSuivant = document.getElementById('cvb-suivant');
    if (btnSuivant) {
      btnSuivant.addEventListener('click', () => {
        this.state.etape = 'formulaire';
        this.update();
      });
    }

    // Générer
    const generer = document.getElementById('cvb-generer');
    if (generer) generer.addEventListener('click', () => this.generer());

    // Télécharger
    const tel = document.getElementById('cvb-telecharger');
    if (tel) tel.addEventListener('click', () => this.telecharger());

    // Modifier
    const mod = document.getElementById('cvb-modifier');
    if (mod) mod.addEventListener('click', () => { this.state.etape = 'formulaire'; this.update(); });

    // Nouveau
    const nouv = document.getElementById('cvb-nouveau');
    if (nouv) nouv.addEventListener('click', () => {
      this.state = { etape: 'choix_pays', paysChoisi: null, templateChoisi: null, typeDoc: 'cv', donnees: {}, resultat: null };
      this.update();
    });
  },

  // ─── Génération ─────────────────────────────────────────
  async generer() {
    this.state.donnees = {
      nom: document.getElementById('cvb-nom')?.value || '',
      poste: document.getElementById('cvb-poste')?.value || '',
      email: document.getElementById('cvb-email')?.value || '',
      tel: document.getElementById('cvb-tel')?.value || '',
      ville: document.getElementById('cvb-ville')?.value || '',
      formation: document.getElementById('cvb-formation')?.value || '',
      experience: document.getElementById('cvb-experience')?.value || '',
      competences: document.getElementById('cvb-competences')?.value || '',
      langues: document.getElementById('cvb-langues')?.value || '',
      entreprise: document.getElementById('cvb-entreprise')?.value || '',
      motivation: document.getElementById('cvb-motivation')?.value || ''
    };

    this.state.etape = 'generation';
    this.update();

    try {
      const p = this.state.paysChoisi;
      const d = this.state.donnees;
      const prompt = `Tu es un expert RH international spécialisé dans les CV pour ${p.nom}.

Génère un document HTML complet et autonome (CSS intégré) avec le style "${this.state.templateChoisi}".

RÈGLES POUR ${p.nom.toUpperCase()}:
- Photo: ${p.photo}
- Longueur: ${p.longueur}
- Style: ${p.style}
- Lettre de motivation: ${p.lettre}
- À éviter: ${p.pieges}

INFORMATIONS DU CANDIDAT:
- Nom: ${d.nom || 'À compléter'}
- Poste visé: ${d.poste || 'À préciser'}
- Email: ${d.email || ''}
- Téléphone: ${d.tel || ''}
- Ville: ${d.ville || ''}
- Formation: ${d.formation || 'À compléter'}
- Expériences: ${d.experience || 'À compléter'}
- Compétences: ${d.competences || ''}
- Langues: ${d.langues || ''}
${this.state.typeDoc !== 'cv' ? `- Entreprise visée: ${d.entreprise || ''}` : ''}
${this.state.typeDoc !== 'cv' ? `- Motivation: ${d.motivation || ''}` : ''}

GÉNÉRER: ${this.state.typeDoc === 'cv' ? 'CV uniquement' : this.state.typeDoc === 'lettre' ? 'Lettre de motivation uniquement' : 'CV + Lettre de motivation'}

Design professionnel, adapté aux codes de ${p.nom}. Contenu réel basé sur les informations fournies.
Réponds UNIQUEMENT avec le code HTML. Pas d'explication.`;

      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 8000,
          messages: [{ role: 'user', content: prompt }]
        })
      });

      const data = await response.json();
      this.state.resultat = data.content[0].text;
      this.state.etape = 'resultat';
      this.update();

      setTimeout(() => {
        const apercu = document.getElementById('cvb-apercu');
        if (apercu) apercu.innerHTML = this.state.resultat;
      }, 100);

    } catch(err) {
      console.error('Erreur CV Builder:', err);
      alert('Une erreur est survenue. Réessaie.');
      this.state.etape = 'formulaire';
      this.update();
    }
  },

  // ─── Télécharger ─────────────────────────────────────────
  telecharger() {
    if (!this.state.resultat) return;
    const blob = new Blob([this.state.resultat], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const nom = (this.state.donnees.nom || 'mon-cv').toLowerCase().replace(/\s+/g,'-');
    a.href = url;
    a.download = `${nom}-${this.state.paysChoisi.id}.html`;
    a.click();
    URL.revokeObjectURL(url);
  },

  // ─── Mise à jour ─────────────────────────────────────────
  update() {
    const content = document.getElementById('cvb-content');
    if (content) {
      content.innerHTML = this.renderEtape();
      this.attachEvents();
    }
  }
};

// ─── CSS ────────────────────────────────────────────────────
const cvbStyle = document.createElement('style');
cvbStyle.textContent = `
  .cvb-container { padding:20px; max-width:900px; margin:0 auto; color:#fff; font-family:inherit; }
  .cvb-header { margin-bottom:24px; }
  .cvb-title { font-size:1.4em; font-weight:700; color:#f0c040; letter-spacing:2px; margin-bottom:6px; }
  .cvb-subtitle { font-size:1em; color:#fff; margin-bottom:4px; }
  .cvb-subtitle-small { font-size:0.85em; color:#aaa; }
  .cvb-section { padding:4px 0; }
  .cvb-question { font-size:1.05em; font-weight:600; color:#f0c040; margin-bottom:16px; }
  .cvb-search { width:100%; background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.15); border-radius:8px; padding:10px 14px; color:#fff; font-size:0.95em; margin-bottom:16px; box-sizing:border-box; }
  .cvb-region-titre { font-size:0.78em; color:#f0c040; text-transform:uppercase; letter-spacing:2px; margin:16px 0 8px; }
  .cvb-pays-grid { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:8px; }
  .cvb-pays-card { background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.1); border-radius:8px; padding:8px 12px; cursor:pointer; display:flex; align-items:center; gap:6px; transition:all 0.2s; font-size:0.88em; }
  .cvb-pays-card:hover { background:rgba(240,192,64,0.15); border-color:#f0c040; }
  .cvb-flag { font-size:1.2em; }
  .cvb-retour { color:#aaa; cursor:pointer; font-size:0.85em; margin-bottom:14px; display:inline-block; }
  .cvb-retour:hover { color:#f0c040; }
  .cvb-pays-selectionne { font-size:1.1em; font-weight:600; color:#f0c040; margin-bottom:16px; }
  .cvb-regles { background:rgba(240,192,64,0.08); border-left:3px solid #f0c040; padding:12px 16px; border-radius:0 8px 8px 0; margin-bottom:20px; }
  .cvb-regle-item { font-size:0.85em; color:#ccc; margin-bottom:4px; line-height:1.5; }
  .cvb-doc-choix { display:flex; gap:10px; flex-wrap:wrap; margin-bottom:20px; }
  .cvb-doc-card { background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.1); border-radius:10px; padding:14px 18px; cursor:pointer; text-align:center; flex:1; min-width:120px; transition:all 0.2s; }
  .cvb-doc-card:hover, .cvb-doc-card.active { background:rgba(240,192,64,0.15); border-color:#f0c040; }
  .cvb-doc-emoji { font-size:1.8em; margin-bottom:6px; }
  .cvb-doc-label { font-size:0.82em; color:#ccc; }
  .cvb-templates { display:flex; gap:8px; flex-wrap:wrap; }
  .cvb-template-card { background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.1); border-radius:8px; padding:8px 14px; cursor:pointer; font-size:0.85em; color:#ccc; transition:all 0.2s; }
  .cvb-template-card:hover, .cvb-template-card.active { background:rgba(240,192,64,0.15); border-color:#f0c040; color:#f0c040; }
  .cvb-hint { background:rgba(240,192,64,0.08); border-left:3px solid #f0c040; padding:10px 14px; border-radius:0 8px 8px 0; font-size:0.85em; color:#ccc; margin-bottom:20px; }
  .cvb-form { display:flex; flex-direction:column; gap:14px; }
  .cvb-form-section-titre { font-size:0.85em; color:#f0c040; font-weight:600; text-transform:uppercase; letter-spacing:1px; margin-top:8px; padding-top:12px; border-top:1px solid rgba(255,255,255,0.08); }
  .cvb-field { display:flex; flex-direction:column; gap:5px; }
  .cvb-field label { font-size:0.82em; color:#bbb; }
  .cvb-field input, .cvb-field textarea { background:rgba(255,255,255,0.07); border:1px solid rgba(255,255,255,0.12); border-radius:7px; padding:10px 12px; color:#fff; font-size:0.9em; font-family:inherit; resize:vertical; transition:border 0.2s; }
  .cvb-field input:focus, .cvb-field textarea:focus { outline:none; border-color:#f0c040; }
  .cvb-btn-generate { background:linear-gradient(135deg,#f0c040,#e08020); color:#111; border:none; padding:13px; border-radius:8px; font-size:1em; font-weight:700; cursor:pointer; margin-top:10px; }
  .cvb-generation { text-align:center; padding:50px 20px; }
  .cvb-loading-icon { font-size:3em; animation:cvbBounce 1s infinite; margin-bottom:16px; }
  @keyframes cvbBounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-10px)} }
  .cvb-loading-title { font-size:1.1em; font-weight:600; color:#f0c040; margin-bottom:8px; }
  .cvb-loading-sub { font-size:0.85em; color:#aaa; margin-bottom:24px; }
  .cvb-loading-bar { width:100%; max-width:300px; margin:0 auto; background:rgba(255,255,255,0.1); border-radius:20px; height:6px; overflow:hidden; }
  .cvb-loading-fill { height:100%; background:linear-gradient(90deg,#f0c040,#e08020); border-radius:20px; animation:cvbFill 3s infinite; }
  @keyframes cvbFill { 0%{width:0} 100%{width:100%} }
  .cvb-succes { text-align:center; margin-bottom:20px; }
  .cvb-succes-icon { font-size:2.5em; margin-bottom:8px; }
  .cvb-succes-titre { font-size:1.2em; font-weight:700; color:#0c8; }
  .cvb-apercu-label { font-size:0.82em; color:#aaa; margin-bottom:8px; }
  .cvb-apercu { background:#fff; border-radius:10px; padding:20px; max-height:500px; overflow-y:auto; margin-bottom:16px; color:#111; }
  .cvb-actions { display:flex; flex-direction:column; gap:10px; margin-bottom:20px; }
  .cvb-btn-primary { background:linear-gradient(135deg,#f0c040,#e08020); color:#111; border:none; padding:13px; border-radius:8px; font-size:1em; font-weight:700; cursor:pointer; }
  .cvb-btn-secondary { background:rgba(255,255,255,0.08); color:#fff; border:1px solid rgba(255,255,255,0.2); padding:11px; border-radius:8px; font-size:0.95em; cursor:pointer; }
  .cvb-btn-tertiary { background:transparent; color:#aaa; border:none; padding:10px; font-size:0.85em; cursor:pointer; }
  .cvb-conseil { background:rgba(240,192,64,0.08); border-left:3px solid #f0c040; padding:12px 16px; border-radius:0 8px 8px 0; font-size:0.85em; color:#ccc; line-height:1.5; }
`;
document.head.appendChild(cvbStyle);

window.addEventListener('load', () => CV_BUILDER.init());
