// ═══════════════════════════════════════════════════
//  PROTECTION DROITS MUSICAUX — Or Eille AI v1.0
//  Alerte avant publication — eviter les coupures
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const MUSIC_RIGHTS = {
  KEY: 'moe_music_rights',

  SAFE_SOURCES: [
    'YouTube Audio Library',
    'Epidemic Sound',
    'Artlist',
    'Musicbed',
    'Soundstripe',
    'TikTok Sons',
    'Instagram Musique',
    'Pixabay Music',
    'Free Music Archive',
    'ccMixter',
    'Bensound',
    'Purple Planet',
  ],

  RISKY_LABELS: [
    'Universal Music',
    'Sony Music',
    'Warner Music',
    'EMI',
    'Capitol Records',
    'Atlantic Records',
    'Def Jam',
    'Columbia Records',
    'Republic Records',
  ],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { checks: [] }; }
    catch { return { checks: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async checkMusic(title, artist, platform, claudeKey) {
    if (!title) { if (window.addChatMsg) addChatMsg('assistant', 'Entrez le titre de la musique.'); return; }

    const isSafe = this.SAFE_SOURCES.some(function(s) {
      return (artist || '').toLowerCase().includes(s.toLowerCase());
    });

    const isRisky = this.RISKY_LABELS.some(function(l) {
      return (artist || '').toLowerCase().includes(l.toLowerCase()) ||
             (title || '').toLowerCase().includes(l.toLowerCase());
    });

    if (isSafe) {
      if (window.addChatMsg) addChatMsg('assistant', '✅ "' + title + '" — Source libre de droits reconnue. Vous pouvez publier sans risque sur ' + (platform || 'toutes les plateformes') + '.');
      return;
    }

    if (isRisky) {
      if (window.addChatMsg) addChatMsg('assistant', '⚠ "' + title + '" — Label majeur detecte. Risque eleve de coupure sur ' + (platform || 'Instagram/TikTok/YouTube') + '. Utilisez une version libre de droits ou une musique de la bibliotheque Or Eille AI.');
      return;
    }

    if (!claudeKey) {
      if (window.addChatMsg) addChatMsg('assistant', '⚠ "' + title + '" par "' + (artist||'?') + '" — Statut inconnu. Verifiez sur soundcharts.com ou tunebat.com avant de publier.');
      return;
    }

    if (window.addChatMsg) addChatMsg('assistant', '🔍 Verification des droits de "' + title + '"...');

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 400,
          messages: [{
            role: 'user',
            content: 'La musique "' + title + '" de "' + (artist||'artiste inconnu') + '" — est-elle generalement libre de droits pour publication sur ' + (platform||'Instagram, TikTok, YouTube') + ' ? Reponds en 3 lignes max : risque (faible/moyen/eleve), explication courte, alternative suggeree si risque.'
          }]
        })
      });
      const data = await r.json();
      const d = this.get();
      d.checks.unshift({ title, artist, platform, result: data.content[0].text, at: new Date().toISOString() });
      d.checks = d.checks.slice(0, 50);
      this.save(d);
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) {
      if (window.addChatMsg) addChatMsg('assistant', 'Erreur. Verifiez votre connexion.');
    }
  },

  renderPanel: function() {
    const d = this.get();
    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +

      '<div class="sec-title">🎵 Droits musicaux</div>' +
      '<p class="note">Verifiez avant de publier. Evitez les coupures de son sur Instagram, TikTok et YouTube.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">' +
          'Avant de publier votre video — verifiez que votre musique ne va pas etre coupee par les algorithmes de detection de droits d auteur. Un seul clic pour savoir.' +
        '</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<input type="text" id="mr-title" placeholder="Titre de la musique"/>' +
      '<input type="text" id="mr-artist" placeholder="Artiste ou source"/>' +

      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
        ['Instagram','TikTok','YouTube','Facebook','Podcast'].map(function(p) {
          return '<button onclick="document.querySelectorAll(\'.mr-plat\').forEach(function(b){b.style.background=\'var(--dark-mid)\';b.style.color=\'var(--muted)\'});this.style.background=\'rgba(196,153,58,.2)\';this.style.color=\'var(--gold)\';document.getElementById(\'mr-platform\').value=\'' + p + '\'" class="mr-plat" style="padding:.3rem .5rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:\'Josefin Sans\',sans-serif;font-size:.48rem;cursor:pointer">' + p + '</button>';
        }).join('') +
        '<input type="hidden" id="mr-platform" value="Instagram"/>' +
      '</div>' +

      '<button class="btn btn-gold" onclick="MUSIC_RIGHTS.checkMusic(document.getElementById(\'mr-title\').value, document.getElementById(\'mr-artist\').value, document.getElementById(\'mr-platform\').value, window.CFG&&window.CFG.CLAUDE_KEY)">🎵 Verifier les droits</button>' +

      '<div class="sec-title">✅ Sources libres de droits recommandees</div>' +
      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
        this.SAFE_SOURCES.map(function(s) {
          return '<span style="padding:.25rem .4rem;background:rgba(129,199,132,.1);border:1px solid rgba(129,199,132,.3);color:#81c784;font-size:.46rem">' + s + '</span>';
        }).join('') +
      '</div>' +

      (d.checks.length > 0 ? (
        '<div class="sec-title">Verifications recentes</div>' +
        d.checks.slice(0,5).map(function(c) {
          return '<div style="padding:.5rem;border:1px solid var(--border);margin-bottom:.3rem">' +
            '<div style="font-size:.54rem;color:var(--text)">' + c.title + (c.artist ? ' — ' + c.artist : '') + '</div>' +
            '<div style="font-size:.48rem;color:var(--muted);margin-top:.2rem">' + c.result.substring(0,100) + '...</div>' +
          '</div>';
        }).join('')
      ) : '') +

    '</div>';
  }
};

window.MUSIC_RIGHTS = MUSIC_RIGHTS;
