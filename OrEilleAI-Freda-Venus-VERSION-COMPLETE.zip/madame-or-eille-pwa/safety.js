// ═══════════════════════════════════════════════════
//  SÉCURITÉ DES FEMMES — SYSTÈME DE CHECK-IN
//  CONFIDENTIEL — Ne pas mentionner publiquement
//  Or Eille AI — v1.0
// ═══════════════════════════════════════════════════

const SAFETY = {
  EMERGENCY_NUMBERS: [
    { num: '3919', label: 'Violences Femmes Info', detail: 'France — gratuit — 24h/24 — anonyme' },
    { num: '119', label: 'Enfance en danger', detail: 'France — gratuit — 24h/24' },
    { num: '17', label: 'Police secours', detail: 'France' },
    { num: '112', label: 'Urgences Europe', detail: 'Sans SIM, partout en Europe' },
    { num: '0800059595', label: 'Viols Femmes Informations', detail: 'France — gratuit' },
    { num: '15', label: 'SAMU', detail: 'Urgences médicales' },
  ],


  KEY: 'moe_safety',
  CHECKIN_INTERVAL: null,

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      contacts: [], activeCheckin: null, blockedPatterns: [], healthReminders: [], objects: []
    }; } catch { return { contacts: [], activeCheckin: null, blockedPatterns: [], healthReminders: [], objects: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Contacts de confiance ────────────────────
  addContact(name, phone, email) {
    const d = this.get();
    d.contacts.push({ id: Date.now().toString(), name, phone, email, addedAt: new Date().toISOString() });
    this.save(d);
  },

  // ─── Check-in avant sortie ────────────────────
  startCheckin(config) {
    const d = this.get();
    const returnTime = new Date(config.returnTime);
    const alertTime = new Date(returnTime.getTime() + 30 * 60000); // +30 min

    d.activeCheckin = {
      id: Date.now().toString(),
      accompagnateur: config.accompagnateur,
      lieu: config.lieu,
      returnTime: returnTime.toISOString(),
      alertTime: alertTime.toISOString(),
      contacts: config.contacts || d.contacts.slice(0, 2),
      status: 'active',
      startedAt: new Date().toISOString(),
      lastPosition: config.lieu,
    };
    this.save(d);

    // Programmer l'alerte
    const msUntilAlert = alertTime.getTime() - Date.now();
    if (msUntilAlert > 0) {
      this.CHECKIN_INTERVAL = setTimeout(() => this.triggerAlert(), msUntilAlert);
    }

    // Notification à l'heure prévue
    const msUntilReturn = returnTime.getTime() - Date.now();
    if (msUntilReturn > 0) {
      setTimeout(() => this.sendReturnNotification(), msUntilReturn);
    }

    return d.activeCheckin;
  },

  sendReturnNotification() {
    const d = this.get();
    if (!d.activeCheckin || d.activeCheckin.status !== 'active') return;
    if (window.addChatMsg) {
      addChatMsg('assistant', '🔔 C\'est l\'heure de votre retour prévu. Tout va bien ? Appuyez sur "RAS" pour confirmer.');
      if (window.speak) speak('C\'est l\'heure de votre retour prévu. Tout va bien ?');
    }
  },

  confirmSafe() {
    const d = this.get();
    if (!d.activeCheckin) return;
    d.activeCheckin.status = 'confirmed';
    clearTimeout(this.CHECKIN_INTERVAL);
    this.save(d);
    if (window.addChatMsg) addChatMsg('assistant', '✓ RAS enregistré. Heureuse de vous savoir rentrée saine et sauve.');
    if (window.speak) speak('RAS enregistré. Bonne soirée.');
  },

  triggerAlert() {
    const d = this.get();
    if (!d.activeCheckin || d.activeCheckin.status !== 'active') return;

    const checkin = d.activeCheckin;
    const msg = `⚠ ALERTE AUTOMATIQUE Or Eille AI

${checkin.contacts[0]?.name || 'Personne de confiance'},

Ce message a été envoyé automatiquement car votre contact n'a pas confirmé son retour.

Informations :
- Devait rentrer à : ${new Date(checkin.returnTime).toLocaleTimeString('fr-FR')}
- Accompagnateur : ${checkin.accompagnateur || 'Non précisé'}
- Dernier lieu connu : ${checkin.lastPosition || 'Non précisé'}
- Heure d'alerte : ${new Date().toLocaleTimeString('fr-FR')}

Si vous n'avez pas de nouvelles dans les 30 minutes, contacter le 17 (Police) avec ces informations.

— Or Eille AI`;

    // Afficher dans l'appli
    if (window.addChatMsg) {
      addChatMsg('assistant', '⚠ Alerte envoyée à vos contacts de confiance. Aucune confirmation de retour reçue après 30 minutes.');
    }

    // Log l'alerte
    d.activeCheckin.status = 'alerted';
    d.activeCheckin.alertSentAt = new Date().toISOString();
    this.save(d);

    // Cascade vers 2ème contact si premier ne répond pas
    setTimeout(() => {
      const d2 = this.get();
      if (d2.activeCheckin?.status === 'alerted' && checkin.contacts[1]) {
        if (window.addChatMsg) addChatMsg('assistant', `⚠ Alerte escaladée vers ${checkin.contacts[1].name}.`);
      }
    }, 30 * 60000);
  },

  updatePosition(lieu) {
    const d = this.get();
    if (d.activeCheckin) {
      d.activeCheckin.lastPosition = lieu;
      d.activeCheckin.positionUpdatedAt = new Date().toISOString();
      this.save(d);
    }
  },

  // ─── Conseils de sécurité ─────────────────────
  SAFETY_TIPS: `RÉFLEXES DE SÉCURITÉ — À lire avant chaque sortie

🔵 VOTRE INSTINCT EST VOTRE PREMIER REMPART
Vous ne vous sentez pas bien ? Vous voulez partir ? Partez.
Sans justification. Sans excuse. Sans culpabilité.
Mieux vaut passer pour une cruche que ne pas rentrer.

🔵 AVANT DE PARTIR
— Partagez le nom, prénom et numéro de téléphone de l'accompagnateur
— Donnez l'adresse exacte dès que vous la connaissez
— Chargez votre téléphone à 100%
— Ayez du liquide sur vous
— Deuxième téléphone dans une pochette isolante : SECRET ABSOLU, ne le mentionnez à personne, jamais

🔵 LE 112 FONCTIONNE
— Sans carte SIM
— Sans crédit
— Batterie quasi morte
— Même hors réseau si une antenne capte
Apprenez-le par cœur : 1-1-2

🔵 SI QUELQUE CHOSE NE VA PAS
— Partez immédiatement, sans expliquer
— Entrez dans un commerce, une pharmacie, demandez de l'aide
— Appelez le 17 (Police) ou le 112
— Vous avez le droit de partir à tout moment

🔵 LE DEUXIÈME TÉLÉPHONE
— Vieux smartphone ou téléphone basique
— Carte SIM prépayée
— Dans une pochette isolante (protection chaleur et humidité)
— Chargé à 100% avant de partir
— SECRET ABSOLU — ne jamais en parler, à personne, jamais
— Recharger complètement une fois par mois

EN 2026, LES DANGERS SONT RÉELS ET DOCUMENTÉS.
La prudence n'est pas de la paranoïa. C'est de la survie.`,

  // ─── Rappels santé ────────────────────────────
  addHealthReminder(medication, times, notes) {
    const d = this.get();
    d.healthReminders.push({
      id: Date.now().toString(),
      medication, times, notes,
      active: true,
      createdAt: new Date().toISOString()
    });
    this.save(d);
    this.scheduleHealthReminders();
  },

  scheduleHealthReminders() {
    const d = this.get();
    d.healthReminders.filter(r => r.active).forEach(reminder => {
      reminder.times.forEach(time => {
        const [hours, minutes] = time.split(':').map(Number);
        const now = new Date();
        let next = new Date();
        next.setHours(hours, minutes, 0, 0);
        if (next <= now) next.setDate(next.getDate() + 1);
        const ms = next.getTime() - now.getTime();
        setTimeout(() => {
          const msg = `💊 Rappel — ${reminder.medication}${reminder.notes ? ' — ' + reminder.notes : ''}`;
          if (window.addChatMsg) addChatMsg('assistant', msg);
          if (window.speak) speak(`Rappel médicament : ${reminder.medication}`);
          // Reprogrammer pour le lendemain
          this.scheduleHealthReminders();
        }, ms);
      });
    });
  },

  // ─── Bibliothèque d'objets ────────────────────
  addObject(name, imageDataUrl, fixedLocation) {
    const d = this.get();
    d.objects.push({
      id: Date.now().toString(),
      name, imageDataUrl, fixedLocation,
      addedAt: new Date().toISOString()
    });
    this.save(d);
  },

  async findObject(name, roomImageDataUrl, claudeKey) {
    if (!claudeKey) return null;
    const d = this.get();
    const obj = d.objects.find(o => o.name.toLowerCase().includes(name.toLowerCase()));

    // D'abord vérifier l'emplacement fixe
    if (obj?.fixedLocation) {
      return `${obj.name} — emplacement habituel : ${obj.fixedLocation}. Si pas là, je vais chercher dans la pièce.`;
    }

    // Si image de la pièce fournie — analyser
    if (roomImageDataUrl && claudeKey) {
      try {
        const r = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
          body: JSON.stringify({
            model: 'claude-sonnet-4-20250514', max_tokens: 200,
            messages: [{
              role: 'user',
              content: [
                { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: roomImageDataUrl.split(',')[1] } },
                { type: 'text', text: `Cherche ${name} dans cette image. Si tu le vois, indique précisément où il se trouve (gauche/droite/centre, premier plan/fond, sur quoi il est posé). Si tu ne le vois pas, dis-le clairement.` }
              ]
            }]
          })
        });
        const data = await r.json();
        return data.content[0].text;
      } catch {}
    }

    return `Je ne trouve pas ${name} dans ma mémoire. Avez-vous filmé la pièce ? Je peux analyser l'image pour chercher.`;
  },

  // ─── Gestion communauté — blocage ─────────────
  BLOCKED_PATTERNS: [],

  analyzeAccount(account) {
    const d = this.get();
    const score = d.blockedPatterns.reduce((s, pattern) => {
      let match = 0;
      if (pattern.username && account.username?.includes(pattern.username.slice(0, 5))) match += 30;
      if (pattern.bio && account.bio?.includes(pattern.bio?.slice(0, 20))) match += 25;
      if (pattern.writingStyle && account.recentComment?.includes(pattern.writingStyle?.slice(0, 15))) match += 45;
      return s + match;
    }, 0);
    return { score, suspicious: score > 50 };
  },

  captureEvidence(account, comments) {
    return {
      id: Date.now().toString(),
      account,
      comments,
      capturedAt: new Date().toISOString(),
      note: 'Preuve capturée avant blocage — Or Eille AI'
    };
  },

  addBlockedPattern(account) {
    const d = this.get();
    d.blockedPatterns.push({
      username: account.username,
      bio: account.bio,
      writingStyle: account.recentComment,
      blockedAt: new Date().toISOString()
    });
    this.save(d);
  },

  // ─── Checklist de départ ──────────────────────
  DEPARTURE_CHECKLIST: [
    { id: 'keys', label: 'Clés' },
    { id: 'phone', label: 'Téléphone (chargé)' },
    { id: 'badge', label: 'Badge' },
    { id: 'wallet', label: 'Portefeuille' },
    { id: 'backup_phone', label: 'Téléphone de secours (si sortie sensible)' },
  ],

  renderDepartureChecklist() {
    return `
    <div style="padding:1rem">
      <div class="sec-title">Avant de partir</div>
      ${this.DEPARTURE_CHECKLIST.map(item => `
        <label style="display:flex;align-items:center;gap:.6rem;padding:.4rem 0;font-size:.6rem;color:var(--text);cursor:pointer;border-bottom:1px solid var(--border)">
          <input type="checkbox" id="chk_${item.id}" style="accent-color:var(--gold);width:16px;height:16px"/>
          ${item.label}
        </label>
      `).join('')}
      <button class="btn btn-gold" style="margin-top:.8rem;width:100%" onclick="SAFETY.validateDeparture()">✓ Tout est bon — je pars</button>
    </div>`;
  },

  validateDeparture() {
    const unchecked = this.DEPARTURE_CHECKLIST.filter(item => !document.getElementById('chk_' + item.id)?.checked);
    if (unchecked.length > 0) {
      const msg = `Attention — vous n'avez pas coché : ${unchecked.map(i => i.label).join(', ')}`;
      if (window.addChatMsg) addChatMsg('assistant', msg);
      if (window.speak) speak(msg);
    } else {
      if (window.addChatMsg) addChatMsg('assistant', '✓ Tout est prêt. Bonne sortie — restez en sécurité.');
      if (window.speak) speak('Tout est prêt. Bonne sortie.');
    }
  },

  // ─── Rappel recharge téléphone de secours ─────
  scheduleBackupPhoneReminder() {
    // Une fois par mois
    const MONTH_MS = 30 * 24 * 3600 * 1000;
    setInterval(() => {
      if (window.addChatMsg) {
        addChatMsg('assistant', '🔋 Rappel mensuel — Pensez à recharger votre téléphone de secours et à vérifier qu\'il fonctionne.');
        if (window.speak) speak('Rappel — rechargez votre téléphone de secours.');
      }
    }, MONTH_MS);
  }
};



// ─── Enregistrement discret universel ─────────
SAFETY._recorder = null;
SAFETY._recording = false;
SAFETY._chunks = [];

SAFETY.startDiscreetRecording = function() {
    if (this._recording) { this.stopDiscreetRecording(); return; }
    const self = this;
    navigator.mediaDevices.getUserMedia({ audio: true }).then(function(stream) {
      self._chunks = [];
      self._recorder = new MediaRecorder(stream);
      self._recorder.ondataavailable = function(e) { if (e.data.size > 0) self._chunks.push(e.data); };
      self._recorder.onstop = function() {
        const blob = new Blob(self._chunks, { type: 'audio/webm' });
        const timestamp = new Date().toISOString();
        const dateStr = new Date().toLocaleString('fr-FR');
        // Sauvegarder métadonnées
        const recordings = JSON.parse(localStorage.getItem('moe_recordings') || '[]');
        recordings.unshift({ id: 'REC-'+Date.now().toString(36).toUpperCase(), dateStr, timestamp, size: blob.size });
        localStorage.setItem('moe_recordings', JSON.stringify(recordings.slice(0,20)));
        // Télécharger
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'preuve_' + dateStr.replace(/[/:]/g,'-') + '.webm';
        a.click();
        if (window.addChatMsg) addChatMsg('assistant', '📼 Enregistrement sauvegarde — ' + dateStr + '. Preuve disponible. Archive 10 ans.');
      };
      self._recorder.start();
      self._recording = true;
      // Indicateur discret
      const btn = document.getElementById('discreet-rec-btn');
      if (btn) { btn.style.background = 'rgba(239,83,80,.3)'; btn.title = 'Enregistrement en cours — cliquer pour arreter'; }
      if (window.addChatMsg) addChatMsg('assistant', '🔴 Enregistrement demarre. Discret. Personne ne voit. Cliquez a nouveau pour arreter et sauvegarder.');
    }).catch(function() {
      if (window.addChatMsg) addChatMsg('assistant', 'Acces au microphone refuse. Verifiez les permissions.');
    });
  },

SAFETY.stopDiscreetRecording = function() {
    if (this._recorder && this._recording) {
      this._recorder.stop();
      this._recording = false;
      const btn = document.getElementById('discreet-rec-btn');
      if (btn) { btn.style.background = 'transparent'; }
    }
  },

window.SAFETY = SAFETY;

// Démarrer les rappels au chargement
window.addEventListener('load', () => {
  setTimeout(() => {
    SAFETY.scheduleHealthReminders();
    SAFETY.scheduleBackupPhoneReminder();
  }, 2000);
});
