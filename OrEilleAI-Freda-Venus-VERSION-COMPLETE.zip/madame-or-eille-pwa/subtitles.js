// ═══════════════════════════════════════════════════
//  SOUS-TITRAGE — Or Eille AI v1.0
//  Whisper haute qualité, toutes langues, toutes polices
//  Mémoire de style, synchronisation précise
// ═══════════════════════════————══════════════════

const SUBTITLES = {
  KEY: 'moe_subtitles',

  LANGUAGES: {
    fr: 'Français', en: 'English', es: 'Español', ar: 'العربية',
    sw: 'Kiswahili', ln: 'Lingála', yo: 'Yorùbá', wo: 'Wolof',
    ha: 'Hausa', am: 'አማርኛ', zh: '中文', ja: '日本語',
    ko: '한국어', pt: 'Português', de: 'Deutsch', it: 'Italiano',
    ru: 'Русский', hi: 'हिन्दी', tr: 'Türkçe', nl: 'Nederlands'
  },

  POSITIONS: { bottom: 'En bas', top: 'En haut', center: 'Au centre' },
  BACKGROUNDS: { black: 'Fond noir', transparent: 'Transparent', white: 'Fond blanc', blur: 'Flou' },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      style: {
        font: 'Josefin Sans', fontSize: 24, color: '#FFFFFF',
        background: 'black', position: 'bottom', bold: false,
        outline: true, outlineColor: '#000000'
      },
      sourceLanguage: 'fr', targetLanguage: 'fr',
      history: []
    }; } catch { return {}; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Transcrire via Whisper/Replicate ─────────
  async transcribe(audioBlob, language) {
    const key = window.CFG?.REPLICATE_KEY;
    if (!key || key.includes('METTRE_ICI')) {
      return this.fallbackTranscription();
    }

    try {
      const base64 = await new Promise((res, rej) => {
        const reader = new FileReader();
        reader.onload = () => res(reader.result.split(',')[1]);
        reader.onerror = rej;
        reader.readAsDataURL(audioBlob);
      });

      const r = await fetch('https://api.replicate.com/v1/predictions', {
        method: 'POST',
        headers: { 'Authorization': `Token ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          version: 'e39e354773f9a7c9c12f9a55e8e6ea44b59f96fb7a8f0aa06de0ad3fc0f5a2e7',
          input: {
            audio: `data:audio/webm;base64,${base64}`,
            language: language || 'fr',
            word_timestamps: true,
            translate: false
          }
        })
      });

      const prediction = await r.json();
      let result = null;
      let attempts = 0;

      while (!result && attempts < 60) {
        await new Promise(res => setTimeout(res, 1000));
        const poll = await fetch(`https://api.replicate.com/v1/predictions/${prediction.id}`, {
          headers: { 'Authorization': `Token ${key}` }
        });
        const data = await poll.json();
        if (data.status === 'succeeded') result = data.output;
        else if (data.status === 'failed') break;
        attempts++;
      }

      return result;
    } catch { return null; }
  },

  fallbackTranscription() {
    return new Promise(resolve => {
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SR) { resolve(null); return; }
      const r = new SR(); r.lang = 'fr-FR'; r.continuous = true;
      const segments = [];
      r.onresult = e => {
        for (let i = e.resultIndex; i < e.results.length; i++) {
          segments.push({ text: e.results[i][0].transcript, start: i * 3, end: (i + 1) * 3 });
        }
      };
      r.onend = () => resolve({ segments });
      r.start();
      setTimeout(() => r.stop(), 30000);
    });
  },

  // ─── Traduire les sous-titres ─────────────────
  async translateSubtitles(segments, targetLang, claudeKey) {
    if (!claudeKey || targetLang === 'fr') return segments;
    const texts = segments.map(s => s.text).join('\n|||SPLIT|||\n');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 1000,
          messages: [{
            role: 'user',
            content: `Traduis ces segments de sous-titres en ${this.LANGUAGES[targetLang] || targetLang}. Garde le séparateur |||SPLIT||| entre chaque segment. Utilise la terminologie naturelle, pas le langage formel ou académique. Réponds UNIQUEMENT avec les traductions séparées par |||SPLIT|||.\n\n${texts}`
          }]
        })
      });
      const data = await r.json();
      const translated = data.content[0].text.split('|||SPLIT|||');
      return segments.map((s, i) => ({ ...s, text: (translated[i] || s.text).trim() }));
    } catch { return segments; }
  },

  // ─── Générer le CSS des sous-titres ───────────
  getSubtitleCSS() {
    const d = this.get();
    const s = d.style;
    const positions = { bottom: 'bottom:10%;', top: 'top:10%;', center: 'top:50%;transform:translateX(-50%) translateY(-50%);' };
    const backgrounds = { black: 'rgba(0,0,0,0.8)', transparent: 'transparent', white: 'rgba(255,255,255,0.9)', blur: 'rgba(0,0,0,0.5)' };

    return `
      position:absolute;left:50%;transform:translateX(-50%);
      ${positions[s.position] || positions.bottom}
      font-family:'${s.font}',sans-serif;
      font-size:${s.fontSize}px;
      color:${s.color};
      font-weight:${s.bold?'bold':'normal'};
      background:${backgrounds[s.background] || backgrounds.black};
      padding:4px 12px;
      border-radius:4px;
      text-align:center;
      max-width:90%;
      ${s.outline?`text-shadow: -1px -1px 0 ${s.outlineColor}, 1px -1px 0 ${s.outlineColor}, -1px 1px 0 ${s.outlineColor}, 1px 1px 0 ${s.outlineColor};`:''}
      ${s.background==='blur'?'backdrop-filter:blur(4px);':''}
    `;
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    const s = d.style;

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div class="sec-title">🎬 Sous-titrer une vidéo</div>
      <p class="note">Uploadez votre vidéo — Or Eille AI transcrit et génère les sous-titres en haute qualité dans la langue de votre choix.</p>

      <input type="file" accept="video/*,audio/*" id="sub-file" onchange="SUBTITLES.handleFile(this)" style="font-size:.56rem;color:var(--muted)"/>

      <div style="display:flex;gap:.4rem">
        <div style="flex:1">
          <span class="klabel">Langue source</span>
          <select id="sub-src-lang" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.56rem;padding:.4rem;outline:none">
            ${Object.entries(this.LANGUAGES).map(([k,v]) => `<option value="${k}" ${d.sourceLanguage===k?'selected':''}>${v}</option>`).join('')}
          </select>
        </div>
        <div style="flex:1">
          <span class="klabel">Langue des sous-titres</span>
          <select id="sub-tgt-lang" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.56rem;padding:.4rem;outline:none">
            ${Object.entries(this.LANGUAGES).map(([k,v]) => `<option value="${k}" ${d.targetLanguage===k?'selected':''}>${v}</option>`).join('')}
          </select>
        </div>
      </div>

      <div class="sep"></div>
      <div class="sec-title">🎨 Style des sous-titres</div>
      <p style="font-size:.48rem;color:var(--muted)">Configuré une fois — mémorisé pour toujours.</p>

      <div style="display:flex;gap:.4rem;align-items:center">
        <span class="klabel" style="min-width:5rem">Police</span>
        <select onchange="SUBTITLES.updateStyle('font',this.value)" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.56rem;padding:.4rem;outline:none">
          ${['Josefin Sans','Montserrat','Impact','Ubuntu','Noto Sans','Oswald','Raleway','Playfair Display'].map(f => `<option value="${f}" ${s.font===f?'selected':''}>${f}</option>`).join('')}
        </select>
      </div>

      <div style="display:flex;gap:.4rem;align-items:center">
        <span class="klabel" style="min-width:5rem">Taille</span>
        <input type="range" min="14" max="48" value="${s.fontSize}" onchange="SUBTITLES.updateStyle('fontSize',parseInt(this.value))" style="flex:1;accent-color:var(--gold)"/>
        <span style="font-size:.56rem;color:var(--muted);min-width:2rem">${s.fontSize}px</span>
      </div>

      <div style="display:flex;gap:.4rem;align-items:center">
        <span class="klabel" style="min-width:5rem">Couleur</span>
        <input type="color" value="${s.color}" onchange="SUBTITLES.updateStyle('color',this.value)" style="flex:1;height:30px;border:none;cursor:pointer;background:transparent"/>
      </div>

      <div style="display:flex;gap:.4rem">
        <div style="flex:1">
          <span class="klabel">Fond</span>
          <select onchange="SUBTITLES.updateStyle('background',this.value)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.56rem;padding:.4rem;outline:none">
            ${Object.entries(this.BACKGROUNDS).map(([k,v]) => `<option value="${k}" ${s.background===k?'selected':''}>${v}</option>`).join('')}
          </select>
        </div>
        <div style="flex:1">
          <span class="klabel">Position</span>
          <select onchange="SUBTITLES.updateStyle('position',this.value)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.56rem;padding:.4rem;outline:none">
            ${Object.entries(this.POSITIONS).map(([k,v]) => `<option value="${k}" ${s.position===k?'selected':''}>${v}</option>`).join('')}
          </select>
        </div>
      </div>

      <!-- Prévisualisation style -->
      <div style="position:relative;background:#333;height:80px;border-radius:4px;overflow:hidden">
        <div style="${this.getSubtitleCSS()}">Aperçu des sous-titres</div>
      </div>

      <button class="btn btn-gold" onclick="SUBTITLES.processVideo()">🎬 Générer les sous-titres</button>
    </div>`;
  },

  updateStyle(key, value) {
    const d = this.get();
    d.style[key] = value;
    this.save(d);
    document.getElementById('subtitlesContent').innerHTML = this.renderPanel();
  },

  handleFile(input) {
    const file = input.files[0];
    if (!file) return;
    this._pendingFile = file;
    if (window.addChatMsg) addChatMsg('assistant', `✅ Fichier chargé: ${file.name} (${(file.size/1e6).toFixed(1)} Mo). Configurez le style et appuyez sur "Générer les sous-titres".`);
  },

  async processVideo() {
    if (!this._pendingFile) {
      if (window.addChatMsg) addChatMsg('assistant', 'Uploadez d\'abord un fichier vidéo ou audio.');
      return;
    }
    const srcLang = document.getElementById('sub-src-lang')?.value || 'fr';
    const tgtLang = document.getElementById('sub-tgt-lang')?.value || 'fr';
    if (window.addChatMsg) addChatMsg('assistant', '🎬 Transcription en cours via Whisper haute qualité...');

    const result = await this.transcribe(this._pendingFile, srcLang);
    if (!result) {
      if (window.addChatMsg) addChatMsg('assistant', 'Transcription impossible. Vérifiez votre connexion et votre clé Replicate.');
      return;
    }

    let segments = result.segments || [];
    if (tgtLang !== srcLang) {
      if (window.addChatMsg) addChatMsg('assistant', `🌍 Traduction en ${this.LANGUAGES[tgtLang]}...`);
      segments = await this.translateSubtitles(segments, tgtLang, window.CFG?.CLAUDE_KEY);
    }

    const srtContent = this.generateSRT(segments);
    if (window.addChatMsg) addChatMsg('assistant', `✅ Sous-titres générés !\n\n${segments.slice(0,3).map(s => s.text).join('\n')}...\n\nFichier SRT prêt à télécharger.`);

    const blob = new Blob([srtContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'sous-titres.srt';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
  },

  generateSRT(segments) {
    return segments.map((s, i) => {
      const start = this.formatTime(s.start || i * 3);
      const end = this.formatTime(s.end || (i + 1) * 3);
      return `${i + 1}\n${start} --> ${end}\n${s.text}\n`;
    }).join('\n');
  },

  formatTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    const ms = Math.round((seconds % 1) * 1000);
    return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')},${String(ms).padStart(3,'0')}`;
  }
};

window.SUBTITLES = SUBTITLES;
