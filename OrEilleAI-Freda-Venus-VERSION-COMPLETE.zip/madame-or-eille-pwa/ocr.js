// ═══════════════════════════════════════════════════
//  OCR & TRANSCRIPTION — Or Eille AI v2.0
//  Photo de notes → documents dans plusieurs langues
//  Braille musical, littéraire, mathématique
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const OCR = {
  KEY: 'moe_ocr',

  LANGUAGES: [{v:'ln',l:'Lingála'},{v:'fon',l:'Fon (Bénin)'},{v:'ber',l:'Amazigh / Tamazight'},{v:'wo',l:'Wolof'},{v:'sw',l:'Kiswahili'},{v:'fr',l:'Français'},{v:'en',l:'English'},{v:'ar',l:'العربية'},{v:'es',l:'Español'},{v:'pt',l:'Português'},{v:'de',l:'Deutsch'},{v:'it',l:'Italiano'},{v:'zh',l:'中文'},{v:'ja',l:'日本語'},{v:'ko',l:'한국어'},{v:'ru',l:'Русский'},{v:'tr',l:'Türkçe'},{v:'hi',l:'हिन्दी'},{v:'vi',l:'Tiếng Việt'},{v:'da',l:'Dansk'},{v:'nl',l:'Nederlands'},{v:'other',l:'Autre langue'}],

  BRAILLE_TYPES: [
    {v:'fr',l:'Braille français'},
    {v:'en1',l:'Braille anglais Grade 1'},
    {v:'en2',l:'Braille anglais Grade 2'},
    {v:'ar',l:'Braille arabe'},
    {v:'zh',l:'Braille chinois'},
    {v:'music',l:'Braille musical — partitions'},
    {v:'math',l:'Braille mathématique — équations'},
  ],

  FORMATS: ['rapport','compte-rendu','article','lettre','liste','brut'],

  RESOURCES: {
    fr: [
      { name:'Association Valentin Haüy — Paris', address:'5 rue Duroc, 75007 Paris', hours:'Lun-Ven 9h30-12h et 14h-17h', url:'https://www.avh.asso.fr', note:'Textes, partitions musicales, signalétique' },
      { name:'ESAT Witkowska — Lyon', address:'Sainte-Foy-lès-Lyon (près de Lyon)', url:'https://www.avh.asso.fr/implantations/centre-odette-witkowska', note:'Imprimerie braille + partitions' },
    ]
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { history:[], selectedLangs:['fr'], selectedBraille:[], format:'brut', srcLang:'auto' }; }
    catch { return { history:[], selectedLangs:['fr'], selectedBraille:[], format:'brut', srcLang:'auto' }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Analyser et générer dans plusieurs langues ─
  async processNotes(imageDataUrl, srcLang, targetLangs, brailleTypes, format, claudeKey) {
    if (!claudeKey) { if(window.addChatMsg) addChatMsg('assistant','Clé API requise.'); return; }
    if (window.addChatMsg) addChatMsg('assistant', `📸 Lecture de vos notes en cours... Génération en ${targetLangs.length} langue(s)${brailleTypes.length?'+'+brailleTypes.length+' version(s) braille':''}.`);

    const results = [];

    for (const lang of targetLangs) {
      try {
        const r = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
          body: JSON.stringify({
            model: 'claude-sonnet-4-20250514', max_tokens: 2000,
            messages: [{
              role: 'user',
              content: [
                { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: imageDataUrl.split(',')[1] } },
                { type: 'text', text: `Transcris ces notes manuscrites${srcLang !== 'auto' ? ' écrites en '+srcLang : ''}.

Génère le document final en : ${lang}
Format : ${format}
Applique les règles typographiques de la langue ${lang}.
${lang !== srcLang && srcLang !== 'auto' ? 'Traduis le contenu vers ' + lang + '.' : ''}

Formats disponibles :
- rapport : titre, introduction, parties numérotées, conclusion
- compte-rendu : date, participants, points, décisions, actions
- article : titre, chapeau, paragraphes
- lettre : objet, corps, formule de politesse
- liste : points organisés par thème
- brut : texte transcrit sans restructuration

Si illisible quelque part : [illisible]
Réponds UNIQUEMENT avec le document — pas d'explication.` }
              ]
            }]
          })
        });
        const data = await r.json();
        results.push({ lang, text: data.content[0].text, format });
      } catch(e) { results.push({ lang, text: 'Erreur de génération', format }); }
    }

    // Braille
    for (const bType of brailleTypes) {
      const bInfo = this.BRAILLE_TYPES.find(b => b.v === bType);
      results.push({
        lang: bInfo?.l || 'Braille',
        text: `[FICHIER BRAILLE ${bType.toUpperCase()}]\n\nCe fichier BRF est prêt pour impression sur imprimante braille.\n\nPour imprimer en France :\n• Association Valentin Haüy — 5 rue Duroc, 75007 Paris\n• avh.asso.fr`,
        format: 'braille',
        isBraille: true
      });
    }

    // Afficher les résultats
    if (window.addChatMsg) {
      results.forEach(r => {
        addChatMsg('assistant', `📄 Document en ${r.lang} :\n\n${r.text.substring(0,300)}${r.text.length>300?'...\n[Document complet disponible]':''}`);
      });
    }

    // Sauvegarder l'historique
    const d = this.get();
    d.history.unshift({ results, at: new Date().toISOString(), format });
    d.history = d.history.slice(0, 10);
    this.save(d);

    document.getElementById('ocrContent').innerHTML = this.renderPanel();
    return results;
  },

  toggleLang(lang) {
    const d = this.get();
    const idx = d.selectedLangs.indexOf(lang);
    if (idx > -1) {
      if (d.selectedLangs.length > 1) d.selectedLangs.splice(idx, 1);
    } else {
      if (d.selectedLangs.length < 5) d.selectedLangs.push(lang);
      else if (window.addChatMsg) addChatMsg('assistant', 'Maximum 5 langues simultanément.');
    }
    this.save(d);
    document.getElementById('ocrContent').innerHTML = this.renderPanel();
  },

  toggleBraille(type) {
    const d = this.get();
    const idx = d.selectedBraille.indexOf(type);
    if (idx > -1) d.selectedBraille.splice(idx, 1);
    else d.selectedBraille.push(type);
    this.save(d);
    document.getElementById('ocrContent').innerHTML = this.renderPanel();
  },

  handlePhoto(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
      this._pendingImage = e.target.result;
      if (window.addChatMsg) addChatMsg('assistant', '✅ Photo chargée. Choisissez vos langues et cliquez sur Transcrire.');
    };
    reader.readAsDataURL(file);
  },

  processPhoto() {
    if (!this._pendingImage) { if(window.addChatMsg) addChatMsg('assistant','Prenez d\'abord une photo de vos notes.'); return; }
    const d = this.get();
    const srcLang = document.getElementById('ocr-src')?.value || 'auto';
    const format = document.getElementById('ocr-fmt')?.value || 'brut';
    this.processNotes(this._pendingImage, srcLang, d.selectedLangs, d.selectedBraille, format, window.CFG?.CLAUDE_KEY);
  },

  renderPanel() {
    const d = this.get();
    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div class="sec-title">📸 Notes manuscrites → Documents multilingues</div>
      <p class="note">Prenez en photo vos notes. Or Eille AI transcrit et génère un document propre dans chaque langue choisie — séparément. Une photo, plusieurs documents.</p>

      <input type="file" accept="image/*" capture="environment" onchange="OCR.handlePhoto(this)" style="font-size:.56rem;color:var(--muted)"/>

      <!-- Langue des notes -->
      <div>
        <span class="klabel">Langue des notes</span>
        <select id="ocr-src" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.56rem;padding:.4rem;outline:none">
          <option value="auto">Détecter automatiquement</option>
          ${this.LANGUAGES.map(l=>`<option value="${l.v}">${l.l}</option>`).join('')}
        </select>
      </div>

      <!-- Langues du document final -->
      <div>
        <span class="klabel">Langues du document final (max 5) — ${d.selectedLangs.length}/5 sélectionnée(s)</span>
        <div style="display:flex;gap:.3rem;flex-wrap:wrap;margin-top:.3rem">
          ${this.LANGUAGES.map(l=>`
            <button onclick="OCR.toggleLang('${l.v}')" style="padding:.3rem .5rem;background:${d.selectedLangs.includes(l.v)?'rgba(196,153,58,.2)':'var(--dark-mid)'};border:1px solid ${d.selectedLangs.includes(l.v)?'var(--gold)':'var(--border)'};color:${d.selectedLangs.includes(l.v)?'var(--gold)':'var(--muted)'};font-family:'Josefin Sans',sans-serif;font-size:.48rem;cursor:pointer">${l.l}</button>
          `).join('')}
        </div>
      </div>

      <!-- Options Braille -->
      <div>
        <span class="klabel">Version(s) braille (optionnel)</span>
        <div style="display:flex;gap:.3rem;flex-wrap:wrap;margin-top:.3rem">
          ${this.BRAILLE_TYPES.map(b=>`
            <button onclick="OCR.toggleBraille('${b.v}')" style="padding:.3rem .5rem;background:${d.selectedBraille.includes(b.v)?'rgba(27,79,138,.3)':'var(--dark-mid)'};border:1px solid ${d.selectedBraille.includes(b.v)?'var(--cobalt)':'var(--border)'};color:${d.selectedBraille.includes(b.v)?'#6BA3D6':'var(--muted)'};font-family:'Josefin Sans',sans-serif;font-size:.48rem;cursor:pointer">${b.l}</button>
          `).join('')}
        </div>
      </div>

      <!-- Format -->
      <div>
        <span class="klabel">Format du document</span>
        <select id="ocr-fmt" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.56rem;padding:.4rem;outline:none">
          ${this.FORMATS.map(f=>`<option value="${f}">${f}</option>`).join('')}
        </select>
      </div>

      <button class="btn btn-gold" onclick="OCR.processPhoto()">
        📄 Transcrire → ${d.selectedLangs.length} document(s)${d.selectedBraille.length?' + '+d.selectedBraille.length+' braille':''}
      </button>

      <!-- Ressources braille -->
      ${d.selectedBraille.length > 0 ? `
      <div style="background:rgba(27,79,138,.1);border:1px solid rgba(27,79,138,.3);padding:.7rem">
        <div style="font-size:.52rem;color:#6BA3D6;margin-bottom:.5rem">👁 Pour imprimer en braille en France</div>
        ${this.RESOURCES.fr.map(r=>`
          <div style="margin-bottom:.4rem">
            <div style="font-size:.54rem;color:var(--text);font-weight:bold">${r.name}</div>
            <div style="font-size:.48rem;color:var(--muted)">${r.address}</div>
            ${r.hours?`<div style="font-size:.46rem;color:var(--muted)">${r.hours}</div>`:''}
            <div style="font-size:.46rem;color:var(--muted);font-style:italic">${r.note}</div>
            <a href="${r.url}" target="_blank" style="font-size:.46rem;color:#6BA3D6">${r.url}</a>
          </div>
        `).join('')}
      </div>` : ''}

      ${d.history.length > 0 ? `
      <div class="sep"></div>
      <div class="sec-title">Documents récents</div>
      ${d.history.slice(0,3).map(h=>`
        <div style="padding:.5rem;border:1px solid var(--border)">
          <div style="font-size:.5rem;color:var(--muted)">${new Date(h.at).toLocaleDateString('fr-FR')} — ${h.results.length} document(s)</div>
          <div style="font-size:.52rem;color:var(--text);margin-top:.2rem">${h.results.map(r=>r.lang).join(', ')}</div>
        </div>
      `).join('')}` : ''}

      <!-- Message Madame Or Eille -->
      <div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">
        <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>
        <p style="font-size:.52rem;color:rgba(240,232,216,.7);line-height:1.8;position:relative;z-index:1">
          Idéal pour — rapports de stage, thèses multilingues, cours à traduire, documents familiaux.<br/>
          Vos notes dans votre langue. Votre document dans la langue du monde entier.
        </p>
        <p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>
      </div>
    </div>`;
  }
};

window.OCR = OCR;
