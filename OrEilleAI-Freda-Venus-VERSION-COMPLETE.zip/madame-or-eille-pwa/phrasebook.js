// ═══════════════════════════════════════════════════
//  PHRASEBOOK UNIVERSEL — Or Eille AI v1.0
//  120 phrases essentielles traduisibles hors ligne
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const PHRASEBOOK = {
  KEY: 'moe_phrasebook',

  PHRASES: [
    { id:1, cat:"Urgences", fr:"Au secours" },
    { id:2, cat:"Urgences", fr:"Appelez une ambulance" },
    { id:3, cat:"Urgences", fr:"Appelez la police" },
    { id:4, cat:"Urgences", fr:"Appelez un medecin" },
    { id:5, cat:"Urgences", fr:"J ai besoin d aide" },
    { id:6, cat:"Urgences", fr:"Je suis en danger" },
    { id:7, cat:"Urgences", fr:"Il y a eu un accident" },

    { id:8, cat:"Sante", fr:"Je suis diabetique" },
    { id:9, cat:"Sante", fr:"Je suis epileptique" },
    { id:10, cat:"Sante", fr:"Je suis cardiaque" },
    { id:11, cat:"Sante", fr:"J ai de l asthme" },
    { id:12, cat:"Sante", fr:"J ai un pacemaker" },
    { id:13, cat:"Sante", fr:"Je suis enceinte" },
    { id:14, cat:"Sante", fr:"Je prends des anticoagulants" },
    { id:15, cat:"Sante", fr:"Je suis allergique a la penicilline" },
    { id:16, cat:"Sante", fr:"Je suis allergique aux arachides" },
    { id:17, cat:"Sante", fr:"J ai besoin de mon insuline" },
    { id:18, cat:"Sante", fr:"J ai besoin de mon inhalateur" },
    { id:19, cat:"Sante", fr:"Je fais un malaise" },
    { id:20, cat:"Sante", fr:"J ai du mal a respirer" },
    { id:21, cat:"Sante", fr:"J ai une douleur dans la poitrine" },
    { id:22, cat:"Sante", fr:"J ai de la fievre" },
    { id:23, cat:"Sante", fr:"J ai mal ici" },
    { id:24, cat:"Sante", fr:"Je saigne" },

    { id:25, cat:"Pharmacie", fr:"Du paracetamol" },
    { id:26, cat:"Pharmacie", fr:"Un pansement" },
    { id:27, cat:"Pharmacie", fr:"Des protections hygieniques" },
    { id:28, cat:"Pharmacie", fr:"De l ibuprofene" },
    { id:29, cat:"Pharmacie", fr:"Un antiseptique" },
    { id:30, cat:"Pharmacie", fr:"Des antihistaminiques" },
    { id:31, cat:"Pharmacie", fr:"Du serum physiologique" },
    { id:32, cat:"Pharmacie", fr:"Des couches" },
    { id:33, cat:"Pharmacie", fr:"Du lait pour bebe" },

    { id:34, cat:"Lieux essentiels", fr:"Ou est l hopital" },
    { id:35, cat:"Lieux essentiels", fr:"Ou est le dispensaire" },
    { id:36, cat:"Lieux essentiels", fr:"Ou est la pharmacie" },
    { id:37, cat:"Lieux essentiels", fr:"Ou est le commissariat de police" },
    { id:38, cat:"Lieux essentiels", fr:"Ou est l ambassade" },
    { id:39, cat:"Lieux essentiels", fr:"Ou est la gare" },
    { id:40, cat:"Lieux essentiels", fr:"Ou est l aeroport" },
    { id:41, cat:"Lieux essentiels", fr:"Ou sont les toilettes" },
    { id:42, cat:"Lieux essentiels", fr:"Ou est le marche" },
    { id:43, cat:"Lieux essentiels", fr:"Ou est la banque" },
    { id:44, cat:"Lieux essentiels", fr:"Ou est le distributeur automatique" },

    { id:45, cat:"Alimentation", fr:"Du pain" },
    { id:46, cat:"Alimentation", fr:"De l eau" },
    { id:47, cat:"Alimentation", fr:"Du riz" },
    { id:48, cat:"Alimentation", fr:"De l huile" },
    { id:49, cat:"Alimentation", fr:"Du sel" },
    { id:50, cat:"Alimentation", fr:"Du sucre" },
    { id:51, cat:"Alimentation", fr:"Du lait" },
    { id:52, cat:"Alimentation", fr:"Des oeufs" },
    { id:53, cat:"Alimentation", fr:"De la viande" },
    { id:54, cat:"Alimentation", fr:"Du poisson" },
    { id:55, cat:"Alimentation", fr:"Des legumes" },
    { id:56, cat:"Alimentation", fr:"Des fruits" },
    { id:57, cat:"Alimentation", fr:"Je suis vegetarien" },
    { id:58, cat:"Alimentation", fr:"Je ne mange pas de porc" },
    { id:59, cat:"Alimentation", fr:"Je suis allergique aux noix" },
    { id:60, cat:"Alimentation", fr:"Sans gluten" },

    { id:61, cat:"Communication", fr:"Bonjour" },
    { id:62, cat:"Communication", fr:"Merci" },
    { id:63, cat:"Communication", fr:"S il vous plait" },
    { id:64, cat:"Communication", fr:"Je ne comprends pas" },
    { id:65, cat:"Communication", fr:"Parlez plus lentement" },
    { id:66, cat:"Communication", fr:"Pouvez-vous ecrire cela" },
    { id:67, cat:"Communication", fr:"Je parle francais" },
    { id:68, cat:"Communication", fr:"Parlez-vous francais" },
    { id:69, cat:"Communication", fr:"Oui" },
    { id:70, cat:"Communication", fr:"Non" },
    { id:71, cat:"Communication", fr:"Je ne sais pas" },
    { id:72, cat:"Communication", fr:"Repetez s il vous plait" },

    { id:73, cat:"Orientation", fr:"Je suis perdu" },
    { id:74, cat:"Orientation", fr:"A gauche" },
    { id:75, cat:"Orientation", fr:"A droite" },
    { id:76, cat:"Orientation", fr:"Tout droit" },
    { id:77, cat:"Orientation", fr:"C est loin" },
    { id:78, cat:"Orientation", fr:"Combien de minutes a pied" },

    { id:79, cat:"Transport", fr:"Un taxi s il vous plait" },
    { id:80, cat:"Transport", fr:"Combien coute le trajet" },
    { id:81, cat:"Transport", fr:"Arretez-vous ici" },
    { id:82, cat:"Transport", fr:"C est trop cher" },

    { id:83, cat:"Argent", fr:"Combien ca coute" },
    { id:84, cat:"Argent", fr:"C est trop cher" },
    { id:85, cat:"Argent", fr:"Avez-vous de la monnaie" },
    { id:86, cat:"Argent", fr:"Je voudrais payer par carte" },
    { id:87, cat:"Argent", fr:"Un recu s il vous plait" },

    { id:88, cat:"Logement", fr:"J ai une reservation" },
    { id:89, cat:"Logement", fr:"L eau ne marche pas" },
    { id:90, cat:"Logement", fr:"La climatisation ne marche pas" },
    { id:91, cat:"Logement", fr:"Le WiFi ne marche pas" },
    { id:92, cat:"Logement", fr:"Je voudrais partir" },

    { id:93, cat:"Securite femmes", fr:"J ai peur" },
    { id:94, cat:"Securite femmes", fr:"Je suis suivie" },
    { id:95, cat:"Securite femmes", fr:"Cet homme me suit" },
    { id:96, cat:"Securite femmes", fr:"Aidez-moi s il vous plait" },
    { id:97, cat:"Securite femmes", fr:"Ne me touchez pas" },
    { id:98, cat:"Securite femmes", fr:"Laissez-moi tranquille" },
    { id:99, cat:"Securite femmes", fr:"N approchez pas" },
    { id:100, cat:"Securite femmes", fr:"Je vais crier" },
    { id:101, cat:"Securite femmes", fr:"Je connais mes droits" },
    { id:102, cat:"Securite femmes", fr:"Y a-t-il une femme a qui je peux parler" },
    { id:103, cat:"Securite femmes", fr:"Appelez quelqu un" },
    { id:104, cat:"Securite femmes", fr:"Je me sens en danger" },

    { id:105, cat:"Enfants", fr:"Mon enfant est malade" },
    { id:106, cat:"Enfants", fr:"Mon enfant a disparu" },
    { id:107, cat:"Enfants", fr:"Mon enfant a de la fievre" },

    { id:108, cat:"Essentiel", fr:"Mon telephone est mort" },
    { id:109, cat:"Essentiel", fr:"J ai perdu mon passeport" },
    { id:110, cat:"Essentiel", fr:"J ai besoin de contacter mon ambassade" },
    { id:111, cat:"Essentiel", fr:"Appelez ce numero s il vous plait" },
    { id:112, cat:"Essentiel", fr:"Il n y a pas d electricite" },
    { id:113, cat:"Essentiel", fr:"Je cherche un endroit sur pour dormir" },
  ],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { translations: {}, preparing: false }; }
    catch { return { translations: {}, preparing: false }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async translateAll(targetLang, claudeKey) {
    if (!targetLang) {
      if (window.addChatMsg) addChatMsg('assistant', 'Entrez une langue cible.');
      return;
    }
    if (!claudeKey) {
      if (window.addChatMsg) addChatMsg('assistant', 'Cle API requise.');
      return;
    }
    if (window.addChatMsg) addChatMsg('assistant', 'Traduction de ' + this.PHRASES.length + ' phrases en ' + targetLang + '... Cela prend environ 30 secondes.');

    const phrases = this.PHRASES.map(function(p) { return p.id + '. ' + p.fr; }).join('\n');

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 4000,
          messages: [{
            role: 'user',
            content: 'Traduis ces phrases du francais vers le ' + targetLang + '.\nReponds UNIQUEMENT avec les traductions numerotees dans le meme ordre.\nFormat: 1. traduction\n2. traduction\netc.\n\n' + phrases
          }]
        })
      });
      const data = await r.json();
      const text = data.content[0].text;
      const lines = text.split('\n');
      const d = this.get();
      if (!d.translations) d.translations = {};
      if (!d.translations[targetLang]) d.translations[targetLang] = {};

      lines.forEach(function(line) {
        const match = line.match(/^(\d+)\.\s*(.+)/);
        if (match) {
          d.translations[targetLang][match[1]] = match[2].trim();
        }
      });
      this.save(d);
      if (window.addChatMsg) addChatMsg('assistant', 'Phrasebook en ' + targetLang + ' pret ! ' + Object.keys(d.translations[targetLang]).length + ' phrases disponibles hors ligne.');
      document.getElementById('phrasebookContent').innerHTML = PHRASEBOOK.renderPanel();
    } catch(e) {
      if (window.addChatMsg) addChatMsg('assistant', 'Erreur. Verifiez votre connexion.');
    }
  },

  speak(text, lang) {
    if (!window.speechSynthesis) return;
    const utt = new SpeechSynthesisUtterance(text);
    utt.lang = lang || 'fr-FR';
    utt.rate = 0.8;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utt);
  },

  renderPanel() {
    const d = this.get();
    const langs = Object.keys(d.translations || {});
    const selectedLang = d.selectedLang || (langs.length > 0 ? langs[0] : '');

    let catHtml = '';
    const cats = {};
    this.PHRASES.forEach(function(p) {
      if (!cats[p.cat]) cats[p.cat] = [];
      cats[p.cat].push(p);
    });

    const catIcons = {
      'Urgences': '🚨',
      'Sante': '🏥',
      'Pharmacie': '💊',
      'Lieux essentiels': '📍',
      'Alimentation': '🛒',
      'Communication': '💬',
      'Orientation': '🗺',
      'Transport': '🚌',
      'Argent': '💰',
      'Logement': '🏨',
      'Securite femmes': '🛡',
      'Enfants': '👶',
      'Essentiel': '⚡',
    };

    Object.keys(cats).forEach(function(cat) {
      const icon = catIcons[cat] || '•';
      catHtml += '<div style="margin-bottom:.5rem">';
      catHtml += '<div style="font-size:.5rem;color:var(--gold);letter-spacing:.1em;text-transform:uppercase;padding:.3rem 0;border-bottom:1px solid var(--border);margin-bottom:.3rem">' + icon + ' ' + cat + '</div>';
      cats[cat].forEach(function(p) {
        const trans = selectedLang && d.translations[selectedLang] ? (d.translations[selectedLang][p.id] || '') : '';
        catHtml += '<div style="padding:.35rem 0;border-bottom:1px solid rgba(255,255,255,.04);display:flex;align-items:center;gap:.4rem">';
        catHtml += '<div style="flex:1">';
        catHtml += '<div style="font-size:.52rem;color:var(--text)">' + p.fr + '</div>';
        if (trans) {
          catHtml += '<div style="font-size:.5rem;color:var(--gold);margin-top:.1rem">' + trans + '</div>';
        }
        catHtml += '</div>';
        if (trans) {
          catHtml += '<button onclick="PHRASEBOOK.speak(\'' + trans.replace(/'/g, '') + '\',\'' + selectedLang + '\')" style="background:transparent;border:none;font-size:.8rem;cursor:pointer;padding:.2rem">🔊</button>';
        }
        catHtml += '</div>';
      });
      catHtml += '</div>';
    });

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">📚 Phrasebook universel</div>' +
      '<p class="note">113 phrases essentielles. Traduisez une fois en WiFi. Consultez partout hors ligne. Protections hygieniques, pharmacie, securite, lieux, alimentation.</p>' +

      '<div style="display:flex;gap:.4rem;align-items:flex-end">' +
        '<div style="flex:1"><span class="klabel">Langue cible</span>' +
          '<input type="text" id="pb-lang" placeholder="Ex: wolof, fon, lingala, tagalog..." value="' + selectedLang + '" style="margin-top:.2rem"/>' +
        '</div>' +
        '<button onclick="const l=document.getElementById(\'pb-lang\').value;const d2=PHRASEBOOK.get();d2.selectedLang=l;PHRASEBOOK.save(d2);PHRASEBOOK.translateAll(l,window.CFG&&window.CFG.CLAUDE_KEY)" style="padding:.5rem .7rem;background:var(--gold);color:var(--dark);border:none;font-size:.5rem;cursor:pointer;white-space:nowrap">Traduire tout</button>' +
      '</div>' +

      (langs.length > 0 ? (
        '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
          langs.map(function(l) {
            return '<button onclick="const d2=PHRASEBOOK.get();d2.selectedLang=\'' + l + '\';PHRASEBOOK.save(d2);document.getElementById(\'phrasebookContent\').innerHTML=PHRASEBOOK.renderPanel()" style="padding:.25rem .5rem;background:' + (l===selectedLang?'rgba(196,153,58,.2)':'var(--dark-mid)') + ';border:1px solid ' + (l===selectedLang?'var(--gold)':'var(--border)') + ';color:' + (l===selectedLang?'var(--gold)':'var(--muted)') + ';font-size:.48rem;cursor:pointer">' + l + '</button>';
          }).join('') +
        '</div>'
      ) : '') +

      catHtml +

      '<div style="font-size:.48rem;color:var(--muted);line-height:1.7;padding:.5rem;border:1px solid var(--border)">' +
        'Preparees en WiFi. Consultables hors ligne. Cliquez sur le haut-parleur pour entendre la prononciation.' +
      '</div>' +
    '</div>';
  }
};

window.PHRASEBOOK = PHRASEBOOK;
