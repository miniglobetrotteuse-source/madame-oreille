// ═══════════════════════════════════════════════════
//  FREEMIUM — Or Eille AI v2.0
//  Gratuit : 10 images + 2 vidéos 3min + 3h conversation
//  Session 1 : pause 4h — Session 2 : pause 8h — Suite libre
//  Payant : illimité à 18€/mois
// ═══════════════════════════════════════════════════

const FREEMIUM = {
  KEY: 'moe_freemium',

  MAX_FREE_IMAGES: 10,
  MAX_FREE_VIDEOS: 2,
  MAX_FREE_VIDEO_MINUTES: 3,
  MAX_FREE_HOURS: 4,
  COOLDOWN_S1: 4, // heures session gratuite
  COOLDOWN_S2: 2, // heures pause après session

  get() {
    try {
      return JSON.parse(localStorage.getItem(this.KEY)) || {
        plan: 'free',
        images: [], videos: [],
        sessionStart: null, totalTimeUsed: 0,
        sessionCount: 0,
        cooldownUntil: null,
        timeCooldownUntil: null,
        lastResetDate: new Date().toDateString(),
      };
    } catch {
      return { plan: 'free', images: [], videos: [], sessionStart: null, totalTimeUsed: 0, sessionCount: 0, cooldownUntil: null, timeCooldownUntil: null, lastResetDate: new Date().toDateString() };
    }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // Réinitialiser chaque jour à minuit heure locale
  resetIfNewDay() {
    const d = this.get();
    const today = new Date().toDateString();
    if (d.lastResetDate !== today) {
      d.images = []; d.videos = [];
      d.totalTimeUsed = 0; d.sessionStart = null;
      d.sessionCount = 0;
      d.cooldownUntil = null; d.timeCooldownUntil = null;
      d.lastResetDate = today;
      this.save(d);
    }
  },

  // Vérifier si en cooldown génération
  checkGenerationCooldown() {
    const d = this.get();
    if (!d.cooldownUntil) return { blocked: false };
    const remaining = new Date(d.cooldownUntil).getTime() - Date.now();
    if (remaining <= 0) {
      // Cooldown terminé — réinitialiser les compteurs de génération
      d.images = []; d.videos = [];
      d.cooldownUntil = null;
      this.save(d);
      return { blocked: false };
    }
    return { blocked: true, remainingMs: remaining, remainingH: Math.ceil(remaining / 3600000) };
  },

  // Vérifier si en cooldown conversation
  checkTimeCooldown() {
    const d = this.get();
    if (!d.timeCooldownUntil) return { blocked: false };
    const remaining = new Date(d.timeCooldownUntil).getTime() - Date.now();
    if (remaining <= 0) {
      d.totalTimeUsed = 0; d.sessionStart = null;
      d.timeCooldownUntil = null;
      this.save(d);
      return { blocked: false };
    }
    return { blocked: true, remainingMs: remaining, remainingH: Math.ceil(remaining / 3600000) };
  },

  // Déclencher un cooldown de génération
  triggerGenerationCooldown() {
    const d = this.get();
    d.sessionCount = (d.sessionCount || 0) + 1;
    const hours = d.sessionCount === 1 ? this.COOLDOWN_S1 : this.COOLDOWN_S2;
    d.cooldownUntil = new Date(Date.now() + hours * 3600000).toISOString();
    this.save(d);
    return hours;
  },

  // Vérifier si peut générer une image
  canGenerateImage() {
    this.resetIfNewDay();
    const d = this.get();
    if (d.plan === 'paid') return { ok: true };
    const cooldown = this.checkGenerationCooldown();
    if (cooldown.blocked) return { ok: false, reason: 'cooldown', remainingH: cooldown.remainingH };
    if (d.images.length >= this.MAX_FREE_IMAGES) {
      const hours = this.triggerGenerationCooldown();
      return { ok: false, reason: 'limit', used: d.images.length, max: this.MAX_FREE_IMAGES, cooldownH: hours };
    }
    return { ok: true, remaining: this.MAX_FREE_IMAGES - d.images.length };
  },

  // Vérifier si peut générer une vidéo
  canGenerateVideo() {
    this.resetIfNewDay();
    const d = this.get();
    if (d.plan === 'paid') return { ok: true };
    const cooldown = this.checkGenerationCooldown();
    if (cooldown.blocked) return { ok: false, reason: 'cooldown', remainingH: cooldown.remainingH };
    if (d.videos.length >= this.MAX_FREE_VIDEOS) {
      const hours = this.triggerGenerationCooldown();
      return { ok: false, reason: 'limit', used: d.videos.length, max: this.MAX_FREE_VIDEOS, cooldownH: hours };
    }
    return { ok: true, remaining: this.MAX_FREE_VIDEOS - d.videos.length };
  },

  // Vérifier si peut utiliser la conversation
  canChat() {
    this.resetIfNewDay();
    const d = this.get();
    if (d.plan === 'paid') return { ok: true };
    const cooldown = this.checkTimeCooldown();
    if (cooldown.blocked) return { ok: false, reason: 'time_cooldown', remainingH: cooldown.remainingH };
    const elapsed = d.sessionStart ? Math.round((Date.now() - d.sessionStart) / 60000) : 0;
    const total = (d.totalTimeUsed || 0) + elapsed;
    const maxMinutes = this.MAX_FREE_HOURS * 60;
    if (total >= maxMinutes) {
      // Déclencher cooldown conversation
      const d2 = this.get();
      d2.sessionCount = (d2.sessionCount || 0) + 1;
      const hours = d2.sessionCount === 1 ? this.COOLDOWN_S1 : this.COOLDOWN_S2;
      d2.timeCooldownUntil = new Date(Date.now() + hours * 3600000).toISOString();
      d2.totalTimeUsed = total;
      this.save(d2);
      return { ok: false, reason: 'time', cooldownH: hours };
    }
    return { ok: true, remainingMinutes: maxMinutes - total };
  },

  // Enregistrer une génération
  recordImage() {
    const check = this.canGenerateImage();
    if (!check.ok) { this.showLimit(check); return false; }
    const d = this.get();
    d.images.push(new Date().toISOString());
    this.save(d);
    // Vérifier si on vient d'atteindre la limite
    if (d.images.length >= this.MAX_FREE_IMAGES) {
      const hours = this.triggerGenerationCooldown();
      if (window.addChatMsg) addChatMsg('assistant', `✨ Vous avez utilisé vos ${this.MAX_FREE_IMAGES} images gratuites. Pause de ${hours}h — revenez dans ${hours} heures ou passez à Or Eille AI illimité à 18€/mois.`);
    }
    return true;
  },

  recordVideo() {
    const check = this.canGenerateVideo();
    if (!check.ok) { this.showLimit(check); return false; }
    const d = this.get();
    d.videos.push(new Date().toISOString());
    this.save(d);
    if (d.videos.length >= this.MAX_FREE_VIDEOS) {
      const hours = this.triggerGenerationCooldown();
      if (window.addChatMsg) addChatMsg('assistant', `🎬 Vous avez utilisé vos ${this.MAX_FREE_VIDEOS} vidéos gratuites. Pause de ${hours}h — revenez dans ${hours} heures ou passez à Or Eille AI illimité à 18€/mois.`);
    }
    return true;
  },

  // Démarrer session
  startSession() {
    const d = this.get();
    if (!d.sessionStart) { d.sessionStart = Date.now(); this.save(d); }
    // Vérifier le temps toutes les 5 minutes
    setInterval(() => {
      const check = this.canChat();
      if (!check.ok && check.reason === 'time') {
        if (window.addChatMsg) addChatMsg('assistant', `⏱ Vos 3 heures gratuites sont écoulées. Pause de ${check.cooldownH}h — revenez dans ${check.cooldownH} heures ou passez à Or Eille AI illimité à 18€/mois.`);
      }
    }, 5 * 60 * 1000);
  },

  // Activer plan payant
  activatePaid(customerId) {
    const d = this.get();
    d.plan = 'paid';
    d.stripeCustomerId = customerId || null;
    this.save(d);
    this.showWelcomePaid();
  },

  showWelcomePaid() {
    const modal = document.createElement('div');
    modal.id = 'welcome-paid';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.96);z-index:99999;display:flex;align-items:center;justify-content:center;padding:1.5rem';
    modal.innerHTML = `
      <div style="max-width:360px;width:100%;text-align:center">
        <img src="/logo.png" style="width:100px;height:100px;object-fit:contain;filter:drop-shadow(0 0 20px rgba(196,153,58,.7));animation:pulse 2s infinite;margin-bottom:1.2rem"/>
        <div style="font-family:'Cormorant Garamond',serif;font-style:italic;color:#C4993A;font-size:1.4rem;margin-bottom:.8rem">✓ Bienvenue dans Or Eille AI illimité.</div>
        <p style="font-size:.56rem;color:rgba(240,232,216,.8);line-height:1.9;margin-bottom:.8rem">
          Votre abonnement est activé.<br/>
          Plus de limites. Plus de pauses.<br/><br/>
          Créez. Publiez. Protégez. Sans contrainte.
        </p>
        <p style="font-size:.54rem;color:rgba(240,232,216,.7);line-height:1.8;margin-bottom:1.2rem">
          Nous sommes fiers de vous avoir parmi nous.
        </p>
        <p style="font-size:.48rem;color:rgba(196,153,58,.6);font-family:'Cormorant Garamond',serif;font-style:italic;margin-bottom:1rem">
          Or Eille AI — L'IA qui s'exécute au doigt et à l'œil<br/>
          © Madame Or Eille Studios
        </p>
        <button onclick="document.getElementById('welcome-paid').remove()" style="padding:.7rem 2rem;background:#C4993A;color:#0F0F0F;border:none;font-family:'Josefin Sans',sans-serif;font-size:.58rem;letter-spacing:.15em;cursor:pointer">
          COMMENCER →
        </button>
      </div>`;
    document.body.appendChild(modal);
  },

  // Modal de limite
  showLimit(check) {
    const existing = document.getElementById('freemiumModal');
    if (existing) return;

    const modal = document.createElement('div');
    modal.id = 'freemiumModal';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.96);z-index:99999;display:flex;align-items:center;justify-content:center;padding:1.5rem';

    let message = '';
    if (check.reason === 'cooldown') message = `Pause de ${check.remainingH}h en cours. Revenez dans ${check.remainingH} heure(s) ou passez à Or Eille AI illimité.`;
    else if (check.reason === 'limit') message = `Vous avez utilisé votre quota gratuit. Pause de ${check.cooldownH}h automatique.`;
    else if (check.reason === 'time') message = `Vos 3 heures gratuites sont épuisées. Pause de ${check.cooldownH}h.`;
    else if (check.reason === 'time_cooldown') message = `Pause de ${check.remainingH}h en cours pour la conversation.`;

    modal.innerHTML = `
      <div style="max-width:340px;width:100%;background:#1a1610;border:1px solid #C4993A;padding:1.5rem;text-align:center">
        <div style="font-size:2rem;margin-bottom:.8rem">⏸</div>
        <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:#C4993A;font-size:1.3rem;margin-bottom:.5rem">Pause bien méritée</h3>
        <p style="font-size:.56rem;color:rgba(240,232,216,.6);line-height:1.7;margin-bottom:1rem">${message}</p>
        <div style="background:rgba(196,153,58,.08);border:1px solid rgba(196,153,58,.25);padding:1rem;margin-bottom:1rem">
          <div style="font-size:1.6rem;color:#C4993A;font-family:'Cormorant Garamond',serif;font-style:italic">18 €<span style="font-size:.7rem">/mois</span></div>
          <div style="font-size:.48rem;color:rgba(240,232,216,.5);margin:.3rem 0 .6rem">Illimité — moins cher que Claude et ChatGPT</div>
          <div style="text-align:left;font-size:.52rem;color:rgba(240,232,216,.7);line-height:1.9">
            ✓ Images illimitées<br/>
            ✓ Vidéos illimitées<br/>
            ✓ Conversation illimitée<br/>
            ✓ Tous les panneaux<br/>
            ✓ Mémoire permanente<br/>
            ✓ 12 langues
          </div>
        </div>
        <button onclick="FREEMIUM.goToPay()" style="width:100%;padding:.85rem;background:#C4993A;color:#0F0F0F;border:none;font-family:'Josefin Sans',sans-serif;font-size:.58rem;letter-spacing:.15em;text-transform:uppercase;cursor:pointer;margin-bottom:.4rem">
          S'abonner — 18 €/mois
        </button>
        <button onclick="document.getElementById('freemiumModal').remove()" style="width:100%;padding:.6rem;background:transparent;border:1px solid rgba(240,232,216,.2);color:rgba(240,232,216,.4);font-family:'Josefin Sans',sans-serif;font-size:.5rem;cursor:pointer">
          Continuer en version gratuite
        </button>
      </div>`;
    document.body.appendChild(modal);
  },

  goToPay() {
    const url = window.CFG?.STRIPE_CHECKOUT_URL || '#';
    if (url === '#') {
      if (window.addChatMsg) addChatMsg('assistant', 'Paiement bientôt disponible.');
      return;
    }
    window.open(url, '_blank');
  },

  // Stats pour affichage
  getStats() {
    this.resetIfNewDay();
    const d = this.get();
    const elapsed = d.sessionStart ? Math.round((Date.now() - d.sessionStart) / 60000) : 0;
    const totalTime = (d.totalTimeUsed || 0) + elapsed;
    const genCooldown = this.checkGenerationCooldown();
    const timeCooldown = this.checkTimeCooldown();
    return {
      plan: d.plan, isPaid: d.plan === 'paid',
      imagesUsed: d.images.length, imagesMax: this.MAX_FREE_IMAGES,
      videosUsed: d.videos.length, videosMax: this.MAX_FREE_VIDEOS,
      minutesUsed: totalTime, minutesMax: this.MAX_FREE_HOURS * 60,
      sessionCount: d.sessionCount || 0,
      generationCooldown: genCooldown,
      timeCooldown: timeCooldown,
    };
  },


  // ─── Désabonnement élégant ────────────────────
  MESSAGE_DEPART: 'Tu pars. C est ton droit. Tes creations te seront envoyees par email. Elles t appartiennent. Bonne route. Et si tu commercialises une creation faite ici — 10% a Madame Or Eille Studios. C est notre accord. © Madame Or Eille Studios',

  MESSAGE_REDEVANCE: 'Toute oeuvre creee avec Or Eille AI qui genere des revenus commerciaux est soumise a une redevance de 10% a Madame Or Eille Studios. Films, chansons, livres, pubs, podcasts monetises — toute exploitation commerciale. Dans 6 mois, dans 10 ans, dans 20 ans. Contact : contact@madame-or-eille.com',

  MESSAGE_BIENVENUE_CGU: 'Tout ce que tu crees t appartient. En echange : si tu commercialises une creation faite ici — 10% des revenus commerciaux a Madame Or Eille Studios. C est notre accord. Simple. Transparent. © Madame Or Eille Studios',


  unsubscribe(userEmail) {
    const d = this.get();
    d.plan = 'free';
    d.unsubscribedAt = new Date().toISOString();
    this.save(d);

    // Afficher le message de départ
    const modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.97);z-index:99999;display:flex;align-items:center;justify-content:center;padding:1.5rem;overflow-y:auto';
    modal.innerHTML =
      '<div style="max-width:400px;width:100%;text-align:center">' +
        '<img src="/logo.png" style="width:70px;height:70px;object-fit:contain;filter:drop-shadow(0 0 15px rgba(196,153,58,.5));margin-bottom:1rem"/>' +
        '<div style="font-family:Cormorant Garamond,serif;font-style:italic;color:#C4993A;font-size:1.1rem;margin-bottom:1rem">Bonne route.</div>' +
        '<pre style="font-size:.48rem;color:rgba(240,232,216,.75);line-height:1.8;text-align:left;white-space:pre-wrap;font-family:Josefin Sans,sans-serif;margin-bottom:1.2rem">' + this.MESSAGE_DEPART + '</pre>' +
        '<button onclick="this.parentElement.parentElement.remove()" style="padding:.7rem 2rem;background:#C4993A;color:#0F0F0F;border:none;font-family:Josefin Sans,sans-serif;font-size:.54rem;cursor:pointer;width:100%">Compris — bonne route</button>' +
      '</div>';
    document.body.appendChild(modal);

    if (window.addChatMsg) addChatMsg('assistant', 'Desabonnement effectue. Tes donnees te seront envoyees par email dans les 24h. ' + (userEmail ? 'A : ' + userEmail : 'Verifie ton email.'));
  },

};

window.FREEMIUM = FREEMIUM;
window.addEventListener('load', () => {
  setTimeout(() => {
    FREEMIUM.startSession();
    const style = document.createElement('style');
    style.textContent = `@keyframes pulse{0%,100%{opacity:1}50%{opacity:.7}}`;
    document.head.appendChild(style);
  }, 1000);
});

// ─── getStats pour la barre de quota ──────────
FREEMIUM.getStats = function() {
  const d = this.get();
  return {
    isPaid: d.plan === 'paid',
    imagesUsed: (d.images || []).length,
    imagesMax: this.MAX_FREE_IMAGES,
    videosUsed: (d.videos || []).length,
    videosMax: this.MAX_FREE_VIDEOS,
    minutesUsed: Math.round((d.totalTimeUsed || 0) / 60),
    minutesMax: this.MAX_FREE_HOURS * 60,
    sessionCount: d.sessionCount || 0,
  };
};
