// ═══════════════════════════════════════════════════
//  SIMULATEUR CODE DE LA ROUTE — Or Eille AI v1.0
//  Adapté par pays + analyse photo/vidéo terrain
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const DRIVING_EXAM = {

  KEY: 'moe_driving_exam',

  // ─── Config par pays ──────────────────────────
  PAYS: {
    france: {
      nom: 'France',
      drapeau: '🇫🇷',
      total_questions: 40,
      seuil_reussite: 35,
      duree_minutes: 20,
      info: '40 questions, 35 bonnes réponses pour réussir',
    },
    senegal: {
      nom: 'Sénégal',
      drapeau: '🇸🇳',
      total_questions: 50,
      seuil_reussite: 40,
      duree_minutes: 30,
      info: '50 questions, 40 bonnes réponses pour réussir',
    },
    maroc: {
      nom: 'Maroc',
      drapeau: '🇲🇦',
      total_questions: 40,
      seuil_reussite: 30,
      duree_minutes: 20,
      info: '40 questions, 30 bonnes réponses pour réussir',
    },
    canada: {
      nom: 'Canada',
      drapeau: '🇨🇦',
      total_questions: 30,
      seuil_reussite: 24,
      duree_minutes: 25,
      info: '30 questions, 24 bonnes réponses pour réussir',
    },
    belgique: {
      nom: 'Belgique',
      drapeau: '🇧🇪',
      total_questions: 50,
      seuil_reussite: 41,
      duree_minutes: 30,
      info: '50 questions, 41 bonnes réponses pour réussir',
    },
    cote_ivoire: {
      nom: "Côte d'Ivoire",
      drapeau: '🇨🇮',
      total_questions: 40,
      seuil_reussite: 32,
      duree_minutes: 20,
      info: '40 questions, 32 bonnes réponses pour réussir',
    },
    cameroun: {
      nom: 'Cameroun',
      drapeau: '🇨🇲',
      total_questions: 40,
      seuil_reussite: 32,
      duree_minutes: 20,
      info: '40 questions, 32 bonnes réponses pour réussir',
    },
    tunisie: {
      nom: 'Tunisie',
      drapeau: '🇹🇳',
      total_questions: 40,
      seuil_reussite: 30,
      duree_minutes: 20,
      info: '40 questions, 30 bonnes réponses pour réussir',
    },
  },

  // ─── Données persistantes ──────────────────────
  getData() {
    try {
      return JSON.parse(localStorage.getItem(this.KEY)) || {
        pays_selectionne: '',
        historique_sessions: [],
        meilleur_score: {},
        total_sessions: 0,
      };
    } catch { return { pays_selectionne: '', historique_sessions: [], meilleur_score: {}, total_sessions: 0 }; }
  },

  saveData(d) {
    try { localStorage.setItem(this.KEY, JSON.stringify(d)); } catch {}
  },

  saveSession(pays, score, total, questions_ratees) {
    const d = this.getData();
    const session = {
      id: 'sess_' + Date.now(),
      date: new Date().toISOString(),
      pays,
      score,
      total,
      pourcentage: Math.round((score / total) * 100),
      reussi: score >= this.PAYS[pays]?.seuil_reussite,
      questions_ratees,
    };
    d.historique_sessions.unshift(session);
    d.historique_sessions = d.historique_sessions.slice(0, 20); // garder 20 dernières
    d.total_sessions++;
    if (!d.meilleur_score[pays] || score > d.meilleur_score[pays]) {
      d.meilleur_score[pays] = score;
    }
    this.saveData(d);
    return session;
  },

  // ─── Message de résultat personnalisé ─────────
  getResultatMessage(session, sessionPrecedente) {
    const config = this.DRIVING_EXAM?.PAYS?.[session.pays] || DRIVING_EXAM.PAYS[session.pays];
    const prenom = window.MEMORY_SYSTEM ? MEMORY_SYSTEM.getProfile().prenom : '';
    const nom = prenom ? prenom : '';

    if (session.reussi) {
      if (sessionPrecedente && sessionPrecedente.score < session.score) {
        return `🏆 Félicitations ${nom} ! ${session.score}/${session.total} — Tu as progressé par rapport à ta dernière session (${sessionPrecedente.score}/${sessionPrecedente.total}). Excellent travail !`;
      }
      return `✅ Bravo ${nom} ! ${session.score}/${session.total} — Tu as réussi l'examen blanc ! Continue comme ça.`;
    } else {
      if (sessionPrecedente && sessionPrecedente.score > session.score) {
        return `💪 ${session.score}/${session.total} — Tu as fait un peu plus de fautes qu'hier (${sessionPrecedente.score}/${sessionPrecedente.total}), mais pas de panique ${nom}. Les erreurs d'aujourd'hui sont les réussites de demain. On révise ensemble ?`;
      }
      if (sessionPrecedente && sessionPrecedente.score < session.score) {
        return `📈 ${session.score}/${session.total} — Tu progresses ${nom} ! Encore un petit effort pour atteindre les ${config?.seuil_reussite} points. Tu y es presque.`;
      }
      return `📚 ${session.score}/${session.total} — Il faut encore ${config?.seuil_reussite - session.score} point(s) pour réussir. On continue à travailler, ${nom} !`;
    }
  },

  // ─── Générer examen via Claude ─────────────────
  async genererExamen(pays, imageBase64, imageContext) {
    const claudeKey = window.getKey ? getKey('claudeKey') : '';
    if (!claudeKey) return null;

    const config = this.PAYS[pays];
    if (!config) return null;

    const messages = [];

    // Si image fournie, l'inclure
    if (imageBase64) {
      messages.push({
        role: 'user',
        content: [
          {
            type: 'image',
            source: { type: 'base64', media_type: 'image/jpeg', data: imageBase64 }
          },
          {
            type: 'text',
            text: `Tu es un examinateur officiel du code de la route en ${config.nom}.

Analyse cette image de la route/rue réelle et génère ${config.total_questions} questions de code de la route basées sur ce que tu vois dans l'image ET sur les règles officielles du code de la route en ${config.nom}.

Pour chaque question, génère exactement ce format JSON :
{
  "questions": [
    {
      "id": 1,
      "question": "...",
      "image_context": "élément visible dans la photo qui justifie cette question (si applicable)",
      "options": ["A. ...", "B. ...", "C. ..."],
      "reponse_correcte": "A",
      "explication": "Explication claire de la bonne réponse selon le code de la route ${config.nom}"
    }
  ]
}

Réponds UNIQUEMENT avec le JSON, sans texte avant ou après.`
          }
        ]
      });
    } else {
      messages.push({
        role: 'user',
        content: `Tu es un examinateur officiel du code de la route en ${config.nom}.

Génère ${config.total_questions} questions de code de la route officielles pour ${config.nom}.
Couvre : panneaux, priorités, distances de sécurité, alcoolémie, vitesses, règles spécifiques à ${config.nom}.

Format JSON strict :
{
  "questions": [
    {
      "id": 1,
      "question": "...",
      "image_context": "",
      "options": ["A. ...", "B. ...", "C. ..."],
      "reponse_correcte": "A",
      "explication": "..."
    }
  ]
}

Réponds UNIQUEMENT avec le JSON.`
      });
    }

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': claudeKey,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 8000,
          messages,
        })
      });
      if (!r.ok) throw new Error('API ' + r.status);
      const data = await r.json();
      const text = data.content.filter(b => b.type === 'text').map(b => b.text).join('');
      const clean = text.replace(/```json|```/g, '').trim();
      return JSON.parse(clean);
    } catch (e) {
      console.error('Erreur génération examen:', e);
      return null;
    }
  },

  // ─── État de l'examen en cours ─────────────────
  _examEnCours: null,
  _questionActuelle: 0,
  _reponsesUtilisateur: [],
  _timerInterval: null,
  _tempsRestant: 0,

  demarrerExamen(pays, questions) {
    const config = this.PAYS[pays];
    this._examEnCours = { pays, questions, config };
    this._questionActuelle = 0;
    this._reponsesUtilisateur = [];
    this._tempsRestant = config.duree_minutes * 60;
    this._afficherQuestion();
    this._demarrerTimer();
  },

  _demarrerTimer() {
    clearInterval(this._timerInterval);
    this._timerInterval = setInterval(() => {
      this._tempsRestant--;
      const el = document.getElementById('exam_timer');
      if (el) {
        const m = Math.floor(this._tempsRestant / 60);
        const s = this._tempsRestant % 60;
        el.textContent = `⏱ ${m}:${s.toString().padStart(2,'0')}`;
        if (this._tempsRestant <= 60) el.style.color = 'var(--red)';
      }
      if (this._tempsRestant <= 0) {
        clearInterval(this._timerInterval);
        this._terminerExamen();
      }
    }, 1000);
  },

  _afficherQuestion() {
    const container = document.getElementById('drivingExamContent');
    if (!container) return;
    const exam = this._examEnCours;
    const q = exam.questions[this._questionActuelle];
    const config = exam.config;
    const progression = this._questionActuelle + 1;

    container.innerHTML = `
      <div style="padding:1rem;display:flex;flex-direction:column;gap:.7rem;height:100%;overflow-y:auto">

        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-size:.55rem;color:var(--muted)">Question ${progression}/${exam.questions.length}</span>
          <span id="exam_timer" style="font-size:.6rem;color:var(--gold)">⏱ ${config.duree_minutes}:00</span>
          <span style="font-size:.55rem;color:var(--muted)">${config.drapeau} ${config.nom}</span>
        </div>

        <div style="background:var(--dark-mid);height:4px;border-radius:2px">
          <div style="background:var(--gold);height:100%;width:${(progression/exam.questions.length)*100}%;border-radius:2px;transition:width .3s"></div>
        </div>

        ${q.image_context ? `<p style="font-size:.5rem;color:var(--gold);font-style:italic">📍 ${q.image_context}</p>` : ''}

        <p style="font-size:.7rem;color:var(--text);line-height:1.6;font-weight:700">${q.question}</p>

        <div style="display:flex;flex-direction:column;gap:.4rem">
          ${q.options.map((opt, i) => {
            const lettre = ['A','B','C','D'][i];
            return `<button onclick="DRIVING_EXAM._repondre('${lettre}')"
              style="text-align:left;padding:.7rem .9rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.6rem;cursor:pointer;transition:all .15s;line-height:1.5"
              onmouseover="this.style.borderColor='var(--gold)'"
              onmouseout="this.style.borderColor='var(--border)'">
              ${opt}
            </button>`;
          }).join('')}
        </div>

        <button onclick="DRIVING_EXAM._abandonner()"
          style="margin-top:auto;background:transparent;border:none;color:var(--muted);font-size:.48rem;cursor:pointer;text-align:center;padding:.3rem">
          Abandonner l'examen
        </button>
      </div>`;
  },

  _repondre(lettre) {
    const q = this._examEnCours.questions[this._questionActuelle];
    const correct = lettre === q.reponse_correcte;
    this._reponsesUtilisateur.push({
      question_id: q.id,
      question: q.question,
      repondu: lettre,
      correct,
      explication: q.explication,
    });

    // Feedback visuel rapide
    const container = document.getElementById('drivingExamContent');
    const btns = container.querySelectorAll('button');
    const options = ['A','B','C','D'];
    btns.forEach((btn, i) => {
      if (i >= options.length) return;
      btn.style.pointerEvents = 'none';
      if (options[i] === q.reponse_correcte) {
        btn.style.background = 'rgba(110,201,138,.2)';
        btn.style.borderColor = 'var(--green)';
        btn.style.color = 'var(--green)';
      } else if (options[i] === lettre && !correct) {
        btn.style.background = 'rgba(224,80,80,.2)';
        btn.style.borderColor = 'var(--red)';
        btn.style.color = 'var(--red)';
      }
    });

    // Afficher explication brièvement puis passer
    const expDiv = document.createElement('div');
    expDiv.style.cssText = 'padding:.6rem;border:1px solid var(--border);font-size:.55rem;color:var(--muted);line-height:1.6;margin-top:.3rem';
    expDiv.textContent = q.explication;
    container.querySelector('div').appendChild(expDiv);

    setTimeout(() => {
      this._questionActuelle++;
      if (this._questionActuelle >= this._examEnCours.questions.length) {
        this._terminerExamen();
      } else {
        this._afficherQuestion();
        this._demarrerTimer(); // reset timer display
      }
    }, 1800);
  },

  _terminerExamen() {
    clearInterval(this._timerInterval);
    const exam = this._examEnCours;
    const bonnes = this._reponsesUtilisateur.filter(r => r.correct).length;
    const ratees = this._reponsesUtilisateur.filter(r => !r.correct);

    const d = this.getData();
    const sessionPrecedente = d.historique_sessions.find(s => s.pays === exam.pays);
    const session = this.saveSession(exam.pays, bonnes, exam.questions.length, ratees.map(r => r.question));
    const message = this.getResultatMessage(session, sessionPrecedente);

    const container = document.getElementById('drivingExamContent');
    container.innerHTML = `
      <div style="padding:1.2rem;display:flex;flex-direction:column;gap:.8rem;overflow-y:auto">

        <div style="text-align:center;padding:1.5rem;border:1px solid ${session.reussi ? 'var(--green)' : 'var(--gold)'};background:${session.reussi ? 'rgba(110,201,138,.08)' : 'rgba(201,168,76,.08)'}">
          <div style="font-size:2rem;margin-bottom:.5rem">${session.reussi ? '🏆' : '📚'}</div>
          <div style="font-size:1.2rem;color:${session.reussi ? 'var(--green)' : 'var(--gold)'};font-family:'Cormorant Garamond',serif;margin-bottom:.4rem">
            ${bonnes} / ${exam.questions.length}
          </div>
          <div style="font-size:.6rem;color:var(--text);line-height:1.6">${message}</div>
        </div>

        ${ratees.length > 0 ? `
          <div class="sec-title" style="margin-top:.3rem">Questions à retravailler</div>
          ${ratees.slice(0, 5).map(r => `
            <div style="padding:.6rem;border:1px solid rgba(224,80,80,.3);font-size:.55rem;line-height:1.6">
              <div style="color:var(--text);margin-bottom:.3rem">❌ ${r.question}</div>
              <div style="color:var(--muted)">${r.explication}</div>
            </div>
          `).join('')}
          ${ratees.length > 5 ? `<p style="font-size:.5rem;color:var(--muted);text-align:center">+ ${ratees.length - 5} autres erreurs</p>` : ''}
        ` : ''}

        <div style="display:flex;gap:.4rem;margin-top:.5rem">
          <button class="btn btn-gold" style="flex:1" onclick="DRIVING_EXAM._relancerExamen()">🔄 Nouvel examen</button>
          <button class="btn btn-ghost" style="flex:1" onclick="document.getElementById('drivingExamContent').innerHTML = DRIVING_EXAM.renderPanel()">← Retour</button>
        </div>

      </div>`;

    this._examEnCours = null;
  },

  _abandonner() {
    clearInterval(this._timerInterval);
    this._examEnCours = null;
    document.getElementById('drivingExamContent').innerHTML = this.renderPanel();
  },

  _relancerExamen() {
    const pays = this._dernierPays || this.getData().pays_selectionne;
    if (pays) this._lancerExamenSansPays(pays);
    else document.getElementById('drivingExamContent').innerHTML = this.renderPanel();
  },

  _dernierPays: null,

  async _lancerExamenSansPays(pays) {
    this._dernierPays = pays;
    const container = document.getElementById('drivingExamContent');
    container.innerHTML = `<div style="padding:2rem;text-align:center;color:var(--muted);font-size:.6rem">⏳ Génération de l'examen en cours…<br><br>Cela peut prendre quelques secondes.</div>`;

    const resultat = await DRIVING_EXAM.genererExamen(pays, null, null);
    if (!resultat || !resultat.questions) {
      container.innerHTML = `<div style="padding:1.5rem;text-align:center"><p style="color:var(--red);font-size:.6rem">Erreur de génération. Vérifiez votre clé Claude.</p><button class="btn btn-ghost" onclick="document.getElementById('drivingExamContent').innerHTML = DRIVING_EXAM.renderPanel()">← Retour</button></div>`;
      return;
    }
    DRIVING_EXAM.demarrerExamen(pays, resultat.questions);
  },

  // ─── Panneau principal ─────────────────────────
  renderPanel() {
    const d = this.getData();
    const pays_list = Object.entries(this.PAYS);

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem" id="drivingExamContent">

      <div class="sec-title">🚗 Simulateur Code de la Route</div>
      <p style="font-size:.55rem;color:var(--muted);line-height:1.6">Entraîne-toi avec de vrais examens blancs adaptés à ton pays. L'IA peut aussi analyser une photo de ta rue pour poser des questions sur ton environnement réel.</p>

      <div class="sec-title" style="margin-top:.3rem">Choisir ton pays</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">
        ${pays_list.map(([key, config]) => {
          const meilleur = d.meilleur_score[key];
          const sessions = d.historique_sessions.filter(s => s.pays === key).length;
          return `
          <button onclick="DRIVING_EXAM._lancerExamenSansPays('${key}')"
            style="padding:.7rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;cursor:pointer;text-align:left;transition:all .15s"
            onmouseover="this.style.borderColor='var(--gold)'"
            onmouseout="this.style.borderColor='var(--border)'">
            <div style="font-size:.85rem;margin-bottom:.2rem">${config.drapeau} ${config.nom}</div>
            <div style="font-size:.48rem;color:var(--muted)">${config.info}</div>
            ${meilleur ? `<div style="font-size:.48rem;color:var(--gold);margin-top:.2rem">⭐ Meilleur : ${meilleur}/${config.total_questions}</div>` : ''}
            ${sessions > 0 ? `<div style="font-size:.45rem;color:var(--muted)">${sessions} session(s)</div>` : ''}
          </button>`;
        }).join('')}
      </div>

      <div class="sep"></div>
      <div class="sec-title">📸 Examen sur photo de ta rue</div>
      <p style="font-size:.52rem;color:var(--muted);line-height:1.6">Prends une photo de ta rue, ton quartier, ton trajet habituel. L'IA génère des questions basées sur ce que tu vois réellement.</p>

      <div style="display:flex;flex-direction:column;gap:.5rem">
        <select id="pays_photo_exam"
          style="background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.58rem;padding:.45rem;outline:none">
          <option value="">— Choisir le pays —</option>
          ${pays_list.map(([key, config]) => `<option value="${key}">${config.drapeau} ${config.nom}</option>`).join('')}
        </select>

        <div class="upz" id="photo_rue_zone" onclick="document.getElementById('photo_rue_input').click()" style="min-height:80px">
          <input type="file" id="photo_rue_input" accept="image/*" style="display:none" onchange="DRIVING_EXAM._chargerPhotoRue(this)"/>
          <div style="font-size:1.2rem">📸</div>
          <div style="font-size:.55rem;color:var(--muted)">Photo de ta rue / ton quartier</div>
        </div>

        <button class="btn btn-gold" id="btn_lancer_photo" disabled
          onclick="DRIVING_EXAM._lancerExamenAvecPhoto()">
          🚦 Lancer l'examen sur ma rue
        </button>
      </div>

      ${d.historique_sessions.length > 0 ? `
        <div class="sep"></div>
        <div class="sec-title">📊 Historique</div>
        ${d.historique_sessions.slice(0, 5).map(s => {
          const config = DRIVING_EXAM.PAYS[s.pays];
          const date = new Date(s.date).toLocaleDateString('fr-FR');
          return `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:.5rem .6rem;border:1px solid var(--border);font-size:.55rem">
            <span>${config?.drapeau || ''} ${config?.nom || s.pays} — ${date}</span>
            <span style="color:${s.reussi ? 'var(--green)' : 'var(--gold)'};font-weight:700">${s.score}/${s.total} ${s.reussi ? '✅' : '❌'}</span>
          </div>`;
        }).join('')}
      ` : ''}

    </div>`;
  },

  _photoRueBase64: null,

  _chargerPhotoRue(input) {
    if (!input.files[0]) return;
    const reader = new FileReader();
    reader.onload = e => {
      this._photoRueBase64 = e.target.result.split(',')[1];
      const zone = document.getElementById('photo_rue_zone');
      zone.innerHTML = `<img src="${e.target.result}" style="max-width:100%;max-height:120px;object-fit:cover"/>`;
      const pays = document.getElementById('pays_photo_exam').value;
      if (pays) document.getElementById('btn_lancer_photo').disabled = false;
    };
    reader.readAsDataURL(input.files[0]);
  },

  async _lancerExamenAvecPhoto() {
    const pays = document.getElementById('pays_photo_exam').value;
    if (!pays || !this._photoRueBase64) return;

    this._dernierPays = pays;
    const container = document.getElementById('drivingExamContent');
    container.innerHTML = `<div style="padding:2rem;text-align:center;color:var(--muted);font-size:.6rem">📸 Analyse de ta rue en cours…<br><br>L'IA génère des questions basées sur ton environnement réel.</div>`;

    const resultat = await this.genererExamen(pays, this._photoRueBase64, true);
    if (!resultat || !resultat.questions) {
      container.innerHTML = `<div style="padding:1.5rem;text-align:center"><p style="color:var(--red);font-size:.6rem">Erreur. Vérifiez votre clé Claude.</p><button class="btn btn-ghost" onclick="document.getElementById('drivingExamContent').innerHTML = DRIVING_EXAM.renderPanel()">← Retour</button></div>`;
      return;
    }
    this.demarrerExamen(pays, resultat.questions);
  },
};

window.DRIVING_EXAM = DRIVING_EXAM;

// ─── Analyse du schéma d'apprentissage ───────────
DRIVING_EXAM.analyserPointsFaibles = function(pays) {
  const d = this.getData();
  const sessions = d.historique_sessions.filter(s => s.pays === pays);
  if (sessions.length === 0) return null;

  // Compter les questions ratées par thème
  const erreurs = {};
  sessions.forEach(s => {
    (s.questions_ratees || []).forEach(q => {
      // Détecter le thème de la question
      const theme = this._detecterTheme(q);
      erreurs[theme] = (erreurs[theme] || 0) + 1;
    });
  });

  // Trier par fréquence d'erreur
  const themes_tries = Object.entries(erreurs)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  return themes_tries;
};

DRIVING_EXAM._detecterTheme = function(question) {
  const q = question.toLowerCase();
  if (q.includes('panneau') || q.includes('signalisation')) return 'Panneaux de signalisation';
  if (q.includes('priorité') || q.includes('céder') || q.includes('stop')) return 'Priorités';
  if (q.includes('vitesse') || q.includes('km/h')) return 'Limitations de vitesse';
  if (q.includes('alcool') || q.includes('alcoolémie') || q.includes('drogue')) return 'Alcool & stupéfiants';
  if (q.includes('distance') || q.includes('sécurité')) return 'Distances de sécurité';
  if (q.includes('nuit') || q.includes('feux') || q.includes('phare')) return 'Éclairage & visibilité';
  if (q.includes('dépasse') || q.includes('dépassement')) return 'Dépassement';
  if (q.includes('stationnement') || q.includes('parking')) return 'Stationnement';
  if (q.includes('piéton') || q.includes('passage clouté')) return 'Piétons';
  if (q.includes('rond-point') || q.includes('giratoire')) return 'Ronds-points';
  return 'Règles générales';
};

DRIVING_EXAM._buildPromptAdapte = function(pays, pointsFaibles) {
  const config = this.PAYS[pays];
  if (!pointsFaibles || pointsFaibles.length === 0) return null;

  const themes = pointsFaibles.map(([theme, count]) => `${theme} (${count} erreur(s))`).join(', ');
  return `Cette personne a des difficultés particulières sur : ${themes}. 
Génère un examen qui insiste davantage sur ces thèmes (50% des questions sur ces points faibles, 50% questions variées).`;
};

// Surcharger genererExamen pour intégrer l'adaptation
const _genererExamenOriginal = DRIVING_EXAM.genererExamen.bind(DRIVING_EXAM);
DRIVING_EXAM.genererExamen = async function(pays, imageBase64, imageContext) {
  const pointsFaibles = this.analyserPointsFaibles(pays);
  const promptAdapte = this._buildPromptAdapte(pays, pointsFaibles);

  if (promptAdapte && !imageBase64) {
    // Examen adapté aux points faibles
    const claudeKey = window.getKey ? getKey('claudeKey') : '';
    if (!claudeKey) return null;
    const config = this.PAYS[pays];

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': claudeKey,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 8000,
          messages: [{
            role: 'user',
            content: `Tu es un examinateur du code de la route en ${config.nom}.

${promptAdapte}

Génère ${config.total_questions} questions adaptées. Format JSON strict :
{
  "questions": [
    {
      "id": 1,
      "question": "...",
      "image_context": "",
      "options": ["A. ...", "B. ...", "C. ..."],
      "reponse_correcte": "A",
      "explication": "..."
    }
  ]
}

Réponds UNIQUEMENT avec le JSON.`
          }]
        })
      });
      if (!r.ok) throw new Error('API ' + r.status);
      const data = await r.json();
      const text = data.content.filter(b => b.type === 'text').map(b => b.text).join('');
      const clean = text.replace(/```json|```/g, '').trim();
      return JSON.parse(clean);
    } catch(e) {
      // Fallback examen standard
      return _genererExamenOriginal(pays, imageBase64, imageContext);
    }
  }

  return _genererExamenOriginal(pays, imageBase64, imageContext);
};
