// ═══════════════════════════════════════════════════
//  ENVOI AUTOMATIQUE APRÈS SILENCE
//  + CONVERSATION VOCALE EN TEMPS RÉEL
//  Or Eille AI — v1.0
// ═══════════════════════════════════════════════════

class AutoSendVoice {
  constructor({ onResult, onInterim, onStart, onStop, silenceMs = 2000 }) {
    this.onResult = onResult;
    this.onInterim = onInterim || (() => {});
    this.onStart = onStart || (() => {});
    this.onStop = onStop || (() => {});
    this.silenceMs = silenceMs;
    this.recog = null;
    this.silenceTimer = null;
    this.transcript = '';
    this.active = false;
  }

  start() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { alert('Reconnaissance vocale : utilisez Chrome ou Safari.'); return; }

    this.recog = new SR();
    this.recog.lang = 'fr-FR';
    this.recog.continuous = true;
    this.recog.interimResults = true;
    this.active = true;
    this.transcript = '';
    this.onStart();

    this.recog.onresult = (e) => {
      let interim = '', final = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) final += e.results[i][0].transcript;
        else interim += e.results[i][0].transcript;
      }
      if (final) this.transcript += final;
      
      // Correction contextuelle via glossaire
      const corrected = MEM.GLOSSARY.correct(this.transcript + interim, 'voice');
      this.onInterim(corrected);

      // Reset silence timer
      clearTimeout(this.silenceTimer);
      this.silenceTimer = setTimeout(() => {
        if (this.transcript.trim()) {
          const final = MEM.GLOSSARY.correct(this.transcript, 'voice');
          this.stop();
          this.onResult(final);
        }
      }, this.silenceMs);
    };

    this.recog.onerror = (e) => {
      console.error('Voice error:', e.error);
      this.stop();
    };

    // Redémarrer automatiquement si toujours actif
    this.recog.onend = () => {
      if (this.active) {
        try { this.recog.start(); } catch {}
      }
    };

    try { this.recog.start(); } catch(e) { console.error(e); }
  }

  stop() {
    this.active = false;
    clearTimeout(this.silenceTimer);
    if (this.recog) {
      this.recog.onend = null;
      try { this.recog.stop(); } catch {}
    }
    this.onStop();
  }

  updateSilenceThreshold(ms) {
    this.silenceMs = ms;
  }
}

// ─── Instance globale pour le chat ────────────────
let globalChatVoice = null;

function startAutoVoiceChat() {
  const threshold = MEM.VOICE.getSilenceThreshold();
  const btn = document.getElementById('chatMic');
  const input = document.getElementById('chatInput');

  if (globalChatVoice) {
    globalChatVoice.stop();
    globalChatVoice = null;
    return;
  }

  globalChatVoice = new AutoSendVoice({
    silenceMs: threshold,
    onStart: () => {
      if (btn) { btn.classList.add('rec'); btn.innerHTML = '⏹ Arrêter'; }
    },
    onInterim: (text) => {
      if (input) input.value = text;
    },
    onResult: (text) => {
      if (input) input.value = text;
      globalChatVoice = null;
      if (btn) { btn.classList.remove('rec'); btn.innerHTML = '🎙 Dicter'; }
      // Envoi automatique
      setTimeout(() => {
        if (window.sendChat) window.sendChat();
      }, 100);
    },
    onStop: () => {
      globalChatVoice = null;
      if (btn) { btn.classList.remove('rec'); btn.innerHTML = '🎙 Dicter'; }
    }
  });

  globalChatVoice.start();
}

// ─── Paramètre silence dans les préférences ───────
function updateSilenceThreshold(ms) {
  MEM.VOICE.setSilenceThreshold(ms);
  if (globalChatVoice) globalChatVoice.updateSilenceThreshold(ms);
  speak(`Seuil de silence réglé à ${Math.round(ms/1000)} secondes.`);
}

window.AutoSendVoice = AutoSendVoice;
window.startAutoVoiceChat = startAutoVoiceChat;
window.updateSilenceThreshold = updateSilenceThreshold;
