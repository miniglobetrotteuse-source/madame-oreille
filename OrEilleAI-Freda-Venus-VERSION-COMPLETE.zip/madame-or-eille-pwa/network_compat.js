// ═══════════════════════════════════════════════════
//  COMPATIBILITÉ RÉSEAUX PAR PAYS — Or Eille AI v1.0
//  On est avec tout le monde — Benetton & MJ
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const NETCOMPAT = {
  // Statut des réseaux par pays
  COUNTRIES: {
    'Chine': { blocked: ['Instagram','Facebook','TikTok','YouTube','Twitter'], alternatives: ['WeChat','Weibo','Douyin','Bilibili','Xiaohongshu'] },
    'Iran': { blocked: ['Instagram','Facebook','Twitter','YouTube'], alternatives: ['Telegram','Aparat','Rubika'] },
    'Russie': { blocked: ['Instagram','Facebook'], alternatives: ['VK','OK.ru','Telegram'] },
    'Inde': { blocked: ['TikTok'], alternatives: ['Instagram Reels','YouTube Shorts','Moj','Josh'] },
    'Pakistan': { blocked: [], alternatives: [] },
    'Turquie': { blocked: [], alternatives: [] },
    'Ethiopie': { blocked: [], alternatives: [] },
    'France': { blocked: [], alternatives: [] },
    'Belgique': { blocked: [], alternatives: [] },
    'Senegal': { blocked: [], alternatives: [] },
    'default': { blocked: [], alternatives: [] }
  },

  GLOBAL_ALTERNATIVES: {
    'Instagram': ['Pinterest','Snapchat','BeReal'],
    'TikTok': ['Instagram Reels','YouTube Shorts','Kwai','Likee'],
    'YouTube': ['Dailymotion','Vimeo','Twitch'],
    'Facebook': ['Telegram','Signal','Discord'],
    'Twitter': ['Mastodon','Bluesky','Telegram'],
  },

  check(country) {
    const data = this.COUNTRIES[country] || this.COUNTRIES.default;
    if (data.blocked.length === 0) {
      if (window.addChatMsg) addChatMsg('assistant', '✅ Bonne nouvelle — tous les grands réseaux fonctionnent en ' + country + '. Instagram, TikTok, YouTube, Facebook — tout est accessible.');
      return;
    }
    let msg = '📡 En ' + country + ' :\n\n';
    msg += '🔴 Réseaux bloqués : ' + data.blocked.join(', ') + '\n\n';
    if (data.alternatives.length > 0) {
      msg += '✅ Alternatives locales : ' + data.alternatives.join(', ') + '\n\n';
    }
    msg += 'Or Eille AI adapte votre contenu pour ces plateformes. Même message. Même puissance. Audience différente.';
    if (window.addChatMsg) addChatMsg('assistant', msg);
  },

  renderPanel: function() {
    const countries = Object.keys(this.COUNTRIES).filter(function(c) { return c !== 'default'; });
    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🌐 Compatibilité réseaux par pays</div>' +
      '<p class="note">On est avec tout le monde. Quel que soit le pays — Or Eille AI trouve la solution.</p>' +
      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">TikTok bloqué en Inde ? Instagram inaccessible en Iran ? Or Eille AI vous dit quoi utiliser à la place. Toujours une solution. On est Benetton et Michael Jackson — avec tout le monde, partout.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +
      '<div style="display:flex;gap:.4rem">' +
        '<select id="nc-country" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.56rem;padding:.4rem;outline:none">' +
          countries.map(function(c) { return '<option>' + c + '</option>'; }).join('') +
        '</select>' +
        '<button onclick="NETCOMPAT.check(document.getElementById(\'nc-country\').value)" style="padding:.5rem .8rem;background:var(--gold);color:var(--dark);border:none;font-size:.5rem;cursor:pointer">Vérifier</button>' +
      '</div>' +
      '<div class="sec-title">Aperçu mondial</div>' +
      Object.entries(this.COUNTRIES).filter(function(e) { return e[0] !== 'default' && e[1].blocked.length > 0; }).map(function(e) {
        return '<div style="padding:.5rem;border:1px solid var(--border);margin-bottom:.3rem">' +
          '<div style="font-size:.54rem;color:var(--text)">' + e[0] + '</div>' +
          '<div style="font-size:.46rem;color:#ef5350">Bloqué : ' + e[1].blocked.join(', ') + '</div>' +
          '<div style="font-size:.46rem;color:#81c784">Alternative : ' + e[1].alternatives.join(', ') + '</div>' +
        '</div>';
      }).join('') +
    '</div>';
  }
};

window.NETCOMPAT = NETCOMPAT;
