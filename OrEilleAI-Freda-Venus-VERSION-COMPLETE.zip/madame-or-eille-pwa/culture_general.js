// ═══════════════════════════════════════════════════
//  CULTURE GÉNÉRALE — Or Eille AI v1.0
//  2 minutes par jour · toutes les civilisations
//  Sources sérieuses · même respect pour toutes
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const CULTURE_GEN = {
  KEY: 'moe_culture_gen',

  THEMES: {
    histoire:      { label:'Histoire',        icon:'📜' },
    sciences:      { label:'Sciences',        icon:'🔬' },
    arts:          { label:'Arts',            icon:'🎨' },
    philosophie:   { label:'Philosophie',     icon:'🧠' },
    geographie:    { label:'Geographie',      icon:'🌍' },
    mathematiques: { label:'Mathematiques',   icon:'🔢' },
    medecine:      { label:'Medecine',        icon:'⚕' },
    droits:        { label:'Droits',          icon:'⚖' },
  },

  CIVILIZATIONS: [
    'Empire du Mali','Egypte ancienne','Royaume du Kongo','Empire Songhai',
    'Zimbabwe ancien','Carthage','Royaumes Yoruba','Empire Ethiopien',
    'Civilisation Maya','Inca','Aztèque','Civilisation de l Indus',
    'Grèce antique','Rome antique','Perse ancienne','Empire Ottoman',
    'Chine impériale','Japon féodal','Inde ancienne',
    'Haïti — premiere revolution noire','Civilisation celtique',
    'Mesopotamie','Phenicie','Empire byzantin','Vikings',
  ],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      theme:'histoire', dayIndex:0, culture:'', sessions:0
    }; }
    catch { return { theme:'histoire', dayIndex:0, culture:'', sessions:0 }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async getLesson(claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const d = this.get();
    const theme = this.THEMES[d.theme];
    const civ = this.CIVILIZATIONS[d.dayIndex % this.CIVILIZATIONS.length];
    if (window.addChatMsg) addChatMsg('assistant', civ + ' — ' + (theme?theme.label:'') + '...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:500,
          messages:[{ role:'user', content:
            'Un fait fascinant sur ' + civ + ' dans le domaine ' + (theme?theme.label:'histoire') + '. ' +
            'Sources serieuses uniquement — universites, institutions de recherche. Si une info est debattue entre chercheurs, le dire honnêtement. ' +
            (d.culture ? 'Fais un lien avec la culture ' + d.culture + ' si pertinent. ' : '') +
            '2 minutes de lecture maximum. Un seul fait principal, bien explique. Accessible sans condescendance. ' +
            'Commence par quelque chose de surprenant. Termine par une question qui donne envie d en savoir plus.'
          }]
        })
      });
      const data = await r.json();
      d.sessions++; d.dayIndex++;
      this.save(d);
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  renderPanel: function() {
    const d = this.get();
    const civ = this.CIVILIZATIONS[d.dayIndex % this.CIVILIZATIONS.length];

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🌍 Culture générale</div>' +
      '<p class="note">2 minutes par jour. Une civilisation. Un fait fascinant. Toutes les cultures avec le même respect.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem">' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">La connaissance appartient à tout le monde. L histoire de toutes les civilisations mérite d être connue — pas seulement celle qu on a apprise à l école.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;font-style:italic">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
        Object.entries(this.THEMES).map(function(e) {
          var sel = d.theme === e[0];
          return '<button onclick="var d2=CULTURE_GEN.get();d2.theme=\'' + e[0] + '\';CULTURE_GEN.save(d2);document.getElementById(\'cultureGenContent\').innerHTML=CULTURE_GEN.renderPanel()" style="padding:.25rem .5rem;background:' + (sel?'rgba(196,153,58,.15)':'var(--dark-mid)') + ';border:1px solid ' + (sel?'var(--gold)':'var(--border)') + ';color:' + (sel?'var(--gold)':'var(--muted)') + ';font-family:Josefin Sans,sans-serif;font-size:.46rem;cursor:pointer">' + e[1].icon + ' ' + e[1].label + '</button>';
        }).join('') +
      '</div>' +

      '<input type="text" id="cg-culture" value="' + (d.culture||'') + '" placeholder="Ta culture — ex: Malien, Breton, Libanais..." onchange="var d2=CULTURE_GEN.get();d2.culture=this.value;CULTURE_GEN.save(d2)"/>' +

      '<div style="border:1px solid rgba(196,153,58,.2);padding:.8rem;background:rgba(196,153,58,.04)">' +
        '<div style="font-size:.44rem;color:var(--muted);margin-bottom:.3rem">Prochaine civilisation</div>' +
        '<div style="font-size:.6rem;color:var(--gold);font-family:Cormorant Garamond,serif;font-style:italic">' + civ + '</div>' +
        '<div style="font-size:.44rem;color:var(--muted);margin-top:.2rem">' + (this.THEMES[d.theme]?this.THEMES[d.theme].label:'') + '</div>' +
      '</div>' +

      '<button class="btn btn-gold" onclick="CULTURE_GEN.getLesson(window.CFG&&window.CFG.CLAUDE_KEY)">🌍 Ma culture du jour — 2 minutes</button>' +

      (d.sessions > 0 ? '<div style="font-size:.48rem;color:rgba(240,232,216,.3);text-align:center">' + d.sessions + ' session(s) — ' + d.dayIndex + ' civilisations explorées</div>' : '') +

    '</div>';
  }
};

window.CULTURE_GEN = CULTURE_GEN;
