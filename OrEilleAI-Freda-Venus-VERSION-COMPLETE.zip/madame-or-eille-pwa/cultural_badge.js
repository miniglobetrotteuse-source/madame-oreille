// ═══════════════════════════════════════════════════
//  PASTILLE CULTURELLE AUTOMATIQUE
//  Protection de la propriété culturelle
//  Or Eille AI — v1.0
// ═══════════════════════════════════════════════════

const CULTURAL_BADGE = {

  // ─── Détection d'éléments culturels ──────────
  CULTURAL_ELEMENTS: {
    kente: { culture: 'Ashanti, Ghana', description: 'Tissu royal Kente — tissu cérémoniel des rois Ashanti, chaque couleur et motif a une signification précise.', region: 'Afrique de l\'Ouest', searchQuery: 'artisans Kente Ghana Instagram' },
    bogolan: { culture: 'Mali', description: 'Bogolan / Bògòlanfini — tissu teint à la boue fermentée, chaque motif raconte une histoire.', region: 'Afrique de l\'Ouest', searchQuery: 'tisserands bogolan Mali' },
    ankara: { culture: 'Afrique de l\'Ouest', description: 'Tissu Ankara — wax africain aux motifs colorés, adopté à travers l\'Afrique.', region: 'Afrique', searchQuery: 'créateurs mode ankara africaine' },
    zellige: { culture: 'Maroc, Maghreb', description: 'Zellige — carrelage artisanal marocain taillé à la main, art islamique millénaire.', region: 'Afrique du Nord', searchQuery: 'artisans zellige Maroc' },
    batik: { culture: 'Indonésie, Afrique de l\'Ouest', description: 'Batik — technique de teinture à la cire, patrimoine mondial UNESCO.', region: 'Asie, Afrique', searchQuery: 'artisans batik traditionnel' },
    hamsa: { culture: 'Moyen-Orient, Maghreb', description: 'Hamsa / Main de Fatma — symbole de protection dans les cultures islamiques et juives.', region: 'Moyen-Orient, Maghreb', searchQuery: '' },
    totem: { culture: 'Peuples autochtones Amériques', description: 'Art totémique — symboles sacrés des peuples autochtones d\'Amérique du Nord.', region: 'Amériques', searchQuery: 'artistes autochtones amérindiens' },
    adinkra: { culture: 'Akan, Ghana', description: 'Symboles Adinkra — symboles visuels représentant des concepts et aphorismes Akan.', region: 'Afrique de l\'Ouest', searchQuery: 'artistes symboles adinkra' },
    henna: { culture: 'Inde, Moyen-Orient, Afrique du Nord', description: 'Henné / Mehndi — art corporel traditionnel aux significations rituelles et festives.', region: 'Inde, Moyen-Orient, Afrique', searchQuery: 'artistes mehndi henné traditionnel' },
    maori: { culture: 'Maori, Nouvelle-Zélande', description: 'Art Maori — motifs tā moko sacrés représentant l\'identité et la généalogie.', region: 'Océanie', searchQuery: 'artistes maori nouvelle-zelande' },
  },

  // Détecter les éléments culturels dans un prompt ou une image
  detectCulturalElements(text) {
    const detected = [];
    const t = text.toLowerCase();
    Object.entries(this.CULTURAL_ELEMENTS).forEach(([key, element]) => {
      if (t.includes(key)) detected.push({ key, ...element });
    });
    return detected;
  },

  // ─── Demande de liens personnels ──────────────
  askPersonalLinks(elements) {
    const names = elements.map(e => e.culture).join(', ');
    return `Cette création utilise des éléments de la culture ${names}.

Avez-vous des liens personnels avec cette communauté ? Si oui, partagez-les — nous les intégrerons à la pastille de reconnaissance culturelle.

Si vous ne partagez pas de liens, Or Eille AI ajoutera automatiquement des références vers des créateurs et artisans de cette culture.

La reconnaissance culturelle est non optionnelle sur Or Eille AI.`;
  },

  // ─── Générer la pastille ───────────────────────
  async generateBadge(elements, personalLinks, claudeKey) {
    let artistLinks = personalLinks || [];

    // Si pas de liens personnels — chercher automatiquement
    if (!personalLinks || personalLinks.length === 0) {
      for (const element of elements) {
        if (element.searchQuery && claudeKey) {
          try {
            const r = await fetch('https://api.anthropic.com/v1/messages', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
              body: JSON.stringify({
                model: 'claude-sonnet-4-20250514', max_tokens: 300,
                tools: [{ type: 'web_search_20250305', name: 'web_search' }],
                messages: [{ role: 'user', content: `Trouve 2-3 artisans ou créateurs de contenu actifs sur Instagram ou TikTok qui perpétuent la tradition "${element.culture}". Donne leurs handles Instagram/TikTok.` }]
              })
            });
            const d = await r.json();
            const text = d.content.filter(b => b.type === 'text').map(b => b.text).join('');
            artistLinks.push({ culture: element.culture, links: text });
          } catch {}
        }
      }
    }

    return {
      elements,
      personalLinks,
      artistLinks,
      addedBy: personalLinks?.length > 0 ? 'creator' : 'Or Eille AI automatique',
      generatedAt: new Date().toISOString(),
    };
  },

  // ─── Intégrer la pastille dans une image ──────
  applyBadgeToCanvas(canvas, badge) {
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;

    // Pastille en bas à droite — discrète mais visible
    const badgeSize = Math.round(W * 0.08);
    const padding = Math.round(W * 0.02);
    const x = W - badgeSize - padding;
    const y = H - badgeSize - padding;

    // Fond cercle doré
    ctx.beginPath();
    ctx.arc(x + badgeSize/2, y + badgeSize/2, badgeSize/2, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(201, 168, 76, 0.9)';
    ctx.fill();

    // Icône oreille stylisée
    ctx.fillStyle = '#1a1410';
    ctx.font = `bold ${Math.round(badgeSize * 0.5)}px serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('◎', x + badgeSize/2, y + badgeSize/2);

    // Encoder les métadonnées culturelles via watermark
    if (window.WATERMARK) {
      const metadata = `CULTURAL|${badge.elements.map(e => e.culture).join(',')}|${badge.addedBy}`;
      WATERMARK.encode(canvas, metadata);
    }

    return canvas;
  },

  // ─── Vérifier si pastille présente ────────────
  async verifyBadge(imageFile) {
    if (!window.WATERMARK) return null;
    const result = await WATERMARK.verify(imageFile);
    if (result && result.includes('CULTURAL|')) {
      const parts = result.split('|');
      return { cultures: parts[1], addedBy: parts[2] };
    }
    return null;
  },

  // ─── Message de blocage si tentative suppression
  SUPPRESSION_WARNING: `⚠ Tentative de suppression de la pastille culturelle détectée.

La reconnaissance culturelle est non optionnelle sur Or Eille AI.

Cette création utilise des éléments culturels qui ne vous appartiennent pas. La pastille protège les droits moraux des communautés concernées.

Vous pouvez :
✓ Conserver la pastille et publier
✗ Retirer la pastille — dans ce cas la création est supprimée et votre compte suspendu 2 semaines

En cas de récidive : suspension permanente sans remboursement.`,
};

window.CULTURAL_BADGE = CULTURAL_BADGE;

// Intercepter la génération pour détecter les éléments culturels
const _origBuildPrompt = window.buildPrompt;
if (_origBuildPrompt) {
  window.buildPrompt = function() {
    const prompt = _origBuildPrompt();
    const elements = CULTURAL_BADGE.detectCulturalElements(prompt);
    if (elements.length > 0 && window.addChatMsg) {
      const msg = CULTURAL_BADGE.askPersonalLinks(elements);
      addChatMsg('assistant', msg);
    }
    return prompt;
  };
}
