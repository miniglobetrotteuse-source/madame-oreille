// ═══════════════════════════════════════════════════
//  SUIVI REVENUS & ABONNEMENTS EN TEMPS RÉEL
//  Or Eille AI — v1.0
//  Pour TOUS les types de revenus récurrents
//  Abonnements, clients, loyers, commissions, etc.
// ═══════════════════════════════════════════════════

const REVENUE = {
  KEY: 'moe_revenue',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      revenueType: 'abonnements', // abonnements, clients, loyers, commissions, autre
      pricePerUnit: 18,
      currency: '€',
      period: 'mois',
      entries: [], // { date, count, amount, note, type: 'new'|'renewal'|'cancel' }
      goal: 0,
      startDate: new Date().toISOString(),
    }; } catch { return {}; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Ajouter une entrée ───────────────────────
  addEntry(type, count, amount, note) {
    const d = this.get();
    d.entries.push({
      id: Date.now().toString(),
      date: new Date().toISOString(),
      type, // 'new', 'renewal', 'cancel', 'payment'
      count: parseInt(count) || 1,
      amount: parseFloat(amount) || 0,
      note: note || ''
    });
    this.save(d);
    return this.getSummary();
  },

  // ─── Calculs ─────────────────────────────────
  getSummary() {
    const d = this.get();
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay());

    const allEntries = d.entries;
    const monthEntries = allEntries.filter(e => new Date(e.date) >= startOfMonth);
    const weekEntries = allEntries.filter(e => new Date(e.date) >= startOfWeek);

    // Compteurs actifs
    const totalNew = allEntries.filter(e => e.type === 'new').reduce((s, e) => s + e.count, 0);
    const totalCancel = allEntries.filter(e => e.type === 'cancel').reduce((s, e) => s + e.count, 0);
    const activeCount = Math.max(0, totalNew - totalCancel);

    // Revenus
    const monthRevenue = monthEntries.filter(e => e.type !== 'cancel').reduce((s, e) => s + e.amount, 0);
    const weekRevenue = weekEntries.filter(e => e.type !== 'cancel').reduce((s, e) => s + e.amount, 0);
    const totalRevenue = allEntries.filter(e => e.type !== 'cancel').reduce((s, e) => s + e.amount, 0);

    // Nouveaux ce mois
    const newThisMonth = monthEntries.filter(e => e.type === 'new').reduce((s, e) => s + e.count, 0);
    const renewalsThisMonth = monthEntries.filter(e => e.type === 'renewal').reduce((s, e) => s + e.count, 0);
    const cancelsThisMonth = monthEntries.filter(e => e.type === 'cancel').reduce((s, e) => s + e.count, 0);

    // Taux de rétention
    const retentionRate = activeCount > 0 ? Math.round(((activeCount - cancelsThisMonth) / activeCount) * 100) : 100;

    // Revenu par heure (basé sur mois = 730h)
    const revenuePerHour = ((activeCount * d.pricePerUnit) / 730).toFixed(2);

    // Projection
    const daysSinceStart = Math.max(1, Math.round((now - new Date(d.startDate)) / (1000 * 60 * 60 * 24)));
    const growthRate = totalNew / daysSinceStart; // nouveaux par jour
    const daysToGoal = d.goal > activeCount ? Math.round((d.goal - activeCount) / Math.max(growthRate, 0.1)) : 0;

    return {
      activeCount,
      monthRevenue,
      weekRevenue,
      totalRevenue,
      newThisMonth,
      renewalsThisMonth,
      cancelsThisMonth,
      retentionRate,
      revenuePerHour,
      daysToGoal,
      pricePerUnit: d.pricePerUnit,
      currency: d.currency,
      period: d.period,
      goal: d.goal,
      revenueType: d.revenueType,
    };
  },

  // ─── Résumé vocal ─────────────────────────────
  getSpeechSummary() {
    const s = this.getSummary();
    const typeLabel = {
      abonnements: 'abonnés actifs',
      clients: 'clients actifs',
      loyers: 'locataires',
      commissions: 'contrats actifs',
      autre: 'entrées actives'
    }[s.revenueType] || 'actifs';

    return `Vous avez actuellement ${s.activeCount} ${typeLabel}. 
Ce mois-ci : ${s.monthRevenue.toFixed(0)}${s.currency}. 
${s.newThisMonth} nouveaux, ${s.renewalsThisMonth} renouvellements, ${s.cancelsThisMonth} résiliations. 
Taux de fidélité : ${s.retentionRate}%.
En ce moment vous générez ${s.revenuePerHour}${s.currency} par heure.
${s.goal > s.activeCount ? `Objectif ${s.goal} ${typeLabel} dans environ ${s.daysToGoal} jours.` : s.goal > 0 ? 'Objectif atteint !' : ''}`;
  },

  // ─── Interface principale ─────────────────────
  renderPanel() {
    const d = this.get();
    const s = this.getSummary();
    const typeLabel = {
      abonnements: 'abonnés', clients: 'clients',
      loyers: 'locataires', commissions: 'contrats', autre: 'entrées'
    }[s.revenueType] || 'actifs';

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <!-- COMPTEUR LIVE -->
      <div style="background:linear-gradient(135deg,#1a1610,#2c2318);border:1px solid var(--gold);padding:1.2rem;text-align:center">
        <div style="font-size:3rem;font-weight:200;color:var(--gold);font-family:'Josefin Sans',sans-serif;line-height:1" id="liveCount">${s.activeCount}</div>
        <div style="font-size:.55rem;color:var(--muted);letter-spacing:.15em;text-transform:uppercase;margin-top:.3rem">${typeLabel} actifs</div>
        <div style="font-size:1.2rem;color:#E8C870;margin-top:.5rem;font-family:'Josefin Sans',sans-serif">${s.monthRevenue.toFixed(0)} ${s.currency}</div>
        <div style="font-size:.5rem;color:var(--muted);letter-spacing:.1em">ce mois-ci</div>
        <div style="margin-top:.8rem;padding:.5rem;background:rgba(196,153,58,.1);border:1px solid rgba(196,153,58,.2)">
          <div style="font-size:.6rem;color:var(--gold)">En ce moment</div>
          <div style="font-size:1rem;color:#fff;font-family:'Josefin Sans',sans-serif">${s.revenuePerHour} ${s.currency}/heure</div>
        </div>
      </div>

      <!-- STATS RAPIDES -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">
        <div style="background:var(--dark-mid);border:1px solid var(--border);padding:.6rem;text-align:center">
          <div style="font-size:1.1rem;color:#4fc3f7;font-family:'Josefin Sans',sans-serif">+${s.newThisMonth}</div>
          <div style="font-size:.48rem;color:var(--muted);text-transform:uppercase;letter-spacing:.1em">nouveaux ce mois</div>
        </div>
        <div style="background:var(--dark-mid);border:1px solid var(--border);padding:.6rem;text-align:center">
          <div style="font-size:1.1rem;color:#81c784;font-family:'Josefin Sans',sans-serif">${s.retentionRate}%</div>
          <div style="font-size:.48rem;color:var(--muted);text-transform:uppercase;letter-spacing:.1em">fidélité</div>
        </div>
        <div style="background:var(--dark-mid);border:1px solid var(--border);padding:.6rem;text-align:center">
          <div style="font-size:1.1rem;color:var(--gold);font-family:'Josefin Sans',sans-serif">${s.weekRevenue.toFixed(0)} ${s.currency}</div>
          <div style="font-size:.48rem;color:var(--muted);text-transform:uppercase;letter-spacing:.1em">cette semaine</div>
        </div>
        <div style="background:var(--dark-mid);border:1px solid var(--border);padding:.6rem;text-align:center">
          <div style="font-size:1.1rem;color:#ce93d8;font-family:'Josefin Sans',sans-serif">${s.totalRevenue.toFixed(0)} ${s.currency}</div>
          <div style="font-size:.48rem;color:var(--muted);text-transform:uppercase;letter-spacing:.1em">total cumulé</div>
        </div>
      </div>

      ${s.goal > 0 ? `
      <!-- PROGRESSION OBJECTIF -->
      <div style="background:var(--dark-mid);border:1px solid var(--border);padding:.7rem">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.4rem">
          <span style="font-size:.55rem;color:var(--muted)">Objectif : ${s.goal} ${typeLabel}</span>
          <span style="font-size:.55rem;color:var(--gold)">${Math.round((s.activeCount/s.goal)*100)}%</span>
        </div>
        <div style="background:#333;height:6px;border-radius:3px">
          <div style="background:var(--gold);height:6px;border-radius:3px;width:${Math.min(100,(s.activeCount/s.goal)*100)}%"></div>
        </div>
        ${s.daysToGoal > 0 ? `<div style="font-size:.48rem;color:var(--muted);margin-top:.3rem">Objectif atteint dans ~${s.daysToGoal} jours à ce rythme</div>` : '<div style="font-size:.48rem;color:#81c784;margin-top:.3rem">✓ Objectif atteint !</div>'}
      </div>` : ''}

      <!-- AJOUTER UNE ENTRÉE -->
      <div class="sep"></div>
      <div class="sec-title">Enregistrer</div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">
        <button onclick="REVENUE.quickAdd('new')" style="padding:.7rem;background:rgba(79,195,247,.15);border:1px solid rgba(79,195,247,.4);color:#4fc3f7;font-family:'Josefin Sans',sans-serif;font-size:.55rem;letter-spacing:.1em;cursor:pointer">
          + Nouveau ${typeLabel.slice(0,-1)}
        </button>
        <button onclick="REVENUE.quickAdd('renewal')" style="padding:.7rem;background:rgba(129,199,132,.15);border:1px solid rgba(129,199,132,.4);color:#81c784;font-family:'Josefin Sans',sans-serif;font-size:.55rem;letter-spacing:.1em;cursor:pointer">
          ↻ Renouvellement
        </button>
        <button onclick="REVENUE.quickAdd('cancel')" style="padding:.7rem;background:rgba(239,83,80,.1);border:1px solid rgba(239,83,80,.3);color:#ef5350;font-family:'Josefin Sans',sans-serif;font-size:.55rem;letter-spacing:.1em;cursor:pointer">
          − Résiliation
        </button>
        <button onclick="REVENUE.quickAdd('payment')" style="padding:.7rem;background:rgba(196,153,58,.15);border:1px solid rgba(196,153,58,.4);color:var(--gold);font-family:'Josefin Sans',sans-serif;font-size:.55rem;letter-spacing:.1em;cursor:pointer">
          € Paiement reçu
        </button>
      </div>

      <button class="voice-btn" onclick="REVENUE.voiceEntry()">🎙 Dicter une entrée</button>
      <button class="btn btn-ghost" onclick="REVENUE.speak()">📢 Résumé vocal</button>

      <!-- PARAMÈTRES -->
      <div class="sep"></div>
      <div class="sec-title">Paramètres</div>
      <div style="display:flex;gap:.4rem;align-items:center">
        <span style="font-size:.56rem;color:var(--muted);min-width:5rem">Type de revenu</span>
        <select onchange="REVENUE.setType(this.value)" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.56rem;padding:.4rem;outline:none">
          <option value="abonnements" ${d.revenueType==='abonnements'?'selected':''}>Abonnements</option>
          <option value="clients" ${d.revenueType==='clients'?'selected':''}>Clients (coiffure, soins...)</option>
          <option value="loyers" ${d.revenueType==='loyers'?'selected':''}>Loyers</option>
          <option value="commissions" ${d.revenueType==='commissions'?'selected':''}>Commissions</option>
          <option value="autre" ${d.revenueType==='autre'?'selected':''}>Autre</option>
        </select>
      </div>
      <div style="display:flex;gap:.4rem;align-items:center">
        <span style="font-size:.56rem;color:var(--muted);min-width:5rem">Prix unitaire</span>
        <input type="number" value="${d.pricePerUnit}" onchange="REVENUE.setPrice(this.value)" style="flex:1"/>
        <select onchange="REVENUE.setCurrency(this.value)" style="background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.56rem;padding:.4rem;outline:none">
          <option value="€" ${d.currency==='€'?'selected':''}>€</option>
          <option value="CHF" ${d.currency==='CHF'?'selected':''}>CHF</option>
          <option value="$" ${d.currency==='$'?'selected':''}>$</option>
          <option value="FCFA" ${d.currency==='FCFA'?'selected':''}>FCFA</option>
        </select>
      </div>
      <div style="display:flex;gap:.4rem;align-items:center">
        <span style="font-size:.56rem;color:var(--muted);min-width:5rem">Objectif</span>
        <input type="number" placeholder="ex: 500 abonnés" value="${d.goal||''}" onchange="REVENUE.setGoal(this.value)" style="flex:1"/>
      </div>
    </div>`;
  },

  quickAdd(type) {
    const d = this.get();
    const labels = { new: 'Combien de nouveaux ?', renewal: 'Combien de renouvellements ?', cancel: 'Combien de résiliations ?', payment: 'Montant reçu ?' };
    const val = prompt(labels[type] || 'Valeur ?');
    if (!val) return;
    const count = type === 'payment' ? 1 : parseInt(val);
    const amount = type === 'payment' ? parseFloat(val) : (type === 'cancel' ? 0 : count * d.pricePerUnit);
    this.addEntry(type, count, amount, '');
    document.getElementById('revenueContent').innerHTML = this.renderPanel();
    if (window.addChatMsg) {
      const s = this.getSummary();
      addChatMsg('assistant', `✓ Enregistré. Total actif : ${s.activeCount}. Ce mois : ${s.monthRevenue.toFixed(0)}${s.currency}.`);
    }
  },

  voiceEntry() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;
    const r = new SR(); r.lang = 'fr-FR'; r.continuous = false;
    r.onresult = e => {
      const txt = e.results[0][0].transcript.toLowerCase();
      const d = this.get();
      let type = 'payment', count = 1, amount = 0;
      if (txt.includes('nouveau') || txt.includes('nouvelle')) type = 'new';
      else if (txt.includes('renouvellement') || txt.includes('reconduit')) type = 'renewal';
      else if (txt.includes('résili') || txt.includes('annulé') || txt.includes('parti')) type = 'cancel';
      const nums = txt.match(/\d+/g);
      if (nums) { count = parseInt(nums[0]); amount = type === 'payment' ? count : count * d.pricePerUnit; count = type === 'payment' ? 1 : count; }
      this.addEntry(type, count, amount, txt);
      document.getElementById('revenueContent').innerHTML = this.renderPanel();
      if (window.addChatMsg) addChatMsg('assistant', `✓ Compris : "${txt}". Enregistré.`);
    };
    r.start();
    if (window.addChatMsg) addChatMsg('assistant', '🎙 Dites ce que vous voulez enregistrer — "5 nouveaux abonnés", "3 résiliations", "paiement 54 euros"...');
  },

  speak() {
    const msg = this.getSpeechSummary();
    if (window.speak) speak(msg);
    if (window.addChatMsg) addChatMsg('assistant', msg);
  },

  setType(v) { const d = this.get(); d.revenueType = v; this.save(d); document.getElementById('revenueContent').innerHTML = this.renderPanel(); },
  setPrice(v) { const d = this.get(); d.pricePerUnit = parseFloat(v)||18; this.save(d); },
  setCurrency(v) { const d = this.get(); d.currency = v; this.save(d); },
  setGoal(v) { const d = this.get(); d.goal = parseInt(v)||0; this.save(d); document.getElementById('revenueContent').innerHTML = this.renderPanel(); },

  // Rafraîchir le compteur live toutes les minutes
  startLiveCounter() {
    setInterval(() => {
      const el = document.getElementById('liveCount');
      if (el) { const s = this.getSummary(); el.textContent = s.activeCount; }
    }, 60000);
  }
};

window.REVENUE = REVENUE;
window.addEventListener('load', () => setTimeout(() => REVENUE.startLiveCounter(), 2000));
