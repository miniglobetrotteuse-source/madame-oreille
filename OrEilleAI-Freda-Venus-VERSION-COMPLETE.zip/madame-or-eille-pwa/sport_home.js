// ═══════════════════════════════════════════════════
//  SPORT À LA MAISON — Or Eille AI v1.0
//  Réaliste · ludique · adapté à ta vraie vie
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const SPORT = {
  KEY: 'moe_sport',

  CONTEXTS: {
    appart_voisins: 'Appartement — voisins en dessous',
    appart_libre:   'Appartement — pas de voisins en dessous',
    maison:         'Maison ou rez-de-chaussée',
    exterieur:      'Accès à un extérieur',
  },

  TIMES: {
    matin:  'Matin avant 9h',
    jour:   'Dans la journée',
    soir:   'Soir après 20h',
    nuit:   'Nuit après 22h',
  },

  DURATIONS: {
    min5:  '5 minutes — j ai juste ca',
    min10: '10 minutes',
    min20: '20 minutes',
    min30: '30 minutes et plus',
  },

  GOALS: {
    energie:  'Me donner de l energie',
    calme:    'Me calmer et decompresser',
    force:    'Gagner en force',
    souplesse:'Gagner en souplesse',
    cardio:   'Faire du cardio',
    fun:      'M amuser en bougeant',
  },

  // Exercices silencieux — appartement avec voisins
  SILENT_EXERCISES: [
    { name:'Gainage planche', duration:'30 secondes x 3', note:'Position tenue — zéro bruit. Le ventre et le dos travaillent vraiment.' },
    { name:'Squats lents', duration:'15 repetitions x 3', note:'Descendre en 3 secondes. Remonter en 3 secondes. Les cuisses brûlent. Pas un bruit.' },
    { name:'Pompes', duration:'10 repetitions x 3', note:'Au sol. Silencieux. Efficace pour les bras, la poitrine et le dos.' },
    { name:'Abdos bicycle', duration:'20 repetitions x 3', note:'Au sol. Coudes aux genoux en alternance. Zéro bruit.' },
    { name:'Fentes statiques', duration:'12 par jambe x 3', note:'Sur place. Pas de saut. Les jambes et les fesses travaillent.' },
    { name:'Yoga flow', duration:'10 minutes', note:'Chien tête en bas, cobra, guerrier. Souplesse et force. Silence total.' },
    { name:'Pilates', duration:'15 minutes', note:'Exercices au sol. Contrôle du souffle. Renforcement profond.' },
    { name:'Étirements profonds', duration:'10 minutes', note:'Récupération et souplesse. Parfait le soir avant de dormir.' },
  ],

  // Exercices libres — pas de contrainte de bruit
  FREE_EXERCISES: [
    { name:'Corde à sauter', duration:'3 minutes x 5', note:'Un des meilleurs cardios. Efficace en 15 minutes.' },
    { name:'Danse cardio', duration:'20 minutes', note:'Afrobeats, dancehall, zumba — tu choisis ta musique. Cardio intense et fun.' },
    { name:'HIIT', duration:'20 minutes', note:'30 secondes effort, 30 secondes repos. Brûle vraiment.' },
    { name:'Boxe shadow', duration:'15 minutes', note:'On imagine un adversaire. Cardio et coordination. Fun.' },
    { name:'Kata karaté seul', duration:'15 minutes', note:'Séquences de mouvements. Corps, concentration, discipline. Parfait seul.' },
  ],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      context: 'appart_voisins', goal: 'energie', duration: 'min10', time: 'soir'
    }; }
    catch { return { context:'appart_voisins', goal:'energie', duration:'min10', time:'soir' }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  isSilentRequired() {
    const d = this.get();
    return d.context === 'appart_voisins' && (d.time === 'soir' || d.time === 'nuit');
  },

  async getSession(claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const d = this.get();
    const silent = this.isSilentRequired();
    const goal = this.GOALS[d.goal] || '';
    const duration = this.DURATIONS[d.duration] || '10 minutes';
    const context = this.CONTEXTS[d.context] || '';

    if (window.addChatMsg) addChatMsg('assistant', 'Preparation de ta session sport' + (silent ? ' — mode silencieux' : '') + '...');

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:700,
          messages:[{ role:'user', content:
            'Cree une seance de sport a la maison pour ' + duration + '. Contexte : ' + context + '. Objectif : ' + goal + (silent ? '. SILENCIEUX OBLIGATOIRE - pas de sauts, pas de course, pas de bruit pour les voisins.' : '') + '. Exercices realistes et ludiques. Instructions claires. Encourage sans culpabiliser. Termine par une note bienveillante.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  renderPanel: function() {
    const d = this.get();
    const silent = this.isSilentRequired();

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">💪 Sport à la maison</div>' +
      '<p class="note">Sans salle. Sans matériel. Adapté à ton espace, tes voisins et ton heure. Réaliste et ludique.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem">' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">Bouger c est pas une punition. C est reprendre possession de son corps. A ton rythme. Dans ton espace.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;font-style:italic">— Madame Or Eille Studios</p>' +
      '</div>' +

      (silent ? '<div style="background:rgba(107,163,214,.08);border:1px solid rgba(107,163,214,.3);padding:.5rem;font-size:.5rem;color:#6BA3D6">🤫 Mode silencieux activé — exercices sans impact pour ne pas déranger les voisins</div>' : '') +

      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">' +

        '<div><span class="klabel">Mon espace</span>' +
        '<select id="sport-context" onchange="const d2=SPORT.get();d2.context=this.value;SPORT.save(d2);document.getElementById(\'sportContent\').innerHTML=SPORT.renderPanel()" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.CONTEXTS).map(function(e) { return '<option value="'+e[0]+'" '+(d.context===e[0]?'selected':'')+'>'+e[1]+'</option>'; }).join('') +
        '</select></div>' +

        '<div><span class="klabel">Heure</span>' +
        '<select id="sport-time" onchange="const d2=SPORT.get();d2.time=this.value;SPORT.save(d2);document.getElementById(\'sportContent\').innerHTML=SPORT.renderPanel()" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.TIMES).map(function(e) { return '<option value="'+e[0]+'" '+(d.time===e[0]?'selected':'')+'>'+e[1]+'</option>'; }).join('') +
        '</select></div>' +

        '<div><span class="klabel">Durée</span>' +
        '<select id="sport-dur" onchange="const d2=SPORT.get();d2.duration=this.value;SPORT.save(d2)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.DURATIONS).map(function(e) { return '<option value="'+e[0]+'" '+(d.duration===e[0]?'selected':'')+'>'+e[1]+'</option>'; }).join('') +
        '</select></div>' +

        '<div><span class="klabel">Objectif</span>' +
        '<select id="sport-goal" onchange="const d2=SPORT.get();d2.goal=this.value;SPORT.save(d2)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.GOALS).map(function(e) { return '<option value="'+e[0]+'" '+(d.goal===e[0]?'selected':'')+'>'+e[1]+'</option>'; }).join('') +
        '</select></div>' +

      '</div>' +

      '<button class="btn btn-gold" onclick="SPORT.getSession(window.CFG&&window.CFG.CLAUDE_KEY)">💪 Ma séance du jour</button>' +

      '<div class="sec-title">Exercices ' + (silent ? 'silencieux' : 'disponibles') + '</div>' +
      (silent ? this.SILENT_EXERCISES : this.FREE_EXERCISES.concat(this.SILENT_EXERCISES)).slice(0,5).map(function(ex) {
        return '<div style="padding:.5rem;border:1px solid var(--border);margin-bottom:.3rem">' +
          '<div style="font-size:.56rem;color:var(--text);font-weight:400">' + ex.name + ' — <span style="color:var(--gold)">' + ex.duration + '</span></div>' +
          '<div style="font-size:.44rem;color:var(--muted);margin-top:.15rem">' + ex.note + '</div>' +
        '</div>';
      }).join('') +

    '</div>';
  }
};

window.SPORT = SPORT;
