// ═══════════════════════════════════════════════════
//  MBOKA NA BISO — Notre Village
//  Protection communautaire — Or Eille AI v1.0
//  Filtrage haine, archivage preuves, droit de plainte
// ═══════════════════════════════════════════════════

const MBOKA = {
  KEY: 'moe_mboka',

  HATE_PATTERNS: [
    /\b(crève|va mourir|je vais te tuer|on va te trouver|tes enfants|ta famille|je sais où tu habites)\b/i,
    /\b(sale\s+(noir|noire|arabe|bougnoule|négresse|nègre|chinetoque|juif|juive))\b/i,
    /\b(retourne dans ton pays|rentre chez toi)\b/i,
    /\b(viol|je vais te violer|t'encul)\b/i,
    /\b(suicide|tue-toi|pendez-vous)\b/i,
  ],

  CONSTRUCTIVE_PATTERNS: [
    /\b(information incorrecte|erreur|inexact|faux|vérifier|source)\b/i,
    /\b(je ne suis pas d'accord|je pense que|selon moi|à mon avis)\b/i,
    /\b(améliorer|suggestion|conseil|peut-être)\b/i,
  ],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      active: false, platforms: [],
      filtered: [], archived: [], reports: [],
      weeklyStats: { filtered: 0, archived: 0, legitimate: 0 },
      lastWeekReset: new Date().toISOString()
    }; } catch { return { active: false, platforms: [], filtered: [], archived: [], reports: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Analyser un commentaire ──────────────────
  analyzeComment(comment, author) {
    const text = comment.toLowerCase();

    // Vérifier si c'est de la haine pure
    const isHate = this.HATE_PATTERNS.some(p => p.test(text));

    // Vérifier si c'est une critique constructive
    const isConstructive = this.CONSTRUCTIVE_PATTERNS.some(p => p.test(text));

    // Détecter les menaces graves
    const isThreatenening = /\b(tuer|violer|trouver|enfants|famille|adresse|je sais)\b/i.test(text);

    if (isThreatenening) return { action: 'archive_threat', severity: 'critical' };
    if (isHate && !isConstructive) return { action: 'filter', severity: 'high' };
    if (isHate && isConstructive) return { action: 'flag', severity: 'medium' };
    return { action: 'allow', severity: 'none' };
  },

  // ─── Analyser une vague de signalements ───────
  analyzeReportWave(reportCount, timeframeHours, totalFollowers) {
    const reportRate = reportCount / Math.max(totalFollowers, 1);
    const isCoordinated = reportCount > 1000 && timeframeHours < 24;
    const isLegitimate = reportRate > 0.05 && !isCoordinated; // Plus de 5% de la communauté

    if (isCoordinated && reportRate < 0.01) {
      return {
        type: 'coordinated_attack',
        message: `⚠ Attaque coordonnée détectée — ${reportCount} signalements en ${timeframeHours}h représentent moins de 1% de votre communauté. Ceci ressemble à une campagne organisée.`,
        action: 'defend',
        prepareEvidence: true
      };
    }

    if (isLegitimate) {
      return {
        type: 'legitimate_concern',
        message: `${reportCount} signalements de votre communauté — ${Math.round(reportRate * 100)}% de vos abonnés. Votre communauté vous envoie un signal. Prenez le temps d'examiner ce contenu.`,
        action: 'review',
        prepareEvidence: false
      };
    }

    return { type: 'normal', action: 'monitor' };
  },

  // ─── Archiver une preuve ──────────────────────
  archiveEvidence(content, author, type) {
    const d = this.get();
    const evidence = {
      id: Date.now().toString(),
      content,
      author,
      type, // 'threat', 'hate', 'harassment', 'coordinated'
      archivedAt: new Date().toISOString(),
      hash: this.simpleHash(content + author + Date.now()),
      legalNote: 'Archivé automatiquement par Or Eille AI comme preuve potentielle. Horodatage: ' + new Date().toISOString()
    };
    d.archived.push(evidence);
    d.archived = d.archived.slice(-500); // Garder 500 preuves max
    this.save(d);
    return evidence;
  },

  // ─── Hash simple pour intégrité ───────────────
  simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash).toString(16);
  },

  // ─── Générer un dossier de plainte ────────────
  generateComplaintFile() {
    const d = this.get();
    const threats = d.archived.filter(a => a.type === 'threat');
    if (!threats.length) return 'Aucune menace archivée.';

    let doc = `DOSSIER DE PREUVES — Or Eille AI\n`;
    doc += `Généré le : ${new Date().toLocaleDateString('fr-FR')}\n`;
    doc += `═══════════════════════════════════\n\n`;
    doc += `Ce dossier contient ${threats.length} menace(s) archivée(s) automatiquement.\n`;
    doc += `Chaque entrée est horodatée et hashée pour garantir son intégrité.\n\n`;

    threats.forEach((t, i) => {
      doc += `MENACE ${i+1}\n`;
      doc += `Date : ${new Date(t.archivedAt).toLocaleString('fr-FR')}\n`;
      doc += `Auteur : ${t.author}\n`;
      doc += `Contenu : ${t.content}\n`;
      doc += `Hash d'intégrité : ${t.hash}\n`;
      doc += `─────────────────\n\n`;
    });

    doc += `DÉMARCHES RECOMMANDÉES :\n`;
    doc += `1. Signaler à la plateforme concernée\n`;
    doc += `2. Déposer une plainte auprès de la police ou gendarmerie\n`;
    doc += `3. Contacter une association spécialisée cyberharcèlement\n`;
    doc += `   - France Victimes : 116 006\n`;
    doc += `   - Cybermalveillance.gouv.fr\n`;
    doc += `   - Association Point de Contact : pointdecontact.net\n`;

    return doc;
  },

  // ─── Rapport hebdomadaire ─────────────────────
  generateWeeklyReport() {
    const d = this.get();
    const now = new Date();
    const weekStart = new Date(d.lastWeekReset);
    const daysSince = Math.round((now - weekStart) / 86400000);

    const report = {
      period: `${weekStart.toLocaleDateString('fr-FR')} — ${now.toLocaleDateString('fr-FR')}`,
      filtered: d.weeklyStats.filtered,
      archived: d.weeklyStats.archived,
      legitimate: d.weeklyStats.legitimate,
      threats: d.archived.filter(a => new Date(a.archivedAt) > weekStart && a.type === 'threat').length
    };

    let msg = `🛡 RAPPORT MBOKA NA BISO — ${report.period}\n\n`;
    msg += `✅ ${report.filtered} commentaires haineux filtrés — vous ne les avez jamais vus\n`;
    msg += `📁 ${report.archived} preuves archivées\n`;
    msg += `💬 ${report.legitimate} critiques constructives laissées passer\n`;
    if (report.threats > 0) {
      msg += `⚠ ${report.threats} menace(s) grave(s) archivée(s) — dossier de plainte disponible\n`;
    }
    msg += `\nVotre village est protégé. Créez en paix.`;

    // Réinitialiser les stats hebdomadaires
    d.weeklyStats = { filtered: 0, archived: 0, legitimate: 0 };
    d.lastWeekReset = now.toISOString();
    this.save(d);

    if (window.addChatMsg) addChatMsg('assistant', msg);
    return report;
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    const threatCount = d.archived.filter(a => a.type === 'threat').length;

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div style="text-align:center;padding:1rem;background:linear-gradient(135deg,#1a1610,#2c2318);border:1px solid var(--gold)">
        <div style="font-size:1.5rem;margin-bottom:.3rem">🛡</div>
        <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.2rem">Mboka na biso</h3>
        <p style="font-size:.52rem;color:var(--muted)">Notre Village — Votre espace protégé</p>
        <div style="margin-top:.6rem;display:flex;justify-content:center;gap:.4rem;align-items:center">
          <div style="width:8px;height:8px;border-radius:50%;background:${d.active?'#81c784':'#666'}"></div>
          <span style="font-size:.52rem;color:${d.active?'#81c784':'var(--muted)'}">${d.active?'Protection active':'Protection inactive'}</span>
        </div>
      </div>

      <button onclick="MBOKA.toggle()" class="btn ${d.active?'btn-ghost':'btn-gold'}" style="${d.active?'border-color:#ef5350;color:#ef5350':''}">
        ${d.active?'⏹ Désactiver la protection':'🛡 Activer Mboka na biso'}
      </button>

      <div class="sec-title">Ce que Mboka na biso fait</div>
      <div style="font-size:.54rem;color:var(--muted);line-height:1.8">
        ✅ Filtre la haine, les menaces, les insultes<br/>
        ✅ Laisse passer les critiques constructives<br/>
        ✅ Archive les menaces graves comme preuves<br/>
        ✅ Détecte les campagnes de harcèlement coordonnées<br/>
        ✅ Génère un rapport hebdomadaire<br/>
        ✅ Prépare les dossiers de plainte<br/>
        ✅ Or Eille AI se réserve le droit de porter plainte
      </div>

      <div class="sep"></div>
      <div class="sec-title">Statistiques</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">
        <div style="background:var(--dark-mid);border:1px solid var(--border);padding:.6rem;text-align:center">
          <div style="font-size:1.2rem;color:#81c784">${d.filtered?.length || 0}</div>
          <div style="font-size:.46rem;color:var(--muted)">Commentaires filtrés</div>
        </div>
        <div style="background:var(--dark-mid);border:1px solid var(--border);padding:.6rem;text-align:center">
          <div style="font-size:1.2rem;color:${threatCount>0?'#ef5350':'#81c784'}">${threatCount}</div>
          <div style="font-size:.46rem;color:var(--muted)">Menaces archivées</div>
        </div>
      </div>

      ${threatCount > 0 ? `
      <div style="background:rgba(239,83,80,.08);border:1px solid rgba(239,83,80,.3);padding:.7rem">
        <div style="font-size:.55rem;color:#ef5350;margin-bottom:.4rem">⚠ ${threatCount} menace(s) archivée(s)</div>
        <p style="font-size:.5rem;color:var(--muted);line-height:1.6;margin-bottom:.4rem">Ces menaces sont conservées comme preuves horodatées. Vous pouvez les utiliser pour porter plainte.</p>
        <button onclick="if(window.addChatMsg)addChatMsg('assistant',MBOKA.generateComplaintFile())" class="btn btn-ghost" style="border-color:#ef5350;color:#ef5350;font-size:.5rem">
          📁 Générer le dossier de plainte
        </button>
      </div>` : ''}

      <div style="display:flex;gap:.4rem">
        <button class="btn btn-ghost" style="flex:1" onclick="MBOKA.generateWeeklyReport()">📊 Rapport hebdomadaire</button>
        <button class="btn btn-ghost" style="flex:1" onclick="MBOKA.testComment()">🧪 Tester un commentaire</button>
      </div>

      <div class="sep"></div>
      <div style="font-size:.48rem;color:var(--muted);line-height:1.7;padding:.5rem;border:1px solid var(--border)">
        <strong style="color:var(--text)">Note légale</strong><br/>
        Or Eille AI se réserve le droit de signaler aux autorités compétentes tout usage de la plateforme à des fins de harcèlement ou de menace. Les preuves archivées peuvent être transmises sur réquisition judiciaire.
      </div>
    </div>`;
  },

  toggle() {
    const d = this.get();
    d.active = !d.active;
    this.save(d);
    document.getElementById('mbokaContent').innerHTML = this.renderPanel();
    if (window.addChatMsg) {
      if (d.active) {
        addChatMsg('assistant', '🛡 Mboka na biso activé. Votre village est protégé. Créez en paix.');
        if (window.speak) speak('Mboka na biso activé. Votre village est protégé.');
      } else {
        addChatMsg('assistant', '⏹ Protection désactivée.');
      }
    }
  },

  testComment() {
    const comment = prompt('Entrez un commentaire à tester :');
    if (!comment) return;
    const result = this.analyzeComment(comment, 'test');
    const messages = {
      allow: '✅ Ce commentaire passe — critique constructive ou neutre.',
      flag: '🟡 Ce commentaire est ambigu — contient des éléments haineux ET constructifs. Il sera signalé pour révision.',
      filter: '🔴 Ce commentaire serait filtré — haine détectée. Vous ne le verriez jamais.',
      archive_threat: '🚨 MENACE GRAVE détectée — ce commentaire serait archivé comme preuve et signalé aux autorités.'
    };
    if (window.addChatMsg) addChatMsg('assistant', messages[result.action] || 'Résultat inconnu.');
  }
};

window.MBOKA = MBOKA;
