// ═══════════════════════════════════════════════════
//  FICHE MÉDICALE D'URGENCE + TRADUCTEUR ORAL
//  Or Eille AI — v1.0
//  Accessible par 4 tapes sur l'écran verrouillé
// ═══════════════════════════════════════════════════

const MEDICAL = {
  KEY: 'moe_medical',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      name: '', age: '', bloodType: '', conditions: [], medications: [],
      allergies: [], emergencyContacts: [], doctor: {}, languages: ['fr','en'],
      isPregnant: false, hasPacemaker: false, isAnticoagulant: false
    }; } catch { return {}; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Questions d'urgence pré-enregistrées ─────
  EMERGENCY_QUESTIONS: {
    fr: [
      "Madame, Monsieur, m'entendez-vous ?",
      "Quel est votre prénom ?",
      "Quel âge avez-vous ?",
      "Où avez-vous mal ?",
      "Avez-vous une maladie chronique ?",
      "Avez-vous un traitement médical en cours ?",
      "Êtes-vous allergique à quelque chose ?",
      "Avez-vous de l'insuline sur vous ?",
      "Êtes-vous enceinte ?",
      "Avez-vous un pacemaker ?",
      "Êtes-vous sous anticoagulants ?",
      "Avez-vous mangé aujourd'hui ?",
      "Avez-vous une douleur dans la poitrine ?",
      "Pouvez-vous bouger les doigts ?",
      "Avez-vous votre ordonnance sur vous ?",
    ],
    en: [
      "Ma'am, Sir, can you hear me?",
      "What is your first name?",
      "How old are you?",
      "Where does it hurt?",
      "Do you have a chronic illness?",
      "Are you on any medication?",
      "Are you allergic to anything?",
      "Do you have insulin with you?",
      "Are you pregnant?",
      "Do you have a pacemaker?",
      "Are you on blood thinners?",
      "Have you eaten today?",
      "Do you have chest pain?",
      "Can you move your fingers?",
      "Do you have your prescription with you?",
    ],
    es: [
      "Señora, Señor, ¿puede oírme?",
      "¿Cuál es su nombre?",
      "¿Cuántos años tiene?",
      "¿Dónde le duele?",
      "¿Tiene alguna enfermedad crónica?",
      "¿Está tomando algún medicamento?",
      "¿Es alérgico a algo?",
      "¿Tiene insulina consigo?",
      "¿Está embarazada?",
      "¿Tiene marcapasos?",
      "¿Toma anticoagulantes?",
      "¿Ha comido hoy?",
      "¿Tiene dolor en el pecho?",
      "¿Puede mover los dedos?",
      "¿Tiene su receta médica?",
    ],
  },

  // Traduire une question via Claude
  async translateQuestion(question, targetLang, claudeKey) {
    if (!claudeKey) return question;
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 100,
          messages: [{ role: 'user', content: `Traduire en ${targetLang} cette question médicale d'urgence, en utilisant la terminologie médicale correcte: "${question}". Réponds UNIQUEMENT avec la traduction, rien d'autre.` }]
        })
      });
      const d = await r.json();
      return d.content[0].text.trim();
    } catch { return question; }
  },

  // Lire une question à voix haute
  speakQuestion(question, lang) {
    if (!window.speechSynthesis) return;
    const utt = new SpeechSynthesisUtterance(question);
    const langMap = { fr:'fr-FR', en:'en-US', es:'es-ES', ar:'ar-SA', sw:'sw-KE', yo:'yo-NG', ha:'ha-NG', am:'am-ET', zu:'zu-ZA' };
    utt.lang = langMap[lang] || 'fr-FR';
    utt.rate = 0.85;
    utt.volume = 1;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utt);
  },

  // ─── Afficher la fiche d'urgence ──────────────
  showEmergencyCard() {
    const d = this.get();
    const langs = d.languages || ['fr', 'en'];

    const CONTACT_LABEL = {
      fr: 'PERSONNE DE CONFIANCE',
      en: 'EMERGENCY CONTACT',
      es: 'CONTACTO DE EMERGENCIA',
      ar: 'جهة الاتصال في حالات الطوارئ',
      sw: 'MWASILIANO WA DHARURA',
      yo: 'ÀSÌ-ỌRỌ ÌPAYÀ',
    };

    const modal = document.createElement('div');
    modal.id = 'emergency-card';
    modal.style.cssText = 'position:fixed;inset:0;background:#000;z-index:99999;overflow-y:auto;padding:1rem;';
    
    modal.innerHTML = `
      <div style="max-width:480px;margin:0 auto">
        <div style="background:#c00;color:#fff;padding:.8rem;text-align:center;font-family:'Josefin Sans',sans-serif;font-size:.9rem;letter-spacing:.2em;margin-bottom:.8rem">
          🚨 URGENCE MÉDICALE / MEDICAL EMERGENCY
        </div>

        <!-- Infos patient -->
        <div style="background:#1a1410;border:2px solid #c9a84c;padding:.8rem;margin-bottom:.6rem">
          <div style="font-size:1.2rem;color:#c9a84c;font-family:'Cormorant Garamond',serif;font-style:italic;margin-bottom:.4rem">${d.name || 'Nom non renseigné'}</div>
          <div style="font-size:.7rem;color:#fff;line-height:1.8">
            ${d.age ? `Âge / Age : <strong>${d.age} ans</strong><br/>` : ''}
            ${d.bloodType ? `Groupe sanguin / Blood type : <strong>${d.bloodType}</strong><br/>` : ''}
            ${d.isPregnant ? `<span style="color:#ff6b6b">⚠ ENCEINTE / PREGNANT</span><br/>` : ''}
            ${d.hasPacemaker ? `<span style="color:#ff6b6b">⚠ PACEMAKER — PAS DE DÉFIBRILLATEUR</span><br/>` : ''}
            ${d.isAnticoagulant ? `<span style="color:#ff6b6b">⚠ ANTICOAGULANTS — ATTENTION AUX INJECTIONS</span><br/>` : ''}
          </div>
        </div>

        <!-- Pathologies -->
        ${d.conditions?.length ? `
        <div style="background:#1a1410;border:1px solid #666;padding:.7rem;margin-bottom:.6rem">
          <div style="font-size:.6rem;color:#c9a84c;letter-spacing:.15em;text-transform:uppercase;margin-bottom:.3rem">Maladies / Conditions</div>
          ${d.conditions.map(c => `<div style="font-size:.75rem;color:#fff">• ${c}</div>`).join('')}
        </div>` : ''}

        <!-- Médicaments -->
        ${d.medications?.length ? `
        <div style="background:#1a1410;border:1px solid #666;padding:.7rem;margin-bottom:.6rem">
          <div style="font-size:.6rem;color:#c9a84c;letter-spacing:.15em;text-transform:uppercase;margin-bottom:.3rem">Traitements / Medications</div>
          ${d.medications.map(m => `<div style="font-size:.75rem;color:#fff">• ${m}</div>`).join('')}
        </div>` : ''}

        <!-- Allergies -->
        ${d.allergies?.length ? `
        <div style="background:#3a0000;border:2px solid #c00;padding:.7rem;margin-bottom:.6rem">
          <div style="font-size:.6rem;color:#ff6b6b;letter-spacing:.15em;text-transform:uppercase;margin-bottom:.3rem">⚠ ALLERGIES</div>
          ${d.allergies.map(a => `<div style="font-size:.75rem;color:#fff;font-weight:bold">• ${a}</div>`).join('')}
        </div>` : ''}

        <!-- Médecin -->
        ${d.doctor?.name ? `
        <div style="background:#1a1410;border:1px solid #666;padding:.7rem;margin-bottom:.6rem">
          <div style="font-size:.6rem;color:#c9a84c;letter-spacing:.15em;text-transform:uppercase;margin-bottom:.3rem">Médecin traitant / Doctor</div>
          <div style="font-size:.75rem;color:#fff">${d.doctor.name}</div>
          ${d.doctor.phone ? `<a href="tel:${d.doctor.phone}" style="font-size:.8rem;color:#4fc3f7;display:block;margin-top:.2rem">📞 ${d.doctor.phone}</a>` : ''}
        </div>` : ''}

        <!-- Contacts de confiance -->
        ${d.emergencyContacts?.length ? `
        <div style="background:#1a1410;border:2px solid #c9a84c;padding:.7rem;margin-bottom:.8rem">
          ${d.emergencyContacts.slice(0,2).map((c,i) => `
            <div style="margin-bottom:${i===0?'.5rem':'0'}">
              <div style="font-size:.6rem;color:#c9a84c;letter-spacing:.15em;text-transform:uppercase">
                ${CONTACT_LABEL['fr']} / ${CONTACT_LABEL['en']}${d.languages[2]&&CONTACT_LABEL[d.languages[2]]?' / '+CONTACT_LABEL[d.languages[2]]:''}
              </div>
              <div style="font-size:.8rem;color:#fff;margin-top:.2rem"><strong>${c.name}</strong></div>
              <a href="tel:${c.phone}" style="font-size:1rem;color:#4fc3f7;display:block;margin-top:.2rem;font-weight:bold">📞 ${c.phone}</a>
            </div>
          `).join('')}
        </div>` : ''}

        <!-- Traducteur oral -->
        <div style="background:#1a1410;border:1px solid #c9a84c;padding:.7rem;margin-bottom:.6rem">
          <div style="font-size:.6rem;color:#c9a84c;letter-spacing:.15em;text-transform:uppercase;margin-bottom:.5rem">Questions d'urgence / Emergency questions</div>
          <div style="display:flex;gap:.3rem;margin-bottom:.5rem;flex-wrap:wrap">
            ${['fr','en','es'].map(l => `<button onclick="MEDICAL.setQuestionLang('${l}')" id="qlang_${l}" style="padding:.3rem .6rem;background:${l==='fr'?'#c9a84c':'#333'};color:${l==='fr'?'#000':'#fff'};border:none;font-family:'Josefin Sans',sans-serif;font-size:.5rem;letter-spacing:.1em;cursor:pointer">${l.toUpperCase()}</button>`).join('')}
          </div>
          <div id="questionsList" style="display:flex;flex-direction:column;gap:.3rem">
            ${(MEDICAL.EMERGENCY_QUESTIONS['fr']||[]).map((q,i) => `
              <button onclick="MEDICAL.speakQuestion('${q.replace(/'/g,"\\'")}','fr')" style="text-align:left;padding:.5rem;background:#2c2318;border:1px solid #444;color:#fff;font-family:'Josefin Sans',sans-serif;font-size:.58rem;cursor:pointer;line-height:1.4">
                🔊 ${q}
              </button>
            `).join('')}
          </div>
        </div>

        <button onclick="document.getElementById('emergency-card').remove()" style="width:100%;padding:.8rem;background:#333;color:#fff;border:none;font-family:'Josefin Sans',sans-serif;font-size:.6rem;letter-spacing:.15em;text-transform:uppercase;cursor:pointer;margin-bottom:1rem">
          Fermer / Close
        </button>
      </div>
    `;

    document.body.appendChild(modal);

    // Envoyer alerte aux contacts
    this.sendEmergencyAlert(d);
  },

  currentQuestionLang: 'fr',
  setQuestionLang(lang) {
    this.currentQuestionLang = lang;
    ['fr','en','es'].forEach(l => {
      const btn = document.getElementById('qlang_'+l);
      if (btn) { btn.style.background = l===lang?'#c9a84c':'#333'; btn.style.color = l===lang?'#000':'#fff'; }
    });
    const questions = this.EMERGENCY_QUESTIONS[lang] || this.EMERGENCY_QUESTIONS['fr'];
    const list = document.getElementById('questionsList');
    if (list) {
      list.innerHTML = questions.map(q => `
        <button onclick="MEDICAL.speakQuestion('${q.replace(/'/g,"\\'")}','${lang}')" style="text-align:left;padding:.5rem;background:#2c2318;border:1px solid #444;color:#fff;font-family:'Josefin Sans',sans-serif;font-size:.58rem;cursor:pointer;line-height:1.4">
          🔊 ${q}
        </button>
      `).join('');
    }
  },

  sendEmergencyAlert(profile) {
    const contacts = profile.emergencyContacts || [];
    const msg = `⚠ ALERTE MÉDICALE — La fiche d'urgence de ${profile.name || 'votre contact'} a été consultée à ${new Date().toLocaleTimeString('fr-FR')}. Les secours semblent être intervenus. Restez joignable.`;
    if (window.addChatMsg) addChatMsg('assistant', msg);
    // Note Jeff : intégrer envoi SMS via Twilio API
  },

  // ─── Détection 4 tapes ────────────────────────
  initTapDetection() {
    let tapCount = 0;
    let tapTimer = null;
    document.addEventListener('touchstart', () => {
      tapCount++;
      clearTimeout(tapTimer);
      tapTimer = setTimeout(() => {
        if (tapCount >= 4) MEDICAL.showEmergencyCard();
        tapCount = 0;
      }, 500);
    });
  },

  // ─── Interface configuration ──────────────────
  renderSetupPanel() {
    const d = this.get();
    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.7rem">
      <div class="sec-title">🆘 Fiche médicale d'urgence</div>
      <p class="note">Accessible par 4 tapes rapides sur l'écran. En 3 langues simultanément. Envoi automatique à vos contacts de confiance.</p>
      
      <input type="text" placeholder="Prénom et nom" value="${d.name||''}" onchange="MEDICAL.updateField('name',this.value)"/>
      <div style="display:flex;gap:.4rem">
        <input type="number" placeholder="Âge" value="${d.age||''}" style="flex:1" onchange="MEDICAL.updateField('age',this.value)"/>
        <select style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.58rem;padding:.45rem;outline:none" onchange="MEDICAL.updateField('bloodType',this.value)">
          <option value="">Groupe sanguin</option>
          ${['A+','A-','B+','B-','AB+','AB-','O+','O-'].map(g=>`<option ${d.bloodType===g?'selected':''}>${g}</option>`).join('')}
        </select>
      </div>

      <div style="display:flex;gap:.5rem;flex-wrap:wrap">
        <label style="display:flex;align-items:center;gap:.3rem;font-size:.56rem;color:var(--muted);cursor:pointer"><input type="checkbox" ${d.isPregnant?'checked':''} onchange="MEDICAL.updateField('isPregnant',this.checked)" style="accent-color:var(--gold)"/> Enceinte</label>
        <label style="display:flex;align-items:center;gap:.3rem;font-size:.56rem;color:var(--muted);cursor:pointer"><input type="checkbox" ${d.hasPacemaker?'checked':''} onchange="MEDICAL.updateField('hasPacemaker',this.checked)" style="accent-color:var(--gold)"/> Pacemaker</label>
        <label style="display:flex;align-items:center;gap:.3rem;font-size:.56rem;color:var(--muted);cursor:pointer"><input type="checkbox" ${d.isAnticoagulant?'checked':''} onchange="MEDICAL.updateField('isAnticoagulant',this.checked)" style="accent-color:var(--gold)"/> Anticoagulants</label>
      </div>

      <textarea placeholder="Maladies chroniques (une par ligne)" style="min-height:60px" onchange="MEDICAL.updateField('conditions',this.value.split('\\n').filter(Boolean))">${(d.conditions||[]).join('\n')}</textarea>
      <textarea placeholder="Médicaments en cours (un par ligne)" style="min-height:60px" onchange="MEDICAL.updateField('medications',this.value.split('\\n').filter(Boolean))">${(d.medications||[]).join('\n')}</textarea>
      <textarea placeholder="Allergies (une par ligne — IMPORTANT)" style="min-height:40px;border-color:var(--red)" onchange="MEDICAL.updateField('allergies',this.value.split('\\n').filter(Boolean))">${(d.allergies||[]).join('\n')}</textarea>

      <div class="sep"></div>
      <div class="sec-title">Médecin traitant</div>
      <input type="text" placeholder="Nom du médecin" value="${d.doctor?.name||''}" onchange="MEDICAL.updateDoctor('name',this.value)"/>
      <input type="tel" placeholder="Téléphone médecin" value="${d.doctor?.phone||''}" onchange="MEDICAL.updateDoctor('phone',this.value)"/>

      <div class="sep"></div>
      <div class="sec-title">Contacts de confiance (2 minimum)</div>
      ${[0,1].map(i => `
        <div style="border:1px solid var(--border);padding:.6rem;margin-bottom:.3rem">
          <input type="text" placeholder="Prénom Nom" value="${d.emergencyContacts?.[i]?.name||''}" style="margin-bottom:.3rem" onchange="MEDICAL.updateContact(${i},'name',this.value)"/>
          <input type="tel" placeholder="Téléphone international (+33...)" value="${d.emergencyContacts?.[i]?.phone||''}" onchange="MEDICAL.updateContact(${i},'phone',this.value)"/>
        </div>
      `).join('')}

      <button class="btn btn-gold" onclick="MEDICAL.showEmergencyCard()">👁 Prévisualiser la fiche d'urgence</button>
      <button class="btn btn-ghost" onclick="MEDICAL.initTapDetection();alert('Détection activée — 4 tapes pour ouvrir la fiche')">✓ Activer détection 4 tapes</button>
    </div>`;
  },

  updateField(key, value) { const d = this.get(); d[key] = value; this.save(d); },
  updateDoctor(key, value) { const d = this.get(); if(!d.doctor)d.doctor={}; d.doctor[key]=value; this.save(d); },
  updateContact(i, key, value) {
    const d = this.get();
    if(!d.emergencyContacts) d.emergencyContacts = [];
    if(!d.emergencyContacts[i]) d.emergencyContacts[i] = {};
    d.emergencyContacts[i][key] = value;
    this.save(d);
  }
};

window.MEDICAL = MEDICAL;
window.addEventListener('load', () => {
  setTimeout(() => MEDICAL.initTapDetection(), 2000);
});
