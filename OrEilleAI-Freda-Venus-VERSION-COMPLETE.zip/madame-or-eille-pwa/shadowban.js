// ═══════════════════════════════════════════════════
//  DÉTECTION SHADOWBAN — Or Eille AI v1.0
//  Suis-je vraiment vue ou invisible ?
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const SHADOWBAN = {
  KEY: 'moe_shadowban',

  SIGNALS: [
    { id: 1, label: 'Mes vues ont chute de plus de 50% sans raison', weight: 3 },
    { id: 2, label: 'Mes hashtags ne semblent plus fonctionner', weight: 3 },
    { id: 3, label: 'Je n apparais plus dans les suggestions', weight: 2 },
    { id: 4, label: 'Mon taux d engagement a baisse brutalement', weight: 2 },
    { id: 5, label: 'Mes nouveaux abonnes ont chute', weight: 2 },
    { id: 6, label: 'J ai recemment utilise des hashtags bannis', weight: 3 },
    { id: 7, label: 'J ai publie du contenu signale par la communaute', weight: 3 },
    { id: 8, label: 'J ai utilise un outil tiers pour liker ou suivre', weight: 3 },
    { id: 9, label: 'J ai publie trop vite en tres peu de temps', weight: 2 },
    { id: 10, label: 'Mon compte est recent et peu etabli', weight: 1 },
  ],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { checks: [], selected: [] }; }
    catch { return { checks: [], selected: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  toggleSignal(id) {
    const d = this.get();
    const idx = d.selected.indexOf(id);
    if (idx > -1) d.selected.splice(idx, 1);
    else d.selected.push(id);
    this.save(d);
    document.getElementById('shadowbanContent').innerHTML = SHADOWBAN.renderPanel();
  },

  async analyze(platform, claudeKey) {
    const d = this.get();
    const selected = this.SIGNALS.filter(function(s) { return d.selected.includes(s.id); });
    const score = selected.reduce(function(sum, s) { return sum + s.weight; }, 0);

    let level, color, advice;

    if (score === 0) {
      level = 'Aucun signal detecte';
      color = '#81c784';
      advice = 'Tout semble normal. Continuez a publier regulierement avec du contenu de qualite.';
    } else if (score <= 3) {
      level = 'Risque faible';
      color = '#81c784';
      advice = 'Quelques signaux mineurs. Continuez normalement mais evitez les comportements suspects.';
    } else if (score <= 6) {
      level = 'Risque modere';
      color = '#F5A623';
      advice = 'Plusieurs signaux detectes. Faites une pause de 48h, nettoyez vos hashtags, evitez les outils tiers.';
    } else {
      level = 'Risque eleve — shadowban probable';
      color = '#ef5350';
      advice = 'Forte probabilite de shadowban. Pause de 3 a 7 jours recommandee. Contactez le support de la plateforme.';
    }

    if (window.addChatMsg) addChatMsg('assistant', '📊 Analyse shadowban ' + (platform||'') + ' — Score: ' + score + '/20\n\n' + level + '\n\n' + advice);

    if (claudeKey && selected.length > 0) {
      const signals = selected.map(function(s) { return '- ' + s.label; }).join('\n');
      try {
        const r = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
          body: JSON.stringify({
            model: 'claude-sonnet-4-20250514', max_tokens: 600,
            messages: [{
              role: 'user',
              content: 'Une creatrice sur ' + (platform||'Instagram') + ' a ces signaux de shadowban :\n' + signals + '\n\nDonne-lui un plan de recovery concret en 5 etapes. Chaleureux et actionnable.'
            }]
          })
        });
        const data = await r.json();
        if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
      } catch(e) {}
    }

    d.checks.unshift({ platform, score, level, at: new Date().toISOString() });
    d.checks = d.checks.slice(0, 20);
    this.save(d);
  },

  renderPanel: function() {
    const d = this.get();
    const score = this.SIGNALS.filter(function(s) { return d.selected.includes(s.id); }).reduce(function(sum, s) { return sum + s.weight; }, 0);
    const scoreColor = score === 0 ? '#81c784' : score <= 3 ? '#81c784' : score <= 6 ? '#F5A623' : '#ef5350';

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +

      '<div class="sec-title">👁 Detection shadowban</div>' +
      '<p class="note">Suis-je vraiment vue ou invisible ? Cochez les signaux que vous observez.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">' +
          'Vous avez l impression que vos posts ne sont plus vus ? Cochez ce que vous observez. Or Eille AI analyse et vous dit quoi faire.' +
        '</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +

      (score > 0 ? '<div style="text-align:center;padding:.5rem;background:rgba(' + (score<=3?'129,199,132':score<=6?'245,166,35':'239,83,80') + ',.1);border:1px solid ' + scoreColor + '">' +
        '<div style="font-size:1.2rem;color:' + scoreColor + '">' + score + '/20</div>' +
        '<div style="font-size:.5rem;color:' + scoreColor + '">' + (score<=3?'Risque faible':score<=6?'Risque modere':'Risque eleve') + '</div>' +
      '</div>' : '') +

      '<div class="sec-title">Signes que vous observez</div>' +
      this.SIGNALS.map(function(s) {
        const selected = d.selected.includes(s.id);
        return '<label style="display:flex;align-items:center;gap:.5rem;padding:.5rem;border:1px solid ' + (selected?'rgba(196,153,58,.4)':'var(--border)') + ';background:' + (selected?'rgba(196,153,58,.08)':'var(--dark-mid)') + ';cursor:pointer;margin-bottom:.3rem">' +
          '<input type="checkbox" ' + (selected?'checked':'') + ' onchange="SHADOWBAN.toggleSignal(' + s.id + ')" style="accent-color:var(--gold)"/>' +
          '<span style="font-size:.54rem;color:' + (selected?'var(--gold)':'var(--muted)') + '">' + s.label + '</span>' +
        '</label>';
      }).join('') +

      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
        ['Instagram','TikTok','YouTube','Facebook'].map(function(p) {
          return '<button onclick="SHADOWBAN.analyze(\'' + p + '\', window.CFG&&window.CFG.CLAUDE_KEY)" style="flex:1;padding:.4rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:\'Josefin Sans\',sans-serif;font-size:.48rem;cursor:pointer">' + p + '</button>';
        }).join('') +
      '</div>' +

      '<button class="btn btn-ghost" onclick="const d=SHADOWBAN.get();d.selected=[];SHADOWBAN.save(d);document.getElementById(\'shadowbanContent\').innerHTML=SHADOWBAN.renderPanel()">Tout decocher</button>' +

    '</div>';
  }
};

window.SHADOWBAN = SHADOWBAN;
