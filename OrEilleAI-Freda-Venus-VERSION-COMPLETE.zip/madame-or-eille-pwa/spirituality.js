// ═══════════════════════════════════════════════════
//  SPIRITUALITÉ UNIVERSELLE — Or Eille AI
//  Horaires de prière, fêtes, versets, pratiques
//  Toutes les traditions respectées
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const SPIRIT = {

  KEY: 'moe_spirit',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || this._default(); }
    catch { return this._default(); }
  },

  _default() {
    return {
      traditions: [],
      rappels_actifs: true,
      latitude: null,
      longitude: null,
    };
  },

  save(d) { try { localStorage.setItem(this.KEY, JSON.stringify(d)); } catch {} },

  // ─── TRADITIONS ───────────────────────────────
  TRADITIONS: {
    islam: {
      nom: 'Islam', icone: '🌙', couleur: '#2E7D32',
      prieres: ['Fajr (Aube)', 'Dhuhr (Midi)', 'Asr (Après-midi)', 'Maghreb (Coucher)', 'Isha (Nuit)'],
      fetes: ['Ramadan', 'Aïd el-Fitr', 'Aïd el-Kébir', 'Mawlid', 'Nuit du Destin', 'Achoura'],
    },
    catholique: {
      nom: 'Christianisme catholique', icone: '✝️', couleur: '#1A237E',
      prieres: ['Laudes (Matin)', 'Tierce', 'Sexte (Midi)', 'None', 'Vêpres (Soir)', 'Complies (Nuit)'],
      fetes: ['Noël', 'Épiphanie', 'Mercredi des Cendres', 'Pâques', 'Ascension', 'Pentecôte', 'Toussaint', 'Assomption'],
    },
    protestant: {
      nom: 'Christianisme protestant', icone: '✟', couleur: '#0D47A1',
      prieres: ['Prière du matin', 'Prière du soir'],
      fetes: ['Noël', 'Pâques', 'Pentecôte', 'Réforme (31 oct)'],
    },
    orthodoxe: {
      nom: 'Christianisme orthodoxe', icone: '☦️', couleur: '#B71C1C',
      prieres: ['Matines', 'Laudes', 'Vêpres', 'Complies'],
      fetes: ['Noël orthodoxe (7 jan)', 'Pâques orthodoxe', 'Théophanie'],
    },
    judaisme: {
      nom: 'Judaïsme', icone: '✡️', couleur: '#1565C0',
      prieres: ['Shacharit (Matin)', 'Mincha (Après-midi)', 'Maariv (Soir)', 'Shabbat (Vendredi soir)'],
      fetes: ['Roch Hachana', 'Yom Kippour', 'Souccot', 'Hanoukka', 'Pourim', 'Pessah', 'Chavouot'],
    },
    hindouisme: {
      nom: 'Hindouisme', icone: '🕉️', couleur: '#E65100',
      prieres: ['Brahma Muhurta (Aube)', 'Sandhya (Lever)', 'Madhyahna (Midi)', 'Sayam (Soir)'],
      fetes: ['Diwali', 'Holi', 'Navratri', 'Dussehra', 'Janmashtami', 'Mahashivaratri'],
    },
    bouddhisme: {
      nom: 'Bouddhisme', icone: '☸️', couleur: '#F57F17',
      prieres: ['Méditation du matin', 'Méditation du soir'],
      fetes: ['Vesak (Bouddha Purnima)', 'Losar (Nouvel An tibétain)', 'Kathina'],
    },
    yoga: {
      nom: 'Yoga & Méditation', icone: '🧘', couleur: '#6A1B9A',
      prieres: ['Salutation au soleil (Matin)', 'Salutation à la lune (Soir)', 'Méditation'],
      fetes: ['Journée internationale du yoga (21 juin)', 'Équinoxes', 'Solstices'],
    },
    animisme: {
      nom: 'Spiritualités africaines', icone: '🌍', couleur: '#4E342E',
      prieres: ['Prière aux ancêtres (Matin)', 'Offrande (Soir)'],
      fetes: ['Fêtes des ancêtres', 'Cérémonies de passage', 'Fêtes des récoltes'],
    },
  },

  // ─── VERSETS DU JOUR ──────────────────────────
  VERSETS: {
    islam: [
      { ref: 'Coran 2:286', texte: 'Dieu n\'impose à aucune âme une charge supérieure à sa capacité.' },
      { ref: 'Coran 94:5-6', texte: 'Certes, avec la difficulté vient la facilité. Certes, avec la difficulté vient la facilité.' },
      { ref: 'Coran 3:200', texte: 'Ô vous qui croyez ! Endurez, surpassez en endurance, soyez prêts, et craignez Dieu.' },
    ],
    catholique: [
      { ref: 'Jean 13:34', texte: 'Aimez-vous les uns les autres, comme je vous ai aimés.' },
      { ref: 'Matthieu 5:9', texte: 'Heureux les artisans de paix : ils seront appelés fils de Dieu.' },
      { ref: 'Philippiens 4:13', texte: 'Je peux tout en Celui qui me fortifie.' },
    ],
    protestant: [
      { ref: 'Psaume 23:1', texte: 'L\'Éternel est mon berger, je ne manquerai de rien.' },
      { ref: 'Romains 8:28', texte: 'Nous savons que toutes choses concourent au bien de ceux qui aiment Dieu.' },
    ],
    judaisme: [
      { ref: 'Proverbes 3:5', texte: 'Confie-toi en l\'Éternel de tout ton cœur, et ne t\'appuie pas sur ta sagesse.' },
      { ref: 'Michée 6:8', texte: 'Agis avec justice, aime la bonté, et marche humblement avec ton Dieu.' },
    ],
    hindouisme: [
      { ref: 'Bhagavad-Gita 2:47', texte: 'Tu as le droit d\'agir, mais jamais au fruit de tes actions.' },
      { ref: 'Bhagavad-Gita 9:22', texte: 'Ceux qui me vénèrent avec dévotion, je pourvois à ce qu\'ils n\'ont pas et préserve ce qu\'ils ont.' },
    ],
    bouddhisme: [
      { ref: 'Dhammapada 1', texte: 'L\'esprit est la source de toutes choses. Ce que nous sommes est le résultat de nos pensées.' },
      { ref: 'Bouddha', texte: 'La paix vient de l\'intérieur. Ne la cherchez pas à l\'extérieur.' },
    ],
    yoga: [
      { ref: 'Yoga Sutra 1:2', texte: 'Le yoga est la cessation des fluctuations du mental.' },
      { ref: 'Sagesse', texte: 'Respire. Tu es ici. Ce moment est tout ce qui existe.' },
    ],
    animisme: [
      { ref: 'Sagesse africaine', texte: 'Un seul bras ne peut pas attacher un paquet.' },
      { ref: 'Proverbe', texte: 'Les ancêtres ne meurent jamais tant qu\'on se souvient d\'eux.' },
    ],
  },

  // ─── CALCUL HORAIRES ISLAM ────────────────────
  _calculPriereIslam(lat, lon, date) {
    // Algorithme simplifié de calcul des heures de prière
    const D2R = Math.PI / 180;
    const R2D = 180 / Math.PI;

    const jour = date.getDate();
    const mois = date.getMonth() + 1;
    const annee = date.getFullYear();

    const JD = Math.floor(365.25 * (annee + 4716)) + Math.floor(30.6001 * (mois + 1)) + jour - 1524.5;
    const T = (JD - 2451545.0) / 36525.0;
    const L0 = 280.46646 + 36000.76983 * T;
    const M = 357.52911 + 35999.05029 * T;
    const Mrad = M * D2R;
    const C = (1.914602 - 0.004817 * T) * Math.sin(Mrad) + 0.019993 * Math.sin(2 * Mrad);
    const sunLon = L0 + C;
    const obliq = 23.439 - 0.00000036 * T * 36525;
    const sinDec = Math.sin(obliq * D2R) * Math.sin(sunLon * D2R);
    const dec = Math.asin(sinDec) * R2D;

    const noon = 12 - lon / 15;
    const cosH = (Math.sin(-0.833 * D2R) - Math.sin(lat * D2R) * Math.sin(dec * D2R)) /
                 (Math.cos(lat * D2R) * Math.cos(dec * D2R));
    const H = Math.acos(Math.max(-1, Math.min(1, cosH))) * R2D / 15;

    const fajrH = Math.acos((Math.sin(-18 * D2R) - Math.sin(lat * D2R) * Math.sin(dec * D2R)) /
                  (Math.cos(lat * D2R) * Math.cos(dec * D2R))) * R2D / 15;

    const asrH = Math.atan(1 / (Math.tan(Math.abs(lat - dec) * D2R) + 1)) * R2D;
    const asrHA = Math.acos((Math.sin(Math.atan(1 / (1 + Math.tan(Math.abs(lat - dec) * D2R)))) -
                  Math.sin(lat * D2R) * Math.sin(dec * D2R)) /
                  (Math.cos(lat * D2R) * Math.cos(dec * D2R))) * R2D / 15;

    const fmt = (h) => {
      const total = Math.round(h * 60);
      const hh = Math.floor(total / 60) % 24;
      const mm = total % 60;
      return `${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}`;
    };

    return {
      'Fajr': fmt(noon - fajrH),
      'Dhuhr': fmt(noon),
      'Asr': fmt(noon + asrHA),
      'Maghreb': fmt(noon + H),
      'Isha': fmt(noon + fajrH + (H - fajrH) * 0.5 + H),
    };
  },

  // ─── FÊTES DE L'ANNÉE ─────────────────────────
  _getFetesProchaines() {
    const now = new Date();
    const annee = now.getFullYear();
    const fetes = [];

    // Calculer Pâques (algorithme de Meeus/Jones/Butcher)
    const a = annee % 19;
    const b = Math.floor(annee / 100);
    const c = annee % 100;
    const d = Math.floor(b / 4);
    const e = b % 4;
    const f = Math.floor((b + 8) / 25);
    const g = Math.floor((b - f + 1) / 3);
    const h = (19 * a + b - d - g + 15) % 30;
    const i = Math.floor(c / 4);
    const k = c % 4;
    const l = (32 + 2 * e + 2 * i - h - k) % 7;
    const m = Math.floor((a + 11 * h + 22 * l) / 451);
    const moisPaques = Math.floor((h + l - 7 * m + 114) / 31);
    const jourPaques = ((h + l - 7 * m + 114) % 31) + 1;
    const paques = new Date(annee, moisPaques - 1, jourPaques);

    fetes.push({ nom: '🐣 Pâques', date: paques, tradition: 'catholique' });
    fetes.push({ nom: '⬆️ Ascension', date: new Date(paques.getTime() + 39 * 86400000), tradition: 'catholique' });
    fetes.push({ nom: '🕊️ Pentecôte', date: new Date(paques.getTime() + 49 * 86400000), tradition: 'catholique' });
    fetes.push({ nom: '🎄 Noël', date: new Date(annee, 11, 25), tradition: 'catholique' });
    fetes.push({ nom: '☀️ Solstice d\'été', date: new Date(annee, 5, 21), tradition: 'yoga' });
    fetes.push({ nom: '🍂 Solstice d\'hiver', date: new Date(annee, 11, 21), tradition: 'yoga' });
    fetes.push({ nom: '🌸 Équinoxe de printemps', date: new Date(annee, 2, 20), tradition: 'yoga' });
    fetes.push({ nom: '🍁 Équinoxe d\'automne', date: new Date(annee, 8, 22), tradition: 'yoga' });
    fetes.push({ nom: '🧘 Journée internationale du yoga', date: new Date(annee, 5, 21), tradition: 'yoga' });
    fetes.push({ nom: '🕎 Hanoukka', date: new Date(annee, 11, 25), tradition: 'judaisme' });

    // Trier par date et prendre les 5 prochaines
    return fetes
      .filter(f => f.date >= now)
      .sort((a, b) => a.date - b.date)
      .slice(0, 5);
  },

  // ─── VERSET DU JOUR ───────────────────────────
  getVersetDuJour(tradition) {
    const versets = this.VERSETS[tradition];
    if (!versets || versets.length === 0) return null;
    const idx = new Date().getDate() % versets.length;
    return versets[idx];
  },

  // ─── PANEL PRINCIPAL ──────────────────────────
  renderPanel() {
    const d = this.get();

    return `
    <div style="padding:1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div class="sec-title">🕊️ Spiritualité & Traditions</div>
      <p style="font-size:.52rem;color:var(--muted);line-height:1.6">
        Toutes les traditions sont respectées et honorées ici. Choisissez les vôtres.
      </p>

      <div class="sec-title">Mes traditions</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">
        ${Object.entries(this.TRADITIONS).map(([key, trad]) => {
          const actif = d.traditions.includes(key);
          return `
          <button onclick="SPIRIT._toggleTradition('${key}')"
            style="padding:.6rem;background:${actif ? `rgba(255,255,255,.12)` : 'var(--dark-mid)'};border:1px solid ${actif ? trad.couleur : 'var(--border)'};color:var(--text);font-family:inherit;cursor:pointer;text-align:left;transition:all .2s">
            <div style="font-size:.9rem;margin-bottom:.2rem">${trad.icone}</div>
            <div style="font-size:.52rem;color:${actif ? '#fff' : 'var(--muted)'}">${trad.nom}</div>
            ${actif ? `<div style="font-size:.4rem;color:${trad.couleur};margin-top:.2rem">✓ Sélectionné</div>` : ''}
          </button>`;
        }).join('')}
      </div>

      ${d.traditions.length > 0 ? `

        <div class="sep"></div>
        <div class="sec-title">📿 Mes prières aujourd'hui</div>
        ${d.traditions.map(key => {
          const trad = this.TRADITIONS[key];
          if (!trad) return '';
          return `
          <div style="padding:.7rem;border:1px solid var(--border)">
            <div style="font-size:.6rem;color:var(--text);margin-bottom:.4rem">${trad.icone} ${trad.nom}</div>
            <div style="display:flex;flex-direction:column;gap:.2rem">
              ${trad.prieres.map(p => `
                <div style="display:flex;align-items:center;gap:.4rem;font-size:.52rem;color:var(--muted)">
                  <span style="width:8px;height:8px;border-radius:50%;background:var(--border);flex-shrink:0"></span>
                  ${p}
                </div>
              `).join('')}
            </div>
          </div>`;
        }).join('')}

        <div class="sep"></div>
        <div class="sec-title">✨ Verset du jour</div>
        ${d.traditions.map(key => {
          const verset = this.getVersetDuJour(key);
          if (!verset) return '';
          const trad = this.TRADITIONS[key];
          return `
          <div style="padding:.8rem;border-left:3px solid ${trad?.couleur || 'var(--gold)'};background:rgba(255,255,255,.03)">
            <div style="font-size:.5rem;color:var(--muted);margin-bottom:.3rem">${trad?.icone} ${verset.ref}</div>
            <div style="font-size:.62rem;color:var(--text);line-height:1.8;font-style:italic">"${verset.texte}"</div>
          </div>`;
        }).join('')}

        <div class="sep"></div>
        <div class="sec-title">🗓️ Fêtes à venir</div>
        ${this._getFetesProchaines().map(f => {
          const date = f.date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' });
          return `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:.5rem .6rem;border:1px solid var(--border);font-size:.55rem">
            <span style="color:var(--text)">${f.nom}</span>
            <span style="color:var(--muted)">${date}</span>
          </div>`;
        }).join('')}

        ${d.traditions.includes('islam') ? `
          <div class="sep"></div>
          <div class="sec-title">🌙 Horaires de prière</div>
          ${d.latitude ? this._renderPriereIslam(d.latitude, d.longitude) : `
            <button onclick="SPIRIT._localiserPriere()"
              class="btn btn-gold">
              📍 Utiliser ma position pour les horaires
            </button>
          `}
        ` : ''}

      ` : `
        <p style="font-size:.55rem;color:var(--muted);text-align:center;padding:1rem">
          Sélectionnez vos traditions ci-dessus pour voir vos horaires et versets.
        </p>
      `}

    </div>`;
  },

  _renderPriereIslam(lat, lon) {
    const horaires = this._calculPriereIslam(lat, lon, new Date());
    return `
    <div style="display:flex;flex-direction:column;gap:.3rem">
      ${Object.entries(horaires).map(([priere, heure]) => `
        <div style="display:flex;justify-content:space-between;padding:.5rem .7rem;border:1px solid var(--border);font-size:.58rem">
          <span style="color:var(--text)">🌙 ${priere}</span>
          <span style="color:var(--gold);font-weight:700">${heure}</span>
        </div>
      `).join('')}
    </div>`;
  },

  _toggleTradition(key) {
    const d = this.get();
    const idx = d.traditions.indexOf(key);
    if (idx >= 0) d.traditions.splice(idx, 1);
    else d.traditions.push(key);
    this.save(d);
    document.getElementById('spiritContent').innerHTML = this.renderPanel();
  },

  _localiserPriere() {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(pos => {
      const d = this.get();
      d.latitude = pos.coords.latitude;
      d.longitude = pos.coords.longitude;
      this.save(d);
      document.getElementById('spiritContent').innerHTML = this.renderPanel();
    });
  },
};

window.SPIRIT = SPIRIT;
