// ═══════════════════════════════════════════════════
//  MODULE FINANCE & COMPTABILITÉ
//  Or Eille AI — v1.0
//  Pour indépendants, créateurs, artisans — tous pays
// ═══════════════════════════════════════════════════

const FINANCE = {
  KEY: 'moe_finance',

  // ─── Données ──────────────────────────────────
  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      profile: {}, transactions: [], stock: [], invoices: [],
      envelopes: [], savings: [], alerts: []
    }; } catch { return { profile: {}, transactions: [], stock: [], invoices: [], envelopes: [], savings: [], alerts: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Profil fiscal ────────────────────────────
  setupProfile(data) {
    const d = this.get();
    d.profile = { ...data, setupAt: new Date().toISOString() };
    this.save(d);
  },

  // ─── Taux selon statut et pays ────────────────
  getRates() {
    const d = this.get();
    const country = d.profile.country || 'FR';
    const status = d.profile.status || 'micro';
    const rates = {
      FR: {
        micro_services: { urssaf: 0.221, ir: 0.011, total: 0.232, label: 'Micro-entreprise services' },
        micro_vente: { urssaf: 0.128, ir: 0.011, total: 0.139, label: 'Micro-entreprise vente' },
        micro_liberal: { urssaf: 0.221, ir: 0.011, total: 0.232, label: 'Libéral' },
        seuil_tva: 36800, seuil_micro: 77700,
        declaration_urssaf: 'trimestrielle',
        declaration_ir: 'annuelle',
      },
      BE: { flat_tax: 0.205, social: 0.205, total: 0.41, label: 'Indépendant Belgique' },
      EE: { corporate: 0, dividend: 0.2, label: 'e-Residency Estonie' },
      CA: { federal: 0.15, provincial: 0.09, total: 0.24, label: 'Travailleur autonome Canada' },
      KE: { income: 0.1, nhif: 0.015, nssf: 0.06, label: 'Freelance Kenya' },
      SN: { forfait: 0.05, label: 'Contribuable Sénégal' },
    };
    return rates[country] || null;
  },

  // ─── Ajouter une transaction ──────────────────
  addTransaction(type, amount, description, category, date) {
    const d = this.get();
    const rates = this.getRates();
    const transaction = {
      id: Date.now().toString(),
      type, // 'income' | 'expense'
      amount: parseFloat(amount),
      description,
      category,
      date: date || new Date().toISOString(),
      charges: type === 'income' && rates ? parseFloat((amount * (rates.micro_services?.total || rates.total || 0.22)).toFixed(2)) : 0,
      net: type === 'income' && rates ? parseFloat((amount * (1 - (rates.micro_services?.total || rates.total || 0.22))).toFixed(2)) : parseFloat(amount),
    };
    d.transactions.push(transaction);
    this.save(d);
    return transaction;
  },

  // ─── Bilan période ────────────────────────────
  getBilan(days = 15) {
    const d = this.get();
    const since = new Date(Date.now() - days * 86400000);
    const txs = d.transactions.filter(t => new Date(t.date) > since);
    const income = txs.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
    const expenses = txs.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
    const charges = txs.filter(t => t.type === 'income').reduce((s, t) => s + t.charges, 0);
    const net = income - expenses - charges;
    return { income, expenses, charges, net, period: days };
  },

  // ─── Scan de facture (via Claude vision) ──────
  async scanInvoice(imageDataUrl, claudeKey) {
    if (!claudeKey) return null;
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 400,
          messages: [{
            role: 'user',
            content: [
              { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: imageDataUrl.split(',')[1] } },
              { type: 'text', text: 'Extrait les informations de cette facture. Réponds UNIQUEMENT en JSON : {"amount": number, "date": "YYYY-MM-DD", "supplier": "string", "description": "string", "type": "expense"}' }
            ]
          }]
        })
      });
      const data = await r.json();
      const text = data.content[0].text.replace(/```json|```/g, '').trim();
      return JSON.parse(text);
    } catch { return null; }
  },

  // ─── Alertes fiscales ─────────────────────────
  checkAlerts() {
    const d = this.get();
    const rates = this.getRates();
    if (!rates) return [];
    const alerts = [];
    const now = new Date();

    // URSSAF France — trimestrielle
    if (d.profile.country === 'FR') {
      const quarters = [
        { month: 3, day: 31, label: 'Q1' },
        { month: 6, day: 30, label: 'Q2' },
        { month: 9, day: 30, label: 'Q3' },
        { month: 12, day: 31, label: 'Q4' },
      ];
      quarters.forEach(q => {
        const deadline = new Date(now.getFullYear(), q.month - 1, q.day);
        const daysLeft = Math.ceil((deadline - now) / 86400000);
        if (daysLeft > 0 && daysLeft <= 30) {
          const bilan = this.getBilan(90);
          alerts.push({
            type: 'urssaf',
            message: `Déclaration URSSAF ${q.label} dans ${daysLeft} jours — montant estimé : ${bilan.charges.toFixed(2)}€`,
            deadline: deadline.toISOString(),
            amount: bilan.charges,
            urgent: daysLeft <= 3,
          });
        }
      });

      // Seuil TVA
      const yearIncome = this.getBilan(365).income;
      if (yearIncome > rates.seuil_tva * 0.9) {
        alerts.push({
          type: 'tva',
          message: `Attention — vous approchez du seuil de TVA (${rates.seuil_tva}€). Vous êtes à ${yearIncome.toFixed(0)}€. Consultez un comptable.`,
          urgent: yearIncome > rates.seuil_tva,
        });
      }
    }
    return alerts;
  },

  // ─── Génération déclaration ───────────────────
  generateDeclaration() {
    const d = this.get();
    const bilan = this.getBilan(90);
    const rates = this.getRates();
    return {
      period: 'Trimestre en cours',
      ca_brut: bilan.income.toFixed(2),
      charges_sociales: bilan.charges.toFixed(2),
      net_imposable: (bilan.income * 0.66).toFixed(2), // abattement 34%
      a_declarer: bilan.charges.toFixed(2),
      generatedAt: new Date().toISOString(),
      country: d.profile.country,
      status: d.profile.status,
    };
  },

  // ─── Gestion du stock ─────────────────────────
  addStockItem(name, quantity, unit, minAlert, costPerUnit) {
    const d = this.get();
    d.stock.push({ id: Date.now().toString(), name, quantity: parseFloat(quantity), unit, minAlert: parseFloat(minAlert), costPerUnit: parseFloat(costPerUnit), updatedAt: new Date().toISOString() });
    this.save(d);
  },

  updateStock(itemId, quantityUsed) {
    const d = this.get();
    const item = d.stock.find(s => s.id === itemId);
    if (!item) return;
    item.quantity -= parseFloat(quantityUsed);
    item.updatedAt = new Date().toISOString();
    // Enregistrer le coût en dépense
    if (item.costPerUnit) {
      this.addTransaction('expense', item.costPerUnit * quantityUsed, `Stock utilisé: ${item.name}`, 'stock');
    }
    this.save(d);
    if (item.quantity <= item.minAlert) {
      return `⚠ Stock bas — ${item.name} : ${item.quantity} ${item.unit} restants. Commande recommandée.`;
    }
    return null;
  },

  checkStockAlerts() {
    const d = this.get();
    return d.stock.filter(s => s.quantity <= s.minAlert).map(s =>
      `⚠ ${s.name} — stock bas : ${s.quantity} ${s.unit} (minimum : ${s.minAlert})`
    );
  },

  // ─── Enveloppes budgétaires ───────────────────
  setupEnvelopes(envelopes) {
    const d = this.get();
    d.envelopes = envelopes.map(e => ({ ...e, spent: 0, id: Date.now().toString() + Math.random() }));
    this.save(d);
  },

  spendFromEnvelope(envelopeId, amount, description) {
    const d = this.get();
    const env = d.envelopes.find(e => e.id === envelopeId);
    if (!env) return;
    env.spent += parseFloat(amount);
    this.save(d);
    const remaining = env.budget - env.spent;
    if (remaining < 0) return `⚠ Enveloppe "${env.name}" dépassée de ${Math.abs(remaining).toFixed(2)}€`;
    if (remaining < env.budget * 0.2) return `⚠ Enveloppe "${env.name}" presque vide — ${remaining.toFixed(2)}€ restants`;
    return null;
  },

  // ─── Défis épargne ────────────────────────────
  start52WeekChallenge() {
    const d = this.get();
    d.savings.push({
      id: Date.now().toString(),
      type: '52weeks',
      name: 'Défi 52 semaines',
      currentWeek: 0,
      totalSaved: 0,
      target: 1378,
      startedAt: new Date().toISOString(),
    });
    this.save(d);
  },

  logWeeklySaving(savingId, amount) {
    const d = this.get();
    const saving = d.savings.find(s => s.id === savingId);
    if (!saving) return;
    saving.currentWeek++;
    saving.totalSaved += parseFloat(amount);
    this.save(d);
    const pct = Math.round(saving.totalSaved / saving.target * 100);
    if (pct >= 100) return `🎉 Défi terminé ! Vous avez économisé ${saving.totalSaved}€ en ${saving.currentWeek} semaines. Bravo !`;
    return `Semaine ${saving.currentWeek}/52 — ${saving.totalSaved}€ économisés (${pct}%). ${saving.target - saving.totalSaved}€ restants.`;
  },

  // ─── Astuces défiscalisation (via Claude web search) ─
  async getTaxTips(claudeKey, country, status, income) {
    if (!claudeKey) return null;
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 800,
          tools: [{ type: 'web_search_20250305', name: 'web_search' }],
          system: 'Tu es un conseiller fiscal pour indépendants et créateurs. Tu donnes des informations générales actualisées. Tu rappelles toujours que pour une situation personnelle, un comptable est recommandé.',
          messages: [{
            role: 'user',
            content: `Quelles sont les astuces de défiscalisation pour un ${status} en ${country} avec un CA d'environ ${income}€ ? Cherche les informations les plus récentes. Sois concret et actionnable.`
          }]
        })
      });
      const data = await r.json();
      return data.content.filter(b => b.type === 'text').map(b => b.text).join('');
    } catch { return null; }
  },

  // ─── Rendu UI bilan ───────────────────────────
  renderBilan() {
    const bilan = this.getBilan(15);
    const alerts = this.checkAlerts();
    const stockAlerts = this.checkStockAlerts();

    return `
    <div style="padding:1.1rem">
      <div class="sec-title">Bilan des 15 derniers jours</div>
      
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.5rem;margin-bottom:.8rem">
        <div style="background:var(--dark-mid);border:1px solid rgba(110,200,138,.3);padding:.8rem;text-align:center">
          <div style="font-size:.52rem;color:var(--muted);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.3rem">Facturé</div>
          <div style="font-size:1.1rem;color:var(--green);font-family:'Cormorant Garamond',serif">${bilan.income.toFixed(2)}€</div>
        </div>
        <div style="background:var(--dark-mid);border:1px solid rgba(224,80,80,.3);padding:.8rem;text-align:center">
          <div style="font-size:.52rem;color:var(--muted);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.3rem">Charges</div>
          <div style="font-size:1.1rem;color:var(--red);font-family:'Cormorant Garamond',serif">${bilan.charges.toFixed(2)}€</div>
        </div>
        <div style="background:var(--dark-mid);border:1px solid rgba(224,80,80,.2);padding:.8rem;text-align:center">
          <div style="font-size:.52rem;color:var(--muted);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.3rem">Dépenses</div>
          <div style="font-size:1.1rem;color:var(--red);font-family:'Cormorant Garamond',serif">${bilan.expenses.toFixed(2)}€</div>
        </div>
        <div style="background:var(--dark-mid);border:1px solid rgba(201,168,76,.4);padding:.8rem;text-align:center">
          <div style="font-size:.52rem;color:var(--muted);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.3rem">À vous</div>
          <div style="font-size:1.1rem;color:var(--gold);font-family:'Cormorant Garamond',serif">${bilan.net.toFixed(2)}€</div>
        </div>
      </div>

      ${alerts.length > 0 ? `
        <div style="margin-bottom:.7rem">
          ${alerts.map(a => `
            <div style="padding:.6rem;border:1px solid ${a.urgent ? 'var(--red)' : 'var(--gold)'};margin-bottom:.35rem;font-size:.58rem;color:${a.urgent ? 'var(--red)' : 'var(--gold-light)'}">
              ${a.urgent ? '⚠ URGENT — ' : '📅 '}${a.message}
            </div>
          `).join('')}
        </div>
      ` : ''}

      ${stockAlerts.length > 0 ? `
        <div style="margin-bottom:.7rem">
          ${stockAlerts.map(a => `<div style="padding:.5rem;border:1px solid var(--border);font-size:.56rem;color:var(--muted);margin-bottom:.3rem">${a}</div>`).join('')}
        </div>
      ` : ''}

      <div class="sep"></div>
      <div class="sec-title" style="margin-top:.6rem">Saisie rapide</div>
      
      <div style="display:flex;gap:.4rem;margin-bottom:.4rem">
        <select id="txType" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.58rem;padding:.45rem;outline:none">
          <option value="income">💰 Revenu</option>
          <option value="expense">💸 Dépense</option>
        </select>
        <input type="number" id="txAmount" placeholder="Montant €" style="flex:1"/>
      </div>
      <input type="text" id="txDesc" placeholder="Description — ou dictez vocalement" style="margin-bottom:.4rem"/>
      <div style="display:flex;gap:.4rem">
        <button class="voice-btn" id="financeVoiceBtn" onclick="startFinanceVoice()" style="flex:1;padding:.5rem">🎙 Dicter</button>
        <button class="btn btn-gold" onclick="addFinanceTransaction()" style="flex:2;padding:.5rem">+ Enregistrer</button>
      </div>

      <div class="sep"></div>
      <div class="sec-title" style="margin-top:.6rem">Actions</div>
      <button class="btn btn-ghost" onclick="showDeclaration()">📄 Générer ma déclaration</button>
      <button class="btn btn-ghost" onclick="showTaxTips()">💡 Astuces défiscalisation</button>
      <button class="btn btn-ghost" onclick="showStockManager()">📦 Gérer mon stock</button>
      <button class="btn btn-ghost" onclick="showEnvelopes()">✉ Enveloppes budgétaires</button>
      <button class="btn btn-ghost" onclick="showSavings()">🎯 Défis épargne</button>
    </div>`;
  },

  // ─── MODULE FISCAL ────────────────────────────
  TAX_LINKS: {
    fr: [
      { label: 'impots.gouv.fr', url: 'https://www.impots.gouv.fr/accueil', icon: '🏛' },
      { label: 'urssaf.fr', url: 'https://www.urssaf.fr/accueil.html', icon: '💼' },
      { label: 'autoentrepreneur.urssaf.fr', url: 'https://www.autoentrepreneur.urssaf.fr', icon: '🧾' },
    ],
    be: [
      { label: 'myminfin.be', url: 'https://www.myminfin.be', icon: '🏛' },
      { label: 'inasti.be', url: 'https://www.inasti.be', icon: '💼' },
    ],
    ch: [{ label: 'estv.admin.ch', url: 'https://www.estv.admin.ch', icon: '🏛' }],
    sn: [{ label: 'impotsetdomaines.gouv.sn', url: 'https://www.impotsetdomaines.gouv.sn', icon: '🏛' }],
    ca: [{ label: 'ARC Canada', url: 'https://www.canada.ca/fr/agence-revenu.html', icon: '🏛' }],
    ci: [{ label: 'dgi.gouv.ci', url: 'https://www.dgi.gouv.ci', icon: '🏛' }],
    cm: [{ label: 'impots.cm', url: 'https://www.impots.cm', icon: '🏛' }],
    default: [
      { label: 'impots.gouv.fr', url: 'https://www.impots.gouv.fr', icon: '🏛' },
      { label: 'urssaf.fr', url: 'https://www.urssaf.fr', icon: '💼' },
    ]
  },

  async generateTaxDeclaration(year, country, status, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant', 'Cle API requise.'); return; }
    const declarationDate = new Date().toLocaleString('fr-FR');
    const prompt = 'Regles fiscales en ' + (country||'France') + ' pour ' + year + ' pour un ' + (status||'travailleur independant') + '. Indique les taux applicables avec sources officielles, les charges deductibles, les formulaires a remplir. Cite les textes de loi consultes avec leurs dates exactes.';
    if (window.addChatMsg) addChatMsg('assistant', 'Recherche des lois fiscales en vigueur...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: 1500, messages: [{ role: 'user', content: prompt }] })
      });
      const data = await r.json();
      const result = data.content[0].text;
      const declaration = { id: 'tax_' + Date.now().toString(36), year, country: country||'France', status: status||'independant', result, declarationDate, archivedUntil: new Date(Date.now() + 10*365.25*24*3600*1000).toISOString() };
      const existing = JSON.parse(localStorage.getItem('moe_tax') || '[]');
      existing.unshift(declaration);
      localStorage.setItem('moe_tax', JSON.stringify(existing.slice(0,20)));
      if (window.addChatMsg) { addChatMsg('assistant', result); addChatMsg('assistant', 'Archive le ' + declarationDate + '. Bonne foi prouvee — 10 ans de conservation.'); }
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant', 'Erreur. Verifiez votre connexion.'); }
  },

  renderTaxPanel: function() {
    const countryMap = { France: 'fr', Belgique: 'be', Suisse: 'ch', Senegal: 'sn', Canada: 'ca' };
    const country = 'fr';
    const links = this.TAX_LINKS[country] || this.TAX_LINKS.default;
    const declarations = JSON.parse(localStorage.getItem('moe_tax') || '[]');
    const countries = ['France','Belgique','Suisse','Senegal','Cote d Ivoire','Cameroun','Canada','Maroc'];

    let linksHtml = links.map(function(l) {
      return '<a href="' + l.url + '" target="_blank" style="display:flex;align-items:center;gap:.5rem;padding:.6rem;border:1px solid var(--border);background:var(--dark-mid);text-decoration:none;margin-bottom:.3rem">' + l.icon + ' <span style="font-size:.56rem;color:var(--gold)">' + l.label + ' →</span></a>';
    }).join('');

    let declHtml = declarations.length > 0 ? '<div class="sec-title">Archives (' + declarations.length + ')</div>' + declarations.slice(0,5).map(function(d) { return '<div style="padding:.5rem;border:1px solid var(--border);margin-bottom:.3rem"><div style="font-size:.54rem;color:var(--text)">' + d.year + ' — ' + d.country + '</div><div style="font-size:.46rem;color:var(--muted)">' + d.declarationDate + '</div></div>'; }).join('') : '';

    let countryOpts = countries.map(function(c) { return '<option>' + c + '</option>'; }).join('');

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🧾 Declaration fiscale</div>' +
      '<p class="note">Pour tous — coiffeuse, plombier, photographe, creatrice, consultant. Or Eille AI recherche les lois en vigueur, calcule, archive. Preuve de bonne foi.</p>' +
      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem"><p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">Archive horodate — date exacte, sources consultees, lois en vigueur ce jour-la. En cas de litige — vous montrez votre bonne foi. Archive 10 ans.</p><p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;font-style:italic">— Madame Or Eille Studios</p></div>' +
      '<div class="sec-title">Acces direct a mon espace fiscal</div>' +
      linksHtml +
      '<div class="sec-title">Generer ma declaration</div>' +
      '<div style="display:flex;gap:.4rem"><input type="number" id="tax-year" value="' + new Date().getFullYear() + '" style="flex:1"/>' +
      '<select id="tax-country" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.56rem;padding:.4rem;outline:none">' + countryOpts + '</select></div>' +
      '<input type="text" id="tax-status" placeholder="Statut — ex: auto-entrepreneur, coiffeuse independante, photographe freelance..."/>' +
      '<button class="btn btn-gold" onclick="FINANCE.generateTaxDeclaration(document.getElementById(&quot;tax-year&quot;).value,document.getElementById(&quot;tax-country&quot;).value,document.getElementById(&quot;tax-status&quot;).value,window.CFG&&window.CFG.CLAUDE_KEY)">🧾 Rechercher les lois et generer ma declaration</button>' +
      '<p style="font-size:.48rem;color:#ef5350;line-height:1.7">⚠ Or Eille AI n est pas comptable. Ces informations sont indicatives. Consultez un professionnel pour validation.</p>' +
      declHtml +
    '</div>';
  }
};

window.FINANCE = FINANCE;

// ─── UI Functions ──────────────────────────────
function addFinanceTransaction() {
  const type = document.getElementById('txType')?.value;
  const amount = document.getElementById('txAmount')?.value;
  const desc = document.getElementById('txDesc')?.value;
  if (!amount || !desc) return;
  const tx = FINANCE.addTransaction(type, amount, desc, 'general');
  document.getElementById('txAmount').value = '';
  document.getElementById('txDesc').value = '';
  const msg = type === 'income'
    ? `Revenu enregistré : ${amount}€. Charges estimées : ${tx.charges}€. Net : ${tx.net}€.`
    : `Dépense enregistrée : ${amount}€ — ${desc}.`;
  if (window.addChatMsg) addChatMsg('assistant', msg);
  if (window.speak) speak(msg);
  refreshFinancePanel();
}

function startFinanceVoice() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return;
  const r = new SR(); r.lang = 'fr-FR'; r.continuous = false;
  r.onresult = async (e) => {
    const text = e.results[0][0].transcript;
    // Parser la commande vocale
    const claudeKey = getKey('claudeKey');
    if (claudeKey) {
      const resp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 150,
          messages: [{ role: 'user', content: `Parse cette commande financière et retourne JSON: {"type":"income"|"expense","amount":number,"description":"string"}. Commande: "${text}"` }]
        })
      });
      const d = await resp.json();
      try {
        const parsed = JSON.parse(d.content[0].text.replace(/```json|```/g,'').trim());
        document.getElementById('txType').value = parsed.type;
        document.getElementById('txAmount').value = parsed.amount;
        document.getElementById('txDesc').value = parsed.description;
        addFinanceTransaction();
      } catch { document.getElementById('txDesc').value = text; }
    } else {
      document.getElementById('txDesc').value = text;
    }
  };
  r.start();
}

async function showDeclaration() {
  const decl = FINANCE.generateDeclaration();
  const msg = `Votre déclaration du trimestre :\n\nCA brut : ${decl.ca_brut}€\nCharges sociales : ${decl.charges_sociales}€\nNet imposable : ${decl.net_imposable}€\nMontant à déclarer : ${decl.a_declarer}€\n\nUne copie PDF a été sauvegardée.`;
  if (window.addChatMsg) addChatMsg('assistant', msg);
  if (window.speak) speak(`Votre déclaration est prête. Montant à déclarer : ${decl.a_declarer} euros.`);
  showPanel('assistant');
}

async function showTaxTips() {
  const claudeKey = getKey('claudeKey');
  const profile = FINANCE.get().profile;
  if (!claudeKey) { alert('Clé Claude requise.'); return; }
  if (window.addChatMsg) addChatMsg('assistant', '🔍 Recherche des astuces de défiscalisation pour votre situation…');
  const tips = await FINANCE.getTaxTips(claudeKey, profile.country || 'FR', profile.status || 'micro', FINANCE.getBilan(365).income);
  if (tips && window.addChatMsg) addChatMsg('assistant', tips);
  showPanel('assistant');
}

function showStockManager() {
  // Afficher dans le chat
  const alerts = FINANCE.checkStockAlerts();
  const msg = alerts.length > 0 ? alerts.join('\n') : 'Votre stock est à jour. Aucune alerte.';
  if (window.addChatMsg) addChatMsg('assistant', msg);
  showPanel('assistant');
}

function showEnvelopes() {
  const d = FINANCE.get();
  if (d.envelopes.length === 0) {
    if (window.addChatMsg) addChatMsg('assistant', 'Aucune enveloppe configurée. Dictez vos enveloppes : "Loyer 800€, Courses 300€, Loisirs 150€, Épargne 200€"');
  } else {
    const msg = d.envelopes.map(e => `${e.name} : ${(e.budget - e.spent).toFixed(2)}€ restants sur ${e.budget}€`).join('\n');
    if (window.addChatMsg) addChatMsg('assistant', msg);
  }
  showPanel('assistant');
}

function showSavings() {
  const d = FINANCE.get();
  if (d.savings.length === 0) {
    if (window.addChatMsg) addChatMsg('assistant', 'Aucun défi épargne en cours. Voulez-vous démarrer le défi des 52 semaines ? À la fin vous aurez économisé 1378€.');
  } else {
    const msg = d.savings.map(s => {
      const pct = Math.round(s.totalSaved / s.target * 100);
      return `${s.name} : ${s.totalSaved}€ / ${s.target}€ (${pct}%)`;
    }).join('\n');
    if (window.addChatMsg) addChatMsg('assistant', msg);
  }
  showPanel('assistant');
}

function refreshFinancePanel() {
  const panel = document.getElementById('financeContent');
  if (panel) panel.innerHTML = FINANCE.renderBilan();
}

// Vérifier les alertes au démarrage
window.addEventListener('load', () => {
  setTimeout(() => {
    const alerts = FINANCE.checkAlerts();
    alerts.filter(a => a.urgent).forEach(a => {
      if (window.addChatMsg) addChatMsg('assistant', '⚠ ' + a.message);
      if (window.speak) speak(a.message);
    });
  }, 3000);
});
