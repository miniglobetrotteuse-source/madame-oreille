// ═══════════════════════════════════════════════════
//  TEXTES D'ACCUEIL — Or Eille AI v2.0
//  © 2026 Madame Or Eille Studios — Tous droits réservés
//  Validés par Judith — Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const WELCOME = {

  // Logo en filigrane — fond de chaque page d'accueil
  WATERMARK: `
    <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;overflow:hidden;z-index:0">
      <div style="font-size:12rem;opacity:.03;color:var(--gold);user-select:none;transform:rotate(-15deg)">👂</div>
    </div>`,

  // Wrapper commun pour tous les textes d'accueil
  wrap(content, panel) {
    return `
    <div style="position:relative;padding:1.2rem;background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.4);margin-bottom:.8rem;overflow:hidden">
      ${this.WATERMARK}
      <div style="position:relative;z-index:1">
        ${content}
        <p style="font-size:.44rem;color:rgba(196,153,58,.5);text-align:right;margin-top:.8rem;font-family:'Cormorant Garamond',serif;font-style:italic">— Madame Or Eille Studios</p>
      </div>
    </div>`;
  },

  TEXTS: {

    general: `
      <div style="text-align:center;margin-bottom:1rem">
        <div style="font-size:2.5rem;margin-bottom:.3rem">👂</div>
        <h2 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.4rem;margin-bottom:.2rem">Or Eille AI</h2>
        <p style="font-size:.5rem;color:var(--muted);letter-spacing:.15em;text-transform:uppercase">L'IA qui s'exécute au doigt et à l'œil</p>
      </div>
      <p style="font-size:.58rem;color:var(--text);line-height:1.9;margin-bottom:.7rem">
        Bonjour, je suis <strong style="color:var(--gold)">Or Eille</strong>, votre assistant intelligence artificielle, créé par Madame Or Eille Studios pour vous aider dans vos créations et votre quotidien.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.6rem">
        Je suis un outil — et même les humains se trompent. Vérifiez toujours les informations importantes auprès d'un professionnel.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.6rem">
        Ici, l'éthique n'est pas une option. Respect, dignité et bienveillance sont nos seules règles.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.6rem">
        Chaque utilisateur est responsable de ses actes. Madame Or Eille Studios décline toute responsabilité pour tout usage contraire à nos conditions générales.
      </p>
      <div style="background:rgba(239,83,80,.08);border:1px solid rgba(239,83,80,.2);padding:.6rem;margin-bottom:.5rem">
        <p style="font-size:.52rem;color:rgba(239,83,80,.85);line-height:1.8">
          Tout acte répréhensible par la loi — trafic, contrefaçon, harcèlement, contenu haineux, négationnisme — entraîne la révocation immédiate et définitive. Madame Or Eille Studios conserve le droit d'utiliser les contenus générés comme preuves et de porter plainte auprès des autorités compétentes.
        </p>
      </div>
      <p style="font-size:.52rem;color:var(--muted);line-height:1.7">
        En utilisant Or Eille AI, vous acceptez l'ensemble de ces conditions.
      </p>`,

    creation: `
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.6rem">🎨 Création</h3>
      <p style="font-size:.56rem;color:var(--text);line-height:1.9;margin-bottom:.6rem">
        Quelle que soit la lumière que vous voulez apporter au monde — un Reel, un documentaire, une chanson, un livre, un dessin animé — nous sommes honorés d'être là à sa naissance.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.6rem">
        Or Eille AI vous guide et vous accompagne à chaque étape. De la première idée jusqu'à la publication finale.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.6rem">
        <strong style="color:var(--text)">Tout ce que vous créez ici vous appartient.</strong> Vous êtes l'artiste. Vous êtes le propriétaire de votre œuvre. Or Eille AI est l'outil — pas le créateur.
      </p>
      <div style="background:rgba(245,166,35,.08);border:1px solid rgba(245,166,35,.25);padding:.6rem">
        <p style="font-size:.52rem;color:rgba(245,166,35,.9);line-height:1.8">
          <strong>Engagement de royalties — usage commercial uniquement</strong><br/>
          En cas d'exploitation commerciale d'une œuvre créée via Or Eille AI — vente, streaming, diffusion, synchronisation, publicité, licensing — Madame Or Eille Studios perçoit 10% des revenus commerciaux générés. Cet engagement est tacite dès la première utilisation à des fins commerciales et fait valeur de loi.<br/><br/>
          Usage personnel et partage gratuit — libre et sans redevance.
        </p>
      </div>`,

    publish: `
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.6rem">🚀 Publication</h3>
      <p style="font-size:.58rem;color:var(--text);line-height:1.9;margin-bottom:.5rem">
        Bravo. Le grand moment arrive.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.6rem">
        Nous sommes aussi impatients que vous de voir votre création prendre son envol. Nous avons été là depuis le début — nous sommes encore là pour les derniers pas. Pas de panique. On y va tranquillement, ensemble.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.6rem">
        Avant de publier — Or Eille AI vérifie tout avec vous. Les sous-titres, les hashtags, le format, les droits musicaux, la légende. Vous avez 60 secondes pour un dernier regard avant que votre œuvre parte dans le monde.
      </p>
      <div style="background:rgba(196,153,58,.08);border:1px solid rgba(196,153,58,.25);padding:.6rem">
        <p style="font-size:.52rem;color:var(--muted);line-height:1.8;font-style:italic">
          Rappelez-vous — le nombre de vues, de likes, de commentaires ne détermine pas la valeur de ce que vous avez créé. Ni la qualité de votre travail. Ni l'engagement que vous y avez mis. Nous sommes profondément fiers d'avoir partagé ce moment de création avec vous. Quelle que soit la réception — ce que vous avez fait existe. Et ça, personne ne peut vous l'enlever.
        </p>
      </div>`,

    protect: `
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.6rem">🛡 Mboka na biso — Notre Village</h3>
      <p style="font-size:.56rem;color:var(--text);line-height:1.9;margin-bottom:.6rem">
        Tout le monde n'est pas forcément bienveillant. Nous le savons. C'est pourquoi nous avons à cœur de protéger chaque membre de notre grande communauté — notre grande famille.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.5rem">
        <strong style="color:var(--text)">Ce que Mboka na biso fait pour vous</strong><br/>
        Or Eille AI filtre les messages haineux, les garde en mémoire pendant <strong style="color:var(--gold)">5 ans</strong>, et peut vous les fournir à votre demande pour des raisons juridiques. Il détecte les profils tendancieux et vous les signale.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.5rem">
        <strong style="color:var(--text)">Être membre du village, c'est aussi un engagement.</strong>
      </p>
      <div style="background:rgba(239,83,80,.08);border:1px solid rgba(239,83,80,.2);padding:.6rem">
        <p style="font-size:.52rem;color:rgba(239,83,80,.85);line-height:1.9">
          <strong>1er avertissement</strong> — contenu tendancieux détecté, rectification demandée.<br/>
          <strong>2ème avertissement</strong> — suspension 3 semaines.<br/>
          <strong>Révocation définitive</strong> — tout propos raciste, négationniste, niant l'esclavage, l'Holocauste ou tout génocide. Sans appel. Sans retour.<br/><br/>
          Le respect de la personne humaine est une valeur non négociable chez Madame Or Eille Studios.
        </p>
      </div>`,

    analyze: `
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.6rem">📊 Analyser</h3>
      <p style="font-size:.56rem;color:var(--text);line-height:1.9;margin-bottom:.6rem">
        Créer c'est bien. Comprendre c'est mieux.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.6rem">
        Ici nous vous aidons à lire ce qui se passe vraiment sur vos réseaux. Pas juste des chiffres — des explications. Pas juste des stats — des propositions concrètes pour faire mieux.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.6rem">
        Vous nous partagez vos chiffres. Or Eille AI les analyse, surveille les changements d'algorithme en temps réel, étudie votre niche. Tous les quinze jours — un rapport complet avec des recommandations adaptées à vous.
      </p>
      <p style="font-size:.48rem;color:rgba(196,153,58,.5);font-style:italic">
        La connexion automatique à vos réseaux sociaux sera disponible prochainement. Bonne nouvelle à venir.
      </p>`,

    daily: `
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.6rem">🏠 Quotidien</h3>
      <p style="font-size:.56rem;color:var(--text);line-height:1.9;margin-bottom:.6rem">
        Qui n'a jamais rêvé d'avoir un comptable, un gestionnaire de stock, un assistant courses et un GPS — tout en un, disponible à toute heure ?
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.5rem">
        Que vous soyez coiffeur, photographe, plombier, créateur ou simplement quelqu'un qui veut reprendre le contrôle de son quotidien — Or Eille AI simplifie ce qui prend du temps.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8">
        <strong style="color:var(--text)">Finances</strong> — suivez vos revenus, générez vos factures, relancez vos clients.<br/>
        <strong style="color:var(--text)">Stock</strong> — Or Eille AI mémorise ce que vous avez et vous alerte avant que vous en manquiez.<br/>
        <strong style="color:var(--text)">Courses</strong> — liste vocale, organisée par rayon, avec alertes promotions de votre supermarché préféré.<br/>
        <strong style="color:var(--text)">GPS</strong> — guidage vocal OpenStreetMap avec signalements communautaires en temps réel.
      </p>`,

    account: `
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.6rem">⚙ Mon compte</h3>
      <p style="font-size:.56rem;color:var(--text);line-height:1.9;margin-bottom:.6rem">
        Et si vous aviez votre propre Carson ?
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.6rem">
        Votre majordome personnel. Toujours disponible. Toujours discret. Il vous connaît, il anticipe, il s'adapte à vous — pas l'inverse.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.5rem">
        <strong style="color:var(--text)">Ce que vous gérez ici</strong><br/>
        Votre abonnement. Votre mémoire. Votre synchronisation multi-appareils. Votre avatar — âge, morphologie, style, coiffure, vêtements, voix, langue, langue des signes, position à l'écran.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.5rem">
        Choisissez parmi notre galerie de personnages — une vraie diversité. Africains, afrodescendants, caribéens, asiatiques, européens. Toutes les morphologies, tous les âges, toutes les coiffures. Grands, petits, ronds, sveltes, avec lunettes, avec canne, avec voile, avec gele. Artiste, business, traditionnel, contemporain, mélangé.
      </p>
      <p style="font-size:.52rem;color:var(--muted);line-height:1.7;font-style:italic">
        Votre avatar est un personnage de dessin animé — beau, soigné, clairement fictif. Un compagnon de travail. Pas un humain. Pas une relation.
      </p>
      <p style="font-size:.5rem;color:var(--muted);line-height:1.7">
        Configurez une fois — mémorisé pour toujours. Choisissez aussi la langue de votre interface, la langue de votre avatar et la langue de vos sous-titres — indépendamment les unes des autres. 12 langues disponibles.
      </p>`,

    mboka: `
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.6rem">🛡 Mboka na biso</h3>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.5rem">
        Notre Village. Votre espace protégé. Créez en paix.
      </p>
      <p style="font-size:.52rem;color:var(--muted);line-height:1.7">
        Preuves archivées 5 ans. Dossier de plainte sur demande. Madame Or Eille Studios se réserve le droit de porter plainte auprès des autorités compétentes.
      </p>`,

    music: `
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.6rem">🎵 Création musicale</h3>
      <p style="font-size:.56rem;color:var(--text);line-height:1.9;margin-bottom:.6rem">
        Nous sommes fiers et honorés d'être là à la naissance de votre musique.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.6rem">
        Tout ce que vous créez ici vous appartient. Vous êtes l'artiste. Or Eille AI est l'outil.
      </p>
      <div style="background:rgba(245,166,35,.08);border:1px solid rgba(245,166,35,.25);padding:.6rem">
        <p style="font-size:.52rem;color:rgba(245,166,35,.9);line-height:1.8">
          <strong>Engagement de royalties</strong><br/>
          En cas d'exploitation commerciale — Madame Or Eille Studios perçoit 10% des revenus. Usage personnel — gratuit et sans redevance.
        </p>
      </div>`,

    neuro: `
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.6rem">🧠 Accompagnement neurodivergent</h3>
      <p style="font-size:.56rem;color:var(--text);line-height:1.9;margin-bottom:.6rem">
        Chaque cerveau fonctionne différemment. Ici, pas de jugement. Pas de pression de performance.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.6rem">
        Des stratégies validées scientifiquement. Un accompagnement adapté à votre profil. Une orientation vers des professionnels spécialisés près de chez vous.
      </p>
      <p style="font-size:.5rem;color:var(--muted);line-height:1.7;font-style:italic">
        Or Eille AI n'est pas médecin. Il accompagne — pas diagnostique. Pour tout suivi médical, consultez un professionnel de santé.
      </p>`,

    safety: `
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.6rem">🛡 Sécurité</h3>
      <p style="font-size:.56rem;color:var(--text);line-height:1.9;margin-bottom:.6rem">
        Parce que sortir, rencontrer, explorer ne devrait jamais être une prise de risque.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.5rem">
        Check-in avant chaque sortie. Contacts de confiance alertés automatiquement. Fiche médicale d'urgence accessible par 4 tapes sur l'écran.
      </p>
      <p style="font-size:.52rem;color:#ef5350;line-height:1.7">
        ⚠ Cette fonctionnalité est confidentielle. Ne la mentionnez à personne.
      </p>`,

    brand: `
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.6rem">💼 Collaborations & Contrats</h3>
      <p style="font-size:.56rem;color:var(--text);line-height:1.9;margin-bottom:.6rem">
        Vous valez ce que vous valez. Pas moins parce que vous êtes qui vous êtes.
      </p>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.8;margin-bottom:.5rem">
        Connaissez votre valeur marchande. Analysez chaque contrat avant de signer. Exigez des conditions équivalentes à tous les créateurs. Facturez correctement.
      </p>
      <p style="font-size:.5rem;color:var(--muted);font-style:italic">
        Or Eille AI n'est pas avocat. Pour validation légale, consultez un professionnel du droit.
      </p>`,

    freemium: `
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.1rem;margin-bottom:.6rem">Version gratuite</h3>
      <p style="font-size:.54rem;color:var(--muted);line-height:1.9;margin-bottom:.5rem">
        ✦ 10 images par session<br/>
        ✦ 2 vidéos de 3 minutes par session<br/>
        ✦ 3 heures de conversation par session<br/>
        ✦ Pause de 4h après session 1 — pause de 8h après session 2<br/>
        ✦ Reset à minuit heure locale
      </p>
      <p style="font-size:.52rem;color:var(--muted);line-height:1.7">
        Vous serez prévenu(e) à 3 unités restantes et à 1 unité restante. Pensez à sauvegarder votre travail.
      </p>`,
  },

  // Afficher un texte avec filigrane
  show(panel) {
    const text = this.TEXTS[panel];
    if (!text) return '';
    return this.wrap(text, panel);
  },

  wrap(content, panel) {
    return `
    <div style="position:relative;padding:1.2rem;background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.35);margin-bottom:.8rem;overflow:hidden">
      <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;overflow:hidden;z-index:0">
        <div style="font-size:12rem;opacity:.04;color:#C4993A;user-select:none;transform:rotate(-15deg)">👂</div>
      </div>
      <div style="position:relative;z-index:1">
        ${content}
        <p style="font-size:.44rem;color:rgba(196,153,58,.45);text-align:right;margin-top:.8rem;font-family:'Cormorant Garamond',serif;font-style:italic">— Madame Or Eille Studios</p>
      </div>
    </div>`;
  },

  // ─── Indicateur de quota permanent ───────────
  renderQuotaBar() {
    if (!window.FREEMIUM) return '';
    const d = FREEMIUM.getStats?.();
    if (!d || d.isPaid) return '';

    const imgR = d.imagesMax - d.imagesUsed;
    const vidR = d.videosMax - d.videosUsed;
    const timeR = Math.max(0, d.minutesMax - d.minutesUsed);
    const warn = v => v <= 1 ? '#ef5350' : v <= 3 ? '#F5A623' : '#81c784';

    return `
    <div id="quota-bar-inner" style="display:flex;gap:.6rem;flex:1;align-items:center;flex-wrap:wrap">
      <span style="font-size:.44rem;color:${warn(imgR)}">🖼 ${imgR}/${d.imagesMax} images</span>
      <span style="font-size:.44rem;color:${warn(vidR)}">🎬 ${vidR}/${d.videosMax} vidéos</span>
      <span style="font-size:.44rem;color:${timeR < 15 ? '#ef5350' : 'var(--muted)'}">⏱ ${Math.floor(timeR/60)}h${String(timeR%60).padStart(2,'0')}m</span>
    </div>`;
  },

  // ─── Alertes préventives ──────────────────────
  checkAndAlert() {
    if (!window.FREEMIUM) return;
    const d = FREEMIUM.getStats?.();
    if (!d || d.isPaid) return;
    const imgR = d.imagesMax - d.imagesUsed;
    const vidR = d.videosMax - d.videosUsed;
    const timeR = Math.max(0, d.minutesMax - d.minutesUsed);
    if (imgR === 3 && window.addChatMsg) addChatMsg('assistant', '⚠ Il vous reste 3 images gratuites. Pensez à sauvegarder votre travail.');
    if (imgR === 1 && window.addChatMsg) addChatMsg('assistant', '⚠ Dernière image gratuite de cette session. Sauvegardez maintenant.');
    if (vidR === 1 && window.addChatMsg) addChatMsg('assistant', '🎬 Dernière vidéo gratuite. Sauvegardez votre travail.');
    if (timeR === 15 && window.addChatMsg) addChatMsg('assistant', '⏱ 15 minutes de conversation restantes. Pensez à sauvegarder.');
  },

  // ─── Célébration après publication ────────────
  showCelebration() {
    const congrats = ['Bravo','Congratulations','Hongera','Ayeye','Félicitations','Mabrook','Parabéns','Bravissimo','Glückwunsch','Tebrikler','Поздравляю','बधाई','恭喜','おめでとう','축하해요'];
    const modal = document.createElement('div');
    modal.id = 'celebration-modal';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.9);z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:2rem';
    modal.innerHTML = `
      <div style="text-align:center;animation:fadeIn .5s ease">
        <div style="font-size:4rem;margin-bottom:1rem;animation:pulse 1s infinite">👂</div>
        <div style="font-size:1.8rem;color:var(--gold);font-family:'Cormorant Garamond',serif;font-style:italic;margin-bottom:1rem;line-height:1.6">
          ${congrats.slice(0,5).join(' • ')}
        </div>
        <div style="font-size:.9rem;color:var(--gold);font-family:'Cormorant Garamond',serif;font-style:italic;margin-bottom:.5rem">
          ${congrats.slice(5,10).join(' • ')}
        </div>
        <div style="font-size:.7rem;color:rgba(196,153,58,.6);margin-bottom:1.5rem">
          ${congrats.slice(10).join(' • ')}
        </div>
        <p style="font-size:.6rem;color:var(--muted);font-style:italic;margin-bottom:.3rem">
          Votre œuvre existe maintenant.
        </p>
        <p style="font-size:.58rem;color:var(--muted);font-style:italic">
          Nous sommes fiers de vous.
        </p>
        <p style="font-size:.44rem;color:rgba(196,153,58,.4);margin-top:1rem;font-family:'Cormorant Garamond',serif;font-style:italic">— Madame Or Eille Studios</p>
      </div>`;
    document.body.appendChild(modal);
    setTimeout(() => modal.remove(), 5000);
  },

  // ─── Initialiser ──────────────────────────────
  init() {
    // Barre de quota
    if (window.FREEMIUM) {
      const d = FREEMIUM.getStats?.();
      if (d && !d.isPaid) {
        const bar = document.createElement('div');
        bar.id = 'quota-bar';
        bar.style.cssText = 'position:fixed;bottom:60px;left:0;right:0;background:rgba(15,15,15,.95);border-top:1px solid var(--border);padding:.35rem .8rem;z-index:8000;display:flex;gap:.5rem;align-items:center;font-family:\'Josefin Sans\',sans-serif';
        bar.innerHTML = this.renderQuotaBar() + `<button onclick="FREEMIUM.goToPay()" style="padding:.2rem .5rem;background:var(--gold);color:var(--dark);border:none;font-family:'Josefin Sans',sans-serif;font-size:.44rem;cursor:pointer;white-space:nowrap;margin-left:auto">18€ illimité</button>`;
        document.body.appendChild(bar);
        setInterval(() => {
          const inner = document.getElementById('quota-bar-inner');
          if (inner) inner.outerHTML = this.renderQuotaBar();
          this.checkAndAlert();
        }, 60000);
      }
    }
  }
};

window.WELCOME = WELCOME;
window.addEventListener('load', () => setTimeout(() => WELCOME.init(), 2000));
