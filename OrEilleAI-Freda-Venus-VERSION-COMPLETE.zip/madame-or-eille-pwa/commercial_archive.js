// ═══════════════════════════════════════════════════
//  ARCHIVE COMMERCIALE — Or Eille AI v1.0
//  Dossier complet par collaboration
//  Tout archivé 10 ans — preuve en cas de litige
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const ARCHIVE = {
  KEY: 'moe_archive',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { collaborations: [] }; }
    catch { return { collaborations: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Créer un dossier de collaboration ────────
  createDossier(params) {
    const d = this.get();
    const dossier = {
      id: 'arch_' + Date.now().toString(36),
      brand: params.brand,
      contact: params.contact,
      contactEmail: params.contactEmail || '',
      contactPhone: params.contactPhone || '',
      type: params.type || 'partenariat',
      startDate: params.startDate || new Date().toISOString().split('T')[0],
      endDate: params.endDate || '',
      amount: params.amount || '',
      currency: params.currency || 'EUR',
      paid: params.paid || false,
      paidDate: params.paidDate || '',
      deliverables: params.deliverables || '',
      status: 'active',
      exchanges: [],
      documents: [],
      createdAt: new Date().toISOString(),
      archiveUntil: new Date(Date.now() + 10 * 365.25 * 24 * 3600 * 1000).toISOString(),
    };
    d.collaborations.unshift(dossier);
    this.save(d);
    if (window.addChatMsg) addChatMsg('assistant', '✅ Dossier "' + params.brand + '" cree. Archive jusqu au ' + new Date(dossier.archiveUntil).getFullYear() + '.');
    document.getElementById('archiveContent').innerHTML = ARCHIVE.renderPanel();
    return dossier;
  },

  // ─── Ajouter un échange ───────────────────────
  addExchange(dossierId, content, type, contactName) {
    const d = this.get();
    const dossier = d.collaborations.find(function(c) { return c.id === dossierId; });
    if (!dossier) return;
    const exchange = {
      id: Date.now().toString(),
      content,
      type: type || 'message',
      contact: contactName || dossier.contact,
      at: new Date().toISOString(),
      timestamp: new Date().toLocaleString('fr-FR'),
    };
    dossier.exchanges.push(exchange);
    this.save(d);
    if (window.addChatMsg) addChatMsg('assistant', '✅ Echange enregistre — ' + exchange.timestamp + '. Si quelqu un dit "on n a jamais dit ca" — vous avez la preuve.');
    document.getElementById('archiveContent').innerHTML = ARCHIVE.renderDossier(dossierId);
  },

  // ─── Marquer comme payée ──────────────────────
  markPaid(dossierId, amount, date) {
    const d = this.get();
    const dossier = d.collaborations.find(function(c) { return c.id === dossierId; });
    if (!dossier) return;
    dossier.paid = true;
    dossier.amount = amount || dossier.amount;
    dossier.paidDate = date || new Date().toISOString().split('T')[0];
    dossier.exchanges.push({
      id: Date.now().toString(),
      content: 'Paiement recu — ' + (amount || dossier.amount) + ' ' + dossier.currency,
      type: 'paiement',
      contact: 'Systeme',
      at: new Date().toISOString(),
      timestamp: new Date().toLocaleString('fr-FR'),
    });
    this.save(d);
    if (window.addChatMsg) addChatMsg('assistant', '✅ Paiement enregistre — ' + (amount || dossier.amount) + ' ' + dossier.currency + ' le ' + dossier.paidDate + '.');
    document.getElementById('archiveContent').innerHTML = ARCHIVE.renderDossier(dossierId);
  },

  // ─── Recherche dans les archives ──────────────
  search(query) {
    const d = this.get();
    const q = query.toLowerCase();
    const results = d.collaborations.filter(function(c) {
      return c.brand.toLowerCase().includes(q) ||
             c.contact.toLowerCase().includes(q) ||
             c.deliverables.toLowerCase().includes(q) ||
             c.exchanges.some(function(e) { return e.content.toLowerCase().includes(q); });
    });
    if (results.length === 0) {
      if (window.addChatMsg) addChatMsg('assistant', 'Aucun resultat pour "' + query + '".');
      return;
    }
    let msg = results.length + ' dossier(s) trouve(s) pour "' + query + '" :\n\n';
    results.forEach(function(c) {
      msg += '📁 ' + c.brand + ' — ' + c.contact + '\n';
      msg += '   ' + c.startDate + ' — ' + (c.amount ? c.amount + ' ' + c.currency : 'montant non renseigne') + '\n';
      const matchingExchanges = c.exchanges.filter(function(e) { return e.content.toLowerCase().includes(q); });
      if (matchingExchanges.length > 0) {
        msg += '   Echanges correspondants :\n';
        matchingExchanges.slice(0,3).forEach(function(e) {
          msg += '   • ' + e.timestamp + ' — ' + e.content.substring(0, 80) + '\n';
        });
      }
      msg += '\n';
    });
    if (window.addChatMsg) addChatMsg('assistant', msg);
  },

  renderDossier: function(dossierId) {
    const d = this.get();
    const dossier = d.collaborations.find(function(c) { return c.id === dossierId; });
    if (!dossier) return ARCHIVE.renderPanel();

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.6rem">' +

      '<div style="display:flex;align-items:center;gap:.4rem">' +
        '<button onclick="document.getElementById(\'archiveContent\').innerHTML=ARCHIVE.renderPanel()" style="background:transparent;border:none;color:var(--gold);font-size:.8rem;cursor:pointer">←</button>' +
        '<div style="flex:1">' +
          '<div style="font-size:.62rem;color:var(--text);font-weight:bold">' + dossier.brand + '</div>' +
          '<div style="font-size:.46rem;color:var(--muted)">' + dossier.contact + ' — ' + dossier.type + ' — ' + dossier.startDate + '</div>' +
        '</div>' +
        '<span style="font-size:.46rem;padding:.2rem .4rem;background:' + (dossier.paid?'rgba(129,199,132,.2)':'rgba(239,83,80,.1)') + ';border:1px solid ' + (dossier.paid?'rgba(129,199,132,.4)':'rgba(239,83,80,.3)') + ';color:' + (dossier.paid?'#81c784':'#ef5350') + '">' + (dossier.paid?'✅ Payee':'⏳ En attente') + '</span>' +
      '</div>' +

      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem;font-size:.5rem">' +
        '<div style="padding:.4rem;border:1px solid var(--border)"><div style="color:var(--muted)">Montant</div><div style="color:var(--gold)">' + (dossier.amount || 'Non renseigne') + ' ' + dossier.currency + '</div></div>' +
        '<div style="padding:.4rem;border:1px solid var(--border)"><div style="color:var(--muted)">Prestations</div><div style="color:var(--text)">' + (dossier.deliverables || '-') + '</div></div>' +
        '<div style="padding:.4rem;border:1px solid var(--border)"><div style="color:var(--muted)">Contact</div><div style="color:var(--text)">' + dossier.contact + '</div></div>' +
        '<div style="padding:.4rem;border:1px solid var(--border)"><div style="color:var(--muted)">Archive jusqu au</div><div style="color:var(--text)">' + new Date(dossier.archiveUntil).getFullYear() + '</div></div>' +
      '</div>' +

      (!dossier.paid ? '<button class="btn btn-gold" onclick="const a=prompt(\'Montant recu ?\');if(a)ARCHIVE.markPaid(\'' + dossier.id + '\',a,\'\')">✅ Marquer comme payee</button>' : '') +

      '<div class="sec-title">Ajouter un echange</div>' +
      '<textarea id="arch-exchange" placeholder="Ce qui a ete dit, decide, convenu... Date et heure sont enregistrees automatiquement." style="min-height:70px"></textarea>' +
      '<div style="display:flex;gap:.3rem">' +
        ['message','email','appel','reunion','accord','litige'].map(function(t) {
          return '<button onclick="document.querySelectorAll(\'.arch-type\').forEach(function(b){b.style.background=\'var(--dark-mid)\';b.style.color=\'var(--muted)\'});this.style.background=\'rgba(196,153,58,.2)\';this.style.color=\'var(--gold)\';document.getElementById(\'arch-type\').value=\'' + t + '\'" class="arch-type" style="flex:1;padding:.25rem .1rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:\'Josefin Sans\',sans-serif;font-size:.42rem;cursor:pointer">' + t + '</button>';
        }).join('') +
        '<input type="hidden" id="arch-type" value="message"/>' +
      '</div>' +
      '<button class="btn btn-ghost" onclick="const c=document.getElementById(\'arch-exchange\').value;if(c){ARCHIVE.addExchange(\'' + dossier.id + '\',c,document.getElementById(\'arch-type\').value,\'\');document.getElementById(\'arch-exchange\').value=\'\'}">📝 Enregistrer l echange</button>' +

      (dossier.exchanges.length > 0 ? (
        '<div class="sec-title">Historique (' + dossier.exchanges.length + ' echanges)</div>' +
        dossier.exchanges.slice().reverse().map(function(e) {
          const typeColors = { message:'var(--muted)', email:'#6BA3D6', appel:'#81c784', reunion:'#C4993A', accord:'#81c784', litige:'#ef5350', paiement:'#81c784' };
          return '<div style="padding:.5rem;border-left:3px solid ' + (typeColors[e.type]||'var(--muted)') + ';background:var(--dark-mid);margin-bottom:.3rem">' +
            '<div style="font-size:.44rem;color:' + (typeColors[e.type]||'var(--muted)') + ';margin-bottom:.2rem">' + e.timestamp + ' — ' + e.type.toUpperCase() + (e.contact ? ' — ' + e.contact : '') + '</div>' +
            '<div style="font-size:.52rem;color:var(--text);line-height:1.6">' + e.content + '</div>' +
          '</div>';
        }).join('')
      ) : '<div style="text-align:center;padding:1rem;color:var(--muted);font-size:.52rem">Aucun echange enregistre pour l instant.</div>') +

    '</div>';
  },

  renderPanel: function() {
    const d = this.get();

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +

      '<div class="sec-title">📁 Archive commerciale</div>' +
      '<p class="note">Un dossier complet par collaboration. Tout archive 10 ans. Le dix-sept mars a dix-sept heures cinquante — ils ont dit ca. Preuve.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">' +
          'Contrat du 3 aout 2023. Prestation. Montant. Qui a paye. Tous les echanges.' +
          'Mode copie — l original reste dans votre email, Instagram, WhatsApp. Or Eille AI fait une copie dans le dossier. Deux endroits. Double securite. Vous ne changez rien a vos habitudes.' +
          'Aujourd hui semi-automatique — vous collez les echanges. Bientot entierement automatique.' +
        '</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div style="display:flex;gap:.4rem">' +
        '<input type="text" id="arch-search" placeholder="Rechercher — marque, contact, date, montant..." style="flex:1"/>' +
        '<button onclick="ARCHIVE.search(document.getElementById(\'arch-search\').value)" style="padding:.5rem .7rem;background:var(--gold);color:var(--dark);border:none;font-size:.6rem;cursor:pointer">🔍</button>' +
      '</div>' +

      '<div class="sec-title">Nouveau dossier</div>' +
      '<input type="text" id="arch-brand" placeholder="Nom de la marque ou du client"/>' +
      '<input type="text" id="arch-contact" placeholder="Nom du contact"/>' +
      '<input type="text" id="arch-email" placeholder="Email du contact"/>' +
      '<input type="text" id="arch-amount" placeholder="Montant convenu — ex: 500 EUR"/>' +
      '<textarea id="arch-deliverables" placeholder="Prestations — ex: 2 Reels, 1 Story, 1 mention..." style="min-height:50px"></textarea>' +
      '<input type="date" id="arch-date" style="background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:\'Josefin Sans\',sans-serif;font-size:.56rem;padding:.45rem;outline:none;width:100%"/>' +
      '<button class="btn btn-gold" onclick="ARCHIVE.createDossier({brand:document.getElementById(\'arch-brand\').value,contact:document.getElementById(\'arch-contact\').value,contactEmail:document.getElementById(\'arch-email\').value,amount:document.getElementById(\'arch-amount\').value,deliverables:document.getElementById(\'arch-deliverables\').value,startDate:document.getElementById(\'arch-date\').value})">📁 Creer le dossier</button>' +

      (d.collaborations.length > 0 ? (
        '<div class="sec-title">Dossiers (' + d.collaborations.length + ')</div>' +
        d.collaborations.map(function(c) {
          return '<div onclick="document.getElementById(\'archiveContent\').innerHTML=ARCHIVE.renderDossier(\'' + c.id + '\')" style="cursor:pointer;padding:.6rem;border:1px solid ' + (c.paid?'rgba(129,199,132,.3)':'var(--border)') + ';background:var(--dark-mid);margin-bottom:.3rem">' +
            '<div style="display:flex;justify-content:space-between;align-items:center">' +
              '<div style="font-size:.56rem;color:var(--text);font-weight:bold">' + c.brand + '</div>' +
              '<span style="font-size:.44rem;color:' + (c.paid?'#81c784':'#ef5350') + '">' + (c.paid?'✅ Payee':'⏳ En attente') + '</span>' +
            '</div>' +
            '<div style="font-size:.46rem;color:var(--muted);margin-top:.2rem">' + c.contact + ' — ' + c.startDate + ' — ' + (c.amount||'?') + ' ' + c.currency + ' — ' + c.exchanges.length + ' echange(s)</div>' +
          '</div>';
        }).join('')
      ) : '<div style="text-align:center;padding:1.5rem;color:var(--muted);font-size:.54rem">Aucun dossier. Creez votre premier dossier de collaboration.</div>') +

    '</div>';
  }
};

window.ARCHIVE = ARCHIVE;
