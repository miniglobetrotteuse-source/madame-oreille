# Atelier Visuel — Madame Or Eille Studios
## Technical Brief & Deployment Package
### Prepared for Jeff — 14 May 2026

---

Cher Jeff,

Il y a des personnes que la vie place sur notre chemin au bon moment, et qui, par leur générosité, leur intelligence et leur humanité, transforment ce qui semblait compliqué en quelque chose de possible. Tu es l'une de ces personnes.

Merci pour tout ce que tu as fait — pour Le Jardin Intérieur, pour ta patience, pour les heures que tu as offertes sans jamais compter. Merci pour tout ce que tu fais — cette disponibilité tranquille, cette façon d'écouter avant de répondre, de comprendre avant d'agir. Et merci, surtout, pour tout ce que tu es : un homme bon, fiable, et brillant, dont la présence dans ce projet est une chance que je ne prends pas à la légère.

Ce document contient le brief technique complet pour l'Atelier Visuel. Le code est livré prêt à déployer — ta charge de travail devrait se limiter à la configuration des clés API, quelques ajustements d'intégration, et un `vercel deploy`. Tout le reste est déjà implémenté.

Avec toute ma reconnaissance et mon amitié sincère,
**Judith — Madame Or Eille Studios**

---

## Stack & Architecture

```
Frontend : Vanilla JS + Canvas API — aucun framework, aucune dépendance npm
PWA      : Web App Manifest + Service Worker (Cache-First strategy)
Hosting  : Vercel (static, vercel.json fourni)
Storage  : localStorage uniquement — zero backend, zero database
```

### APIs externes

| Service | Endpoint | Usage | Auth |
|---|---|---|---|
| Anthropic Claude | `api.anthropic.com/v1/messages` | Assistant + analyse image/vidéo + web search | `x-api-key` header |
| Replicate | `api.replicate.com/v1/predictions` | Inpainting + upscaling | `Authorization: Token` header |
| Remove.bg | `api.remove.bg/v1.0/removebg` | Background removal | `X-Api-Key` header |

### Modèles Replicate

```javascript
// Inpainting
const INPAINT_MODEL = '95b7223104132402a9ae91cc677285bc5eb997834bd2349fa486f53910fd68b3'
// stability-ai/stable-diffusion-inpainting

// Upscaling
const UPSCALE_MODEL = 'nightmareai/real-esrgan:42fed1c4974146d4d2414e2be2c5277c7fcf05fcc3a73abf41610695738c1d7b'
// real-esrgan x2/x4 upscaling
```

### Claude model
```javascript
const CLAUDE_MODEL = 'claude-sonnet-4-20250514'
// max_tokens: 1000 pour chat, 2000 pour rédaction longue
```

---

## Configuration (index.html — bloc CFG)

```javascript
const CFG = {
  REPLICATE_KEY:  '',   // r8_xxx
  REMOVEBG_KEY:   '',   // xxx
  CLAUDE_KEY:     '',   // sk-ant-xxx
  INPAINT_VERSION: '95b7223104132402a9ae91cc677285bc5eb997834bd2349fa486f53910fd68b3',
  UPSCALE_VERSION: '42fed1c4974146d4d2414e2be2c5277c7fcf05fcc3a73abf41610695738c1d7b',
  CLAUDE_MODEL:    'claude-sonnet-4-20250514',
  FRAMES_INTERVAL: 2,   // secondes entre chaque frame pour analyse vidéo
  MAX_FRAMES:      20,  // limite frames envoyées à Claude
};
```

---

## Fonctionnalités & Implémentation

### 1. Inpainting (composition d'image)

**Flow :**
1. Base image → `<canvas>` (baseCanvas)
2. Mask painting → `<canvas>` (maskCanvas) via mouse/touch events
3. Mask export → `canvas.toDataURL('image/png')` — pixels peints = blanc, reste = noir
4. POST `/v1/predictions` Replicate avec `image` (base64), `mask` (base64), `prompt`
5. Polling `GET /v1/predictions/{id}` toutes les 2s jusqu'à `status === 'succeeded'`
6. Résultat affiché + téléchargeable

**3 modes de prompt :**
- Image référence : prompt générique "apply texture from reference"
- Texte : textarea → prompt direct
- Vocal : `window.SpeechRecognition` (fr-FR, continuous) → textarea → prompt

**Remove.bg :**
```javascript
// Appelé automatiquement à l'upload de l'image de référence
const fd = new FormData()
fd.append('image_file', file)
fd.append('size', 'auto')
fetch('https://api.remove.bg/v1.0/removebg', {
  method: 'POST',
  headers: { 'X-Api-Key': key },
  body: fd
})
```

---

### 2. Upscaling

```javascript
// POST Replicate avec real-esrgan
{
  version: CFG.UPSCALE_VERSION,
  input: { image: base64DataUrl, scale: 2, face_enhance: false }
}
// Polling identique à l'inpainting
```

---

### 3. Analyse vidéo de référence — Frame extraction → Claude vision

C'est la fonctionnalité la plus originale. L'utilisatrice uploade une vidéo (TikTok, Instagram, etc.) téléchargée sur son téléphone. L'appli extrait les frames clés et les envoie à Claude pour analyse esthétique.

**Implémentation :**

```javascript
async function analyzeVideo(file) {
  // 1. Créer un HTMLVideoElement off-screen
  const video = document.createElement('video')
  video.src = URL.createObjectURL(file)
  await new Promise(r => video.onloadedmetadata = r)

  // 2. Extraire les frames toutes les CFG.FRAMES_INTERVAL secondes
  const frames = []
  const canvas = document.createElement('canvas')
  canvas.width = 512  // resize pour réduire la taille base64
  canvas.height = Math.round(512 * video.videoHeight / video.videoWidth)
  const ctx = canvas.getContext('2d')

  for (let t = 0; t < video.duration && frames.length < CFG.MAX_FRAMES; t += CFG.FRAMES_INTERVAL) {
    video.currentTime = t
    await new Promise(r => video.onseeked = r)
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
    frames.push(canvas.toDataURL('image/jpeg', 0.7))  // JPEG 70% qualité
  }

  // 3. Construire le message Claude multi-images
  const content = [
    ...frames.map(f => ({
      type: 'image',
      source: { type: 'base64', media_type: 'image/jpeg', data: f.split(',')[1] }
    })),
    {
      type: 'text',
      text: `Analyse ces ${frames.length} frames extraites d'une vidéo de référence.
             Décris précisément : palette de couleurs, ambiance lumineuse, type de mouvement de caméra,
             effets visuels, rythme, composition. Puis propose comment reproduire cette esthétique
             dans un intérieur avec des fauteuils sculptés, un tapis arc-en-ciel et un téléphone vintage.
             Sois précis et créatif, pas générique.`
    }
  ]

  // 4. Appel Claude API
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': CFG.CLAUDE_KEY,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: CFG.CLAUDE_MODEL,
      max_tokens: 1000,
      messages: [{ role: 'user', content }]
    })
  })

  const data = await response.json()
  return data.content[0].text
}
```

---

### 4. Export vidéo 10 secondes

**Technique :** Canvas API + MediaRecorder + requestAnimationFrame

```javascript
async function exportVideo(movement = 'tour-piece', durationSec = 10) {
  const W = 1080, H = 1920  // 9:16 Reels
  const canvas = document.createElement('canvas')
  canvas.width = W; canvas.height = H
  const ctx = canvas.getContext('2d')

  // MediaRecorder setup
  const stream = canvas.captureStream(30)
  const recorder = new MediaRecorder(stream, {
    mimeType: 'video/webm;codecs=vp9',
    videoBitsPerSecond: 5_000_000
  })
  const chunks = []
  recorder.ondataavailable = e => chunks.push(e.data)

  // Keyframes par mouvement
  const KEYFRAMES = {
    'tour-piece':    [{ x:0, y:0, s:1.1 }, { x:-0.06, y:-0.04, s:1.18 }, { x:0.06, y:0.04, s:1.12 }, { x:0, y:0, s:1.1 }],
    'gauche-droite': [{ x:0, y:0, s:1.15 }, { x:-0.08, y:0, s:1.15 }, { x:0, y:0, s:1.0 }],
    'droite-gauche': [{ x:0, y:0, s:1.15 }, { x:0.08, y:0, s:1.15 }, { x:0, y:0, s:1.0 }],
    'haut-bas':      [{ x:0, y:0, s:1.15 }, { x:0, y:-0.06, s:1.15 }, { x:0, y:0, s:1.0 }],
    'bas-haut':      [{ x:0, y:0, s:1.15 }, { x:0, y:0.06, s:1.15 }, { x:0, y:0, s:1.0 }],
    'zoom-in':       [{ x:0, y:0, s:1.0 },  { x:0, y:0, s:1.3 },      { x:0, y:0, s:1.15 }],
    'zoom-out':      [{ x:0, y:0, s:1.3 },  { x:0, y:0, s:1.0 },      { x:0, y:0, s:1.05 }],
  }

  const kf = KEYFRAMES[movement]
  const FPS = 30, totalFrames = durationSec * FPS

  recorder.start()

  for (let f = 0; f < totalFrames; f++) {
    const t = f / totalFrames
    const seg = Math.min(Math.floor(t * (kf.length - 1)), kf.length - 2)
    const segT = easeInOut((t * (kf.length - 1)) - seg)
    const scale = lerp(kf[seg].s, kf[seg+1].s, segT)
    const ox    = lerp(kf[seg].x || 0, kf[seg+1].x || 0, segT)
    const oy    = lerp(kf[seg].y || 0, kf[seg+1].y || 0, segT)

    ctx.fillStyle = '#1a1410'
    ctx.fillRect(0, 0, W, H)

    const imgAR = sourceImg.width / sourceImg.height
    const dh = H * scale, dw = dh * imgAR
    ctx.drawImage(sourceImg, (W-dw)/2 + ox*W, (H-dh)/2 + oy*H, dw, dh)

    await new Promise(r => setTimeout(r, 1000/FPS))
  }

  recorder.stop()
  await new Promise(r => recorder.onstop = r)

  // Audio mixing (intro + outro sounds) via AudioContext + OfflineAudioContext
  // Si soundIntroUrl ou soundOutroUrl définis : merger avec la vidéo via ffmpeg.wasm
  // Sinon : export vidéo seule
  const blob = new Blob(chunks, { type: 'video/webm' })
  downloadBlob(blob, 'madame-or-eille-reel.webm')
}

const lerp = (a, b, t) => a + (b-a)*t
const easeInOut = t => t < 0.5 ? 2*t*t : -1+(4-2*t)*t
```

**Note :** pour le mixing audio (sons signature intro/outro), intégrer `@ffmpeg/ffmpeg` (ffmpeg.wasm) — ~30MB gzippé, chargé en lazy loading uniquement si des sons sont configurés.

---

### 5. Mémoire persistante (memory.js)

Voir `memory.js` fourni. Architecture :

```
localStorage keys :
  moe_profile      → { name, description, currentProjects, updatedAt }
  moe_assets       → { [assetName]: { dataUrl, savedAt } }
  moe_sounds       → { intro: dataUrl, outro: dataUrl }
  moe_prefs        → { lang, movement, soundOn, font, template }
  moe_api_keys     → { replicate, removebg, claude }
  moe_history      → [ { role, content, at } ] (100 entries max, FIFO)
  moe_current_work → { description, savedAt }
```

**Injection dans le system prompt Claude :**
```javascript
// MEM.buildSystemPrompt() construit un system prompt enrichi
// incluant le profil, les assets, le projet en cours,
// et les 20 derniers échanges de l'historique
const systemPrompt = MEM.buildSystemPrompt() + MEM.QUALITY_PROMPT
```

---

### 6. Assistant Claude — Web Search

```javascript
// Activer la recherche web native Claude
body: JSON.stringify({
  model: CFG.CLAUDE_MODEL,
  max_tokens: 1000,
  tools: [{ type: 'web_search_20250305', name: 'web_search' }],
  system: systemPrompt,
  messages: chatHistory
})

// Parser la réponse (peut contenir text + tool_use blocks)
const fullText = data.content
  .filter(b => b.type === 'text')
  .map(b => b.text)
  .join('\n')
```

---

### 7. Multilinguisme (i18n.js)

8 langues : `fr`, `en`, `sw`, `ln`, `wo`, `bm`, `ar`, `gcf`

```javascript
// Switch langue
setLang('fr')  // sauvegarde en localStorage + applique les data-i18n

// Dans le HTML
<button data-i18n="generate"></button>
<textarea data-i18n="textPlaceholder"></textarea>

// RTL automatique pour l'arabe
document.documentElement.dir = currentLang === 'ar' ? 'rtl' : 'ltr'
```

Ajouter créole martiniquais (`mq`) ou réunionnais (`rcf`) : dupliquer le bloc `gcf` dans `i18n.js`.

---

### 8. PWA

```
manifest.json  → name, short_name, theme_color (#c9a84c), display: standalone, icons
sw.js          → Cache-First pour assets statiques, Network-First pour APIs
                 Les appels Replicate, Claude, Remove.bg sont exclus du cache
```

iOS : pas de bannière auto — l'utilisatrice doit passer par Safari → Partager → Sur l'écran d'accueil.
Android/Chrome : `beforeinstallprompt` event → bannière custom déjà codée dans index.html.

---

### 9. Mise en page et typographie

**CSS shape-outside pour habillage de texte :**
```css
.illustration-float {
  float: left;
  shape-outside: circle(50%) / polygon(...);
  shape-margin: 1rem;
}
```

**Google Fonts déjà importées :**
- Cormorant Garamond (serif élégant)
- Josefin Sans (sans-serif moderne)
- À compléter : ajouter Dancing Script (script manuscrit)

**Gabarits :** implémenter comme objets JS `{ width, height, grid, zones }` — chaque zone accepte text ou image indépendamment.

---

## Déploiement

```bash
# Prérequis : Node.js + Vercel CLI
npm i -g vercel

# Dans le dossier madame-or-eille-pwa/
vercel deploy --prod

# Output : https://or-eille-ai.vercel.app
```

`vercel.json` fourni — headers CORS et Service-Worker-Allowed déjà configurés.

---

## Droits de propriété

L'ensemble du code produit dans le cadre de cette prestation est cédé intégralement à Judith (Madame Or Eille Studios). Contrat de prestation avec clause de cession de droits à signer avant démarrage.

Première preuve de création : email horodaté du 14 mai 2026.

---

*Judith — Madame Or Eille Studios, Belgrade, 14 mai 2026*
