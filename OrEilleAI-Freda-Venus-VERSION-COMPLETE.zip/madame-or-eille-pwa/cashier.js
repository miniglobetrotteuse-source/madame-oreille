// ═══════════════════════════════════════════════════
//  CAISSE & ENCAISSEMENT — Or Eille AI v1.0
//  Scan, vocal, manuel. Stripe auto en v2 (Jeff)
// ═══════════════════════════════════════════════════

const CASHIER = {
  KEY: 'moe_cashier',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { transactions:[], dailyGoal:0, currency:'€' }; }
    catch { return { transactions:[], dailyGoal:0, currency:'€' }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  addTransaction(amount, label, source) {
    const d = this.get();
    const tx = { id: Date.now().toString(), date: new Date().toISOString(), amount: parseFloat(amount)||0, label: label||'Encaissement', source: source||'manuel' };
    d.transactions.push(tx);
    this.save(d);
    return tx;
  },

  getToday() {
    const d = this.get();
    const today = new Date().toDateString();
    const todayTx = d.transactions.filter(t => new Date(t.date).toDateString() === today);
    const total = todayTx.reduce((s,t) => s + t.amount, 0);
    return { total, count: todayTx.length, transactions: todayTx, currency: d.currency, goal: d.dailyGoal };
  },

  getWeek() {
    const d = this.get();
    const weekAgo = new Date(); weekAgo.setDate(weekAgo.getDate() - 7);
    const weekTx = d.transactions.filter(t => new Date(t.date) >= weekAgo);
    return weekTx.reduce((s,t) => s + t.amount, 0);
  },

  getMonth() {
    const d = this.get();
    const startOfMonth = new Date(); startOfMonth.setDate(1); startOfMonth.setHours(0,0,0,0);
    const monthTx = d.transactions.filter(t => new Date(t.date) >= startOfMonth);
    return monthTx.reduce((s,t) => s + t.amount, 0);
  },

  // Scan ticket via Or Eille AI vision
  async scanTicket(imageDataUrl) {
    const claudeKey = window.CFG?.CLAUDE_KEY;
    if (!claudeKey) {
      if(window.addChatMsg) addChatMsg('assistant', 'Scan non disponible. Entrez le montant manuellement.');
      return null;
    }
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:100,
          messages:[{ role:'user', content:[
            { type:'image', source:{ type:'base64', media_type:'image/jpeg', data: imageDataUrl.split(',')[1] } },
            { type:'text', text:'Lis ce ticket de caisse. Réponds UNIQUEMENT en JSON sans markdown: {"montant":45.50,"label":"description"}. Si illisible: {"montant":0,"label":"Non lisible"}.' }
          ]}]
        })
      });
      const data = await r.json();
      return JSON.parse(data.content[0].text.trim());
    } catch(e) { return null; }
  },

  // Saisie vocale
  startVoice() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;
    const r = new SR(); r.lang = 'fr-FR'; r.continuous = false;
    r.onresult = e => {
      const txt = e.results[0][0].transcript;
      const nums = txt.match(/(\d+(?:[.,]\d{1,2})?)/g);
      const amount = nums ? parseFloat(nums[0].replace(',','.')) : 0;
      if (amount > 0) {
        const tx = this.addTransaction(amount, txt, 'vocal');
        document.getElementById('cashierContent').innerHTML = this.renderPanel();
        if(window.addChatMsg) addChatMsg('assistant', `✓ Encaissement vocal enregistré : ${amount} ${this.get().currency} — "${txt}"`);
        if(window.speak) speak(`Encaissement de ${amount} ${this.get().currency} enregistré.`);
      } else {
        if(window.addChatMsg) addChatMsg('assistant', `Je n'ai pas compris le montant dans "${txt}". Réessayez en disant par exemple "j'ai encaissé 45 euros".`);
      }
    };
    r.start();
    if(window.addChatMsg) addChatMsg('assistant', '🎙 Dites le montant — par exemple "45 euros coupe brushing" ou "j\'ai encaissé 120 euros".');
  },

  renderPanel() {
    const d = this.get();
    const today = this.getToday();
    const week = this.getWeek();
    const month = this.getMonth();
    const pct = today.goal > 0 ? Math.min(100, Math.round((today.total/today.goal)*100)) : null;

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <!-- TOTAL JOUR -->
      <div style="background:linear-gradient(135deg,#1a1610,#2c2318);border:1px solid var(--gold);padding:1.2rem;text-align:center">
        <div style="font-size:.5rem;color:var(--muted);letter-spacing:.15em;text-transform:uppercase;margin-bottom:.3rem">Aujourd'hui</div>
        <div style="font-size:2.8rem;color:var(--gold);font-family:'Josefin Sans',sans-serif;font-weight:200;line-height:1">${today.total.toFixed(2)} ${today.currency}</div>
        <div style="font-size:.55rem;color:var(--muted);margin-top:.3rem">${today.count} encaissement${today.count>1?'s':''}</div>
        ${pct !== null ? `
        <div style="margin-top:.8rem">
          <div style="display:flex;justify-content:space-between;font-size:.48rem;color:var(--muted);margin-bottom:.3rem"><span>Objectif journalier</span><span>${pct}%</span></div>
          <div style="background:#333;height:5px;border-radius:3px"><div style="background:var(--gold);height:5px;border-radius:3px;width:${pct}%"></div></div>
        </div>` : ''}
      </div>

      <!-- STATS -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">
        <div style="background:var(--dark-mid);border:1px solid var(--border);padding:.6rem;text-align:center">
          <div style="font-size:1rem;color:#81c784;font-family:'Josefin Sans',sans-serif">${week.toFixed(0)} ${today.currency}</div>
          <div style="font-size:.46rem;color:var(--muted);text-transform:uppercase;letter-spacing:.08em">Cette semaine</div>
        </div>
        <div style="background:var(--dark-mid);border:1px solid var(--border);padding:.6rem;text-align:center">
          <div style="font-size:1rem;color:#ce93d8;font-family:'Josefin Sans',sans-serif">${month.toFixed(0)} ${today.currency}</div>
          <div style="font-size:.46rem;color:var(--muted);text-transform:uppercase;letter-spacing:.08em">Ce mois</div>
        </div>
      </div>

      <!-- ENCAISSER -->
      <div class="sep"></div>
      <div class="sec-title">Encaisser</div>

      <!-- Scan ticket -->
      <button onclick="CASHIER.openCamera()" style="display:flex;align-items:center;gap:.8rem;padding:1rem;background:rgba(196,153,58,.1);border:1px solid rgba(196,153,58,.4);color:var(--gold);font-family:'Josefin Sans',sans-serif;font-size:.6rem;letter-spacing:.1em;cursor:pointer;text-transform:uppercase">
        <span style="font-size:1.5rem">📷</span>
        <div style="text-align:left"><div>Scanner un ticket</div><div style="font-size:.48rem;color:var(--muted);text-transform:none;letter-spacing:0">Or Eille AI lit le montant automatiquement</div></div>
      </button>
      <input type="file" id="ticketInput" accept="image/*" capture="environment" style="display:none" onchange="CASHIER.handleTicketScan(this)"/>

      <!-- Vocal -->
      <button onclick="CASHIER.startVoice()" style="display:flex;align-items:center;gap:.8rem;padding:1rem;background:rgba(79,195,247,.1);border:1px solid rgba(79,195,247,.4);color:#4fc3f7;font-family:'Josefin Sans',sans-serif;font-size:.6rem;letter-spacing:.1em;cursor:pointer;text-transform:uppercase">
        <span style="font-size:1.5rem">🎙</span>
        <div style="text-align:left"><div>Dicter un encaissement</div><div style="font-size:.48rem;color:var(--muted);text-transform:none;letter-spacing:0">"J'ai encaissé 45 euros coupe brushing"</div></div>
      </button>

      <!-- Manuel -->
      <div style="border:1px solid var(--border);padding:.7rem">
        <div style="font-size:.55rem;color:var(--muted);margin-bottom:.5rem;letter-spacing:.1em;text-transform:uppercase">Saisie manuelle</div>
        <div style="display:flex;gap:.4rem">
          <input type="number" id="manualAmount" placeholder="Montant" step="0.01" style="flex:1"/>
          <input type="text" id="manualLabel" placeholder="Description (optionnel)" style="flex:2"/>
        </div>
        <button onclick="CASHIER.manualEntry()" class="btn btn-gold" style="width:100%;margin-top:.5rem">✓ Encaisser</button>
      </div>

      <!-- Transactions du jour -->
      ${today.transactions.length > 0 ? `
      <div class="sep"></div>
      <div class="sec-title">Aujourd'hui</div>
      ${today.transactions.slice().reverse().map(tx => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:.5rem 0;border-bottom:1px solid var(--border)">
          <div>
            <div style="font-size:.58rem;color:var(--text)">${tx.label}</div>
            <div style="font-size:.46rem;color:var(--muted)">${new Date(tx.date).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})} — ${tx.source}</div>
          </div>
          <div style="font-size:.7rem;color:var(--gold);font-family:'Josefin Sans',sans-serif">+${tx.amount.toFixed(2)} ${today.currency}</div>
        </div>
      `).join('')}` : ''}

      <!-- Objectif journalier -->
      <div class="sep"></div>
      <div style="display:flex;gap:.4rem;align-items:center">
        <span style="font-size:.56rem;color:var(--muted);min-width:7rem">Objectif/jour</span>
        <input type="number" placeholder="ex: 300" value="${d.dailyGoal||''}" onchange="CASHIER.setGoal(this.value)" style="flex:1"/>
        <select onchange="CASHIER.setCurrency(this.value)" style="background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.56rem;padding:.4rem;outline:none">
          <option value="€" ${d.currency==='€'?'selected':''}>€</option>
          <option value="CHF" ${d.currency==='CHF'?'selected':''}>CHF</option>
          <option value="$" ${d.currency==='$'?'selected':''}>$</option>
          <option value="FCFA" ${d.currency==='FCFA'?'selected':''}>FCFA</option>
        </select>
      </div>

      <p style="font-size:.46rem;color:var(--muted);line-height:1.5;margin-top:.3rem">
        V2 — Connexion automatique Stripe/banque (Jeff configure l'API). Les paiements reçus s'enregistreront seuls.
      </p>
    </div>`;
  },

  openCamera() { document.getElementById('ticketInput')?.click(); },

  async handleTicketScan(input) {
    if (!input.files[0]) return;
    if(window.addChatMsg) addChatMsg('assistant', '📷 Analyse du ticket en cours…');
    const reader = new FileReader();
    reader.onload = async e => {
      const result = await this.scanTicket(e.target.result);
      if (result?.montant > 0) {
        this.addTransaction(result.montant, result.label || 'Ticket scanné', 'scan');
        document.getElementById('cashierContent').innerHTML = this.renderPanel();
        if(window.addChatMsg) addChatMsg('assistant', `✓ Ticket lu : ${result.montant} ${this.get().currency}${result.label ? ' — ' + result.label : ''}. Enregistré.`);
        if(window.speak) speak(`Ticket enregistré : ${result.montant} ${this.get().currency}.`);
      } else {
        if(window.addChatMsg) addChatMsg('assistant', 'Je n\'ai pas réussi à lire le montant. Essayez la saisie manuelle ou dictez le montant.');
      }
    };
    reader.readAsDataURL(input.files[0]);
  },

  manualEntry() {
    const amount = parseFloat(document.getElementById('manualAmount')?.value);
    const label = document.getElementById('manualLabel')?.value || 'Encaissement';
    if (!amount || amount <= 0) { if(window.speak) speak('Entrez un montant valide.'); return; }
    this.addTransaction(amount, label, 'manuel');
    document.getElementById('cashierContent').innerHTML = this.renderPanel();
    if(window.addChatMsg) addChatMsg('assistant', `✓ ${amount} ${this.get().currency} enregistré${label ? ' — ' + label : ''}.`);
    if(window.speak) speak(`${amount} ${this.get().currency} enregistré.`);
  },

  setGoal(v) { const d = this.get(); d.dailyGoal = parseFloat(v)||0; this.save(d); document.getElementById('cashierContent').innerHTML = this.renderPanel(); },
  setCurrency(v) { const d = this.get(); d.currency = v; this.save(d); }
};

window.CASHIER = CASHIER;
