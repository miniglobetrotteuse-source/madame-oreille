// ═══════════════════════════════════════════════════
//  SYNCHRONISATION MULTI-APPAREILS — Or Eille AI v1.0
//  Supabase — données chiffrées, privées, sécurisées
//  Jeff : SUPABASE_URL + SUPABASE_KEY dans CFG
// ═══════════════════════════════════════════════════

const SYNC = {
  KEY: 'moe_sync',
  SYNC_KEYS: ['moe_memory','moe_finance','moe_tracker','moe_analytics','moe_newsletter','moe_cultural_db','moe_fonts','moe_safety','moe_stock','moe_shopping','moe_gps','moe_revenue','moe_freemium','moe_content','moe_subtitles','moe_podcast'],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { userId: null, lastSync: null, syncEnabled: false }; }
    catch { return { userId: null, lastSync: null, syncEnabled: false }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Générer un ID utilisateur unique ─────────
  generateUserId() {
    return 'u_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
  },

  // ─── Chiffrer les données avant sync ──────────
  async encryptData(data, userId) {
    const encoder = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey('raw', encoder.encode(userId.padEnd(32, '0').substring(0, 32)), 'AES-GCM', false, ['encrypt']);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, keyMaterial, encoder.encode(JSON.stringify(data)));
    return { iv: Array.from(iv), data: Array.from(new Uint8Array(encrypted)) };
  },

  // ─── Déchiffrer les données ───────────────────
  async decryptData(encryptedData, userId) {
    try {
      const encoder = new TextEncoder();
      const keyMaterial = await crypto.subtle.importKey('raw', encoder.encode(userId.padEnd(32, '0').substring(0, 32)), 'AES-GCM', false, ['decrypt']);
      const iv = new Uint8Array(encryptedData.iv);
      const data = new Uint8Array(encryptedData.data);
      const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, keyMaterial, data);
      return JSON.parse(new TextDecoder().decode(decrypted));
    } catch { return null; }
  },

  // ─── Créer la table automatiquement si elle n'existe pas ──
  async initSupabase() {
    const cfg = window.CFG;
    if (!cfg?.SUPABASE_URL || cfg.SUPABASE_URL.includes('METTRE')) return false;
    try {
      // Vérifier si la table existe en tentant une lecture
      const r = await fetch(`${cfg.SUPABASE_URL}/rest/v1/user_data?limit=1`, {
        headers: { 'apikey': cfg.SUPABASE_KEY, 'Authorization': `Bearer ${cfg.SUPABASE_KEY}` }
      });
      if (r.status === 404 || r.status === 400) {
        // Table n'existe pas — la créer via SQL RPC
        await fetch(`${cfg.SUPABASE_URL}/rest/v1/rpc/create_user_data_table`, {
          method: 'POST',
          headers: { 'apikey': cfg.SUPABASE_KEY, 'Authorization': `Bearer ${cfg.SUPABASE_KEY}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({})
        });
      }
      return true;
    } catch { return false; }
  },

  // ─── Synchroniser vers Supabase ───────────────
  async pushToCloud() {
    const cfg = window.CFG;
    if (!cfg?.SUPABASE_URL || cfg.SUPABASE_URL.includes('METTRE')) {
      return { error: 'Supabase non configuré — Jeff: ajouter SUPABASE_URL et SUPABASE_KEY dans CFG' };
    }

    await this.initSupabase();
    const d = this.get();
    if (!d.userId) { d.userId = this.generateUserId(); this.save(d); }

    const allData = {};
    this.SYNC_KEYS.forEach(key => {
      const val = localStorage.getItem(key);
      if (val) allData[key] = JSON.parse(val);
    });

    try {
      const encrypted = await this.encryptData(allData, d.userId);
      const r = await fetch(`${cfg.SUPABASE_URL}/rest/v1/user_data`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': cfg.SUPABASE_KEY,
          'Authorization': `Bearer ${cfg.SUPABASE_KEY}`,
          'Prefer': 'resolution=merge-duplicates'
        },
        body: JSON.stringify({ user_id: d.userId, encrypted_data: encrypted, updated_at: new Date().toISOString() })
      });

      if (r.ok) {
        d.lastSync = new Date().toISOString();
        this.save(d);
        return { success: true, syncedAt: d.lastSync };
      }
      return { error: 'Erreur Supabase: ' + r.status };
    } catch(e) { return { error: e.message }; }
  },

  // ─── Récupérer depuis Supabase ────────────────
  async pullFromCloud() {
    const cfg = window.CFG;
    if (!cfg?.SUPABASE_URL || cfg.SUPABASE_URL.includes('METTRE')) return null;

    const d = this.get();
    if (!d.userId) return null;

    try {
      const r = await fetch(`${cfg.SUPABASE_URL}/rest/v1/user_data?user_id=eq.${d.userId}&select=encrypted_data`, {
        headers: { 'apikey': cfg.SUPABASE_KEY, 'Authorization': `Bearer ${cfg.SUPABASE_KEY}` }
      });

      if (!r.ok) return null;
      const rows = await r.json();
      if (!rows.length) return null;

      const decrypted = await this.decryptData(rows[0].encrypted_data, d.userId);
      if (!decrypted) return null;

      // Restaurer les données
      Object.entries(decrypted).forEach(([key, val]) => {
        localStorage.setItem(key, JSON.stringify(val));
      });

      d.lastSync = new Date().toISOString();
      this.save(d);
      return { success: true, restoredAt: d.lastSync };
    } catch { return null; }
  },

  // ─── Sync automatique toutes les 5 minutes ────
  startAutoSync() {
    const d = this.get();
    if (!d.syncEnabled) return;
    setInterval(async () => {
      const result = await this.pushToCloud();
      if (result?.success) console.log('Auto-sync OK:', result.syncedAt);
    }, 5 * 60 * 1000);
  },

  // ─── Partager l'ID avec un autre appareil ─────
  async getShareCode() {
    await this.initSupabase();
    const d = this.get();
    if (!d.userId) { d.userId = this.generateUserId(); this.save(d); }
    return d.userId;
  },

  setShareCode(code) {
    const d = this.get();
    d.userId = code;
    this.save(d);
    return this.pullFromCloud();
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    const cfg = window.CFG;
    const supabaseOk = cfg?.SUPABASE_URL && !cfg.SUPABASE_URL.includes('METTRE');

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div class="sec-title">🔄 Synchronisation multi-appareils</div>

      ${!supabaseOk ? `
        <div style="background:rgba(239,83,80,.08);border:1px solid rgba(239,83,80,.3);padding:.7rem">
          <div style="font-size:.55rem;color:#ef5350;margin-bottom:.3rem">⚠ Synchronisation non configurée</div>
          <div style="font-size:.5rem;color:var(--muted);line-height:1.6">Jeff doit ajouter SUPABASE_URL et SUPABASE_KEY dans le fichier de configuration.</div>
        </div>
      ` : `
        <div style="background:rgba(129,199,132,.08);border:1px solid rgba(129,199,132,.3);padding:.5rem">
          <div style="font-size:.54rem;color:#81c784">✓ Synchronisation disponible</div>
          ${d.lastSync ? `<div style="font-size:.48rem;color:var(--muted)">Dernière sync: ${new Date(d.lastSync).toLocaleString('fr-FR')}</div>` : ''}
        </div>
      `}

      <p class="note">Vos données sont chiffrées AES-256 avant d'être envoyées. Personne d'autre ne peut y accéder — même pas Or Eille AI.</p>

      <div style="display:flex;gap:.4rem">
        <button class="btn btn-gold" style="flex:1" onclick="SYNC.pushToCloud().then(r=>{if(r?.success&&window.addChatMsg)addChatMsg('assistant','✅ Données synchronisées vers le cloud.');else if(r?.error&&window.addChatMsg)addChatMsg('assistant','❌ '+r.error)})">
          ☁ Sauvegarder
        </button>
        <button class="btn btn-ghost" style="flex:1" onclick="SYNC.pullFromCloud().then(r=>{if(r?.success&&window.addChatMsg)addChatMsg('assistant','✅ Données restaurées depuis le cloud.');else if(window.addChatMsg)addChatMsg('assistant','Aucune donnée trouvée ou erreur.')})">
          ⬇ Restaurer
        </button>
      </div>

      <div class="sep"></div>
      <div class="sec-title">📱 Connecter un nouvel appareil</div>
      <p class="note">Pour accéder à vos données sur un autre téléphone ou ordinateur.</p>

      <div style="padding:.6rem;background:var(--dark-mid);border:1px solid var(--border)">
        <div style="font-size:.5rem;color:var(--muted);margin-bottom:.3rem">Votre code de synchronisation</div>
        <div style="font-size:.6rem;color:var(--gold);letter-spacing:.1em;word-break:break-all">${d.userId || 'Cliquez sur Sauvegarder pour générer'}</div>
      </div>

      <button class="btn btn-ghost" onclick="navigator.clipboard?.writeText(SYNC.getShareCode()).then(()=>{if(window.addChatMsg)addChatMsg('assistant','✅ Code copié. Collez-le sur votre autre appareil.')})">
        📋 Copier le code
      </button>

      <div style="display:flex;gap:.4rem">
        <input type="text" id="sync-code" placeholder="Code de l'autre appareil..." style="flex:1"/>
        <button onclick="SYNC.setShareCode(document.getElementById('sync-code').value).then(r=>{if(r?.success&&window.addChatMsg)addChatMsg('assistant','✅ Données récupérées. Bienvenue !')})" class="btn btn-ghost">Connecter</button>
      </div>

      <div class="sep"></div>
      <label style="display:flex;align-items:center;gap:.5rem;font-size:.56rem;color:var(--muted);cursor:pointer">
        <input type="checkbox" ${d.syncEnabled?'checked':''} onchange="const s=SYNC.get();s.syncEnabled=this.checked;SYNC.save(s);if(this.checked)SYNC.startAutoSync()" style="accent-color:var(--gold)"/>
        Synchronisation automatique toutes les 5 minutes
      </label>
    </div>`;
  }
};

window.SYNC = SYNC;

window.addEventListener('load', () => {
  setTimeout(() => {
    const d = SYNC.get();
    if (d.syncEnabled) SYNC.startAutoSync();
  }, 3000);
});
