// ═══════════════════════════════════════════════════
//  CUISINE, LOISIRS, DIY & ÉVÉNEMENTS — Or Eille AI v1.0
//  Toutes les cultures · tous les budgets · tous les âges
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const RECIPES = {
  KEY: 'moe_recipes',

  NUTRITION_PROFILES: {
    simple:  'Je mange et c est tout — pas de chiffres',
    curieux: 'Je suis curieux — quelques infos',
    sportif: 'Je suis sportif — macros et proteines',
    athlete: 'Sportif de haut niveau — plan complet',
  },

  DIETS: {
    tout:'On mange de tout', vegetarien:'Vegetarien', vegan:'Vegan',
    halal:'Halal', casher:'Casher', sans_gluten:'Sans gluten',
    sans_lactose:'Sans lactose', sans_noix:'Allergie noix',
    sans_oeuf:'Sans oeufs', keto:'Keto', high_protein:'Riche en proteines',
  },

  EVENTS: {
    halloween:   'Halloween',
    noel:        'Noel',
    anniversaire:'Anniversaire',
    aid:         'Aid',
    hanoukka:    'Hanoukka',
    kwanzaa:     'Kwanzaa',
    paques:      'Paques',
    saint_valentin:'Saint-Valentin',
    carnaval:    'Carnaval',
    tamkharit:   'Tamkharit',
    noel_congo:  'Noel congolais',
    diwali:      'Diwali',
  },

  CRAFTS_BY_CULTURE: {
    'Mali Senegal':    ['Bogolan — teinture naturelle','Teinture indigo','Broderie peul'],
    'Ghana':           ['Kente — tissage','Adinkra — impression tissu'],
    'Maroc Algerie':   ['Broderie berbere','Zellige — mosaique','Henné'],
    'Congo':           ['Vannerie congolaise','Raphia','Sculpture bois'],
    'Nigeria':         ['Perles yoruba','Tissu aso-oke','Adire — batik'],
    'Liban':           ['Broderie au point de croix oriental','Filet — dentelle'],
    'France':          ['Point de croix','Tricot','Crochet','Patchwork','Macrame'],
    'Bretagne':        ['Dentelle au fuseau','Broderie bretonne'],
    'Japon':           ['Origami','Sashiko — broderie','Furoshiki — pliage tissu'],
    'Inde':            ['Broderie kantha','Block printing','Tie-dye bandhani'],
    'Mexique':         ['Otomi — broderie','Huichol — perles','Papel picado'],
    'Bresil':          ['Renda — dentelle','Carnaval — costume'],
  },

  AGE_FOR_CRAFT: {
    '2+':  ['Peinture doigts','Coloriage','Jardin pot','Pate a sel'],
    '6+':  ['Tricot initiation','Broderie simple','Origami'],
    '8+':  ['Couture simple','Point de croix','Bricolage leger','Cuisine avec adulte'],
    '12+': ['Couture machine','Teinture tissu','DIY avance'],
    'adulte': ['Tout — aucune limite'],
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      nutritionProfile:'simple', diet:'tout', budget:'libre',
      kitchen:'complet', alone:false, withFamily:false, scans:[]
    }; }
    catch { return { nutritionProfile:'simple', diet:'tout', budget:'libre', kitchen:'complet', scans:[] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async scanPlate(imageData, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const d = this.get();
    const wantsNumbers = d.nutritionProfile !== 'simple';
    if (window.addChatMsg) addChatMsg('assistant','Analyse de ton assiette...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:600,
          messages:[{ role:'user', content:[
            { type:'image', source:{ type:'base64', media_type:'image/jpeg', data:imageData } },
            { type:'text', text: wantsNumbers ?
              'Analyse cette assiette. Identifie chaque aliment. Estime le poids en grammes. Calcule calories, proteines, glucides, lipides. Bienveillant. Jamais de jugement.' :
              'Regarde cette assiette. Dis-moi ce qu il y a dedans simplement. Pas de chiffres. Est-ce equilibre ? Qu est-ce qui est bien ? Bienveillant.'
            }
          ]}]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  async getRecipe(request, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const d = this.get();
    if (window.addChatMsg) addChatMsg('assistant','Recherche de recette...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:800,
          messages:[{ role:'user', content:
            'Recette pour : ' + request + '\n' +
            'Regime : ' + (this.DIETS[d.diet]||'tout') + '\n' +
            'Budget : ' + (d.budget||'libre') + '\n' +
            'Cuisine : ' + (d.kitchen||'complete') + '\n' +
            'Profil nutrition : ' + (this.NUTRITION_PROFILES[d.nutritionProfile]||'simple') + '\n\n' +
            'Donne une recette claire etape par etape. Si un ingredient est introuvable selon le pays, propose un substitut local. Bienveillant. Jamais de jugement alimentaire. Jamais perdre du poids.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  async getDIY(request, culture, age, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    if (window.addChatMsg) addChatMsg('assistant','Recherche de tuto DIY...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:800,
          messages:[{ role:'user', content:
            'Tutoriel DIY pour : ' + request + '\n' +
            (culture ? 'Culture d origine : ' + culture + '. Si des materiaux traditionnels sont introuvables ailleurs, propose des substituts locaux accessibles.\n' : '') +
            (age ? 'Age : ' + age + '. Adapte les instructions et outils.\n' : '') +
            'Instructions claires etape par etape. Materiaux simples et accessibles. Bienveillant.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  async getEventDeco(event, photo, budget, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const eventName = this.EVENTS[event] || event;
    if (window.addChatMsg) addChatMsg('assistant','Ideas deco pour ' + eventName + '...');
    try {
      const content = photo ?
        [{ type:'image', source:{ type:'base64', media_type:'image/jpeg', data:photo } },
         { type:'text', text:'Voici ma piece ou ma table. Propose des idees de decoration pour ' + eventName + ' avec ce que je vois. Budget : ' + (budget||'petit')+'. DIY si possible. Etapes claires.' }] :
        [{ type:'text', text:'Propose des idees de decoration DIY pour ' + eventName + '. Budget : ' + (budget||'petit') + '. Avec des objets du quotidien. Etapes claires. Inspirant et concret.' }];

      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({ model:'claude-sonnet-4-20250514', max_tokens:700, messages:[{ role:'user', content }] })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  renderPanel: function() {
    const d = this.get();
    const events = Object.entries(this.EVENTS);
    const cultures = Object.keys(this.CRAFTS_BY_CULTURE);

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🍳 Cuisine · 🎨 Loisirs · 🔨 DIY · 🎃 Événements</div>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem">' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">Recettes de toutes les cultures. Loisirs adaptés à ton pays. DIY avec ce que tu as. Déco pour toutes les occasions. Jamais de jugement. Toujours bienveillant.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;font-style:italic">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div class="sec-title">🍳 Cuisine & Recettes</div>' +
      '<div style="display:flex;gap:.3rem;align-items:center;flex-wrap:wrap">' +
        '<select id="rec-diet" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.DIETS).map(function(e) { return '<option value="'+e[0]+'">'+e[1]+'</option>'; }).join('') +
        '</select>' +
        '<select id="rec-profile" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.NUTRITION_PROFILES).map(function(e) { return '<option value="'+e[0]+'">'+e[1]+'</option>'; }).join('') +
        '</select>' +
      '</div>' +
      '<input type="text" id="rec-request" placeholder="Que veux-tu cuisiner ? Ex: poulet yassa, crepes vegan, gateau sans four..."/>' +
      '<button class="btn btn-gold" onclick="RECIPES.getRecipe(document.getElementById(\'rec-request\').value,window.CFG&&window.CFG.CLAUDE_KEY)">🍳 Trouver une recette</button>' +

      '<div class="sep"></div>' +
      '<div class="sec-title">📸 Scanner mon assiette</div>' +
      '<p class="note">Tu prends une photo de ton assiette — Or Eille AI analyse ce qu il y a dedans. Bienveillant. Jamais de jugement.</p>' +
      '<input type="file" accept="image/*" id="plate-photo" style="font-size:.5rem;color:var(--muted)"/>' +
      '<button class="btn btn-ghost" onclick="const f=document.getElementById(\'plate-photo\').files[0];if(f){const r=new FileReader();r.onload=function(e){const b64=e.target.result.split(\',\')[1];RECIPES.scanPlate(b64,window.CFG&&window.CFG.CLAUDE_KEY);};r.readAsDataURL(f);}">📸 Analyser mon assiette</button>' +

      '<div class="sep"></div>' +
      '<div class="sec-title">🎨 Loisirs créatifs & DIY par culture</div>' +
      '<div style="display:flex;gap:.3rem">' +
        '<select id="diy-culture" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          '<option value="">Toutes les cultures</option>' +
          cultures.map(function(c) { return '<option value="'+c+'">'+c+'</option>'; }).join('') +
        '</select>' +
        '<select id="diy-age" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          '<option value="">Tous les ages</option>' +
          Object.keys(this.AGE_FOR_CRAFT).map(function(a) { return '<option value="'+a+'">'+a+'</option>'; }).join('') +
        '</select>' +
      '</div>' +
      '<input type="text" id="diy-request" placeholder="Que veux-tu faire ? Ex: tissu bogolan a Paris, point de croix debutant, placard a chaussures..."/>' +
      '<button class="btn btn-gold" onclick="RECIPES.getDIY(document.getElementById(\'diy-request\').value,document.getElementById(\'diy-culture\').value,document.getElementById(\'diy-age\').value,window.CFG&&window.CFG.CLAUDE_KEY)">🎨 Trouver un tuto DIY</button>' +

      '<div class="sep"></div>' +
      '<div class="sec-title">🎃 Déco & Événements</div>' +
      '<p class="note">Tu prends une photo de ta pièce — Or Eille AI te propose comment la transformer pour l occasion.</p>' +
      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
        events.map(function(e) {
          return '<button onclick="RECIPES.getEventDeco(\''+e[0]+'\',null,\'petit\',window.CFG&&window.CFG.CLAUDE_KEY)" style="padding:.3rem .5rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:Josefin Sans,sans-serif;font-size:.46rem;cursor:pointer">'+e[1]+'</button>';
        }).join('') +
      '</div>' +
      '<input type="file" accept="image/*" id="event-photo" style="font-size:.5rem;color:var(--muted);margin-top:.3rem"/>' +
      '<input type="text" id="event-custom" placeholder="Ou decris ton evenement..."/>' +
      '<button class="btn btn-ghost" onclick="const f=document.getElementById(\'event-photo\').files[0];const ev=document.getElementById(\'event-custom\').value;if(f){const r=new FileReader();r.onload=function(e2){RECIPES.getEventDeco(ev||\'evenement\',e2.target.result.split(\',\')[1],\'petit\',window.CFG&&window.CFG.CLAUDE_KEY);};r.readAsDataURL(f);}else{RECIPES.getEventDeco(ev||\'evenement\',null,\'petit\',window.CFG&&window.CFG.CLAUDE_KEY);}">🎃 Idees deco pour cet evenement</button>' +

    '</div>';
  }
};

window.RECIPES = RECIPES;
