// ═══════════════════════════════════════════════════
//  GESTIONNAIRE DE PROJETS — Or Eille AI v1.0
//  Simple vs Complexe — Récurrent vs Unique
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const PROJECTS = {
  KEY: 'moe_projects',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { projects: [], templates: [] }; }
    catch { return { projects: [], templates: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Créer un nouveau projet ──────────────────
  create(params) {
    const d = this.get();
    const project = {
      id: 'proj_' + Date.now().toString(36),
      title: params.title,
      type: params.type, // 'simple', 'complex'
      format: params.format, // 'reel', 'video', 'podcast', 'newsletter', 'document', 'other'
      platform: params.platform,
      recurring: params.recurring || false,
      recurringPeriod: params.recurringPeriod || null, // 'weekly', 'monthly', 'yearly'
      parts: params.type === 'complex' ? [
        { id: 'research', label: '📚 Recherche', status: 'todo', content: null },
        { id: 'text', label: '✍ Texte', status: 'todo', content: null },
        { id: 'visual', label: '🖼 Visuels', status: 'todo', content: null },
        { id: 'audio', label: '🎵 Audio', status: 'todo', content: null },
        { id: 'assembly', label: '🎬 Assemblage', status: 'todo', content: null },
      ] : [
        { id: 'create', label: '🎨 Création', status: 'todo', content: null },
        { id: 'publish', label: '🚀 Publication', status: 'todo', content: null },
      ],
      researchMode: null, // 'ai', 'own', 'complement'
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: 'active',
      isTemplate: false,
    };
    d.projects.unshift(project);
    this.save(d);
    return project;
  },

  // ─── Sauvegarder comme modèle récurrent ───────
  saveAsTemplate(projectId) {
    const d = this.get();
    const project = d.projects.find(p => p.id === projectId);
    if (!project) return;
    const template = { ...project, id: 'tpl_' + Date.now().toString(36), isTemplate: true, createdAt: new Date().toISOString() };
    d.templates.push(template);
    this.save(d);
    if (window.addChatMsg) addChatMsg('assistant', `✅ "${project.title}" sauvegardé comme modèle. Or Eille AI vous rappellera de l'utiliser à la prochaine échéance.`);
    return template;
  },

  // ─── Vérifier les modèles à rappeler ──────────
  checkRecurringReminders() {
    const d = this.get();
    const now = new Date();
    d.templates.forEach(tpl => {
      if (!tpl.recurring || !tpl.recurringPeriod) return;
      const lastUsed = tpl.lastUsed ? new Date(tpl.lastUsed) : new Date(tpl.createdAt);
      const daysSince = Math.round((now - lastUsed) / 86400000);
      const periods = { weekly: 7, monthly: 30, yearly: 365 };
      const period = periods[tpl.recurringPeriod];
      if (period && daysSince >= period - 2) {
        if (window.addChatMsg) addChatMsg('assistant', `📅 Rappel — "${tpl.title}" est prévu tous les ${tpl.recurringPeriod === 'weekly' ? '7 jours' : tpl.recurringPeriod === 'monthly' ? 'mois' : 'an'}. Voulez-vous créer la prochaine édition ?`);
      }
    });
  },

  // ─── Mettre à jour une partie ─────────────────
  updatePart(projectId, partId, status, content) {
    const d = this.get();
    const project = d.projects.find(p => p.id === projectId);
    if (!project) return;
    const part = project.parts.find(p => p.id === partId);
    if (part) { part.status = status; if (content) part.content = content; }
    project.updatedAt = new Date().toISOString();
    // Vérifier si tout est terminé
    const allDone = project.parts.every(p => p.status === 'done');
    if (allDone && project.status !== 'ready') {
      project.status = 'ready';
      if (window.addChatMsg) addChatMsg('assistant', `🎉 "${project.title}" est prêt ! Toutes les parties sont terminées. Voulez-vous passer à l'assemblage et à la publication ?`);
    }
    this.save(d);
  },

  // ─── Interface de démarrage nouveau projet ─────
  showNewProjectWizard() {
    const modal = document.createElement('div');
    modal.id = 'project-wizard';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.96);z-index:99999;display:flex;align-items:center;justify-content:center;padding:1.5rem;overflow-y:auto';
    modal.innerHTML = `
    <div style="max-width:420px;width:100%;background:#1a1610;border:1px solid var(--gold);padding:1.4rem">
      <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1.2rem;margin-bottom:1rem">Nouveau projet</h3>

      <input type="text" id="pw-title" placeholder="Titre de votre projet" style="margin-bottom:.6rem"/>

      <div style="margin-bottom:.6rem">
        <span class="klabel">Que créez-vous ?</span>
        <div style="display:flex;gap:.3rem;flex-wrap:wrap;margin-top:.3rem">
          ${[['reel','🎬 Reel'],['video','📹 Vidéo longue'],['podcast','🎙 Podcast'],['newsletter','✉ Newsletter'],['document','📄 Document'],['other','📦 Autre']].map(([v,l]) => `
            <button onclick="document.querySelectorAll('.pw-format').forEach(b=>b.classList.remove('active'));this.classList.add('active');document.getElementById('pw-format').value='${v}'" class="pw-format" style="padding:.3rem .5rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:'Josefin Sans',sans-serif;font-size:.5rem;cursor:pointer">${l}</button>
          `).join('')}
          <input type="hidden" id="pw-format" value="reel"/>
        </div>
      </div>

      <div style="margin-bottom:.6rem">
        <span class="klabel">Projet simple ou complexe ?</span>
        <div style="display:flex;gap:.4rem;margin-top:.3rem">
          <button onclick="document.getElementById('pw-type').value='simple';this.style.background='rgba(196,153,58,.2)';this.style.borderColor='var(--gold)';this.nextElementSibling.style.background='var(--dark-mid)';this.nextElementSibling.style.borderColor='var(--border)'" style="flex:1;padding:.5rem;background:rgba(196,153,58,.2);border:1px solid var(--gold);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.52rem;cursor:pointer">
            Simple<br/><span style="font-size:.44rem;color:var(--muted)">Je fais ça en une fois</span>
          </button>
          <button onclick="document.getElementById('pw-type').value='complex';this.style.background='rgba(196,153,58,.2)';this.style.borderColor='var(--gold)';this.previousElementSibling.style.background='var(--dark-mid)';this.previousElementSibling.style.borderColor='var(--border)'" style="flex:1;padding:.5rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.52rem;cursor:pointer">
            Complexe<br/><span style="font-size:.44rem;color:var(--muted)">Plusieurs parties à assembler</span>
          </button>
          <input type="hidden" id="pw-type" value="simple"/>
        </div>
      </div>

      <div style="margin-bottom:.6rem">
        <span class="klabel">Ce contenu est-il récurrent ?</span>
        <div style="display:flex;gap:.3rem;margin-top:.3rem;flex-wrap:wrap">
          ${[['','Non — unique'],['weekly','Hebdomadaire'],['monthly','Mensuel'],['yearly','Annuel']].map(([v,l]) => `
            <button onclick="document.querySelectorAll('.pw-recur').forEach(b=>b.classList.remove('active'));this.classList.add('active');document.getElementById('pw-recur').value='${v}'" class="pw-recur${v===''?' active':''}" style="padding:.3rem .5rem;background:${v===''?'rgba(196,153,58,.2)':'var(--dark-mid)'};border:1px solid ${v===''?'var(--gold)':'var(--border)'};color:var(--muted);font-family:'Josefin Sans',sans-serif;font-size:.5rem;cursor:pointer">${l}</button>
          `).join('')}
          <input type="hidden" id="pw-recur" value=""/>
        </div>
      </div>

      <div style="display:flex;gap:.4rem;margin-top:1rem">
        <button onclick="document.getElementById('project-wizard').remove()" style="flex:1;padding:.6rem;background:transparent;border:1px solid var(--border);color:var(--muted);font-family:'Josefin Sans',sans-serif;font-size:.52rem;cursor:pointer">Annuler</button>
        <button onclick="
          const title = document.getElementById('pw-title').value;
          const format = document.getElementById('pw-format').value;
          const type = document.getElementById('pw-type').value;
          const recur = document.getElementById('pw-recur').value;
          if(!title){if(window.addChatMsg)addChatMsg('assistant','Donnez un titre à votre projet.');return;}
          const proj = PROJECTS.create({title,format,type,recurring:!!recur,recurringPeriod:recur||null,platform:''});
          document.getElementById('project-wizard').remove();
          document.getElementById('projectsContent').innerHTML = PROJECTS.renderProject(proj.id);
          if(window.addChatMsg)addChatMsg('assistant','✅ Projet \"'+title+'\" créé. Par où voulez-vous commencer ?');
        " style="flex:2;padding:.6rem;background:var(--gold);color:var(--dark);border:none;font-family:'Josefin Sans',sans-serif;font-size:.52rem;cursor:pointer">Créer le projet</button>
      </div>
    </div>`;
    document.body.appendChild(modal);
  },

  // ─── Afficher un projet ───────────────────────
  renderProject(projectId) {
    const d = this.get();
    const project = d.projects.find(p => p.id === projectId);
    if (!project) return this.renderPanel();

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">
      <div style="display:flex;align-items:center;gap:.5rem">
        <button onclick="document.getElementById('projectsContent').innerHTML=PROJECTS.renderPanel()" style="background:transparent;border:none;color:var(--gold);font-size:.8rem;cursor:pointer">←</button>
        <h3 style="font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-size:1rem;flex:1">${project.title}</h3>
        ${project.recurring ? `<span style="font-size:.44rem;color:var(--cobalt);border:1px solid var(--cobalt);padding:.1rem .3rem">🔄 Récurrent</span>` : ''}
      </div>

      <!-- Parties du projet -->
      ${project.parts.map(part => `
        <div style="border:1px solid ${part.status==='done'?'rgba(129,199,132,.4)':part.status==='progress'?'rgba(196,153,58,.4)':'var(--border)'};padding:.7rem;background:${part.status==='done'?'rgba(129,199,132,.05)':'var(--dark-mid)'}">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:.4rem">
            <span style="font-size:.58rem;color:var(--text)">${part.label}</span>
            <div style="display:flex;gap:.3rem">
              <button onclick="PROJECTS.updatePart('${project.id}','${part.id}','progress',null);document.getElementById('projectsContent').innerHTML=PROJECTS.renderProject('${project.id}')" style="padding:.2rem .4rem;background:rgba(196,153,58,.15);border:1px solid rgba(196,153,58,.3);color:var(--gold);font-size:.44rem;cursor:pointer">En cours</button>
              <button onclick="PROJECTS.updatePart('${project.id}','${part.id}','done',null);document.getElementById('projectsContent').innerHTML=PROJECTS.renderProject('${project.id}')" style="padding:.2rem .4rem;background:rgba(129,199,132,.15);border:1px solid rgba(129,199,132,.3);color:#81c784;font-size:.44rem;cursor:pointer">✓ Terminé</button>
            </div>
          </div>
          ${part.id === 'research' && part.status !== 'done' ? `
            <div style="display:flex;gap:.3rem;flex-wrap:wrap;margin-top:.3rem">
              ${[['ai','Or Eille AI cherche pour moi'],['own','J\'apporte mes recherches'],['complement','On complète ensemble']].map(([v,l]) => `
                <button onclick="PROJECTS.setResearchMode('${project.id}','${v}')" style="padding:.25rem .4rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:'Josefin Sans',sans-serif;font-size:.46rem;cursor:pointer">${l}</button>
              `).join('')}
            </div>
          ` : ''}
          ${part.status === 'done' ? '<div style="font-size:.46rem;color:#81c784">✓ Terminé</div>' : part.status === 'progress' ? '<div style="font-size:.46rem;color:var(--gold)">En cours...</div>' : '<div style="font-size:.46rem;color:var(--muted)">À faire</div>'}
        </div>
      `).join('')}

      <div style="display:flex;gap:.4rem;margin-top:.4rem">
        ${project.recurring ? `<button class="btn btn-ghost" style="flex:1" onclick="PROJECTS.saveAsTemplate('${project.id}')">💾 Sauvegarder comme modèle</button>` : ''}
        <button class="btn btn-ghost" onclick="SHARING.showPanel?.() || (document.getElementById('sharingContent').innerHTML=SHARING.renderPanel())" style="flex:1">🔗 Partager</button>
      </div>
    </div>`;
  },

  setResearchMode(projectId, mode) {
    const d = this.get();
    const project = d.projects.find(p => p.id === projectId);
    if (project) { project.researchMode = mode; this.save(d); }
    const messages = {
      ai: 'Or Eille AI va chercher pour vous. Quel est le sujet précis ?',
      own: 'Parfait. Uploadez vos recherches ou collez-les dans le panneau texte.',
      complement: 'Commencez par partager ce que vous avez — Or Eille AI comblera les manques.'
    };
    if (window.addChatMsg) addChatMsg('assistant', messages[mode]);
  },

  // ─── Rendu panel principal ────────────────────
  renderPanel() {
    const d = this.get();
    const active = d.projects.filter(p => p.status !== 'archived');

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">
      <div class="sec-title">📁 Mes projets</div>

      <button class="btn btn-gold" onclick="PROJECTS.showNewProjectWizard()">+ Nouveau projet</button>

      ${active.length === 0 ? `
        <div style="text-align:center;padding:2rem;color:var(--muted);font-size:.56rem">
          Aucun projet en cours.<br/>Commencez par créer votre premier projet.
        </div>
      ` : active.map(p => `
        <div onclick="document.getElementById('projectsContent').innerHTML=PROJECTS.renderProject('${p.id}')" style="border:1px solid var(--border);padding:.7rem;cursor:pointer;background:var(--dark-mid)">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <div>
              <div style="font-size:.58rem;color:var(--text)">${p.title}</div>
              <div style="font-size:.46rem;color:var(--muted);margin-top:.2rem">
                ${p.type === 'complex' ? 'Complexe' : 'Simple'} · 
                ${p.parts.filter(pt=>pt.status==='done').length}/${p.parts.length} parties
                ${p.recurring ? ' · 🔄 Récurrent' : ''}
              </div>
            </div>
            <span style="font-size:.6rem;color:var(--gold)">›</span>
          </div>
          <!-- Barre de progression -->
          <div style="background:var(--border);height:3px;border-radius:2px;margin-top:.4rem">
            <div style="background:var(--gold);height:3px;border-radius:2px;width:${Math.round(p.parts.filter(pt=>pt.status==='done').length/p.parts.length*100)}%"></div>
          </div>
        </div>
      `).join('')}

      ${d.templates.length > 0 ? `
        <div class="sep"></div>
        <div class="sec-title">📋 Modèles récurrents</div>
        ${d.templates.map(t => `
          <div style="display:flex;align-items:center;gap:.5rem;padding:.5rem;border:1px solid var(--border)">
            <div style="flex:1">
              <div style="font-size:.56rem;color:var(--text)">${t.title}</div>
              <div style="font-size:.46rem;color:var(--muted)">${t.recurringPeriod === 'weekly' ? 'Hebdomadaire' : t.recurringPeriod === 'monthly' ? 'Mensuel' : 'Annuel'}</div>
            </div>
            <button onclick="const p=PROJECTS.create({...${JSON.stringify({title:t.title,format:t.format,type:t.type,recurring:t.recurring,recurringPeriod:t.recurringPeriod,platform:t.platform})},title:'${t.title} — nouvelle édition'});document.getElementById('projectsContent').innerHTML=PROJECTS.renderProject(p.id)" style="padding:.3rem .5rem;background:var(--gold);color:var(--dark);border:none;font-size:.48rem;cursor:pointer">Nouvelle édition</button>
          </div>
        `).join('')}
      ` : ''}
    </div>`;
  }
};

window.PROJECTS = PROJECTS;
window.addEventListener('load', () => setTimeout(() => PROJECTS.checkRecurringReminders(), 4000));
