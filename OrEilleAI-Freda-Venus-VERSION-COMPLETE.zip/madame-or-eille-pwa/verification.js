// ═══════════════════════════════════════════════════
//  VÉRIFICATION TERRAIN COMMUNAUTAIRE — Or Eille AI v1.0
//  Les utilisateurs enrichissent la base de données
//  Vérifications géolocalisées, horodatées, confirmées
// ═══════════════════════════════════════════════════

const VERIF = {
  KEY: 'moe_verif',

  CATEGORIES: {
    lieu: '📍 Lieu (restaurant, commerce, adresse)',
    transport: '🚌 Transport (gare, bus, horaires)',
    sante: '🏥 Santé (médecin, pharmacie)',
    info: 'ℹ️ Information générale',
    histoire: '📚 Histoire et culture',
    loi: '⚖️ Loi et réglementation',
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { verifications: [] }; }
    catch { return { verifications: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Ajouter une vérification terrain ─────────
  addVerification(subject, truth, category, position) {
    const d = this.get();
    const verif = {
      id: Date.now().toString(),
      subject: subject.trim(),
      truth: truth.trim(),
      category: category || 'info',
      lat: position?.lat || null,
      lng: position?.lng || null,
      verifiedAt: new Date().toISOString(),
      confirmedBy: 1,
      disputed: false,
      source: 'terrain',
    };
    d.verifications.push(verif);
    this.save(d);

    // Aussi enregistrer dans le cache global de vérifications
    if (window.VERIFICATION_CACHE) {
      VERIFICATION_CACHE.add(subject, truth, 'Vérifié sur le terrain par un utilisateur Or Eille AI');
    }

    return verif;
  },

  // ─── Rechercher une vérification ──────────────
  search(query) {
    const d = this.get();
    const q = query.toLowerCase();
    return d.verifications
      .filter(v => v.subject.toLowerCase().includes(q) || v.truth.toLowerCase().includes(q))
      .sort((a, b) => b.confirmedBy - a.confirmedBy)
      .slice(0, 5);
  },

  // ─── Confirmer une vérification existante ─────
  confirm(id) {
    const d = this.get();
    const verif = d.verifications.find(v => v.id === id);
    if (verif) {
      verif.confirmedBy++;
      verif.lastConfirmed = new Date().toISOString();
      this.save(d);
    }
    return verif;
  },

  // ─── Contester une vérification ───────────────
  dispute(id, correction) {
    const d = this.get();
    const verif = d.verifications.find(v => v.id === id);
    if (verif) {
      verif.disputed = true;
      verif.correction = correction;
      verif.disputedAt = new Date().toISOString();
      this.save(d);
    }
    return verif;
  },

  // ─── Vérifier avec l'IA + terrain ─────────────
  async verify(subject, claudeKey) {
    if (window.addChatMsg) addChatMsg('assistant', `🔍 Vérification en cours : "${subject}"...`);

    // 1. Chercher dans la base terrain d'abord
    const terrain = this.search(subject);
    if (terrain.length > 0) {
      const best = terrain[0];
      const msg = `✓ Vérification terrain (${best.confirmedBy} confirmation(s)) :\n\n${best.truth}\n\nVérifié le ${new Date(best.verifiedAt).toLocaleDateString('fr-FR')} par la communauté Or Eille AI.`;
      if (window.addChatMsg) addChatMsg('assistant', msg);
      return best;
    }

    // 2. Vérifier dans le cache
    if (window.VERIFICATION_CACHE) {
      const cached = VERIFICATION_CACHE.find(subject);
      if (cached) {
        const msg = `✓ Information vérifiée le ${new Date(cached.verifiedAt).toLocaleDateString('fr-FR')} — source : ${cached.source}\n\n${cached.result}`;
        if (window.addChatMsg) addChatMsg('assistant', msg);
        return cached;
      }
    }

    // 3. Recherche web via Claude
    if (!claudeKey) {
      if (window.addChatMsg) addChatMsg('assistant', 'Clé API non configurée. Impossible de vérifier en ligne.');
      return null;
    }

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 300,
          tools: [{ type: 'web_search_20250305', name: 'web_search' }],
          system: window.OR_EILLE_SYSTEM_PROMPT || 'Tu vérifies des informations factuelles. Tu cites toujours ta source et la date de vérification. Si tu n\'as pas de confirmation fiable, tu le dis clairement.',
          messages: [{ role: 'user', content: `Vérifie cette information : "${subject}". Donne une réponse factuelle avec ta source et la date. Si tu ne peux pas confirmer, dis-le clairement.` }]
        })
      });
      const data = await r.json();
      const text = data.content.filter(b => b.type === 'text').map(b => b.text).join('');

      // Enregistrer dans le cache
      if (window.VERIFICATION_CACHE) {
        VERIFICATION_CACHE.add(subject, text, 'Recherche web Or Eille AI — ' + new Date().toLocaleDateString('fr-FR'));
      }

      if (window.addChatMsg) addChatMsg('assistant', `🔍 Vérification web :\n\n${text}\n\nSi vous avez une vérification terrain, appuyez sur "Ajouter ma vérification" pour enrichir la base.`);
      return { result: text };
    } catch {
      if (window.addChatMsg) addChatMsg('assistant', 'Erreur de vérification. Vérifiez votre connexion.');
      return null;
    }
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    const recent = d.verifications.slice(-10).reverse();

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div class="sec-title">🔍 Vérifier une information</div>
      <p class="note">Or Eille AI vérifie d'abord dans la base terrain de la communauté, puis en ligne. Aucune affirmation sans source.</p>

      <div style="display:flex;gap:.4rem">
        <input type="text" id="verif-query" placeholder="Que voulez-vous vérifier ?" style="flex:1"/>
        <button onclick="VERIF.verify(document.getElementById('verif-query').value,window.CFG?.CLAUDE_KEY)" style="padding:.5rem .7rem;background:var(--gold);color:var(--dark);border:none;font-family:'Josefin Sans',sans-serif;font-size:.52rem;cursor:pointer">Vérifier</button>
      </div>
      <button class="btn btn-ghost" onclick="WHISPER.start(t=>{document.getElementById('verif-query').value=t;VERIF.verify(t,window.CFG?.CLAUDE_KEY)})">🎙 Dicter la question</button>

      <div class="sep"></div>
      <div class="sec-title">✅ Ajouter ma vérification terrain</div>
      <p class="note">Vous savez que quelque chose a changé ? Partagez-le avec la communauté.</p>

      <input type="text" id="verif-subject" placeholder="Sujet (ex: Gare routière de Belgrade)" style="margin-bottom:.3rem"/>
      <textarea id="verif-truth" placeholder="La vérité terrain (ex: La gare est ouverte depuis mai 2026, nouveau bâtiment côté nord)" style="min-height:70px;margin-bottom:.3rem"></textarea>
      <select id="verif-cat" style="background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.58rem;padding:.45rem;outline:none;margin-bottom:.4rem">
        ${Object.entries(this.CATEGORIES).map(([k,v]) => `<option value="${k}">${v}</option>`).join('')}
      </select>
      <button class="btn btn-gold" onclick="
        const s=document.getElementById('verif-subject').value;
        const t=document.getElementById('verif-truth').value;
        const c=document.getElementById('verif-cat').value;
        if(s&&t){
          VERIF.addVerification(s,t,c,null);
          document.getElementById('verif-subject').value='';
          document.getElementById('verif-truth').value='';
          document.getElementById('verifContent').innerHTML=VERIF.renderPanel();
          if(window.addChatMsg)addChatMsg('assistant','✓ Vérification terrain enregistrée et partagée. Merci pour votre contribution !');
        }
      ">✓ Publier ma vérification</button>

      ${recent.length > 0 ? `
        <div class="sep"></div>
        <div class="sec-title">Vérifications récentes de la communauté</div>
        ${recent.map(v => `
          <div style="padding:.6rem;border:1px solid var(--border);background:var(--dark-mid)">
            <div style="font-size:.58rem;color:var(--text);margin-bottom:.2rem">${v.subject}</div>
            <div style="font-size:.52rem;color:var(--muted);line-height:1.5;margin-bottom:.3rem">${v.truth}</div>
            <div style="display:flex;justify-content:space-between;align-items:center">
              <div style="font-size:.44rem;color:var(--muted)">
                ${new Date(v.verifiedAt).toLocaleDateString('fr-FR')} · ${v.confirmedBy} confirmation(s)
              </div>
              <div style="display:flex;gap:.3rem">
                <button onclick="VERIF.confirm('${v.id}');document.getElementById('verifContent').innerHTML=VERIF.renderPanel()" style="padding:.2rem .4rem;background:rgba(129,199,132,.15);border:1px solid rgba(129,199,132,.4);color:#81c784;font-size:.44rem;cursor:pointer">✓ Confirmer</button>
                <button onclick="const c=prompt('Quelle est la correction ?');if(c)VERIF.dispute('${v.id}',c)" style="padding:.2rem .4rem;background:rgba(239,83,80,.1);border:1px solid rgba(239,83,80,.3);color:#ef5350;font-size:.44rem;cursor:pointer">✗ Contester</button>
              </div>
            </div>
          </div>
        `).join('')}
      ` : ''}
    </div>`;
  }
};

window.VERIF = VERIF;
