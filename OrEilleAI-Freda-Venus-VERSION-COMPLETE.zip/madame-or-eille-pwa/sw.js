// Service Worker — Or Eille AI
// Cache local + mode économie batterie/réseau
const CACHE = 'oe-ai-v1';
const STATIC = [
  '/', '/index.html',
  '/style.css', '/app.js',
  '/kids.js', '/recipes.js', '/method_oe.js',
  '/sport_home.js', '/etiquette.js', '/literacy.js',
  '/culture_general.js', '/parent_guides.js',
  '/numeracy.js', '/events_deco.js', '/intro_pages.js',
  '/learning_style.js', '/translator.js',
];

// Installation — mise en cache des fichiers statiques
self.addEventListener('install', function(e) {
  e.waitUntil(
    caches.open(CACHE).then(function(cache) {
      return cache.addAll(STATIC.filter(function(url) {
        return url.indexOf('.js') > -1 || url === '/index.html';
      }));
    }).catch(function() { return; })
  );
  self.skipWaiting();
});

// Activation
self.addEventListener('activate', function(e) {
  e.waitUntil(
    caches.keys().then(function(keys) {
      return Promise.all(keys.filter(function(k){return k!==CACHE;}).map(function(k){return caches.delete(k);}));
    })
  );
  self.clients.claim();
});

// Fetch — cache first pour les fichiers statiques
self.addEventListener('fetch', function(e) {
  var url = e.request.url;
  // API calls — toujours réseau
  if (url.indexOf('anthropic.com') > -1 || url.indexOf('replicate.com') > -1) {
    e.respondWith(fetch(e.request).catch(function() {
      return new Response(JSON.stringify({error:'Pas de connexion. Verifie ton reseau.'}), {headers:{'Content-Type':'application/json'}});
    }));
    return;
  }
  // Fichiers statiques — cache first
  e.respondWith(
    caches.match(e.request).then(function(cached) {
      return cached || fetch(e.request).then(function(response) {
        if (response && response.status === 200) {
          var clone = response.clone();
          caches.open(CACHE).then(function(cache) { cache.put(e.request, clone); });
        }
        return response;
      });
    }).catch(function() {
      return caches.match('/index.html');
    })
  );
});
