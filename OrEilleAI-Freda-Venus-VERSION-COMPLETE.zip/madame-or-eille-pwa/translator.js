// ═══════════════════════════════════════════════════
//  TRADUCTEUR INSTANTANÉ — Or Eille AI v1.0
//  Conversation multilingue en temps réel
//  Français + Wolof + Malais = tout le monde se comprend
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const TRANSLATOR = {
  KEY: 'moe_translator',

  LANGUAGES: {
    fr: { name: 'Français', flag: '🇫🇷', voice: 'fr-FR' },
    en: { name: 'English', flag: '🇬🇧', voice: 'en-US' },
    ln: { name: 'Lingála', flag: '🌍', voice: 'fr-FR' },
    fon: { name: 'Fon (Bénin)', flag: '🇧🇯', voice: 'fr-FR' },
    ber: { name: 'Amazigh / Tamazight', flag: '🌍', voice: 'ar-SA' },
    wo: { name: 'Wolof', flag: '🇸🇳', voice: 'fr-FR' },
    sw: { name: 'Kiswahili', flag: '🌍', voice: 'sw-TZ' },
    ar: { name: 'العربية', flag: '🌍', voice: 'ar-SA' },
    zh: { name: '中文', flag: '🇨🇳', voice: 'zh-CN' },
    ja: { name: '日本語', flag: '🇯🇵', voice: 'ja-JP' },
    ko: { name: '한국어', flag: '🇰🇷', voice: 'ko-KR' },
    vi: { name: 'Tiếng Việt', flag: '🇻🇳', voice: 'vi-VN' },
    hi: { name: 'हिन्दी', flag: '🇮🇳', voice: 'hi-IN' },
    ru: { name: 'Русский', flag: '🇷🇺', voice: 'ru-RU' },
    tr: { name: 'Türkçe', flag: '🇹🇷', voice: 'tr-TR' },
  },

  getData() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      myLang: 'fr', targetLangs: ['en'], history: [], mode: 'text'
    }; } catch { return {}; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Traduire un texte ────────────────────────
  async translate(text, fromLang, toLang, claudeKey) {
    if (!claudeKey) return null;
    if (fromLang === toLang) return text;

    const fromName = this.LANGUAGES[fromLang]?.name || fromLang;
    const toName = this.LANGUAGES[toLang]?.name || toLang;

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 300,
          messages: [{
            role: 'user',
            content: `Traduis ce texte du ${fromName} vers le ${toName}. Réponds UNIQUEMENT avec la traduction, rien d'autre, sans guillemets:\n\n${text}`
          }]
        })
      });
      const data = await r.json();
      return data.content[0].text.trim();
    } catch { return null; }
  },

  // ─── Traduire vers plusieurs langues ──────────
  async translateToAll(text, fromLang, targetLangs, claudeKey) {
    if (!claudeKey) return {};
    const results = {};
    await Promise.all(targetLangs.map(async lang => {
      if (lang !== fromLang) {
        results[lang] = await this.translate(text, fromLang, lang, claudeKey);
      }
    }));
    return results;
  },

  // ─── Lire à voix haute ────────────────────────
  speak(text, lang) {
    if (!window.speechSynthesis) return;
    const langInfo = this.LANGUAGES[lang];
    const utt = new SpeechSynthesisUtterance(text);
    utt.lang = langInfo?.voice || lang;
    utt.rate = 0.85;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utt);
  },

  // ─── Mode conversation multilingue ────────────
  async sendMessage(text, claudeKey) {
    const d = this.getData();
    if (!text.trim()) return;

    const message = {
      id: Date.now().toString(),
      original: text,
      fromLang: d.myLang,
      translations: {},
      at: new Date().toISOString()
    };

    // Afficher immédiatement
    d.history.push(message);
    d.history = d.history.slice(-50);
    this.save(d);
    document.getElementById('translatorContent').innerHTML = this.renderPanel();

    // Traduire vers toutes les langues cibles
    if (claudeKey) {
      const translations = await this.translateToAll(text, d.myLang, d.targetLangs, claudeKey);
      message.translations = translations;
      this.save(d);
      document.getElementById('translatorContent').innerHTML = this.renderPanel();
    }
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.getData();

    return `
    <div style="display:flex;flex-direction:column;flex:1;overflow:hidden">

      <!-- Config langues -->
      <div style="padding:.6rem;border-bottom:1px solid var(--border);background:var(--dark)">
        <div style="font-size:.48rem;color:var(--muted);margin-bottom:.3rem">Je parle</div>
        <div style="display:flex;gap:.3rem;flex-wrap:wrap;margin-bottom:.4rem">
          ${Object.entries(this.LANGUAGES).map(([k,v]) => `
            <button onclick="const dd=TRANSLATOR.getData();dd.myLang='${k}';TRANSLATOR.save(dd);document.getElementById('translatorContent').innerHTML=TRANSLATOR.renderPanel()" style="padding:.25rem .4rem;background:${d.myLang===k?'var(--gold)':'var(--dark-mid)'};color:${d.myLang===k?'var(--dark)':'var(--muted)'};border:1px solid ${d.myLang===k?'var(--gold)':'var(--border)'};font-size:.48rem;cursor:pointer">${v.flag} ${v.name}</button>
          `).join('')}
        </div>

        <div style="font-size:.48rem;color:var(--muted);margin-bottom:.3rem">Traduire vers (12 langues rapides + toutes les langues du monde)</div>
        <div style="display:flex;gap:.3rem;flex-wrap:wrap;margin-bottom:.3rem">
          ${Object.entries(this.LANGUAGES).filter(([k]) => k !== d.myLang).map(([k,v]) => {
            const selected = d.targetLangs.includes(k);
            return `<button onclick="const dd=TRANSLATOR.getData();const idx=dd.targetLangs.indexOf('${k}');if(idx>-1)dd.targetLangs.splice(idx,1);else dd.targetLangs.push('${k}');TRANSLATOR.save(dd);document.getElementById('translatorContent').innerHTML=TRANSLATOR.renderPanel()" style="padding:.25rem .4rem;background:${selected?'rgba(27,79,138,.3)':'var(--dark-mid)'};color:${selected?'#6BA3D6':'var(--muted)'};border:1px solid ${selected?'#1B4F8A':'var(--border)'};font-size:.48rem;cursor:pointer">${v.flag} ${v.name}</button>`;
          }).join('')}
        </div>
        <div style="display:flex;gap:.3rem;align-items:center">
          <input type="text" id="custom-lang-input" placeholder="Autre langue — bambara, tagalog, créole..." style="flex:1;font-size:.52rem"/>
          <button onclick="const val=document.getElementById('custom-lang-input').value.trim();if(val){const dd=TRANSLATOR.getData();if(!dd.targetLangs.includes(val))dd.targetLangs.push(val);TRANSLATOR.save(dd);document.getElementById('custom-lang-input').value='';document.getElementById('translatorContent').innerHTML=TRANSLATOR.renderPanel();if(window.addChatMsg)addChatMsg('assistant','✓ '+val+' ajouté. Claude traduit vers cette langue.')}" style="padding:.35rem .6rem;background:var(--cobalt);color:#fff;border:none;font-size:.5rem;cursor:pointer">+ Ajouter</button>
        </div>
        ${d.targetLangs.filter(l => !Object.keys(this.LANGUAGES).includes(l)).length > 0 ? `
        <div style="display:flex;gap:.3rem;flex-wrap:wrap;margin-top:.3rem">
          ${d.targetLangs.filter(l => !Object.keys(this.LANGUAGES).includes(l)).map(l => `
            <button onclick="const dd=TRANSLATOR.getData();dd.targetLangs=dd.targetLangs.filter(x=>x!=='${l}');TRANSLATOR.save(dd);document.getElementById('translatorContent').innerHTML=TRANSLATOR.renderPanel()" style="padding:.25rem .4rem;background:rgba(27,79,138,.3);color:#6BA3D6;border:1px solid #1B4F8A;font-size:.48rem;cursor:pointer">🌐 ${l} ×</button>
          `).join('')}
        </div>` : ''}
      </div>

      <!-- Historique -->
      <div style="flex:1;overflow-y:auto;padding:.6rem;display:flex;flex-direction:column;gap:.6rem">
        ${d.history.length === 0 ? `
          <div style="text-align:center;padding:2rem;color:var(--muted);font-size:.56rem">
            Un Français, un Sénégalais et un Malaysien se parlent.<br/>
            Choisissez vos langues et commencez à écrire.
          </div>
        ` : d.history.slice().reverse().map(msg => `
          <div style="background:var(--dark-mid);border:1px solid var(--border);padding:.6rem">
            <div style="display:flex;align-items:center;gap:.3rem;margin-bottom:.4rem">
              <span style="font-size:.8rem">${this.LANGUAGES[msg.fromLang]?.flag || ''}</span>
              <span style="font-size:.56rem;color:var(--text)">${msg.original}</span>
              <button onclick="TRANSLATOR.speak('${msg.original.replace(/'/g,"\\'")}','${msg.fromLang}')" style="margin-left:auto;background:transparent;border:none;font-size:.7rem;cursor:pointer">🔊</button>
            </div>
            ${Object.entries(msg.translations || {}).map(([lang, text]) => text ? `
              <div style="padding:.3rem 0;border-top:1px solid var(--border);display:flex;align-items:center;gap:.3rem">
                <span style="font-size:.7rem">${this.LANGUAGES[lang]?.flag || ''}</span>
                <span style="font-size:.52rem;color:var(--muted);flex:1">${text}</span>
                <button onclick="TRANSLATOR.speak('${text.replace(/'/g,"\\'")}','${lang}')" style="background:transparent;border:none;font-size:.65rem;cursor:pointer">🔊</button>
              </div>
            ` : '').join('')}
          </div>
        `).join('')}
      </div>

      <!-- Saisie -->
      <div style="padding:.6rem;border-top:1px solid var(--border);display:flex;gap:.4rem">
        <input type="text" id="trans-input" placeholder="Écrivez ou dictez..." style="flex:1" onkeydown="if(event.key==='Enter')TRANSLATOR.sendMessage(this.value,window.CFG?.CLAUDE_KEY).then(()=>{this.value=''})"/>
        <button onclick="TRANSLATOR.sendMessage(document.getElementById('trans-input').value,window.CFG?.CLAUDE_KEY).then(()=>{document.getElementById('trans-input').value=''})" style="padding:.5rem .7rem;background:var(--gold);color:var(--dark);border:none;font-size:.7rem;cursor:pointer">→</button>
        <button onclick="WHISPER.start(t=>{document.getElementById('trans-input').value=t;TRANSLATOR.sendMessage(t,window.CFG?.CLAUDE_KEY).then(()=>{document.getElementById('trans-input').value=''})})" style="padding:.5rem .6rem;background:transparent;border:1px solid var(--gold);color:var(--gold);font-size:.75rem;cursor:pointer">🎙</button>
      </div>
    </div>`;
  }
};

window.TRANSLATOR = TRANSLATOR;
