// ═══════════════════════════════════════════════════
//  MULTI-COMPTE & ADAPTATION CULTURELLE — Or Eille AI v1.0
//  Plusieurs pages — adaptation par culture
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const MULTICULTURAL = {
  KEY: 'moe_multicultural',

  CULTURES: [
    { id: 'fr_metro', label: 'France metropolitaine', icon: '🇫🇷', notes: 'Humour subtil, references universelles, ton direct mais poli' },
    { id: 'fr_afro', label: 'Afrodescendants France', icon: '🌍', notes: 'References diaspora, codes culturels mixtes, authenticite valorisee' },
    { id: 'sn', label: 'Senegal', icon: '🇸🇳', notes: 'Teranga, codes wolof, references locales, famille centrale' },
    { id: 'ci', label: 'Cote d Ivoire', icon: '🇨🇮', notes: 'Nouchi, humour ivoirien, references locales, ton festif' },
    { id: 'cm', label: 'Cameroun', icon: '🇨🇲', notes: 'Diversite linguistique, humour camfranglais, references locales' },
    { id: 'be', label: 'Belgique', icon: '🇧🇪', notes: 'Humour belge, auto-derision, references franco-belges' },
    { id: 'ca', label: 'Canada francophone', icon: '🇨🇦', notes: 'Quebec, joual, references nord-americaines, ton direct' },
    { id: 'fon', label: 'Bénin / Fon', icon: '🇧🇯', notes: 'Fon, references benineoises, Vaudou culture, ton chaleureux, famille et communaute centrales' },
    { id: 'antilles', label: 'Antilles', icon: '🌴', notes: 'Creole, references antillaises, ton chaud, humour specifique' },
  ],

  ACCOUNT_KEY: 'moe_accounts',

  getAccounts() {
    try { return JSON.parse(localStorage.getItem(this.ACCOUNT_KEY)) || []; }
    catch { return []; }
  },
  saveAccounts(accounts) { localStorage.setItem(this.ACCOUNT_KEY, JSON.stringify(accounts)); },

  addAccount(name, platform, culture, niche) {
    const accounts = this.getAccounts();
    accounts.push({ id: Date.now().toString(), name, platform, culture, niche, createdAt: new Date().toISOString() });
    this.saveAccounts(accounts);
    if (window.addChatMsg) addChatMsg('assistant', '✅ Compte "' + name + '" ajoute. Or Eille AI adaptera le contenu pour ' + culture + '.');
    document.getElementById('multiculturalContent').innerHTML = MULTICULTURAL.renderPanel();
  },

  async adaptContent(content, fromCulture, toCulture, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant', 'Cle API requise.'); return; }
    if (!content) { if (window.addChatMsg) addChatMsg('assistant', 'Entrez le contenu a adapter.'); return; }

    const from = this.CULTURES.find(function(c) { return c.id === fromCulture; }) || { label: 'France', notes: '' };
    const to = this.CULTURES.find(function(c) { return c.id === toCulture; }) || { label: toCulture, notes: '' };

    if (window.addChatMsg) addChatMsg('assistant', 'Adaptation de ' + from.label + ' vers ' + to.label + '...');

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 800,
          messages: [{
            role: 'user',
            content: 'Adapte ce contenu pour une audience ' + to.label + '.\n\nNotes culturelles : ' + to.notes + '\n\nContenu original :\n' + content + '\n\nGarde le message et lemotion. Adapte les references, le ton, les expressions. Pas une traduction — une adaptation culturelle authentique. Meme langue (francais) mais codes culturels differents.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', '✅ Version ' + to.label + ' :\n\n' + data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant', 'Erreur. Verifiez votre connexion.'); }
  },

  renderPanel: function() {
    const accounts = this.getAccounts();

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🌍 Adaptation culturelle</div>' +
      '<p class="note">Ce qui marche en France metropolitaine ne marche pas forcement au Senegal ou aux Antilles. Or Eille AI adapte votre contenu pour chaque culture — meme message, codes differents.</p>' +
      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">Pas une traduction. Une vraie adaptation culturelle. Les memes mots mais les bonnes references, le bon humour, le bon ton pour chaque communaute.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div class="sec-title">Adapter un contenu</div>' +
      '<textarea id="mc-content" placeholder="Collez votre contenu a adapter..." style="min-height:80px"></textarea>' +
      '<div style="display:flex;gap:.4rem">' +
        '<div style="flex:1"><span class="klabel">Culture originale</span>' +
          '<select id="mc-from" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.56rem;padding:.4rem;outline:none">' +
          this.CULTURES.map(function(c) { return '<option value="' + c.id + '">' + c.icon + ' ' + c.label + '</option>'; }).join('') +
          '</select></div>' +
        '<div style="flex:1"><span class="klabel">Culture cible</span>' +
          '<select id="mc-to" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.56rem;padding:.4rem;outline:none">' +
          this.CULTURES.map(function(c) { return '<option value="' + c.id + '">' + c.icon + ' ' + c.label + '</option>'; }).join('') +
          '</select></div>' +
      '</div>' +
      '<button class="btn btn-gold" onclick="MULTICULTURAL.adaptContent(document.getElementById(\'mc-content\').value,document.getElementById(\'mc-from\').value,document.getElementById(\'mc-to\').value,window.CFG&&window.CFG.CLAUDE_KEY)">🌍 Adapter culturellement</button>' +

      '<div class="sep"></div>' +
      '<div class="sec-title">📱 Mes comptes (multi-compte)</div>' +
      '<p class="note">Gerez plusieurs pages depuis Or Eille AI. Contenu adapte automatiquement pour chaque compte.</p>' +
      '<div style="display:flex;gap:.4rem">' +
        '<input type="text" id="acc-name" placeholder="Nom du compte" style="flex:1"/>' +
        '<select id="acc-platform" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.52rem;padding:.4rem;outline:none">' +
          '<option>Instagram</option><option>TikTok</option><option>YouTube</option><option>Facebook</option>' +
        '</select>' +
      '</div>' +
      '<select id="acc-culture" style="width:100%;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.56rem;padding:.4rem;outline:none">' +
        this.CULTURES.map(function(c) { return '<option value="' + c.id + '">' + c.icon + ' ' + c.label + '</option>'; }).join('') +
      '</select>' +
      '<button class="btn btn-ghost" onclick="MULTICULTURAL.addAccount(document.getElementById(\'acc-name\').value,document.getElementById(\'acc-platform\').value,document.getElementById(\'acc-culture\').value,\'\')">+ Ajouter ce compte</button>' +

      (accounts.length > 0 ? (
        accounts.map(function(a) {
          const cult = MULTICULTURAL.CULTURES.find(function(c) { return c.id === a.culture; });
          return '<div style="padding:.5rem;border:1px solid var(--border);background:var(--dark-mid);margin-bottom:.3rem">' +
            '<div style="font-size:.56rem;color:var(--text)">' + (cult?cult.icon:'🌍') + ' ' + a.name + ' — ' + a.platform + '</div>' +
            '<div style="font-size:.46rem;color:var(--muted)">' + (cult?cult.label:a.culture) + '</div>' +
          '</div>';
        }).join('')
      ) : '') +

    '</div>';
  }
};

window.MULTICULTURAL = MULTICULTURAL;
