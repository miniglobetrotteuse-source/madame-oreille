// ═══════════════════════════════════════════════════
//  MODE ÉCONOMIE — Or Eille AI v1.0
//  Batterie · réseau · optimisation automatique
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const POWER = {

  // Enregistrer le service worker
  registerSW: function() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(function(){});
    }
  },

  // Détecter batterie faible
  checkBattery: async function() {
    if (!navigator.getBattery) return false;
    try {
      const battery = await navigator.getBattery();
      return battery.level < 0.2 && !battery.charging;
    } catch(e) { return false; }
  },

  // Détecter réseau lent
  checkNetwork: function() {
    if (!navigator.connection) return false;
    const slow = ['slow-2g','2g'];
    return slow.indexOf(navigator.connection.effectiveType) > -1;
  },

  // Mode économie — réduire les requêtes
  isSaveMode: async function() {
    const lowBattery = await this.checkBattery();
    const slowNetwork = this.checkNetwork();
    return lowBattery || slowNetwork;
  },

  // Afficher un avertissement si mode économie
  showSaveModeAlert: async function() {
    const save = await this.isSaveMode();
    if (!save) return;
    const el = document.getElementById('power-alert');
    if (el) el.style.display = 'flex';
  },

  // Initialiser
  init: function() {
    this.registerSW();
    this.showSaveModeAlert();
  }
};

window.POWER = POWER;
document.addEventListener('DOMContentLoaded', function() {
  if (window.POWER) POWER.init();
});
