// ═══════════════════════════════════════════════════
//  MÉTHODE OR EILLE AI — Transversale
//  Centrer · Exécuter · Ancrer
//  Dans chaque module. Partout. Toujours.
//  Basée sur des recherches scientifiques validées.
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const METHOD = {
  KEY: 'moe_method',

  // ─── Les 3 temps — partout, toujours ──────────
  THREE_TIMES: {
    center: {
      label: 'Centrer',
      duration: 30,
      instruction: 'Pose-toi. Inspire lentement 4 secondes. Retiens 4 secondes. Expire 6 secondes. Tu es la. Tu es pret.',
    },
    execute: {
      label: 'Executer',
      instruction: 'Un geste a la fois. Pas d anticipation. Pas de jugement. Juste ce geste, maintenant.',
    },
    anchor: {
      label: 'Ancrer',
      duration: 15,
      instruction: 'Tu viens de faire quelque chose. Prends 15 secondes pour le sentir. Ton cerveau vient d enregistrer.',
    },
  },

  // ─── Modules 2 minutes ────────────────────────
  MODULES: {
    ma_langue:      { label:'Ma langue à moi',   icon:'🌍', category:'langue', note:'Tu choisis laquelle — anglais, chinois, lingala, serbe, tout' },
    bonne_maniere:  { label:'Bonne manière',     icon:'🤝', category:'culture' },
    culture_monde:  { label:'Culture du monde',  icon:'🌐', category:'culture' },
    histoire:       { label:'Histoire',          icon:'📜', category:'culture' },
    sport_maison:   { label:'Sport maison',      icon:'💪', category:'corps' },
    posture:        { label:'Posture & maintien',icon:'🧍', category:'corps' },
    nutrition:      { label:'Nutrition',         icon:'🥗', category:'corps' },
    mental:         { label:'Mental & concentration', icon:'🧠', category:'mental' },
    respiration:    { label:'Respiration',       icon:'🌬', category:'mental' },
    lecture:        { label:'Apprendre à lire',  icon:'📖', category:'savoir' },
    maths:          { label:'Maths du quotidien',icon:'🔢', category:'savoir' },
    bricolage:      { label:'Bricolage',         icon:'🔨', category:'pratique' },
    cuisine:        { label:'Cuisine',           icon:'🍳', category:'pratique' },
    diy_culture:    { label:'DIY & artisanat',   icon:'🎨', category:'pratique' },
  },

  // ─── Contextes sportifs sans bruit ────────────
  SPORT_CONTEXTS: {
    appartement_voisins: {
      label: 'Appartement avec voisins',
      silent: true,
      exercises: ['Gainage','Squats lents','Pompes','Abdos','Yoga','Pilates','Etirements profonds','Musculation au sol'],
    },
    appartement_libre: {
      label: 'Appartement libre',
      silent: false,
      exercises: ['Corde a sauter','Cardio danse','HIIT','Tout'],
    },
    maison_jardin: {
      label: 'Maison avec exterieur',
      silent: false,
      exercises: ['Course','Corde','Sport collectif','Tout'],
    },
  },

  // ─── Progression 30 jours ─────────────────────
  getProgression(day) {
    if (day <= 7)  return { phase:'Effort conscient', message:'C est nouveau. C est normal que ca demande un effort. Continue.' };
    if (day <= 14) return { phase:'Ca commence a rentrer', message:'Tu sens la difference ? C est ton cerveau qui se reparametre. Continue.' };
    if (day <= 21) return { phase:'Ca devient automatique', message:'Ton cerveau a cree de nouvelles connexions. Ca rentre tout seul maintenant.' };
    return { phase:'C est toi maintenant', message:'Tu ne sais meme plus que tu l as appris. C est juste toi. Ajoute un nouveau module si tu veux.' };
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      activeModules: ['anglais','bonne_maniere','sport_maison'],
      dayCount: 1,
      lastSession: null,
      sportContext: 'appartement_voisins',
      profile: 'adulte',
    }; }
    catch { return { activeModules:['anglais'], dayCount:1, lastSession:null }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async getSession(claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const d = this.get();
    const prog = this.getProgression(d.dayCount);
    const modules = d.activeModules.slice(0, 10);
    const totalMin = modules.length * 2;

    if (window.addChatMsg) addChatMsg('assistant',
      'Jour ' + d.dayCount + ' — ' + prog.phase + '\n\n' +
      prog.message + '\n\n' +
      'Ta session du jour — ' + totalMin + ' minutes au total :\n' +
      modules.map(function(m,i) { return (i+1) + '. ' + (METHOD.MODULES[m]?METHOD.MODULES[m].icon+' ':' ') + (METHOD.MODULES[m]?METHOD.MODULES[m].label:m) + ' — 2 min'; }).join('\n')
    );

    // Generer le contenu de chaque module
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:800,
          messages:[{ role:'user', content:
            'Genere une session de ' + totalMin + ' minutes avec ces modules de 2 minutes chacun : ' + modules.join(', ') + '.\n\n' +
            'Pour chaque module :\n' +
            '1. CENTRER — 30 secondes de respiration simple\n' +
            '2. EXECUTER — le contenu du module en 2 minutes (exercice, mot, notion, code culturel)\n' +
            '3. ANCRER — 15 secondes pour sentir ce qu on vient de faire\n\n' +
            'Contenu base sur des recherches scientifiques validees. Concret. Efficace. Bienveillant. Jamais de developpement personnel creux. Jamais de promesses. Juste les bons exercices.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);

      // Incrementer le compteur de jours
      d.dayCount++;
      d.lastSession = new Date().toISOString();
      this.save(d);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  toggleModule(moduleKey) {
    const d = this.get();
    const idx = d.activeModules.indexOf(moduleKey);
    if (idx > -1) d.activeModules.splice(idx, 1);
    else d.activeModules.push(moduleKey);
    this.save(d);
    document.getElementById('methodContent').innerHTML = METHOD.renderPanel();
  },

  renderPanel: function() {
    const d = this.get();
    const prog = this.getProgression(d.dayCount);
    const totalMin = d.activeModules.length * 2;
    const categories = ['langue','culture','corps','mental','savoir','pratique'];
    const catLabels = { langue:'🗣 Langues', culture:'🌍 Culture & Manières', corps:'💪 Corps & Sport', mental:'🧠 Mental', savoir:'📖 Savoir de base', pratique:'🔨 Pratique' };

    let modulesHtml = categories.map(function(cat) {
      const mods = Object.entries(METHOD.MODULES).filter(function(e) { return e[1].category === cat; });
      return '<div style="margin-bottom:.8rem">' +
        '<div style="font-size:.44rem;letter-spacing:.15em;text-transform:uppercase;color:rgba(196,153,58,.5);margin-bottom:.3rem">' + catLabels[cat] + '</div>' +
        '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
          mods.map(function(e) {
            const sel = d.activeModules.includes(e[0]);
            return '<button onclick="METHOD.toggleModule(\'' + e[0] + '\')" style="padding:.3rem .5rem;background:' + (sel?'rgba(196,153,58,.15)':'var(--dark-mid)') + ';border:1px solid ' + (sel?'var(--gold)':'var(--border)') + ';color:' + (sel?'var(--gold)':'var(--muted)') + ';font-family:Josefin Sans,sans-serif;font-size:.46rem;cursor:pointer">' + e[1].icon + ' ' + e[1].label + '</button>';
          }).join('') +
        '</div></div>';
    }).join('');

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +

      '<div class="sec-title">⚡ Méthode Or Eille AI — 2 minutes par module</div>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem">' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">Centrer · Exécuter · Ancrer. Partout. Toujours. 2 minutes par module. Tous les jours. Ce qui rentre dans la session rentre dans la vie.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;font-style:italic">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div style="padding:.6rem;border:1px solid rgba(196,153,58,.2);background:rgba(196,153,58,.04)">' +
        '<div style="font-size:.52rem;color:#C4993A">Jour ' + d.dayCount + ' — ' + prog.phase + '</div>' +
        '<div style="font-size:.46rem;color:rgba(240,232,216,.5);margin-top:.2rem">' + prog.message + '</div>' +
      '</div>' +

      '<div style="display:flex;gap:.4rem;align-items:center;padding:.5rem;border:1px solid var(--border)">' +
        '<div style="flex:1">' +
          '<div style="font-size:.54rem;color:var(--text)">' + d.activeModules.length + ' module(s) actif(s)</div>' +
          '<div style="font-size:.46rem;color:var(--muted)">' + totalMin + ' minutes au total par session</div>' +
        '</div>' +
        '<button class="btn btn-gold" onclick="METHOD.getSession(window.CFG&&window.CFG.CLAUDE_KEY)" style="padding:.5rem 1rem">▶ Ma session du jour</button>' +
      '</div>' +

      '<div class="sec-title">Mes modules — choisis ce que tu veux travailler</div>' +
      modulesHtml +

    '</div>';
  }
};

window.METHOD = METHOD;
