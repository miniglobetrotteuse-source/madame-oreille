// ═══════════════════════════════════════════════════
//  TÉLÉPROMPTER VOCAL — Or Eille AI v1.0
//  Le texte suit votre voix en temps réel
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const TELEPROMPTER = {
  KEY: 'moe_teleprompter',
  _recognition: null,
  _words: [],
  _currentWord: 0,
  _isRunning: false,
  _fontSize: 48,
  _speed: 1,

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { scripts: [] }; }
    catch { return { scripts: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  saveScript(title, text) {
    const d = this.get();
    d.scripts.unshift({ id: Date.now().toString(), title, text, createdAt: new Date().toISOString() });
    d.scripts = d.scripts.slice(0, 20);
    this.save(d);
    if (window.addChatMsg) addChatMsg('assistant', 'Script "' + title + '" sauvegarde.');
    document.getElementById('teleprompterContent').innerHTML = TELEPROMPTER.renderPanel();
  },

  // ─── Lancer le téléprompter vocal ─────────────
  start(text) {
    if (!text || !text.trim()) {
      if (window.addChatMsg) addChatMsg('assistant', 'Entrez votre script.');
      return;
    }

    this._words = text.trim().split(/\s+/);
    this._currentWord = 0;
    this._isRunning = true;

    // Afficher en plein écran
    this.showFullscreen(text);

    // Reconnaissance vocale
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      if (window.addChatMsg) addChatMsg('assistant', 'Reconnaissance vocale non disponible sur cet appareil. Le texte va defiler a vitesse fixe.');
      this.startFixedScroll();
      return;
    }

    this._recognition = new SpeechRecognition();
    this._recognition.continuous = true;
    this._recognition.interimResults = true;
    this._recognition.lang = 'fr-FR';

    const self = this;
    this._recognition.onresult = function(event) {
      const transcript = Array.from(event.results)
        .map(function(r) { return r[0].transcript; })
        .join(' ').toLowerCase().trim();

      const spokenWords = transcript.split(/\s+/);
      const lastSpoken = spokenWords[spokenWords.length - 1];

      // Avancer dans le script si le mot est reconnu
      for (let i = self._currentWord; i < Math.min(self._currentWord + 5, self._words.length); i++) {
        const scriptWord = self._words[i].toLowerCase().replace(/[^a-zàâäéèêëïîôùûü]/g, '');
        if (scriptWord && lastSpoken && lastSpoken.includes(scriptWord.substring(0, 4))) {
          self._currentWord = i + 1;
          self.updateHighlight();
          break;
        }
      }
    };

    this._recognition.onerror = function() {
      self.startFixedScroll();
    };

    this._recognition.start();
  },

  startFixedScroll() {
    const container = document.getElementById('tp-scroll');
    if (!container) return;
    let pos = 0;
    const self = this;
    this._scrollInterval = setInterval(function() {
      if (!self._isRunning) { clearInterval(self._scrollInterval); return; }
      pos += self._speed;
      container.scrollTop = pos;
    }, 50);
  },

  updateHighlight() {
    const words = document.querySelectorAll('.tp-word');
    words.forEach(function(w, i) {
      w.style.color = i < TELEPROMPTER._currentWord ? 'rgba(255,255,255,.3)' :
                      i === TELEPROMPTER._currentWord ? '#C4993A' : '#ffffff';
      if (i === TELEPROMPTER._currentWord) {
        w.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    });
  },

  stop() {
    this._isRunning = false;
    if (this._recognition) { this._recognition.stop(); this._recognition = null; }
    if (this._scrollInterval) { clearInterval(this._scrollInterval); }
    const overlay = document.getElementById('tp-fullscreen');
    if (overlay) overlay.remove();
  },

  showFullscreen(text) {
    const existing = document.getElementById('tp-fullscreen');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.id = 'tp-fullscreen';
    overlay.style.cssText = 'position:fixed;inset:0;background:#000;z-index:99999;display:flex;flex-direction:column;overflow:hidden';

    const wordsHtml = this._words.map(function(w, i) {
      return '<span class="tp-word" data-index="' + i + '" style="color:#fff;margin:0 .3em;line-height:1.6;cursor:pointer;transition:color .2s" onclick="TELEPROMPTER._currentWord=' + i + ';TELEPROMPTER.updateHighlight()">' + w + '</span>';
    }).join(' ');

    overlay.innerHTML =
      '<div style="display:flex;align-items:center;justify-content:space-between;padding:.8rem 1rem;background:rgba(196,153,58,.1);border-bottom:1px solid rgba(196,153,58,.3)">' +
        '<span style="font-size:.7rem;color:var(--gold)">🎙 Teleprompter vocal actif</span>' +
        '<div style="display:flex;gap:.5rem">' +
          '<button onclick="TELEPROMPTER._fontSize=Math.max(24,TELEPROMPTER._fontSize-8);document.getElementById(&quot;tp-text&quot;).style.fontSize=TELEPROMPTER._fontSize+&quot;px&quot;" style="background:rgba(255,255,255,.1);border:none;color:#fff;padding:.3rem .6rem;cursor:pointer;font-size:.7rem">A-</button>' +
          '<button onclick="TELEPROMPTER._fontSize=Math.min(96,TELEPROMPTER._fontSize+8);document.getElementById(&quot;tp-text&quot;).style.fontSize=TELEPROMPTER._fontSize+&quot;px&quot;" style="background:rgba(255,255,255,.1);border:none;color:#fff;padding:.3rem .6rem;cursor:pointer;font-size:.7rem">A+</button>' +
          '<button onclick="TELEPROMPTER._currentWord=Math.max(0,TELEPROMPTER._currentWord-3);TELEPROMPTER.updateHighlight()" style="background:rgba(255,255,255,.1);border:none;color:#fff;padding:.3rem .6rem;cursor:pointer;font-size:.7rem">◀</button>' +
          '<button onclick="TELEPROMPTER._currentWord=Math.min(TELEPROMPTER._words.length-1,TELEPROMPTER._currentWord+3);TELEPROMPTER.updateHighlight()" style="background:rgba(255,255,255,.1);border:none;color:#fff;padding:.3rem .6rem;cursor:pointer;font-size:.7rem">▶</button>' +
          '<button onclick="TELEPROMPTER.stop()" style="background:#ef5350;border:none;color:#fff;padding:.3rem .8rem;cursor:pointer;font-size:.7rem">✕ Stop</button>' +
        '</div>' +
      '</div>' +
      '<div id="tp-scroll" style="flex:1;overflow-y:auto;padding:2rem;text-align:center">' +
        '<div id="tp-text" style="font-size:' + this._fontSize + 'px;line-height:1.8;font-family:Georgia,serif">' + wordsHtml + '</div>' +
      '</div>' +
      '<div style="padding:.5rem;text-align:center;font-size:.5rem;color:rgba(255,255,255,.4)">Parlez normalement — le texte suit votre voix. Cliquez sur un mot pour vous repositionner.</div>';

    document.body.appendChild(overlay);
    this.updateHighlight();
  },

  renderPanel: function() {
    const d = this.get();
    let html = '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">';
    html += '<div class="sec-title">🎙 Teleprompter vocal</div>';
    html += '<p class="note">Le texte suit votre voix en temps reel. Vous accelerez — ca accelere. Vous pausez — ca s arrete.</p>';
    html += '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem">';
    html += '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">Ecrivez votre script. Appuyez sur Lancer. Le texte s affiche en grand et suit exactement votre voix. Cliquez sur un mot pour vous repositionner.</p>';
    html += '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;font-style:italic">— Madame Or Eille Studios</p>';
    html += '</div>';
    html += '<input type="text" id="tp-title" placeholder="Titre — ex: Reel 21 juin, Live astro..."/>';
    html += '<textarea id="tp-script" placeholder="Collez votre script ici..." style="min-height:120px"></textarea>';
    html += '<div style="display:flex;gap:.4rem">';
    html += '<button class="btn btn-gold" style="flex:2" onclick="TELEPROMPTER.startFromPanel()">🎙 Lancer le teleprompter</button>';
    html += '<button class="btn btn-ghost" style="flex:1" onclick="TELEPROMPTER.saveFromPanel()">💾 Sauvegarder</button>';
    html += '</div>';
    if (d.scripts.length > 0) {
      html += '<div class="sec-title">Scripts sauvegardes</div>';
      d.scripts.slice(0,5).forEach(function(s) {
        html += '<div style="display:flex;align-items:center;gap:.4rem;padding:.5rem;border:1px solid var(--border);margin-bottom:.3rem">';
        html += '<div style="flex:1"><div style="font-size:.54rem;color:var(--text)">' + s.title + '</div>';
        html += '<div style="font-size:.44rem;color:var(--muted)">' + s.text.substring(0,60) + '...</div></div>';
        html += '<button data-id="' + s.id + '" onclick="TELEPROMPTER.loadScript(this.getAttribute(&quot;data-id&quot;))" style="background:var(--gold);border:none;color:var(--dark);padding:.3rem .5rem;font-size:.46rem;cursor:pointer">Charger</button>';
        html += '</div>';
      });
    }
    html += '</div>';
    return html;
  }
};

TELEPROMPTER.startFromPanel = function() {
  const el = document.getElementById('tp-script');
  if (el) TELEPROMPTER.start(el.value);
};

TELEPROMPTER.saveFromPanel = function() {
  const t = document.getElementById('tp-title');
  const s = document.getElementById('tp-script');
  if (t && s) TELEPROMPTER.saveScript(t.value, s.value);
};

TELEPROMPTER.loadScript = function(id) {
  const d = TELEPROMPTER.get();
  const s = d.scripts.find(function(x) { return x.id === id; });
  if (!s) return;
  const t = document.getElementById('tp-script');
  const ti = document.getElementById('tp-title');
  if (t) t.value = s.text;
  if (ti) ti.value = s.title;
};

window.TELEPROMPTER = TELEPROMPTER;
