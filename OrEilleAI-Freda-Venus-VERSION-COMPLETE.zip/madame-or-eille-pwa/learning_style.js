// ═══════════════════════════════════════════════════
//  PROFIL D'APPRENTISSAGE — Or Eille AI v1.0
//  Detection automatique + adaptation du ton
//  Par defaut : chaleureux et visuel pour les creatifs
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const LEARNING = {
  KEY: 'moe_learning',

  // Profils de base
  PROFILES: {
    visuel: {
      label: 'Visuel et creatif',
      icon: '🎨',
      description: 'Tu penses en images. Tu as besoin de couleurs, de metaphores, d exemples concrets et vivants.',
      prompt: 'Reponds de facon chaleureuse et visuelle. Utilise des metaphores concretes et des exemples vivants. Evite les listes froides et le jargon. Va droit au but mais avec de la chaleur.'
    },
    analytique: {
      label: 'Analytique et structure',
      icon: '📊',
      description: 'Tu penses en chiffres et en logique. Tu veux de la precision et de la structure claire.',
      prompt: 'Reponds de facon precise et structuree. Utilise des chiffres, des etapes claires, des tableaux si utile. Va droit au but sans fioritures. Sois exact.'
    },
    narratif: {
      label: 'Narratif et intuitif',
      icon: '📖',
      description: 'Tu apprends par les histoires. Tu veux comprendre le sens avant les details.',
      prompt: 'Reponds en commencant par le sens global avant les details. Utilise des analogies et des histoires courtes. Donne la vision d ensemble d abord.'
    },
    mixte: {
      label: 'Mixte — selon le contexte',
      icon: '⚖',
      description: 'Tu alternes selon le sujet. Structure quand necessaire, creativite quand possible.',
      prompt: 'Adapte ton style selon le sujet. Structure pour les sujets techniques. Chaleur et creativite pour les sujets creatifs. Toujours concret et direct.'
    }
  },

  // Signaux de detection automatique
  SIGNALS: {
    visuel: ['couleur', 'image', 'voir', 'beau', 'design', 'visuel', 'photo', 'joli', 'esthetique', 'emoji', 'waouh', 'sympa'],
    analytique: ['chiffre', 'tableau', 'excel', 'pourcentage', 'calcul', 'precision', 'exactement', 'combien', 'statistique', 'donnee'],
    narratif: ['pourquoi', 'histoire', 'sens', 'comprendre', 'expliquer', 'contexte', 'fond', 'raison', 'logique'],
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      profile: 'visuel',
      detected: false,
      messageCount: 0,
      signals: { visuel: 0, analytique: 0, narratif: 0 }
    }; }
    catch { return { profile: 'visuel', detected: false, messageCount: 0, signals: { visuel: 0, analytique: 0, narratif: 0 } }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Analyser un message pour detecter le style ─
  analyzeMessage(text) {
    const d = this.get();
    const lower = text.toLowerCase();
    d.messageCount = (d.messageCount || 0) + 1;

    Object.keys(this.SIGNALS).forEach(function(profile) {
      LEARNING.SIGNALS[profile].forEach(function(signal) {
        if (lower.includes(signal)) {
          d.signals[profile] = (d.signals[profile] || 0) + 1;
        }
      });
    });

    // Detecter apres 5 messages
    if (d.messageCount >= 5 && !d.detected) {
      const max = Math.max(d.signals.visuel || 0, d.signals.analytique || 0, d.signals.narratif || 0);
      if (max > 0) {
        if (d.signals.visuel === max) d.profile = 'visuel';
        else if (d.signals.analytique === max) d.profile = 'analytique';
        else d.profile = 'narratif';
        d.detected = true;
        this.save(d);

        const p = this.PROFILES[d.profile];
        if (window.addChatMsg) addChatMsg('assistant', 'J ai adapte ma facon de communiquer a votre style — ' + p.icon + ' ' + p.label + '. Vous pouvez changer cela dans votre profil.');
      }
    }

    this.save(d);
    return d.profile;
  },

  // ─── Obtenir le prompt système adapté ─────────
  getSystemPrompt() {
    const d = this.get();
    const profile = this.PROFILES[d.profile] || this.PROFILES.visuel;
    return profile.prompt;
  },

  // ─── Changer manuellement le profil ───────────
  setProfile(profileKey) {
    const d = this.get();
    d.profile = profileKey;
    d.detected = true;
    this.save(d);
    const p = this.PROFILES[profileKey];
    if (window.addChatMsg) addChatMsg('assistant', 'Profil mis a jour — ' + p.icon + ' ' + p.label + '. Je vais adapter ma facon de vous repondre.');
    document.getElementById('learningContent').innerHTML = LEARNING.renderPanel();
  },

  renderPanel: function() {
    const d = this.get();
    const current = this.PROFILES[d.profile] || this.PROFILES.visuel;

    let profilesHtml = '';
    Object.keys(this.PROFILES).forEach(function(key) {
      const p = LEARNING.PROFILES[key];
      const isSelected = d.profile === key;
      profilesHtml += '<div onclick="LEARNING.setProfile(\'' + key + '\')" style="cursor:pointer;padding:.7rem;border:2px solid ' + (isSelected ? 'var(--gold)' : 'var(--border)') + ';background:' + (isSelected ? 'rgba(196,153,58,.1)' : 'var(--dark-mid)') + ';margin-bottom:.4rem">';
      profilesHtml += '<div style="display:flex;align-items:center;gap:.4rem;margin-bottom:.2rem">';
      profilesHtml += '<span style="font-size:1.2rem">' + p.icon + '</span>';
      profilesHtml += '<span style="font-size:.58rem;color:' + (isSelected ? 'var(--gold)' : 'var(--text)') + ';font-weight:' + (isSelected ? 'bold' : 'normal') + '">' + p.label + '</span>';
      if (isSelected) profilesHtml += '<span style="margin-left:auto;font-size:.46rem;color:var(--gold)">✓ Actif</span>';
      profilesHtml += '</div>';
      profilesHtml += '<div style="font-size:.5rem;color:var(--muted);line-height:1.6">' + p.description + '</div>';
      profilesHtml += '</div>';
    });

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +

      '<div class="sec-title">🧠 Mon style de communication</div>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">' +
          'Or Eille AI s adapte a votre facon de penser. Pas de style impose. Chacun recoit ce dont il a besoin — tableaux pour les analytiques, couleurs et metaphores pour les creatifs, les deux pour les mixtes.' +
        '</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div style="padding:.6rem;background:rgba(196,153,58,.08);border:1px solid rgba(196,153,58,.2)">' +
        '<div style="font-size:.48rem;color:var(--muted);margin-bottom:.2rem">Profil actuel detecte</div>' +
        '<div style="font-size:.7rem">' + current.icon + '</div>' +
        '<div style="font-size:.58rem;color:var(--gold)">' + current.label + '</div>' +
        '<div style="font-size:.48rem;color:var(--muted);margin-top:.2rem">' + (d.detected ? 'Detecte automatiquement apres analyse de vos messages' : 'Par defaut — sera affine au fil de la conversation') + '</div>' +
      '</div>' +

      '<div class="sec-title">Choisir votre profil</div>' +
      profilesHtml +

      '<div style="font-size:.48rem;color:var(--muted);line-height:1.7;padding:.5rem;border:1px solid var(--border)">' +
        'Or Eille AI observe votre facon d ecrire et adapte automatiquement ses reponses. Vous pouvez aussi choisir manuellement. Vous pouvez changer a tout moment.' +
      '</div>' +

    '</div>';
  },
  // ─── Photo de cours — réexplication adaptée ───
  LEARNING_STYLES: {
    visuel:   'Apprend par les images, schemas et couleurs',
    auditif:  'Apprend en ecoutant et en repetant a voix haute',
    kinesthesique: 'Apprend par le mouvement et la pratique',
    narratif: 'Apprend par les histoires et les exemples concrets',
    logique:  'Apprend par la logique et les schemas',
  },

  LANGUAGES_LEARN: {
    anglais:'Anglais', espagnol:'Espagnol', arabe:'Arabe',
    chinois:'Chinois', japonais:'Japonais', lingala:'Lingala',
    wolof:'Wolof', allemand:'Allemand', portugais:'Portugais',
    swahili:'Swahili', fon:'Fon', russe:'Russe',
  },

  async explainCourse(imageData, childName, ageGroup, style, culture, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const name = childName || 'toi';
    const styleName = this.LEARNING_STYLES[style] || '';
    const ag = style || 'moyen';
    if (window.addChatMsg) addChatMsg('assistant','Je lis ton cours et je te l explique autrement...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:800,
          messages:[{ role:'user', content:[
            { type:'image', source:{ type:'base64', media_type:'image/jpeg', data:imageData } },
            { type:'text', text:
              'Voici un cours scolaire. Reexplique pour ' + name + ' style ' + styleName + (culture ? ' culture ' + culture : '') + '. Va a l essentiel. Exemples de la vraie vie. Termine par 3 questions. Bienveillant.'
            }
          ]}]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  async learnLanguage(targetLang, level, style, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const levels = { debutant:'debutant', mois1:'1 mois', mois3:'3 mois', mois6:'6 mois' };
    if (window.addChatMsg) addChatMsg('assistant','Lecon de ' + targetLang + '...');
    try {
      const prompt = 'Lecon de ' + targetLang + ' niveau ' + (levels[level]||level) + '. Style : ' + (this.LEARNING_STYLES[style]||'narratif') + '. 10 mots essentiels avec prononciation phonetique, traduction francais et phrase exemple amusante. 15 min par jour. Ludique. Bienveillant. Jamais de honte.';
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({ model:'claude-sonnet-4-20250514', max_tokens:700, messages:[{ role:'user', content: prompt }] })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  renderLearningPanel: function() {
    const styles = this.LEARNING_STYLES;
    const langs = this.LANGUAGES_LEARN;

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🎓 Apprendre autrement</div>' +
      '<p class="note">Tu prends une photo de ton cours. Or Eille AI te l explique a ta facon. Plus vite. Plus ancre. Et ca reste.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem">' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">15 ans d ecole peuvent devenir 7 ou 8 ans avec la bonne methode. Pas parce que tu es plus intelligent. Parce que tu apprends enfin a ta facon.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;font-style:italic">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div class="sec-title">📸 Photo de mon cours</div>' +
      '<p class="note">Prends une photo de ton cours — Or Eille AI le reexplique autrement. A ta facon.</p>' +
      '<div style="display:flex;gap:.3rem">' +
        '<select id="learn-style" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(styles).map(function(e) { return '<option value="'+e[0]+'">'+e[0].charAt(0).toUpperCase()+e[0].slice(1)+'</option>'; }).join('') +
        '</select>' +
        '<input type="text" id="learn-culture" placeholder="Ta culture ex: Congo, Liban..." style="flex:1"/>' +
      '</div>' +
      '<input type="file" accept="image/*" id="course-photo" style="font-size:.5rem;color:var(--muted)"/>' +
      '<button class="btn btn-gold" onclick="LEARNING.startCourseScan()">📸 Reexplique ce cours a ma facon</button>' +

      '<div class="sep"></div>' +
      '<div class="sec-title">🌍 Apprendre une langue</div>' +
      '<p class="note">200 mots en 3 mois. Une conversation en 6 mois. 15 minutes par jour. A ta facon.</p>' +
      '<div style="display:flex;gap:.3rem">' +
        '<select id="lang-target" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(langs).map(function(e) { return '<option value="'+e[0]+'">'+e[1]+'</option>'; }).join('') +
        '</select>' +
        '<select id="lang-level" style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          '<option value="debutant">Je pars de zero</option>' +
          '<option value="mois1">1 mois — j ai les bases</option>' +
          '<option value="mois3">3 mois — je commande</option>' +
          '<option value="mois6">6 mois — je converse</option>' +
        '</select>' +
      '</div>' +
      '<button class="btn btn-gold" onclick="LEARNING.startLangLesson()">🌍 Ma lecon de langue du jour</button>' +

    '</div>';
  }


};



LEARNING.startLangLesson = function() {
  var lang = document.getElementById('lang-target') ? document.getElementById('lang-target').value : 'anglais';
  var level = document.getElementById('lang-level') ? document.getElementById('lang-level').value : 'debutant';
  var style = document.getElementById('learn-style') ? document.getElementById('learn-style').value : 'narratif';
  LEARNING.learnLanguage(lang, level, style, window.CFG && window.CFG.CLAUDE_KEY);
};


LEARNING.startCourseScan = function() {
  var f = document.getElementById('course-photo').files[0];
  if (!f) { if (window.addChatMsg) addChatMsg('assistant','Choisis une photo de cours.'); return; }
  var style = document.getElementById('learn-style') ? document.getElementById('learn-style').value : 'visuel';
  var culture = document.getElementById('learn-culture') ? document.getElementById('learn-culture').value : '';
  var reader = new FileReader();
  reader.onload = function(e) {
    var b64 = e.target.result.split(',')[1];
    LEARNING.explainCourse(b64, '', '', style, culture, window.CFG && window.CFG.CLAUDE_KEY);
  };
  reader.readAsDataURL(f);
};


// ─── Détection silencieuse du style d'apprentissage ───
// L'enfant joue. Or Eille AI observe. Personne ne sait.

LEARNING.DETECTION = {
  signals: { visuel:0, auditif:0, kinesthesique:0, narratif:0, logique:0 },
  responses: {},

  record: function(style) {
    if (this.signals[style] !== undefined) this.signals[style]++;
  },

  getStyle: function() {
    var max = 0; var detected = 'narratif';
    var self = this;
    Object.keys(this.signals).forEach(function(k) {
      if (self.signals[k] > max) { max = self.signals[k]; detected = k; }
    });
    return detected;
  },

  reset: function() {
    var self = this;
    Object.keys(this.signals).forEach(function(k) { self.signals[k] = 0; });
    this.responses = {};
  },
};

LEARNING.saveDetectedStyle = function() {
  var style = LEARNING.DETECTION.getStyle();
  var d = LEARNING.get();
  d.detectedStyle = style;
  d.styleDetectedAt = new Date().toISOString();
  LEARNING.save(d);
  return style;
};


window.LEARNING = LEARNING;
