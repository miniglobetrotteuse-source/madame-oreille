// ============================================================
// BOUTON MADAME OR EILLE — Or Eille AI v20
// Bouton fixe + détection automatique de détresse
// © 2026 Madame Or Eille Studios
// ============================================================

const MADAME_OR_EILLE_BTN = {

  INSTAGRAM_URL: 'https://instagram.com/madameoreille',

  // Mots-clés qui déclenchent l'affichage automatique du lien
  motsCles: [
    'je ne sais plus', 'je suis perdue', 'je suis perdu', 'je n\'y arrive pas',
    'j\'en peux plus', 'je suis épuisée', 'je suis épuisé', 'j\'abandonne',
    'ça ne sert à rien', 'je suis nulle', 'je suis nul', 'je me sens seule',
    'je me sens seul', 'personne ne comprend', 'je suis bloquée', 'je suis bloqué',
    'je craque', 'tout va mal', 'je n\'arrive pas', 'c\'est trop dur',
    'j\'ai besoin d\'aide', 'parler à quelqu\'un', 'je suis perdu',
    'overwhelmed', 'burnout', 'je suis à bout'
  ],

  init() {
    this.creerBoutonFlottant();
    this.activerDetectionAuto();
    console.log('✅ Bouton Madame Or Eille actif');
  },

  // ─── Bouton flottant permanent ───────────────────────────
  creerBoutonFlottant() {
    const btn = document.createElement('div');
    btn.id = 'moe-btn-flottant';
    btn.innerHTML = `
      <div class="moe-btn-inner" id="moe-btn-trigger">
        🎙️
        <span class="moe-btn-label">Parler à<br>Madame Or Eille</span>
      </div>
    `;
    document.body.appendChild(btn);

    document.getElementById('moe-btn-trigger').addEventListener('click', () => {
      this.afficherModal();
    });
  },

  // ─── Modal de contact ────────────────────────────────────
  afficherModal(message) {
    const existing = document.getElementById('moe-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.id = 'moe-modal';
    modal.innerHTML = `
      <div class="moe-modal-overlay" id="moe-overlay">
        <div class="moe-modal-box">
          <div class="moe-modal-close" id="moe-close">✕</div>
          <div class="moe-modal-icon">🎙️</div>
          <div class="moe-modal-titre">Madame Or Eille</div>
          <div class="moe-modal-sous-titre">Un espace pour déposer ta vérité.</div>
          ${message ? `<div class="moe-modal-message">${message}</div>` : ''}
          <div class="moe-modal-texte">
            Prends une demi-heure. On va discuter.<br>
            Pas de jugement. Pas de performance.<br>
            Juste ta voix et la mienne.
          </div>
          <a href="${this.INSTAGRAM_URL}" target="_blank" class="moe-modal-btn">
            📲 Réserver sur Instagram
          </a>
          <div class="moe-modal-hint">@madameoreille</div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    document.getElementById('moe-close').addEventListener('click', () => modal.remove());
    document.getElementById('moe-overlay').addEventListener('click', (e) => {
      if (e.target === document.getElementById('moe-overlay')) modal.remove();
    });
  },

  // ─── Détection automatique dans les conversations ────────
  activerDetectionAuto() {
    // Observer les messages de l'assistant
    const observer = new MutationObserver((mutations) => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) {
            const texte = node.textContent?.toLowerCase() || '';
            if (this.detecterDetresse(texte)) {
              this.afficherBanniereDouce();
            }
          }
        });
      });
    });

    const chatContainer = document.getElementById('chat-messages') ||
                          document.getElementById('messages') ||
                          document.querySelector('.chat-container');
    if (chatContainer) {
      observer.observe(chatContainer, { childList: true, subtree: true });
    }

    // Observer aussi les inputs utilisateur
    document.addEventListener('keyup', (e) => {
      if (e.key === 'Enter') {
        const input = document.querySelector('textarea, input[type="text"]');
        if (input) {
          const texte = input.value?.toLowerCase() || '';
          if (this.detecterDetresse(texte)) {
            setTimeout(() => this.afficherBanniereDouce(), 1000);
          }
        }
      }
    });
  },

  // ─── Détection de détresse ───────────────────────────────
  detecterDetresse(texte) {
    return this.motsCles.some(mot => texte.includes(mot));
  },

  // ─── Bannière douce (non intrusive) ─────────────────────
  afficherBanniereDouce() {
    const existing = document.getElementById('moe-banniere');
    if (existing) return; // Ne pas afficher deux fois

    const banniere = document.createElement('div');
    banniere.id = 'moe-banniere';
    banniere.innerHTML = `
      <div class="moe-banniere-inner">
        <span class="moe-banniere-icon">🎙️</span>
        <span class="moe-banniere-texte">Tu traverses quelque chose de difficile ? <strong>Madame Or Eille</strong> est là pour t'écouter.</span>
        <button class="moe-banniere-btn" id="moe-banniere-btn">Prendre un rendez-vous</button>
        <span class="moe-banniere-close" id="moe-banniere-close">✕</span>
      </div>
    `;
    document.body.appendChild(banniere);

    document.getElementById('moe-banniere-btn').addEventListener('click', () => {
      banniere.remove();
      this.afficherModal('Je vois que les choses sont un peu difficiles en ce moment. Tu n\'as pas à traverser ça seul(e).');
    });

    document.getElementById('moe-banniere-close').addEventListener('click', () => banniere.remove());

    // Auto-disparition après 10 secondes
    setTimeout(() => { if (banniere.parentNode) banniere.remove(); }, 10000);
  }
};

// ─── CSS ────────────────────────────────────────────────────
const moeStyle = document.createElement('style');
moeStyle.textContent = `
  /* Bouton flottant */
  #moe-btn-flottant {
    position: fixed;
    bottom: 80px;
    right: 16px;
    z-index: 999;
  }

  .moe-btn-inner {
    background: linear-gradient(135deg, #c0392b, #922b21);
    color: white;
    border-radius: 50px;
    padding: 10px 14px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 4px 20px rgba(192,57,43,0.5);
    font-size: 1.2em;
    transition: transform 0.2s;
  }

  .moe-btn-inner:hover { transform: scale(1.05); }

  .moe-btn-label {
    font-size: 0.65em;
    font-weight: 600;
    line-height: 1.3;
    white-space: nowrap;
  }

  /* Modal */
  .moe-modal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.7);
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
  }

  .moe-modal-box {
    background: #1a1a2e;
    border: 1px solid rgba(192,57,43,0.4);
    border-radius: 16px;
    padding: 32px 24px;
    max-width: 360px;
    width: 100%;
    text-align: center;
    position: relative;
  }

  .moe-modal-close {
    position: absolute;
    top: 12px;
    right: 16px;
    color: #aaa;
    cursor: pointer;
    font-size: 1.1em;
  }

  .moe-modal-icon { font-size: 2.5em; margin-bottom: 12px; }

  .moe-modal-titre {
    font-size: 1.3em;
    font-weight: 700;
    color: #f0c040;
    margin-bottom: 4px;
  }

  .moe-modal-sous-titre {
    font-size: 0.9em;
    color: #ccc;
    margin-bottom: 16px;
    font-style: italic;
  }

  .moe-modal-message {
    background: rgba(192,57,43,0.15);
    border-left: 3px solid #c0392b;
    padding: 10px 14px;
    border-radius: 0 8px 8px 0;
    font-size: 0.85em;
    color: #ddd;
    margin-bottom: 16px;
    text-align: left;
  }

  .moe-modal-texte {
    font-size: 0.88em;
    color: #ccc;
    line-height: 1.6;
    margin-bottom: 20px;
  }

  .moe-modal-btn {
    display: block;
    background: linear-gradient(135deg, #c0392b, #922b21);
    color: white;
    text-decoration: none;
    padding: 13px;
    border-radius: 8px;
    font-weight: 700;
    font-size: 0.95em;
    margin-bottom: 10px;
    transition: opacity 0.2s;
  }

  .moe-modal-btn:hover { opacity: 0.9; }

  .moe-modal-hint {
    font-size: 0.78em;
    color: #888;
  }

  /* Bannière douce */
  #moe-banniere {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 998;
    padding: 12px 16px;
    background: linear-gradient(135deg, #1a0a0a, #2d0f0f);
    border-top: 1px solid rgba(192,57,43,0.4);
    animation: moeSlideUp 0.3s ease;
  }

  @keyframes moeSlideUp {
    from { transform: translateY(100%); }
    to { transform: translateY(0); }
  }

  .moe-banniere-inner {
    display: flex;
    align-items: center;
    gap: 10px;
    max-width: 700px;
    margin: 0 auto;
    flex-wrap: wrap;
  }

  .moe-banniere-icon { font-size: 1.3em; }

  .moe-banniere-texte {
    flex: 1;
    font-size: 0.85em;
    color: #ddd;
    min-width: 200px;
  }

  .moe-banniere-btn {
    background: rgba(192,57,43,0.8);
    color: white;
    border: none;
    padding: 8px 14px;
    border-radius: 6px;
    font-size: 0.82em;
    cursor: pointer;
    white-space: nowrap;
  }

  .moe-banniere-close {
    color: #888;
    cursor: pointer;
    font-size: 1em;
    padding: 4px;
  }
`;
document.head.appendChild(moeStyle);

window.addEventListener('load', () => MADAME_OR_EILLE_BTN.init());
