// ═══════════════════════════════════════════════════
//  APPRENDRE AVEC MA VIE — Or Eille AI
//  Lire, écrire, compter par le réel
//  100% oral — bienveillant — hors ligne
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const LEARN = {

  KEY: 'moe_learn',

  // ─── Données persistantes ──────────────────────
  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || this._default(); }
    catch { return this._default(); }
  },

  _default() {
    return {
      profil: {
        prenom: '',
        langue: 'fr',
        aime: [],           // ce que la personne aime
        naime_pas: [],
        environnement: [],  // photos prises par la personne
        niveau: 0,          // 0=découverte, 1=lettres, 2=mots, 3=phrases, 4=compter
      },
      mots_appris: [],
      lettres_apprises: [],
      chiffres_appris: [],
      sessions: 0,
      derniere_session: null,
      photos_marche: [],    // photos prises au marché
    };
  },

  save(d) {
    try { localStorage.setItem(this.KEY, JSON.stringify(d)); } catch {}
  },

  // ─── Messages bienveillants ────────────────────
  ENCOURAGEMENTS: [
    "C'est pas mal ! Tu progresses.",
    "Bien joué. On continue tranquillement.",
    "Prends ton temps. Ça va aller.",
    "Tu y es presque. Encore une fois.",
    "Excellent ! Tu vois, tu y arrives.",
    "On respire. On recommence doucement.",
    "Chaque jour tu avances. C'est ça qui compte.",
    "C'est bien. Pas de souci, on prend le temps.",
  ],

  getEncouragement() {
    return this.ENCOURAGEMENTS[Math.floor(Math.random() * this.ENCOURAGEMENTS.length)];
  },

  // ─── Parler à la personne ─────────────────────
  dire(texte, callback) {
    if (window.speak) {
      speak(texte);
    }
    // Afficher aussi le texte avec gros bouton vert pour valider
    const container = document.getElementById('learnVoiceBox');
    if (container) {
      container.innerHTML = `
        <div style="padding:1.2rem;text-align:center;display:flex;flex-direction:column;gap:1rem;align-items:center">
          <div style="font-size:.85rem;color:var(--text);line-height:1.8;max-width:280px">${texte}</div>
          ${callback ? `
            <button onclick="(${callback})()"
              style="width:70px;height:70px;border-radius:50%;background:#4CAF50;border:none;font-size:2rem;cursor:pointer;box-shadow:0 4px 15px rgba(76,175,80,.4)">
              ✓
            </button>
            <div style="font-size:.5rem;color:var(--muted)">Appuie quand tu es prêt(e)</div>
          ` : ''}
        </div>`;
    }
  },

  // ─── Écouter la personne ──────────────────────
  ecouter(callback) {
    const container = document.getElementById('learnVoiceBox');
    if (container) {
      container.innerHTML = `
        <div style="padding:1.2rem;text-align:center;display:flex;flex-direction:column;gap:1rem;align-items:center">
          <div style="font-size:2rem;animation:pulse 1s infinite">🎙️</div>
          <div style="font-size:.65rem;color:var(--gold)">Je t'écoute...</div>
          <button onclick="LEARN._stopEcoute()"
            style="width:60px;height:60px;border-radius:50%;background:#ef5350;border:none;font-size:1.5rem;cursor:pointer">
            ⏹
          </button>
        </div>`;
    }

    if (window.startVoice) {
      startVoice(
        (texte) => { callback && callback(texte); },
        'learnMic', null,
        () => {}, () => {}, () => false,
        false
      );
    }
  },

  _stopEcoute() {
    if (window.stopVoice) stopVoice();
  },

  // ─── ÉTAPE 1 : Accueil et profil ──────────────
  demarrer() {
    const container = document.getElementById('learnContent');
    container.innerHTML = `
      <div style="display:flex;flex-direction:column;height:100%;background:var(--dark)">

        <div style="padding:.8rem 1rem;background:linear-gradient(135deg,#2E7D32,#4CAF50);display:flex;align-items:center;gap:.6rem;flex-shrink:0">
          <span style="font-size:1.3rem">🌱</span>
          <div>
            <div style="font-size:.65rem;color:#fff;font-weight:700">Apprendre avec ma vie</div>
            <div style="font-size:.45rem;color:rgba(255,255,255,.8)">À ton rythme · Dans ta langue · Avec ta vie</div>
          </div>
        </div>

        <div id="learnVoiceBox" style="flex:1;display:flex;align-items:center;justify-content:center;padding:1rem">
        </div>

        <div style="padding:.8rem;border-top:1px solid var(--border);flex-shrink:0;display:flex;gap:.5rem">
          <button onclick="LEARN._repeter()"
            style="flex:1;padding:.6rem;background:rgba(255,255,255,.08);color:var(--text);border:1px solid var(--border);font-family:inherit;font-size:.55rem;cursor:pointer">
            🔄 Répéter
          </button>
          <button id="learnMic"
            style="flex:1;padding:.6rem;background:var(--gold);color:var(--dark);border:none;font-family:inherit;font-size:.55rem;font-weight:700;cursor:pointer">
            🎙️ Parler
          </button>
        </div>

      </div>`;

    // Lancer l'accueil
    setTimeout(() => this._accueil(), 500);
  },

  _accueilTexte: '',

  _accueil() {
    const d = this.get();
    if (d.profil.prenom) {
      // Personne connue — reprendre
      this._accueilTexte = `Bonjour ${d.profil.prenom} ! Content de te retrouver. On continue là où on s'était arrêtés ?`;
      this.dire(this._accueilTexte, 'LEARN._commencerSession');
    } else {
      // Première fois — créer le profil
      this._accueilTexte = `Bonjour ! Bienvenue. Je vais apprendre à te connaître pour t'aider à apprendre. D'abord, comment tu t'appelles ?`;
      this.dire(this._accueilTexte, 'LEARN._demanderPrenom');
    }
  },

  _repeter() {
    if (this._accueilTexte && window.speak) speak(this._accueilTexte);
  },

  _demanderPrenom() {
    this.dire('Dis-moi ton prénom. Appuie sur le bouton et parle.', null);
    setTimeout(() => {
      this.ecouter((prenom) => {
        if (prenom && prenom.length > 0) {
          const d = this.get();
          d.profil.prenom = prenom.trim();
          this.save(d);
          this._demanderAimes(prenom.trim());
        }
      });
    }, 1500);
  },

  _demanderAimes(prenom) {
    const texte = `Enchanté ${prenom} ! Maintenant dis-moi, qu'est-ce que tu aimes dans la vie ? Le foot ? La cuisine ? La musique ? Dis-moi ce que tu veux.`;
    this.dire(texte, 'LEARN._ecouterAimes');
  },

  _ecouterAimes() {
    this.ecouter((reponse) => {
      if (reponse) {
        const d = this.get();
        d.profil.aime.push(reponse);
        this.save(d);
        this._proposerPhoto();
      }
    });
  },

  _proposerPhoto() {
    const d = this.get();
    const texte = `Parfait ${d.profil.prenom} ! Maintenant j'aimerais que tu fasses quelque chose. Prends ton téléphone et va prendre une photo de quelque chose autour de toi — un fruit, un légume, une chose dans ta maison, un panneau dans ta rue. N'importe quoi. Ce sera notre point de départ.`;
    this.dire(texte, 'LEARN._ouvrirCamera');
  },

  _ouvrirCamera() {
    const container = document.getElementById('learnVoiceBox');
    container.innerHTML = `
      <div style="padding:1rem;text-align:center;display:flex;flex-direction:column;gap:.8rem;align-items:center">
        <div style="font-size:.65rem;color:var(--text);line-height:1.8">Prends une photo de quelque chose autour de toi</div>
        <input type="file" id="learnPhotoInput" accept="image/*" capture="environment" style="display:none"
          onchange="LEARN._analyserPhoto(this)"/>
        <button onclick="document.getElementById('learnPhotoInput').click()"
          style="width:80px;height:80px;border-radius:50%;background:var(--gold);border:none;font-size:2rem;cursor:pointer">
          📷
        </button>
        <div style="font-size:.48rem;color:var(--muted)">Appuie pour ouvrir l'appareil photo</div>
      </div>`;
  },

  // ─── ANALYSE DE LA PHOTO ──────────────────────
  async _analyserPhoto(input) {
    if (!input.files[0]) return;

    const container = document.getElementById('learnVoiceBox');
    container.innerHTML = `<div style="padding:2rem;text-align:center;color:var(--muted);font-size:.6rem">🔍 Je regarde ta photo...</div>`;

    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = e.target.result.split(',')[1];
      const claudeKey = window.getKey ? getKey('claudeKey') : '';

      if (!claudeKey) {
        this._afficherMotsSansIA();
        return;
      }

      try {
        const r = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': claudeKey,
            'anthropic-version': '2023-06-01'
          },
          body: JSON.stringify({
            model: 'claude-sonnet-4-20250514',
            max_tokens: 500,
            messages: [{
              role: 'user',
              content: [
                { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: base64 } },
                { type: 'text', text: `Regarde cette photo. Identifie 3 objets simples visibles. Pour chaque objet, donne :
- Le mot en français
- Comment le prononcer simplement (phonétique simple)
- Un chiffre associé (combien il y en a, ou un nombre lié)

Format JSON uniquement :
{"objets": [{"mot": "tomate", "prononcer": "to-ma-te", "chiffre": 3, "description": "fruit rouge rond"}]}` }
              ]
            }]
          })
        });
        const data = await r.json();
        const text = data.content.filter(b => b.type === 'text').map(b => b.text).join('');
        const parsed = JSON.parse(text.replace(/```json|```/g, '').trim());
        this._enseignerMots(parsed.objets, e.target.result);
      } catch {
        this._afficherMotsSansIA();
      }
    };
    reader.readAsDataURL(input.files[0]);
  },

  // ─── ENSEIGNER LES MOTS ───────────────────────
  _enseignerMots(objets, imageDataUrl) {
    const d = this.get();
    let index = 0;

    const enseignerSuivant = () => {
      if (index >= objets.length) {
        this._finLecon();
        return;
      }
      const obj = objets[index];
      index++;

      const container = document.getElementById('learnVoiceBox');
      container.innerHTML = `
        <div style="padding:1rem;display:flex;flex-direction:column;gap:.8rem;align-items:center;text-align:center">
          ${imageDataUrl ? `<img src="${imageDataUrl}" style="max-width:100%;max-height:120px;object-fit:cover;border-radius:4px"/>` : ''}
          
          <div style="font-size:1.8rem;color:var(--gold);font-family:'Bodoni Moda',serif;font-weight:700;letter-spacing:.1em">
            ${obj.mot.toUpperCase()}
          </div>
          
          <div style="font-size:.6rem;color:var(--muted)">${obj.description || ''}</div>
          
          <div style="font-size:.55rem;color:var(--text);line-height:1.8">
            On prononce : <strong>${obj.prononcer}</strong>
          </div>

          <div style="display:flex;gap:1rem;align-items:center;margin:.5rem 0">
            <span style="font-size:2rem;color:var(--gold);font-weight:700">${obj.chiffre}</span>
            <span style="font-size:.55rem;color:var(--muted)">fois · ${obj.chiffre} ${obj.mot}${obj.chiffre > 1 ? 's' : ''}</span>
          </div>

          <button onclick="LEARN._pratiquer('${obj.mot}', '${obj.prononcer}', enseignerSuivant)"
            style="padding:.7rem 1.5rem;background:#4CAF50;color:#fff;border:none;font-family:inherit;font-size:.6rem;font-weight:700;cursor:pointer;border-radius:2px">
            ▶ Répète avec moi
          </button>

          <button onclick="(${enseignerSuivant})()"
            style="background:transparent;border:none;color:var(--muted);font-size:.5rem;cursor:pointer">
            Passer →
          </button>
        </div>`;

      // Dire le mot à voix haute
      const texte = `Regarde. Ce mot c'est ${obj.mot}. On dit : ${obj.prononcer}. Tu en vois ${obj.chiffre}. Répète avec moi : ${obj.mot}.`;
      if (window.speak) speak(texte);

      // Sauvegarder le mot appris
      if (!d.mots_appris.includes(obj.mot)) {
        d.mots_appris.push(obj.mot);
        this.save(d);
      }
    };

    enseignerSuivant();
  },

  // ─── PRATIQUE VOCALE ──────────────────────────
  _pratiquer(mot, prononcer, callback) {
    this.dire(`Dis le mot : ${mot}`, null);
    setTimeout(() => {
      this.ecouter((reponse) => {
        const correct = reponse && reponse.toLowerCase().includes(mot.toLowerCase());
        const encourage = this.getEncouragement();

        if (correct) {
          const texte = `Bravo ! Tu as bien dit ${mot}. ${encourage}`;
          this.dire(texte, callback ? `(${callback})` : null);
          if (window.speak) speak(texte);
        } else {
          const texte = `Presque ! On reprend doucement. ${mot}. ${prononcer}. ${encourage}`;
          this.dire(texte, `LEARN._pratiquer('${mot}', '${prononcer}', ${callback})`);
          if (window.speak) speak(texte);
        }
      });
    }, 1000);
  },

  // ─── FIN DE LEÇON ─────────────────────────────
  _finLecon() {
    const d = this.get();
    d.sessions++;
    d.derniere_session = new Date().toISOString();
    this.save(d);

    const texte = `Excellent travail ${d.profil.prenom} ! Tu as appris ${d.mots_appris.length} mot${d.mots_appris.length > 1 ? 's' : ''} aujourd'hui. On s'arrête là pour aujourd'hui. À bientôt !`;
    this.dire(texte, 'LEARN._afficherBilan');
    if (window.speak) speak(texte);
  },

  _commencerSession() {
    this._proposerPhoto();
  },

  _afficherMotsSansIA() {
    const texte = 'Je ne peux pas analyser la photo maintenant. Mais dis-moi, qu\'est-ce que tu vois autour de toi ? Nomme une chose.';
    this.dire(texte, 'LEARN._ecouterMot');
  },

  _ecouterMot() {
    this.ecouter((mot) => {
      if (mot) {
        const d = this.get();
        if (!d.mots_appris.includes(mot)) {
          d.mots_appris.push(mot);
          this.save(d);
        }
        const texte = `${mot}. Bien ! On dit ${mot}. Répète avec moi : ${mot}. ${this.getEncouragement()}`;
        this.dire(texte, 'LEARN._proposerPhoto');
        if (window.speak) speak(texte);
      }
    });
  },

  _afficherBilan() {
    const d = this.get();
    const container = document.getElementById('learnVoiceBox');
    container.innerHTML = `
      <div style="padding:1.2rem;text-align:center;display:flex;flex-direction:column;gap:.7rem;align-items:center">
        <div style="font-size:2rem">🌱</div>
        <div style="font-size:.7rem;color:var(--gold);font-weight:700">Session terminée !</div>
        <div style="font-size:.6rem;color:var(--text)">Mots appris : <strong>${d.mots_appris.length}</strong></div>
        <div style="font-size:.6rem;color:var(--text)">Sessions : <strong>${d.sessions}</strong></div>
        <div style="font-size:.55rem;color:var(--muted);line-height:1.6">Reviens demain. Chaque jour tu grandis un peu plus.</div>
        <button onclick="LEARN.demarrer()"
          style="padding:.7rem 1.5rem;background:#4CAF50;color:#fff;border:none;font-family:inherit;font-size:.6rem;font-weight:700;cursor:pointer">
          Nouvelle leçon
        </button>
      </div>`;
  },

  // ─── PANNEAU PRINCIPAL ─────────────────────────
  renderPanel() {
    const d = this.get();
    return `
    <div style="display:flex;flex-direction:column;height:100%" id="learnContent">
      <div style="padding:.8rem 1rem;background:linear-gradient(135deg,#2E7D32,#4CAF50);display:flex;align-items:center;gap:.6rem;flex-shrink:0">
        <span style="font-size:1.3rem">🌱</span>
        <div>
          <div style="font-size:.65rem;color:#fff;font-weight:700">Apprendre avec ma vie</div>
          <div style="font-size:.45rem;color:rgba(255,255,255,.8)">À ton rythme · Dans ta langue · Avec ta vie</div>
        </div>
      </div>

      <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:1.5rem;gap:1rem;text-align:center">
        
        ${d.profil.prenom ? `
          <div style="font-size:.7rem;color:var(--gold)">Bonjour ${d.profil.prenom} !</div>
          <div style="font-size:.55rem;color:var(--muted)">${d.mots_appris.length} mot(s) appris · ${d.sessions} session(s)</div>
        ` : `
          <div style="font-size:.65rem;color:var(--text);line-height:1.8">Apprends à lire, écrire et compter<br>avec ce qui t'entoure chaque jour.</div>
        `}

        <button onclick="LEARN.demarrer()"
          style="width:100px;height:100px;border-radius:50%;background:linear-gradient(135deg,#2E7D32,#4CAF50);border:none;font-size:2.5rem;cursor:pointer;box-shadow:0 6px 20px rgba(76,175,80,.4)">
          ${d.profil.prenom ? '▶' : '🌱'}
        </button>

        <div style="font-size:.5rem;color:var(--muted)">
          ${d.profil.prenom ? 'Appuie pour commencer' : 'Appuie pour démarrer'}
        </div>

        ${d.mots_appris.length > 0 ? `
          <div style="margin-top:.5rem;width:100%">
            <div style="font-size:.48rem;color:var(--muted);margin-bottom:.3rem;text-align:left">Mots appris :</div>
            <div style="display:flex;flex-wrap:wrap;gap:.3rem">
              ${d.mots_appris.slice(-10).map(m => `
                <span style="padding:.2rem .4rem;background:rgba(76,175,80,.15);border:1px solid rgba(76,175,80,.3);font-size:.5rem;color:#4CAF50">${m}</span>
              `).join('')}
            </div>
          </div>
        ` : ''}

      </div>
    </div>`;
  },
};

window.LEARN = LEARN;
