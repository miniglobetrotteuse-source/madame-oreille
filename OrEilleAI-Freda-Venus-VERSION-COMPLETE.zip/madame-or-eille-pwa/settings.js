// ═══════════════════════════════════════════════════
//  PARAMÈTRES & ACCESSIBILITÉ
//  Or Eille AI — v1.0
// ═══════════════════════════════════════════════════

const SETTINGS = {

  // ─── Paramètres par défaut ────────────────────
  DEFAULTS: {
    silenceThreshold: 2000,   // ms avant envoi auto
    pauseReminder: 90,        // minutes avant rappel pause
    eyeReminder: 20,          // minutes règle 20-20-20
    fontSize: 'medium',       // small | medium | large
    soundOn: true,
    lang: 'fr',
    movement: 'tour-piece',
    colorMode: 'voice',       // voice | touch | both
    wellbeingEnabled: true,
    gdriveSyncEnabled: false,
  },

  get() {
    try { return { ...this.DEFAULTS, ...JSON.parse(localStorage.getItem('moe_settings') || '{}') }; }
    catch { return { ...this.DEFAULTS }; }
  },

  set(key, value) {
    const s = this.get();
    s[key] = value;
    localStorage.setItem('moe_settings', JSON.stringify(s));
    this.apply();
  },

  apply() {
    const s = this.get();
    // Font size
    const sizes = { small: '12px', medium: '16px', large: '20px' };
    document.documentElement.style.setProperty('--base-font', sizes[s.fontSize] || '16px');
    // RTL
    document.documentElement.dir = s.lang === 'ar' ? 'rtl' : 'ltr';
    // Update silence threshold
    if (window.updateSilenceThreshold) updateSilenceThreshold(s.silenceThreshold);
  },

  // ─── Rendu du panel paramètres ───────────────
  renderPanel() {
    const s = this.get();
    return `
    <div style="padding:1.1rem;display:flex;flex-direction:column;gap:.9rem;overflow-y:auto;flex:1">

      <div class="sec-title">🎙 Reconnaissance vocale</div>

      <div>
        <span class="klabel">Délai avant envoi automatique : <strong style="color:var(--gold)">${s.silenceThreshold/1000}s</strong></span>
        <input type="range" min="1000" max="20000" step="500" value="${s.silenceThreshold}"
          style="width:100%;margin:.4rem 0"
          oninput="this.nextElementSibling.textContent=this.value/1000+'s';SETTINGS.set('silenceThreshold',parseInt(this.value))"
        />
        <span style="font-size:.52rem;color:var(--muted)">${s.silenceThreshold/1000}s — pour les personnes avec difficultés d'élocution, augmentez jusqu'à 20s</span>
      </div>

      <div class="sep"></div>
      <div class="sec-title">🎨 Retouche colorimétrique</div>
      <div style="display:flex;gap:.4rem">
        <button onclick="SETTINGS.set('colorMode','voice')" class="${s.colorMode==='voice'?'tbtn active':'tbtn'}">🎙 Vocal pur</button>
        <button onclick="SETTINGS.set('colorMode','touch')" class="${s.colorMode==='touch'?'tbtn active':'tbtn'}">👆 Tactile</button>
        <button onclick="SETTINGS.set('colorMode','both')" class="${s.colorMode==='both'?'tbtn active':'tbtn'}">Les deux</button>
      </div>

      <div class="sep"></div>
      <div class="sec-title">❤ Bien-être</div>
      <label style="display:flex;align-items:center;gap:.5rem;font-size:.58rem;color:var(--muted);cursor:pointer">
        <input type="checkbox" ${s.wellbeingEnabled?'checked':''} onchange="SETTINGS.set('wellbeingEnabled',this.checked)" style="accent-color:var(--gold)"/>
        Activer les rappels de pause et de bien-être
      </label>
      <div>
        <span class="klabel">Rappel de pause toutes les : <strong style="color:var(--gold)">${s.pauseReminder} min</strong></span>
        <input type="range" min="30" max="180" step="15" value="${s.pauseReminder}"
          style="width:100%;margin:.4rem 0"
          oninput="this.nextElementSibling.textContent=this.value+' min';SETTINGS.set('pauseReminder',parseInt(this.value))"
        />
        <span style="font-size:.52rem;color:var(--muted)">${s.pauseReminder} minutes</span>
      </div>

      <div class="sep"></div>
      <div class="sec-title">🔡 Accessibilité</div>
      <div>
        <span class="klabel">Taille du texte</span>
        <div style="display:flex;gap:.4rem;margin-top:.3rem">
          <button onclick="SETTINGS.set('fontSize','small')" class="${s.fontSize==='small'?'tbtn active':'tbtn'}" style="font-size:.7rem">A</button>
          <button onclick="SETTINGS.set('fontSize','medium')" class="${s.fontSize==='medium'?'tbtn active':'tbtn'}" style="font-size:.9rem">A</button>
          <button onclick="SETTINGS.set('fontSize','large')" class="${s.fontSize==='large'?'tbtn active':'tbtn'}" style="font-size:1.1rem">A</button>
        </div>
      </div>

      <div class="sep"></div>
      <div class="sec-title">☁ Sauvegarde Google Drive</div>
      <p class="note" style="margin-bottom:.5rem">Sauvegardez votre mémoire, assets et préférences sur Google Drive — protection si vous perdez votre téléphone.</p>
      <button class="btn btn-ghost" onclick="SETTINGS.syncGDrive()">
        ${s.gdriveSyncEnabled ? '✓ Synchronisé avec Google Drive' : '☁ Connecter Google Drive'}
      </button>

      <div class="sep"></div>
      <div class="sec-title">📋 Conditions d'utilisation</div>
      <button class="btn btn-ghost" onclick="CGU.showModal()">Relire et mettre à jour les CGU</button>
      <p class="note" style="margin-top:.3rem">Usage actuel : <strong style="color:var(--gold-light)">${CGU.getUsageType() === 'commercial' ? 'Commercial' : 'Personnel'}</strong></p>

      <div class="sep"></div>
      <div class="sec-title">🔍 Vérifier un filigrane</div>
      <p class="note" style="margin-bottom:.5rem">Vérifiez si une image a été créée avec Or Eille AI.</p>
      <div class="upz" id="verifyZone" style="min-height:50px">
        <input type="file" accept="image/*" onchange="SETTINGS.verifyWatermark(this)"/>
        <div class="ut">Uploader une image à vérifier</div>
      </div>
      <div id="verifyResult" style="display:none;font-size:.58rem;padding:.6rem;border:1px solid var(--border);line-height:1.7"></div>

      <div class="sep"></div>
      <button class="btn btn-ghost" style="border-color:var(--red);color:var(--red)" onclick="MEM.resetAll()">⚠ Réinitialiser toute la mémoire</button>
    </div>`;
  },

  // Google Drive sync (base — Jeff doit configurer OAuth)
  async syncGDrive() {
    alert('Synchronisation Google Drive — Jeff : intégrer l\'API Google Drive avec OAuth2. La mémoire à sauvegarder est dans localStorage sous les clés "moe_*". Exporter en JSON, uploader sur Drive.');
  },

  // Vérifier filigrane
  async verifyWatermark(input) {
    const file = input.files[0];
    if (!file) return;
    const result = await WATERMARK.verify(file);
    const el = document.getElementById('verifyResult');
    el.style.display = 'block';
    if (result) {
      el.style.borderColor = 'var(--green)';
      el.style.color = 'var(--green)';
      el.innerHTML = `✓ Filigrane détecté — Créé avec Or Eille AI<br/><small style="color:var(--muted)">${result}</small>`;
    } else {
      el.style.borderColor = 'var(--red)';
      el.style.color = 'var(--red)';
      el.innerHTML = '✕ Aucun filigrane Or Eille AI détecté dans cette image.';
    }
  }
};

window.SETTINGS = SETTINGS;
window.addEventListener('load', () => SETTINGS.apply());
