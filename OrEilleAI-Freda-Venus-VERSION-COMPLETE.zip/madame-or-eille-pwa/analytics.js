// ═══════════════════════════════════════════════════
//  ANALYTICS & VEILLE STRATÉGIQUE — Or Eille AI v2.0
//  Niche, algo, comportement, mémoire, rapport bimensuel
// ═══════════════════════════════════════════════════

const ANALYTICS = {
  KEY: 'moe_analytics',
  REPORT_INTERVAL: 15 * 24 * 3600 * 1000,

  get() {
    try {
      return JSON.parse(localStorage.getItem(this.KEY)) || {
        profile: { niche: null, platforms: [], location: null, bestDay: null, bestHour: null, avgEngagement: 0, style: null, audience: null },
        reports: [], lastReportDate: null, competitors: [],
        algoAlerts: [], performanceHistory: [], contentHistory: []
      };
    } catch { return { profile: {}, reports: [], competitors: [], algoAlerts: [], performanceHistory: [], contentHistory: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Profil créateur ──────────────────────────
  saveProfile(profile) {
    const d = this.get();
    d.profile = { ...d.profile, ...profile, updatedAt: new Date().toISOString() };
    this.save(d);
  },

  // ─── Enregistrer performance d'un contenu ─────
  recordContent(content) {
    const d = this.get();
    d.contentHistory.push({
      id: Date.now().toString(),
      ...content,
      recordedAt: new Date().toISOString()
    });
    // Garder 90 jours d'historique
    const cutoff = Date.now() - 90 * 24 * 3600000;
    d.contentHistory = d.contentHistory.filter(c => new Date(c.recordedAt).getTime() > cutoff);
    this.save(d);
  },

  // ─── Analyse des meilleures heures ────────────
  getBestPublishTime() {
    const d = this.get();
    if (!d.contentHistory.length) return null;
    const byHour = {};
    d.contentHistory.forEach(c => {
      if (!c.publishedAt || !c.engagement) return;
      const hour = new Date(c.publishedAt).getHours();
      if (!byHour[hour]) byHour[hour] = { total: 0, count: 0 };
      byHour[hour].total += c.engagement;
      byHour[hour].count++;
    });
    let bestHour = null, bestAvg = 0;
    Object.entries(byHour).forEach(([hour, data]) => {
      const avg = data.total / data.count;
      if (avg > bestAvg) { bestAvg = avg; bestHour = parseInt(hour); }
    });
    return bestHour;
  },

  // ─── Analyse décrochages ──────────────────────
  analyzeDropoffs(videoStats) {
    if (!videoStats?.dropoffs) return null;
    const critical = videoStats.dropoffs
      .filter(d => d.percentageLeft > 20)
      .sort((a, b) => b.percentageLeft - a.percentageLeft);
    return {
      criticalMoments: critical,
      recommendation: critical.length > 0
        ? `${critical[0].percentageLeft}% des viewers décrochent à ${critical[0].second}s. Raccourcissez ou dynamisez ce passage.`
        : 'Bon maintien de l\'audience — continuez sur cette lancée.'
    };
  },

  // ─── Veille algorithme en temps réel ──────────
  async checkAlgoChanges(claudeKey) {
    if (!claudeKey) return null;
    const d = this.get();
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 400,
          tools: [{ type: 'web_search_20250305', name: 'web_search' }],
          messages: [{
            role: 'user',
            content: `Recherche les changements d'algorithme Instagram, TikTok et YouTube des 7 derniers jours. Y a-t-il eu des mises à jour majeures ? Si oui, lesquelles et comment affectent-elles les créateurs de contenu ? Réponse concise et actionnable en français.`
          }]
        })
      });
      const data = await r.json();
      const text = data.content.filter(b => b.type === 'text').map(b => b.text).join('');
      const alert = { text, detectedAt: new Date().toISOString(), read: false };
      d.algoAlerts.unshift(alert);
      d.algoAlerts = d.algoAlerts.slice(0, 10); // Garder 10 alertes
      this.save(d);
      return alert;
    } catch { return null; }
  },

  // ─── Analyse de niche ─────────────────────────
  async analyzeNiche(claudeKey) {
    const d = this.get();
    if (!d.profile.niche) return null;
    if (!claudeKey) return null;

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 600,
          tools: [{ type: 'web_search_20250305', name: 'web_search' }],
          messages: [{
            role: 'user',
            content: `Analyse la niche "${d.profile.niche}" sur les réseaux sociaux cette semaine.
            
Recherche et fournis:
1. Les 3 contenus qui performent le mieux en ce moment dans cette niche
2. Les formats qui marchent (Reel, carrousel, live, etc.)
3. Les sujets qui émergent et qui n'ont pas encore été sur-exploités
4. Ce que les concurrents font et ce que personne ne fait encore
5. 5 idées de contenu concrètes et actionnables pour cette niche

Localisation: ${d.profile.location || 'France'}
Plateformes: ${(d.profile.platforms || ['Instagram']).join(', ')}

Réponse structurée, concrète, en français.`
          }]
        })
      });
      const data = await r.json();
      const text = data.content.filter(b => b.type === 'text').map(b => b.text).join('');
      const report = { text, generatedAt: new Date().toISOString(), niche: d.profile.niche };
      d.reports.unshift(report);
      d.reports = d.reports.slice(0, 6); // 6 rapports = 3 mois
      d.lastReportDate = new Date().toISOString();
      this.save(d);
      return report;
    } catch { return null; }
  },

  // ─── Détection shadowban ──────────────────────
  detectShadowban(recentStats) {
    if (!recentStats || recentStats.length < 7) return null;
    const recent = recentStats.slice(0, 7);
    const older = recentStats.slice(7, 14);
    if (!older.length) return null;
    const recentAvg = recent.reduce((s, v) => s + v.reach, 0) / recent.length;
    const olderAvg = older.reduce((s, v) => s + v.reach, 0) / older.length;
    const drop = ((olderAvg - recentAvg) / olderAvg) * 100;
    if (drop > 40) {
      return {
        suspected: true,
        dropPercent: Math.round(drop),
        message: `⚠ Chute de portée de ${Math.round(drop)}% en 7 jours. Possible shadowban. Vérifiez vos hashtags et évitez de poster trop fréquemment pendant quelques jours.`,
        actions: [
          'Évitez les hashtags bannis',
          'Réduisez la fréquence de publication temporairement',
          'Engagez manuellement avec votre communauté',
          'Vérifiez si votre compte apparaît dans les recherches',
          'Attendez 48-72h avant de republier'
        ]
      };
    }
    return { suspected: false };
  },

  // ─── Rapport bimensuel automatique ────────────
  shouldGenerateReport() {
    const d = this.get();
    if (!d.lastReportDate) return true;
    return (Date.now() - new Date(d.lastReportDate).getTime()) > this.REPORT_INTERVAL;
  },

  async generateBiweeklyReport(claudeKey) {
    if (!this.shouldGenerateReport()) return null;
    if (window.addChatMsg) addChatMsg('assistant', '📊 Génération de votre rapport bimensuel en cours...');
    const [nicheReport, algoAlert] = await Promise.all([
      this.analyzeNiche(claudeKey),
      this.checkAlgoChanges(claudeKey)
    ]);
    const d = this.get();
    const bestHour = this.getBestPublishTime();
    const days = ['dimanche','lundi','mardi','mercredi','jeudi','vendredi','samedi'];
    let summary = `📊 RAPPORT BIMENSUEL — ${new Date().toLocaleDateString('fr-FR')}\n\n`;
    if (bestHour !== null) summary += `⏰ Votre meilleure heure de publication : ${bestHour}h00\n`;
    if (algoAlert) summary += `\n🔔 ALGORITHME :\n${algoAlert.text}\n`;
    if (nicheReport) summary += `\n🎯 VOTRE NICHE :\n${nicheReport.text}`;
    if (window.addChatMsg) addChatMsg('assistant', summary);
    return { nicheReport, algoAlert, bestHour };
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    const lastReport = d.reports[0];
    const unreadAlerts = d.algoAlerts.filter(a => !a.read);

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      ${unreadAlerts.length > 0 ? `
      <div style="background:rgba(27,79,138,.15);border:1px solid rgba(27,79,138,.4);padding:.7rem">
        <div style="font-size:.55rem;color:#1B4F8A;letter-spacing:.1em;text-transform:uppercase;margin-bottom:.3rem">🔔 ${unreadAlerts.length} alerte(s) algorithme</div>
        <div style="font-size:.54rem;color:var(--muted);line-height:1.6">${unreadAlerts[0].text.substring(0, 200)}...</div>
        <button onclick="ANALYTICS.showAlerts()" style="margin-top:.4rem;padding:.3rem .6rem;background:transparent;border:1px solid #1B4F8A;color:#1B4F8A;font-family:'Josefin Sans',sans-serif;font-size:.5rem;cursor:pointer">Voir tout</button>
      </div>` : ''}

      <div class="sec-title">Mon profil créateur</div>
      <input type="text" id="an-niche" placeholder="Ma niche (ex: fleuriste, coach bien-être, cuisine africaine...)" value="${d.profile.niche||''}" onchange="ANALYTICS.saveProfile({niche:this.value})"/>
      <input type="text" id="an-location" placeholder="Ma localisation (ex: Paris, Abidjan, Montréal...)" value="${d.profile.location||''}" onchange="ANALYTICS.saveProfile({location:this.value})"/>
      <div style="display:flex;gap:.3rem;flex-wrap:wrap">
        ${['Instagram','TikTok','YouTube','Snapchat','Pinterest','LinkedIn'].map(p => `
          <button onclick="ANALYTICS.togglePlatform('${p}')" style="padding:.3rem .6rem;background:${(d.profile.platforms||[]).includes(p)?'var(--gold)':'var(--dark-mid)'};color:${(d.profile.platforms||[]).includes(p)?'var(--dark)':'var(--muted)'};border:1px solid ${(d.profile.platforms||[]).includes(p)?'var(--gold)':'var(--border)'};font-family:'Josefin Sans',sans-serif;font-size:.48rem;cursor:pointer">${p}</button>
        `).join('')}
      </div>

      <div class="sep"></div>
      <div class="sec-title">Analyse et rapports</div>

      <div style="display:flex;gap:.4rem;flex-wrap:wrap">
        <button class="btn btn-gold" style="flex:1" onclick="ANALYTICS.generateBiweeklyReport(window.CFG?.CLAUDE_KEY)">📊 Rapport niche maintenant</button>
        <button class="btn btn-ghost" style="flex:1" onclick="ANALYTICS.checkAlgoChanges(window.CFG?.CLAUDE_KEY).then(a=>{if(a&&window.addChatMsg)addChatMsg('assistant','🔔 '+a.text)})">🔔 Vérifier les algos</button>
      </div>

      ${lastReport ? `
      <div style="border:1px solid var(--border);padding:.7rem;background:var(--dark-mid)">
        <div style="font-size:.5rem;color:var(--gold);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.4rem">Dernier rapport — ${new Date(lastReport.generatedAt).toLocaleDateString('fr-FR')}</div>
        <div style="font-size:.54rem;color:var(--muted);line-height:1.7;max-height:150px;overflow-y:auto">${lastReport.text}</div>
      </div>` : `
      <div style="text-align:center;padding:1.5rem;color:var(--muted);font-size:.56rem">
        Configurez votre niche et générez votre premier rapport.
      </div>`}

      <div class="sep"></div>
      <div class="sec-title">Performances récentes</div>
      <div style="display:flex;gap:.4rem">
        <input type="text" id="an-content" placeholder="Titre ou description du contenu" style="flex:2"/>
        <input type="number" id="an-eng" placeholder="Engagement %" style="flex:1"/>
        <button onclick="ANALYTICS.recordContent({title:document.getElementById('an-content').value,engagement:parseFloat(document.getElementById('an-eng').value)||0,publishedAt:new Date().toISOString()})" style="padding:.5rem;background:var(--gold);color:var(--dark);border:none;font-size:.7rem;cursor:pointer">+</button>
      </div>

      ${d.contentHistory.length > 0 ? `
      <div>
        <div style="font-size:.5rem;color:var(--muted);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.3rem">Historique (${d.contentHistory.length} contenus)</div>
        ${d.contentHistory.slice(0,5).map(c => `
          <div style="display:flex;justify-content:space-between;padding:.35rem 0;border-bottom:1px solid var(--border)">
            <span style="font-size:.54rem;color:var(--text);flex:1">${c.title||'Sans titre'}</span>
            <span style="font-size:.54rem;color:${c.engagement>5?'#81c784':'var(--muted)'}">${c.engagement}%</span>
          </div>
        `).join('')}
      </div>` : ''}
    </div>`;
  },

  togglePlatform(platform) {
    const d = this.get();
    if (!d.profile.platforms) d.profile.platforms = [];
    const idx = d.profile.platforms.indexOf(platform);
    if (idx > -1) d.profile.platforms.splice(idx, 1);
    else d.profile.platforms.push(platform);
    this.save(d);
    document.getElementById('analyticsContent').innerHTML = this.renderPanel();
  },

  showAlerts() {
    const d = this.get();
    d.algoAlerts.forEach(a => a.read = true);
    this.save(d);
    const text = d.algoAlerts.map(a => `${new Date(a.detectedAt).toLocaleDateString('fr-FR')} :\n${a.text}`).join('\n\n---\n\n');
    if (window.addChatMsg) addChatMsg('assistant', text || 'Aucune alerte.');
    document.getElementById('analyticsContent').innerHTML = this.renderPanel();
  }
};

window.ANALYTICS = ANALYTICS;

// Vérifier si rapport bimensuel nécessaire au chargement
window.addEventListener('load', () => {
  setTimeout(() => {
    if (ANALYTICS.shouldGenerateReport() && window.CFG?.CLAUDE_KEY) {
      const d = ANALYTICS.get();
      if (d.profile.niche) {
        if (window.addChatMsg) addChatMsg('assistant', '📊 Il est temps de votre rapport bimensuel. Je le génère automatiquement.');
        ANALYTICS.generateBiweeklyReport(window.CFG.CLAUDE_KEY);
      }
    }
    // Vérifier les algos une fois par semaine
    const d = ANALYTICS.get();
    const lastAlgo = d.algoAlerts[0]?.detectedAt;
    if (!lastAlgo || (Date.now() - new Date(lastAlgo).getTime()) > 7 * 24 * 3600000) {
      if (window.CFG?.CLAUDE_KEY) ANALYTICS.checkAlgoChanges(window.CFG.CLAUDE_KEY);
    }
  }, 5000);
});
