// ═══════════════════════════════════════════════════
//  OPTIMISATION RÉSEAU LENT — Or Eille AI v1.0
//  Fonctionne même avec 2 barres de signal
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const NETWORK = {
  KEY: 'moe_network',
  _quality: null,

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { mode: 'auto', savings: true }; }
    catch { return { mode: 'auto', savings: true }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Détecter la qualité du réseau ───────────
  detect() {
    const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    if (!conn) return 'unknown';
    const type = conn.effectiveType || conn.type || '';
    const downlink = conn.downlink || 0;
    const saveData = conn.saveData || false;

    if (saveData || type === 'slow-2g' || type === '2g' || downlink < 0.5) return 'slow';
    if (type === '3g' || downlink < 2) return 'medium';
    return 'fast';
  },

  // ─── Adapter les requêtes API selon le réseau ─
  getApiConfig() {
    const quality = this.detect();
    this._quality = quality;

    if (quality === 'slow') {
      return {
        model: 'claude-sonnet-4-20250514',
        max_tokens: 500,        // Réponses courtes
        compress: true,
        timeout: 30000,
        retries: 3,
        label: 'Mode réseau lent — réponses optimisées'
      };
    }
    if (quality === 'medium') {
      return {
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        compress: false,
        timeout: 20000,
        retries: 2,
        label: 'Mode réseau moyen'
      };
    }
    return {
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      compress: false,
      timeout: 15000,
      retries: 1,
      label: 'Réseau rapide'
    };
  },

  // ─── Appel API optimisé avec retry ────────────
  async callAPI(prompt, claudeKey, options) {
    options = options || {};
    const config = this.getApiConfig();
    const maxRetries = options.retries || config.retries;
    const maxTokens = options.max_tokens || config.max_tokens;

    // Prompt allégé si réseau lent
    let finalPrompt = prompt;
    if (this._quality === 'slow') {
      finalPrompt = 'Réponds de façon très concise (max 3 phrases). ' + prompt;
    }

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(function() { controller.abort(); }, config.timeout);

        const r = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': claudeKey,
            'anthropic-version': '2023-06-01'
          },
          body: JSON.stringify({
            model: config.model,
            max_tokens: maxTokens,
            messages: [{ role: 'user', content: finalPrompt }]
          }),
          signal: controller.signal
        });

        clearTimeout(timeout);

        if (!r.ok) throw new Error('HTTP ' + r.status);
        const data = await r.json();
        return data.content[0].text;

      } catch(e) {
        if (attempt === maxRetries) {
          if (e.name === 'AbortError') {
            if (window.addChatMsg) addChatMsg('assistant', 'Connexion trop lente. Réessayez ou passez en mode valise numérique.');
          } else {
            if (window.addChatMsg) addChatMsg('assistant', 'Erreur réseau. Vérifiez votre connexion.');
          }
          return null;
        }
        // Attendre avant de réessayer
        await new Promise(function(resolve) { setTimeout(resolve, attempt * 2000); });
        if (window.addChatMsg) addChatMsg('assistant', 'Tentative ' + (attempt+1) + '/' + maxRetries + '...');
      }
    }
    return null;
  },

  // ─── Afficher la qualité réseau ───────────────
  renderNetworkBadge() {
    const quality = this.detect();
    const colors = { slow: '#ef5350', medium: '#F5A623', fast: '#81c784', unknown: 'var(--muted)' };
    const labels = { slow: '📶 Réseau lent — mode optimisé', medium: '📶 Réseau moyen', fast: '📶 Réseau rapide', unknown: '📶 Réseau inconnu' };
    return '<div style="font-size:.46rem;color:' + colors[quality] + ';padding:.2rem .4rem;border:1px solid ' + colors[quality] + ';display:inline-block">' + labels[quality] + '</div>';
  },

  // ─── Initialiser la surveillance réseau ───────
  init() {
    const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    if (conn) {
      conn.addEventListener('change', function() {
        const quality = NETWORK.detect();
        if (quality === 'slow') {
          if (window.addChatMsg) addChatMsg('assistant', '📶 Réseau lent détecté. Mode économie activé automatiquement. Les réponses seront plus courtes pour aller plus vite.');
        }
      });
    }

    // Afficher badge réseau dans le header si lent
    const quality = this.detect();
    if (quality === 'slow') {
      setTimeout(function() {
        if (window.addChatMsg) addChatMsg('assistant', '📶 Réseau lent détecté. Or Eille AI fonctionne en mode optimisé. Réponses condensées, moins de données. Si possible, préparez vos projets en WiFi avec la Valise numérique.');
      }, 3000);
    }
  }
};

window.NETWORK = NETWORK;
window.addEventListener('load', function() {
  setTimeout(function() { NETWORK.init(); }, 2000);
});
