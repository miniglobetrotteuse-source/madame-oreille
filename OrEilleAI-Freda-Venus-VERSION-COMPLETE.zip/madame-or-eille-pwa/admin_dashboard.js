// ═══════════════════════════════════════════════════
//  TABLEAU DE BORD ADMIN — Or Eille AI
//  Réservé à la propriétaire — accès protégé
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const ADMIN = {

  KEY: 'moe_admin',
  STATS_KEY: 'moe_stats',
  ERRORS_KEY: 'moe_errors',

  // ─── Mot de passe admin (à changer après déploiement) ─
  // Stocké hashé — jamais en clair
  ADMIN_HASH: null, // sera configuré via Supabase en production

  // ─── Vérifier accès admin ─────────────────────
  isAdmin() {
    try {
      const session = sessionStorage.getItem('moe_admin_session');
      if (!session) return false;
      const data = JSON.parse(session);
      return data.valid && (Date.now() - data.time) < 3600000; // 1h
    } catch { return false; }
  },

  // ─── Connexion admin ──────────────────────────
  async login(password) {
    // En production — vérification via Supabase
    const adminEmail = window.CFG?.ADMIN_EMAIL || 'admin@oreille-ai.com';
    const stored = localStorage.getItem('moe_admin_pwd');

    // Hash simple pour le local (Supabase en production)
    const hash = await this._hash(password);
    const storedHash = stored || await this._hash('OrEilleAdmin2026!');

    if (hash === storedHash) {
      sessionStorage.setItem('moe_admin_session', JSON.stringify({
        valid: true,
        time: Date.now(),
      }));
      return true;
    }
    return false;
  },

  logout() {
    sessionStorage.removeItem('moe_admin_session');
    document.getElementById('adminContent').innerHTML = this.renderLogin();
  },

  async _hash(str) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
  },

  // ─── Enregistrer une statistique ──────────────
  logStat(type, data = {}) {
    try {
      const stats = JSON.parse(localStorage.getItem(this.STATS_KEY) || '[]');
      stats.push({
        type,
        data,
        date: new Date().toISOString(),
        lang: localStorage.getItem('moe_lang') || 'fr',
        userAgent: navigator.userAgent.slice(0, 50),
        online: navigator.onLine,
      });
      // Garder les 500 dernières stats
      localStorage.setItem(this.STATS_KEY, JSON.stringify(stats.slice(-500)));
    } catch {}
  },

  // ─── Enregistrer une erreur ───────────────────
  logError(module, message, stack = '') {
    try {
      const errors = JSON.parse(localStorage.getItem(this.ERRORS_KEY) || '[]');
      errors.push({
        module,
        message,
        stack: stack.slice(0, 200),
        date: new Date().toISOString(),
        lang: localStorage.getItem('moe_lang') || 'fr',
        online: navigator.onLine,
      });
      localStorage.setItem(this.ERRORS_KEY, JSON.stringify(errors.slice(-100)));
    } catch {}
  },

  // ─── Analyser les statistiques ────────────────
  getAnalytics() {
    try {
      const stats = JSON.parse(localStorage.getItem(this.STATS_KEY) || '[]');
      const errors = JSON.parse(localStorage.getItem(this.ERRORS_KEY) || '[]');

      // Modules les plus utilisés
      const modules = {};
      stats.forEach(s => {
        if (s.type === 'panel_open') {
          modules[s.data.panel] = (modules[s.data.panel] || 0) + 1;
        }
      });

      // Langues utilisées
      const langues = {};
      stats.forEach(s => {
        langues[s.lang] = (langues[s.lang] || 0) + 1;
      });

      // Alertes sécurité
      const alertes = stats.filter(s => s.type === 'security_block');

      // SOS Premiers Secours
      const sos = stats.filter(s => s.type === 'first_aid_open');

      // Apprendre avec ma vie
      const apprenants = stats.filter(s => s.type === 'learn_session');

      // Erreurs par module
      const errorsParModule = {};
      errors.forEach(e => {
        errorsParModule[e.module] = (errorsParModule[e.module] || 0) + 1;
      });

      // Sessions offline vs online
      const offline = stats.filter(s => !s.online).length;
      const online = stats.filter(s => s.online).length;

      return {
        total_events: stats.length,
        modules: Object.entries(modules).sort((a,b) => b[1]-a[1]).slice(0,10),
        langues: Object.entries(langues).sort((a,b) => b[1]-a[1]),
        alertes_securite: alertes.length,
        sos_premiers_secours: sos.length,
        sessions_apprentissage: apprenants.length,
        erreurs: errors.slice(-10),
        erreurs_par_module: Object.entries(errorsParModule).sort((a,b) => b[1]-a[1]),
        offline_sessions: offline,
        online_sessions: online,
        derniere_activite: stats.length > 0 ? stats[stats.length-1].date : null,
      };
    } catch { return null; }
  },

  // ─── RENDU LOGIN ──────────────────────────────
  renderLogin() {
    return `
    <div style="padding:2rem;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;gap:1rem">
      <div style="font-size:1.5rem">🔐</div>
      <div style="font-size:.7rem;color:var(--gold);font-family:'Cormorant Garamond',serif">Espace Administrateur</div>
      <div style="font-size:.52rem;color:var(--muted)">Réservé à la propriétaire</div>

      <div style="width:100%;max-width:280px;display:flex;flex-direction:column;gap:.5rem;margin-top:.5rem">
        <input type="password" id="adminPwd" placeholder="Mot de passe"
          style="width:100%;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.6rem;padding:.6rem;outline:none;box-sizing:border-box"
          onkeydown="if(event.key==='Enter') ADMIN._tentativeLogin()"/>
        <button onclick="ADMIN._tentativeLogin()"
          class="btn btn-gold" style="width:100%">
          Accéder au tableau de bord
        </button>
        <div id="adminError" style="font-size:.5rem;color:#ef5350;text-align:center;display:none">
          Mot de passe incorrect
        </div>
      </div>
    </div>`;
  },

  async _tentativeLogin() {
    const pwd = document.getElementById('adminPwd')?.value;
    if (!pwd) return;
    const ok = await this.login(pwd);
    if (ok) {
      document.getElementById('adminContent').innerHTML = this.renderDashboard();
    } else {
      const err = document.getElementById('adminError');
      if (err) err.style.display = 'block';
    }
  },

  // ─── RENDU TABLEAU DE BORD ────────────────────
  renderDashboard() {
    const data = this.getAnalytics();
    if (!data) return '<div style="padding:1rem;color:var(--muted)">Aucune donnée disponible.</div>';

    const now = new Date().toLocaleString('fr-FR');

    return `
    <div style="padding:1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div style="display:flex;justify-content:space-between;align-items:center">
        <div class="sec-title">📊 Tableau de bord Admin</div>
        <button onclick="ADMIN.logout()"
          style="background:transparent;border:1px solid var(--border);color:var(--muted);font-size:.48rem;padding:.3rem .6rem;cursor:pointer;font-family:inherit">
          Déconnexion
        </button>
      </div>
      <div style="font-size:.45rem;color:var(--muted)">${now}</div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">
        <div style="padding:.7rem;border:1px solid var(--border);text-align:center">
          <div style="font-size:1.3rem;color:var(--gold);font-weight:700">${data.total_events}</div>
          <div style="font-size:.48rem;color:var(--muted)">Événements total</div>
        </div>
        <div style="padding:.7rem;border:1px solid var(--border);text-align:center">
          <div style="font-size:1.3rem;color:#4CAF50;font-weight:700">${data.sessions_apprentissage}</div>
          <div style="font-size:.48rem;color:var(--muted)">Sessions apprentissage</div>
        </div>
        <div style="padding:.7rem;border:1px solid ${data.alertes_securite > 0 ? '#ef5350' : 'var(--border)'};text-align:center">
          <div style="font-size:1.3rem;color:${data.alertes_securite > 0 ? '#ef5350' : 'var(--text)'};font-weight:700">${data.alertes_securite}</div>
          <div style="font-size:.48rem;color:var(--muted)">Alertes sécurité</div>
        </div>
        <div style="padding:.7rem;border:1px solid ${data.sos_premiers_secours > 0 ? '#ef5350' : 'var(--border)'};text-align:center">
          <div style="font-size:1.3rem;color:${data.sos_premiers_secours > 0 ? '#ef5350' : 'var(--text)'};font-weight:700">${data.sos_premiers_secours}</div>
          <div style="font-size:.48rem;color:var(--muted)">Accès Premiers Secours</div>
        </div>
      </div>

      <div style="display:flex;gap:.5rem;font-size:.52rem;color:var(--muted)">
        <span>📶 En ligne : ${data.online_sessions}</span>
        <span>📵 Hors ligne : ${data.offline_sessions}</span>
      </div>

      ${data.modules.length > 0 ? `
        <div class="sec-title">Modules les plus utilisés</div>
        ${data.modules.map(([panel, count]) => `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:.4rem .6rem;border:1px solid var(--border);font-size:.55rem">
            <span style="color:var(--text)">${panel}</span>
            <span style="color:var(--gold);font-weight:700">${count} fois</span>
          </div>
        `).join('')}
      ` : ''}

      ${data.langues.length > 0 ? `
        <div class="sec-title">Langues utilisées</div>
        ${data.langues.map(([lang, count]) => `
          <div style="display:flex;justify-content:space-between;padding:.35rem .6rem;border:1px solid var(--border);font-size:.52rem">
            <span style="color:var(--muted)">${lang}</span>
            <span style="color:var(--text)">${count}</span>
          </div>
        `).join('')}
      ` : ''}

      ${data.erreurs.length > 0 ? `
        <div class="sec-title" style="color:#ef5350">⚠️ Erreurs récentes</div>
        ${data.erreurs.map(e => `
          <div style="padding:.5rem;border:1px solid rgba(239,83,80,.3);font-size:.5rem">
            <div style="color:#ef5350;margin-bottom:.2rem">${e.module} — ${new Date(e.date).toLocaleString('fr-FR')}</div>
            <div style="color:var(--muted)">${e.message}</div>
          </div>
        `).join('')}
      ` : `
        <div style="padding:.6rem;border:1px solid rgba(76,175,80,.3);font-size:.52rem;color:#4CAF50;text-align:center">
          ✅ Aucune erreur récente
        </div>
      `}

      <div class="sec-title">Actions</div>
      <button onclick="ADMIN._exporterStats()"
        class="btn btn-gold" style="width:100%">
        📥 Exporter les statistiques
      </button>
      <button onclick="ADMIN._effacerStats()"
        style="width:100%;padding:.6rem;background:transparent;border:1px solid var(--border);color:var(--muted);font-family:inherit;font-size:.55rem;cursor:pointer">
        🗑️ Effacer les données
      </button>

    </div>`;
  },

  _exporterStats() {
    const stats = localStorage.getItem(this.STATS_KEY) || '[]';
    const errors = localStorage.getItem(this.ERRORS_KEY) || '[]';
    const data = { stats: JSON.parse(stats), errors: JSON.parse(errors), exported_at: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `oreille-ai-stats-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
  },

  _effacerStats() {
    if (confirm('Effacer toutes les statistiques ?')) {
      localStorage.removeItem(this.STATS_KEY);
      localStorage.removeItem(this.ERRORS_KEY);
      document.getElementById('adminContent').innerHTML = this.renderDashboard();
    }
  },

  // ─── Panneau principal ─────────────────────────
  renderPanel() {
    if (this.isAdmin()) return this.renderDashboard();
    return this.renderLogin();
  },
};

window.ADMIN = ADMIN;

// ─── Intercepter les erreurs JS globales ───────
window.addEventListener('error', (e) => {
  if (window.ADMIN) {
    ADMIN.logError(
      e.filename?.split('/').pop() || 'unknown',
      e.message,
      e.error?.stack || ''
    );
  }
});

// ─── Logger les ouvertures de panels ──────────
const _origShowPanelAdmin = window.showPanel;
window.showPanel = function(id) {
  if (window.ADMIN) ADMIN.logStat('panel_open', { panel: id });
  _origShowPanelAdmin && _origShowPanelAdmin(id);
};

// ─── Gestion des blocages dérive ──────────────
ADMIN.getBlocages = function() {
  // En production, ça viendra de Supabase
  // En local, on lit les stats
  try {
    const stats = JSON.parse(localStorage.getItem('moe_stats') || '[]');
    return stats.filter(s => s.type === 'derive_block').map(s => ({
      code: s.data.code,
      jours: s.data.jours,
      date: s.date,
      longSuspension: s.data.longSuspension,
      delaiMinutes: s.data.delaiMinutes,
      interpretation: s.data.interpretation,
    }));
  } catch { return []; }
};

ADMIN.validerRdv = function(code) {
  // Débloquer la personne qui a ce code
  // En production — via Supabase avec le code
  // En local — pour les tests
  const block = JSON.parse(localStorage.getItem('moe_derive_block') || '{}');
  if (block.code === code) {
    block.rdv_confirmed = true;
    block.confirmed_at = new Date().toISOString();
    localStorage.setItem('moe_derive_block', JSON.stringify(block));
    alert(`✅ Code ${code} validé. La personne sera débloquée dans la journée.`);
    document.getElementById('adminContent').innerHTML = ADMIN.renderDashboard();
  } else {
    alert('Code incorrect.');
  }
};

// Ajouter section blocages dans le dashboard
const _renderDashOrig = ADMIN.renderDashboard.bind(ADMIN);
ADMIN.renderDashboard = function() {
  let html = _renderDashOrig();
  const blocages = this.getBlocages();

  if (blocages.length > 0) {
    const section = `
      <div class="sec-title" style="color:#1565C0;margin-top:.5rem">🔵 Rendez-vous de déblocage</div>
      ${blocages.map(b => `
        <div style="padding:.7rem;border:2px solid #1565C0;background:rgba(21,101,192,.08);display:flex;flex-direction:column;gap:.4rem">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="font-size:.7rem;color:#1565C0;font-weight:700;letter-spacing:.15em">${b.code}</span>
            <span style="font-size:.45rem;color:#fff;background:${b.longSuspension ? '#ef5350' : '#1565C0'};padding:.2rem .5rem">
              ${b.longSuspension ? 'SUSPENSION 1 MOIS' : 'SUSPENSION 3 JOURS'}
            </span>
          </div>
          <div style="font-size:.48rem;color:var(--muted)">${new Date(b.date).toLocaleString('fr-FR')}</div>
          ${b.delaiMinutes !== undefined ? `
            <div style="font-size:.5rem;margin-top:.2rem">
              <span style="color:var(--muted)">Délai avant RDV : </span>
              <strong style="color:var(--text)">${b.delaiMinutes < 60 ? b.delaiMinutes + ' min' : Math.round(b.delaiMinutes/60) + 'h'}</strong>
            </div>
            <div style="font-size:.5rem;color:var(--gold)">${b.interpretation || ''}</div>
          ` : '<div style="font-size:.48rem;color:var(--muted)">⏳ En attente de prise de RDV</div>'}
          <div style="display:flex;gap:.4rem;margin-top:.3rem">
            <input type="text" placeholder="Entrer le code pour valider"
              id="rdv_input_${b.code}"
              style="flex:1;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:inherit;font-size:.55rem;padding:.35rem;outline:none;letter-spacing:.1em;text-transform:uppercase"/>
            <button onclick="ADMIN.validerRdv(document.getElementById('rdv_input_${b.code}').value.toUpperCase())"
              style="padding:.35rem .7rem;background:#4CAF50;color:#fff;border:none;font-family:inherit;font-size:.52rem;font-weight:700;cursor:pointer">
              ✓ Valider
            </button>
          </div>
        </div>
      `).join('')}`;

    html = html.replace('<div class="sec-title">Actions</div>', section + '<div class="sec-title">Actions</div>');
  }

  return html;
};
