// ═══════════════════════════════════════════════════
//  LISTE DE COURSES — Or Eille AI v1.0
//  Vocale, intelligente, connectée au stock
//  Alertes promos supermarchés
// ═══════════════════════════════════════════════════

const SHOPPING = {
  KEY: 'moe_shopping',

  STORES: [
    { id: 'carrefour', name: 'Carrefour', url: 'https://www.carrefour.fr/r/courses-en-ligne', promoUrl: 'https://www.carrefour.fr/promotions' },
    { id: 'leclerc', name: 'E.Leclerc', url: 'https://www.e.leclerc/sf/drive', promoUrl: 'https://www.e.leclerc/sf/promotions' },
    { id: 'intermarche', name: 'Intermarché', url: 'https://www.intermarche.com/courses', promoUrl: 'https://www.intermarche.com/promotions' },
    { id: 'auchan', name: 'Auchan', url: 'https://www.auchan.fr/courses', promoUrl: 'https://www.auchan.fr/promotions' },
    { id: 'lidl', name: 'Lidl', url: 'https://www.lidl.fr', promoUrl: 'https://www.lidl.fr/promotions' },
    { id: 'monoprix', name: 'Monoprix', url: 'https://www.monoprix.fr/courses', promoUrl: 'https://www.monoprix.fr/promotions' },
  ],

  CATEGORIES: {
    'fruits_legumes': '🥦 Fruits & Légumes',
    'viandes_poissons': '🥩 Viandes & Poissons',
    'produits_laitiers': '🥛 Produits Laitiers',
    'boulangerie': '🍞 Boulangerie',
    'épicerie': '🫙 Épicerie',
    'boissons': '💧 Boissons',
    'hygiène': '🧴 Hygiène',
    'entretien': '🧹 Entretien',
    'autre': '📦 Autre',
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      items: [], preferredStore: 'carrefour', lastPromoCheck: null
    }; } catch { return { items: [], preferredStore: 'carrefour', lastPromoCheck: null }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Ajouter à la liste ───────────────────────
  addToList(name, quantity, category) {
    const d = this.get();

    // Vérifier dans le stock avant d'ajouter
    const stockCheck = STOCK.checkBeforeBuying(name);
    if (stockCheck?.hasStock) {
      // Proposer à l'utilisateur
      if (window.addChatMsg) {
        addChatMsg('assistant', `⚠ ${stockCheck.message}\n\nVoulez-vous quand même l'ajouter à la liste ?`);
        // Ajouter quand même avec confirmation
        const confirmed = confirm(stockCheck.message + '\n\nAjouter quand même à la liste ?');
        if (!confirmed) return;
      }
    }

    const existing = d.items.find(i => i.name.toLowerCase() === name.toLowerCase() && !i.checked);
    if (existing) {
      existing.quantity += parseFloat(quantity) || 1;
    } else {
      d.items.push({
        id: Date.now().toString(),
        name, quantity: parseFloat(quantity) || 1,
        category: category || this.guessCategory(name),
        checked: false,
        addedAt: new Date().toISOString(),
      });
    }
    this.save(d);
    return d.items;
  },

  // ─── Deviner la catégorie ─────────────────────
  guessCategory(name) {
    const n = name.toLowerCase();
    if (/pomme|banane|tomate|salade|carotte|oignon|ail|courgette|poivron|citron|orange|fraise|raisin/.test(n)) return 'fruits_legumes';
    if (/poulet|boeuf|porc|saumon|thon|crevette|jambon|steak/.test(n)) return 'viandes_poissons';
    if (/lait|yaourt|fromage|beurre|crème|oeuf/.test(n)) return 'produits_laitiers';
    if (/pain|baguette|croissant|brioche/.test(n)) return 'boulangerie';
    if (/eau|jus|soda|café|thé|bière|vin/.test(n)) return 'boissons';
    if (/shampoing|gel|dentifrice|savon|déodorant/.test(n)) return 'hygiène';
    if (/lessive|liquide|essuie|papier|éponge/.test(n)) return 'entretien';
    return 'épicerie';
  },

  // ─── Cocher un article ────────────────────────
  checkItem(id) {
    const d = this.get();
    const item = d.items.find(i => i.id === id);
    if (item) {
      item.checked = !item.checked;
      if (item.checked) {
        // Mettre à jour le stock automatiquement
        STOCK.addItem(item.name, item.quantity, 'unité', 'général');
      }
    }
    this.save(d);
  },

  // ─── Vider les articles cochés ────────────────
  clearChecked() {
    const d = this.get();
    d.items = d.items.filter(i => !i.checked);
    this.save(d);
  },

  // ─── Saisie vocale ────────────────────────────
  voiceAdd() {
    WHISPER.start(text => {
      // Parser "ajoute du lait, des tomates et du pain"
      const cleaned = text.toLowerCase()
        .replace(/ajoute[r]?|mets|rajoute[r]?|il me faut|j'ai besoin de|acheter/g, '');

      // Séparer par virgules, "et", "ainsi que"
      const items = cleaned.split(/,|et\s|ainsi que\s/).map(s => s.trim()).filter(Boolean);

      items.forEach(item => {
        const nums = item.match(/(\d+)/);
        const qty = nums ? parseInt(nums[0]) : 1;
        const name = item.replace(/\d+/g, '').replace(/^(du|de la|des|un|une|le|la|les)\s/g, '').trim();
        if (name.length > 1) this.addToList(name, qty, null);
      });

      if (window.addChatMsg) addChatMsg('assistant', `✓ ${items.length} article(s) ajouté(s) à la liste.`);
      document.getElementById('shoppingContent').innerHTML = this.renderPanel();
    });
  },

  // ─── Ouvrir le drive du supermarché ───────────
  openStore(storeId) {
    const store = this.STORES.find(s => s.id === storeId);
    if (!store) return;
    const d = this.get();
    d.preferredStore = storeId;
    this.save(d);
    window.open(store.url, '_blank');
    if (window.addChatMsg) addChatMsg('assistant', `🛒 Ouverture de ${store.name}. Bonne course !`);
  },

  // ─── Vérifier les promos ──────────────────────
  async checkPromos(claudeKey) {
    const d = this.get();
    const store = this.STORES.find(s => s.id === d.preferredStore);
    if (!store || !claudeKey) return;

    if (window.addChatMsg) addChatMsg('assistant', `🔍 Vérification des promotions ${store.name} cette semaine...`);

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 300,
          tools: [{ type: 'web_search_20250305', name: 'web_search' }],
          messages: [{ role: 'user', content: `Cherche les promotions et ventes flash ${store.name} cette semaine. Liste les 5 meilleures offres avec le produit et la réduction. Réponse concise en français.` }]
        })
      });
      const data = await r.json();
      const text = data.content.filter(b => b.type === 'text').map(b => b.text).join('');

      d.lastPromoCheck = new Date().toISOString();
      this.save(d);

      if (window.addChatMsg) addChatMsg('assistant', `🏷 Promotions ${store.name} cette semaine :\n\n${text}`);
    } catch {
      if (window.addChatMsg) addChatMsg('assistant', 'Impossible de vérifier les promotions. Vérifiez votre connexion.');
    }
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    const unchecked = d.items.filter(i => !i.checked);
    const checked = d.items.filter(i => i.checked);
    const categories = [...new Set(unchecked.map(i => i.category))];

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <!-- Ajouter vocal -->
      <div style="display:flex;gap:.4rem">
        <input type="text" id="shop-item" placeholder="Ajouter un article..." style="flex:1"/>
        <button onclick="SHOPPING.addToList(document.getElementById('shop-item').value,1,null);document.getElementById('shoppingContent').innerHTML=SHOPPING.renderPanel()" style="padding:.5rem .7rem;background:var(--gold);color:var(--dark);border:none;font-size:.7rem;cursor:pointer">+</button>
        <button onclick="SHOPPING.voiceAdd()" style="padding:.5rem .6rem;background:transparent;border:1px solid var(--gold);color:var(--gold);font-size:.75rem;cursor:pointer">🎙</button>
      </div>

      <!-- Supermarché préféré -->
      <div>
        <span class="klabel">Mon supermarché</span>
        <div style="display:flex;gap:.3rem;margin-top:.3rem;flex-wrap:wrap">
          ${this.STORES.map(s => `
            <button onclick="SHOPPING.openStore('${s.id}')" style="padding:.3rem .6rem;background:${d.preferredStore===s.id?'var(--gold)':'var(--dark-mid)'};color:${d.preferredStore===s.id?'var(--dark)':'var(--muted)'};border:1px solid ${d.preferredStore===s.id?'var(--gold)':'var(--border)'};font-family:'Josefin Sans',sans-serif;font-size:.48rem;cursor:pointer">${s.name}</button>
          `).join('')}
        </div>
      </div>

      <div style="display:flex;gap:.4rem">
        <button class="btn btn-ghost" style="flex:1" onclick="SHOPPING.checkPromos(window.CFG?.CLAUDE_KEY)">🏷 Promos cette semaine</button>
        ${checked.length > 0 ? `<button class="btn btn-ghost" style="flex:1" onclick="SHOPPING.clearChecked();document.getElementById('shoppingContent').innerHTML=SHOPPING.renderPanel()">🗑 Vider cochés</button>` : ''}
      </div>

      <!-- Liste par catégorie -->
      ${unchecked.length === 0 && checked.length === 0 ? `
        <div style="text-align:center;padding:2rem;color:var(--muted);font-size:.56rem">
          Votre liste est vide.<br/>Dites ce dont vous avez besoin !
        </div>
      ` : ''}

      ${categories.map(cat => `
        <div>
          <div style="font-size:.5rem;color:var(--cobalt);letter-spacing:.12em;text-transform:uppercase;margin-bottom:.3rem">${this.CATEGORIES[cat] || cat}</div>
          ${unchecked.filter(i => i.category === cat).map(item => `
            <div style="display:flex;align-items:center;gap:.5rem;padding:.45rem 0;border-bottom:1px solid var(--border)">
              <div onclick="SHOPPING.checkItem('${item.id}');document.getElementById('shoppingContent').innerHTML=SHOPPING.renderPanel()" style="width:20px;height:20px;border:2px solid var(--gold);border-radius:3px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0"></div>
              <span style="flex:1;font-size:.58rem;color:var(--text)">${item.name}</span>
              <span style="font-size:.5rem;color:var(--muted)">${item.quantity > 1 ? '×'+item.quantity : ''}</span>
              <button onclick="const d=SHOPPING.get();d.items=d.items.filter(i=>i.id!=='${item.id}');SHOPPING.save(d);document.getElementById('shoppingContent').innerHTML=SHOPPING.renderPanel()" style="background:transparent;border:none;color:rgba(239,83,80,.5);font-size:.65rem;cursor:pointer">×</button>
            </div>
          `).join('')}
        </div>
      `).join('')}

      ${checked.length > 0 ? `
        <div style="opacity:.5">
          <div style="font-size:.5rem;color:var(--muted);letter-spacing:.12em;text-transform:uppercase;margin-bottom:.3rem">✓ Dans le caddie</div>
          ${checked.map(item => `
            <div style="display:flex;align-items:center;gap:.5rem;padding:.35rem 0;border-bottom:1px solid var(--border)">
              <div onclick="SHOPPING.checkItem('${item.id}');document.getElementById('shoppingContent').innerHTML=SHOPPING.renderPanel()" style="width:20px;height:20px;border:2px solid #81c784;border-radius:3px;background:#81c784;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:.7rem">✓</div>
              <span style="flex:1;font-size:.56rem;color:var(--muted);text-decoration:line-through">${item.name}</span>
            </div>
          `).join('')}
        </div>
      ` : ''}
    </div>`;
  }
};

window.SHOPPING = SHOPPING;
