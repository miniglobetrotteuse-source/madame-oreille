// ═══════════════════════════════════════════════════
//  JINGLES & SONS — Or Eille AI v1.0
//  Génération jingles, vérification droits, multi-plateformes
// ═══════════════════════════════════════════════════

const JINGLES = {
  KEY: 'moe_jingles',

  MUSIC_STYLES: {
    afrobeats: 'Afrobeats — rythmé, percussions africaines, énergie',
    jazz: 'Jazz — sophistiqué, improvisé, chaleureux',
    classique: 'Classique — élégant, orchestral, intemporel',
    lofi: 'Lo-fi — détendu, cosy, étude',
    epic: 'Épique — cinématographique, dramatique, puissant',
    pop: 'Pop — accrocheur, moderne, mainstream',
    acoustique: 'Acoustique — naturel, authentique, guitare',
    electronic: 'Électronique — moderne, dynamique, futuriste',
    gospel: 'Gospel — spirituel, puissant, chœurs',
    maqam: 'Maqam — oriental, méditatif, arabesque',
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      jingleIntro: null, jingleOutro: null, library: [],
      preferredStyle: null, rightsClearanceCache: {}
    }; } catch { return {}; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Générer un jingle via Replicate ──────────
  async generateJingle(type, style, duration, referenceStyle) {
    const key = window.CFG?.REPLICATE_KEY;
    if (!key || key.includes('METTRE')) {
      if (window.addChatMsg) addChatMsg('assistant', 'Génération musicale non disponible — clé Replicate requise.');
      return null;
    }

    const styleInfo = this.MUSIC_STYLES[style] || style;
    let prompt = `${type === 'intro' ? 'Jingle d\'introduction' : 'Jingle de clôture'} — ${styleInfo}`;
    if (referenceStyle) prompt += ` — dans le style de ${referenceStyle} mais original et libre de droits`;
    prompt += ` — durée ${duration || 3} secondes — professionnel`;

    if (window.addChatMsg) addChatMsg('assistant', `🎵 Génération du jingle ${type} en cours...`);

    try {
      const r = await fetch('https://api.replicate.com/v1/predictions', {
        method: 'POST',
        headers: { 'Authorization': `Token ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          version: '671ac645ce5e552cc63a54a2bbff63fcf798043055d2dac5fc9e36a837eedcfb',
          input: { prompt, duration: duration || 3, output_format: 'mp3' }
        })
      });
      const prediction = await r.json();
      let result = null, attempts = 0;
      while (!result && attempts < 60) {
        await new Promise(res => setTimeout(res, 1000));
        const poll = await fetch(`https://api.replicate.com/v1/predictions/${prediction.id}`, {
          headers: { 'Authorization': `Token ${key}` }
        });
        const data = await poll.json();
        if (data.status === 'succeeded') result = data.output;
        else if (data.status === 'failed') break;
        attempts++;
      }

      if (result) {
        const d = this.get();
        if (type === 'intro') d.jingleIntro = { url: result, style, generatedAt: new Date().toISOString(), owned: true };
        else if (type === 'outro') d.jingleOutro = { url: result, style, generatedAt: new Date().toISOString(), owned: true };
        d.library.push({ id: Date.now().toString(), type, url: result, style, generatedAt: new Date().toISOString() });
        this.save(d);
        if (window.addChatMsg) addChatMsg('assistant', `✅ Jingle ${type} généré ! Il vous appartient — libre de droits sur toutes les plateformes.`);
        return result;
      }
    } catch {}
    return null;
  },

  // ─── Vérifier droits d'un son ─────────────────
  async checkRights(soundName, claudeKey) {
    const d = this.get();
    if (d.rightsClearanceCache[soundName]) return d.rightsClearanceCache[soundName];
    if (!claudeKey) return null;

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 300,
          tools: [{ type: 'web_search_20250305', name: 'web_search' }],
          messages: [{
            role: 'user',
            content: `Recherche si "${soundName}" est protégé par des droits d'auteur et si son utilisation sur Instagram, TikTok et YouTube est libre ou soumise à des restrictions. Réponds clairement: LIBRE, RESTREINT, ou BLOQUÉ selon la plateforme.`
          }]
        })
      });
      const data = await r.json();
      const result = { text: data.content.filter(b => b.type === 'text').map(b => b.text).join(''), checkedAt: new Date().toISOString() };
      d.rightsClearanceCache[soundName] = result;
      this.save(d);
      return result;
    } catch { return null; }
  },

  // ─── Adapter un son pour toutes les plateformes ─
  async adaptForAllPlatforms(originalSound, mood, claudeKey) {
    if (!claudeKey) return null;
    if (window.addChatMsg) addChatMsg('assistant', `🎵 Génération d'alternatives libres de droits pour toutes vos plateformes...`);

    const platforms = ['Instagram', 'TikTok', 'YouTube', 'Snapchat'];
    const alternatives = [];

    for (const platform of platforms) {
      try {
        const r = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
          body: JSON.stringify({
            model: 'claude-sonnet-4-20250514', max_tokens: 150,
            messages: [{
              role: 'user',
              content: `Décris en 2 phrases un prompt musical pour générer via IA un son qui capture l'ambiance de "${originalSound}" (${mood}) pour ${platform}, mais 100% original et libre de droits. Sois très précis sur le style, les instruments, le tempo.`
            }]
          })
        });
        const data = await r.json();
        alternatives.push({ platform, prompt: data.content[0].text });
      } catch {}
    }

    if (alternatives.length > 0 && window.addChatMsg) {
      const msg = alternatives.map(a => `**${a.platform}** — ${a.prompt}`).join('\n\n');
      addChatMsg('assistant', `🎵 Alternatives libres de droits générées :\n\n${msg}\n\nVoulez-vous que je génère ces sons via Replicate ?`);
    }

    return alternatives;
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div class="sec-title">🎵 Ma signature sonore</div>
      <p class="note">Vos jingles vous appartiennent — générés par IA, libres de droits sur toutes les plateformes.</p>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">
        <div style="border:1px solid ${d.jingleIntro?'var(--gold)':'var(--border)'};padding:.6rem;text-align:center">
          <div style="font-size:.5rem;color:var(--muted);margin-bottom:.3rem">Jingle d'intro</div>
          ${d.jingleIntro ? `<audio controls src="${d.jingleIntro.url}" style="width:100%;margin-bottom:.3rem"></audio><div style="font-size:.44rem;color:#81c784">✓ Votre propriété</div>` : '<div style="font-size:.44rem;color:var(--muted)">Non configuré</div>'}
        </div>
        <div style="border:1px solid ${d.jingleOutro?'var(--gold)':'var(--border)'};padding:.6rem;text-align:center">
          <div style="font-size:.5rem;color:var(--muted);margin-bottom:.3rem">Jingle de clôture</div>
          ${d.jingleOutro ? `<audio controls src="${d.jingleOutro.url}" style="width:100%;margin-bottom:.3rem"></audio><div style="font-size:.44rem;color:#81c784">✓ Votre propriété</div>` : '<div style="font-size:.44rem;color:var(--muted)">Non configuré</div>'}
        </div>
      </div>

      <!-- Générer jingles -->
      <div>
        <span class="klabel">Style musical</span>
        <select id="jg-style" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.56rem;padding:.4rem;outline:none">
          ${Object.entries(this.MUSIC_STYLES).map(([k,v]) => `<option value="${k}">${v}</option>`).join('')}
        </select>
      </div>
      <input type="text" id="jg-reference" placeholder="Style de référence (ex: Adele, Burna Boy) — sera recréé original"/>
      <div style="display:flex;gap:.4rem">
        <button class="btn btn-gold" style="flex:1" onclick="JINGLES.generateJingle('intro',document.getElementById('jg-style').value,3,document.getElementById('jg-reference').value)">🎵 Générer intro</button>
        <button class="btn btn-ghost" style="flex:1" onclick="JINGLES.generateJingle('outro',document.getElementById('jg-style').value,3,document.getElementById('jg-reference').value)">🎵 Générer clôture</button>
      </div>

      <div class="sep"></div>
      <div class="sec-title">⚖ Vérifier les droits d'un son</div>
      <div style="display:flex;gap:.4rem">
        <input type="text" id="jg-sound-check" placeholder="Nom du son ou de la chanson" style="flex:1"/>
        <button onclick="JINGLES.checkRights(document.getElementById('jg-sound-check').value,window.CFG?.CLAUDE_KEY).then(r=>{if(r&&window.addChatMsg)addChatMsg('assistant','⚖ '+r.text)})" class="btn btn-ghost">Vérifier</button>
      </div>

      <div class="sep"></div>
      <div class="sec-title">🌐 Adapter pour toutes les plateformes</div>
      <div style="display:flex;gap:.4rem">
        <input type="text" id="jg-original" placeholder="Son de référence (ex: Skyfall Adele)" style="flex:1"/>
        <input type="text" id="jg-mood" placeholder="Ambiance" style="flex:1"/>
      </div>
      <button class="btn btn-ghost" onclick="JINGLES.adaptForAllPlatforms(document.getElementById('jg-original').value,document.getElementById('jg-mood').value,window.CFG?.CLAUDE_KEY)">🌐 Créer alternatives libres</button>
    </div>`;
  }
};

window.JINGLES = JINGLES;
