// ═══════════════════════════════════════════════════
//  MODE ENFANTS — Or Eille AI v1.0
//  3-12 ans — L'enfant est le héros
//  Toujours en sécurité — Je suis avec toi
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const KIDS = {
  KEY: 'moe_kids',
  ALERTS_KEY: 'moe_kids_alerts',

  AGE_GROUPS: {
    petit: { label:'3-5 ans', icon:'🌱', timer:20, routines:['Range tes jouets','Bois un verre d eau','Fais pipi','Va jouer dehors'] },
    moyen: { label:'6-8 ans', icon:'🌿', timer:30, routines:['Range ta chambre','Fais ton lit','Prepare ton sac','Bois de l eau','Va sauter ou faire du velo'] },
    grand: { label:'9-12 ans', icon:'🌳', timer:45, routines:['Range ta chambre','Fais ton lit','Prepare ton sac','Mets ton gouter','Verifie tes devoirs','Bois de l eau','20 squats ou une course'] },
  },

  EVENING_CHECKLIST: [
    'Mon sac est prepare','Mes devoirs sont dans mon sac',
    'Mon gouter est pret','Mes chaussures sont devant la porte',
    'Mon lit est fait','J ai bu assez d eau','J ai range ma chambre',
  ],

  ENCOURAGEMENTS: [
    'Bravo champion !','Bravo championne !','Tu as vraiment bien travaille !',
    'Je suis tellement fier de toi !','Tu vois — tu y arrives !',
    'Quelle bonne idee !','Tu grandis tellement vite.',
    'Wow ! Tu as fait ca tout seul ?','Tu m etonnes chaque jour.',
  ],

  CULTURES: [
    'Liban','Congo','Senegal','Maroc','Cote d Ivoire','Cameroun','Mali',
    'Algerie','Tunisie','Madagascar','Benin','Togo','Guinee','Rwanda',
    'France','Belgique','Suisse','Canada','Haiti','Martinique','Guadeloupe',
    'Vietnam','Chine','Japon','Inde','Bresil','Mexique','Serbie','Grece','Algerie berbere Amazigh',
  ],

  DISTRESS_SIGNALS: [
    'triste','j ai peur','on me fait du mal','je veux partir',
    'personne ne m aime','on me frappe','on me touche','ca fait mal',
    'je veux mourir','je suis seul','espece de','abruti','ta gueule',
    'ferme la','idiot','nul','casse toi',
  ],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { childName:'', ageGroup:'moyen', cultures:[], language:'fr' }; }
    catch { return { childName:'', ageGroup:'moyen', cultures:[], language:'fr' }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },
  getAlerts() { try { return JSON.parse(localStorage.getItem(this.ALERTS_KEY) || '[]'); } catch { return []; } },
  saveAlert(type, text, context) {
    const alerts = this.getAlerts();
    alerts.unshift({
      id: 'KID-' + Date.now().toString(36).toUpperCase(),
      type, text: text.substring(0,500), context: context||'',
      childName: this.get().childName || 'enfant',
      at: new Date().toISOString(),
      dateStr: new Date().toLocaleString('fr-FR'),
    });
    localStorage.setItem(this.ALERTS_KEY, JSON.stringify(alerts.slice(0,50)));
  },

  enc() { return this.ENCOURAGEMENTS[Math.floor(Math.random()*this.ENCOURAGEMENTS.length)]; },

  checkDistress(text, isEnvironment) {
    const lower = text.toLowerCase();
    const found = this.DISTRESS_SIGNALS.filter(function(s) { return lower.includes(s); });
    if (found.length === 0) return false;

    this.saveAlert(isEnvironment ? 'environment' : 'child', text, isEnvironment ? 'Voix ou bruit violent detecte pendant session enfant' : '');

    if (isEnvironment) {
      if (window.addChatMsg) addChatMsg('assistant',
        'Il y a beaucoup de bruit autour de toi en ce moment.\n\n' +
        'Prends ton telephone ou ta tablette. Glisse-toi doucement dans ta chambre ou derriere le canape. Trouve un endroit un peu plus calme.\n\n' +
        'Je suis avec toi. On va respirer ensemble.'
      );
      this.breathingExercise();
    } else {
      if (window.addChatMsg) addChatMsg('assistant',
        'Je t entends. Ce que tu ressens est important.\n\n' +
        'Tu n es pas seul. Il y a un adulte de confiance pres de toi — un professeur, une tante, un voisin — a qui tu peux parler.\n\n' +
        'Tu peux aussi appeler le 119. C est gratuit. C est pour toi. Ils ecoutent toujours.\n\n' +
        'Je suis avec toi. ' + this.enc()
      );
    }
    return true;
  },

  breathingExercise() {
    const existing = document.getElementById('kids-breath');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.id = 'kids-breath';
    modal.style.cssText = 'position:fixed;inset:0;background:#0a1628;z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:2rem;text-align:center';

    const phases = [
      { text:'Inspire doucement...', duration:4000, color:'#C4993A', size:'6rem' },
      { text:'Retiens...', duration:4000, color:'#6BA3D6', size:'7rem' },
      { text:'Expire lentement...', duration:5000, color:'#81c784', size:'5rem' },
    ];

    modal.innerHTML =
      '<p style="font-size:.6rem;color:rgba(255,255,255,.5);margin-bottom:1.5rem">Je suis avec toi. On respire ensemble.</p>' +
      '<div id="breath-circle" style="width:120px;height:120px;border-radius:50%;background:rgba(196,153,58,.2);border:3px solid #C4993A;display:flex;align-items:center;justify-content:center;margin-bottom:1.5rem;transition:all 1s ease">🌬</div>' +
      '<div id="breath-text" style="font-size:1.2rem;color:#fff;margin-bottom:2rem">Inspire doucement...</div>' +
      '<button onclick="document.getElementById(\'kids-breath\').remove()" style="padding:.6rem 1.5rem;background:transparent;border:1px solid rgba(255,255,255,.3);color:rgba(255,255,255,.6);font-size:.5rem;cursor:pointer">Je me sens mieux</button>';

    document.body.appendChild(modal);

    let phaseIdx = 0;
    const runPhase = function() {
      const p = phases[phaseIdx % phases.length];
      const circle = document.getElementById('breath-circle');
      const text = document.getElementById('breath-text');
      if (!circle || !text) return;
      text.textContent = p.text;
      text.style.color = p.color;
      circle.style.borderColor = p.color;
      circle.style.background = 'rgba(' + (phaseIdx%3===0?'196,153,58':phaseIdx%3===1?'27,79,138':'129,199,132') + ',.2)';
      phaseIdx++;
      setTimeout(runPhase, p.duration);
    };
    runPhase();
  },

  startSession() {
    const d = this.get();
    const ag = this.AGE_GROUPS[d.ageGroup];
    const name = d.childName || 'champion';
    if (window.addChatMsg) addChatMsg('assistant', 'Bonjour ' + name + ' ! On commence — tu as ' + ag.timer + ' minutes. ' + this.enc());
    const self = this;
    setTimeout(function() { self.endSession(); }, ag.timer * 60 * 1000);
    document.getElementById('kidsContent').innerHTML = KIDS.renderPanel();
  },

  endSession() {
    const d = this.get();
    const ag = this.AGE_GROUPS[d.ageGroup];
    const name = d.childName || 'champion';
    if (window.addChatMsg) addChatMsg('assistant',
      this.enc() + '\n\nBravo ' + name + ' ! Ta session est terminee.\n\nMission maintenant :\n\n' +
      ag.routines.map(function(r,i) { return (i+1)+'. '+r; }).join('\n') +
      '\n\nJe suis avec toi. Quand tout est fait — reviens me dire !'
    );
    document.getElementById('kidsContent').innerHTML = KIDS.renderPanel();
  },

  eveningCheck() {
    const d = this.get();
    const name = d.childName || 'champion';
    if (window.addChatMsg) addChatMsg('assistant',
      'Bonsoir ' + name + ' ! C est l heure de preparer pour demain.\n\n' +
      this.EVENING_CHECKLIST.map(function(item,i) { return (i+1)+'. '+item+' ?'; }).join('\n') +
      '\n\nQuand tout est coche — au lit. Je suis avec toi. Demain on a de nouvelles aventures. ' + this.enc()
    );
  },

  async generateStory(claudeKey) {
    const d = this.get();
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const name = d.childName || 'le petit heros';
    const cultures = d.cultures.length > 0 ? d.cultures.slice(0,2).join(' et ') : 'du monde entier';
    const ag = this.AGE_GROUPS[d.ageGroup];
    if (window.addChatMsg) addChatMsg('assistant','Je cree ton histoire...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:800,
          messages:[{ role:'user', content:
            'Cree une histoire pour un enfant de ' + ag.label + '. Le heros s appelle ' + name + '.\n' +
            'L histoire melange les cultures : ' + cultures + '.\n' +
            'Inclure : elements culturels authentiques des deux cultures, valeurs de partage et respect, humour adapte.\n' +
            'L enfant decouvre sa double culture comme une richesse — pas une difficulte.\n' +
            'Langage simple. 10 a 15 phrases. Commence par Il etait une fois ' + name + '...'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  async learnLanguage(targetLang, claudeKey) {
    const d = this.get();
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const name = d.childName || 'champion';
    const ag = this.AGE_GROUPS[d.ageGroup];
    if (window.addChatMsg) addChatMsg('assistant','On apprend le ' + targetLang + ' ensemble !');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:600,
          messages:[{ role:'user', content:
            'Cree une lecon de ' + targetLang + ' pour ' + name + ', ' + ag.label + '.\n' +
            '6 mots simples du quotidien avec : le mot en ' + targetLang + ', la prononciation phonetique, la traduction en francais, une phrase exemple amusante.\n' +
            'Format ludique et encourage. Termine par un encouragement chaleureux.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  renderPanel: function() {
    const d = this.get();
    const alerts = this.getAlerts();
    const ag = this.AGE_GROUPS[d.ageGroup];

    let culturesHtml = this.CULTURES.map(function(c) {
      const sel = d.cultures.includes(c);
      return '<button onclick="const d2=KIDS.get();const idx=d2.cultures.indexOf(\'' + c + '\');if(idx>-1)d2.cultures.splice(idx,1);else if(d2.cultures.length<3)d2.cultures.push(\'' + c + '\');KIDS.save(d2);document.getElementById(\'kidsContent\').innerHTML=KIDS.renderPanel()" style="padding:.25rem .4rem;background:' + (sel?'rgba(196,153,58,.2)':'var(--dark-mid)') + ';border:1px solid ' + (sel?'var(--gold)':'var(--border)') + ';color:' + (sel?'var(--gold)':'var(--muted)') + ';font-family:Josefin Sans,sans-serif;font-size:.44rem;cursor:pointer">' + c + '</button>';
    }).join('');

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +

      '<div class="sec-title">🌱 Mode enfants</div>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">L enfant est le heros. Toujours en securite. Toujours ecoute. Je suis avec toi.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div style="display:flex;gap:.4rem">' +
        '<div style="flex:1"><span class="klabel">Prenom</span><input type="text" id="kids-name" value="' + d.childName + '" placeholder="Prenom de l enfant" oninput="const d2=KIDS.get();d2.childName=this.value;KIDS.save(d2)" style="margin-top:.2rem"/></div>' +
      '</div>' +

      '<div class="sec-title">Age</div>' +
      '<div style="display:flex;gap:.3rem">' +
        Object.entries(this.AGE_GROUPS).map(function(e) {
          const sel = d.ageGroup === e[0];
          return '<button onclick="const d2=KIDS.get();d2.ageGroup=\'' + e[0] + '\';KIDS.save(d2);document.getElementById(\'kidsContent\').innerHTML=KIDS.renderPanel()" style="flex:1;padding:.5rem;background:' + (sel?'rgba(196,153,58,.2)':'var(--dark-mid)') + ';border:1px solid ' + (sel?'var(--gold)':'var(--border)') + ';color:' + (sel?'var(--gold)':'var(--muted)') + ';font-family:Josefin Sans,sans-serif;font-size:.5rem;cursor:pointer">' + e[1].icon + ' ' + e[1].label + '</button>';
        }).join('') +
      '</div>' +

      '<div class="sec-title">Cultures (max 2-3)</div>' +
      '<div style="display:flex;gap:.2rem;flex-wrap:wrap">' + culturesHtml + '</div>' +

      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
        '<button class="btn btn-gold" style="flex:1" onclick="KIDS.startSession()">▶ Commencer la session (' + ag.timer + ' min)</button>' +
        '<button class="btn btn-ghost" style="flex:1" onclick="KIDS.eveningCheck()">🌙 Checklist du soir</button>' +
      '</div>' +

      '<div class="sec-title">Activites</div>' +
      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' +
        '<button onclick="KIDS.generateStory(window.CFG&&window.CFG.CLAUDE_KEY)" style="flex:1;padding:.5rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:Josefin Sans,sans-serif;font-size:.5rem;cursor:pointer">📖 Mon histoire</button>' +
        '<button onclick="KIDS.financeLesson(window.CFG&&window.CFG.CLAUDE_KEY)" style="flex:1;padding:.5rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:Josefin Sans,sans-serif;font-size:.5rem;cursor:pointer">💰 Argent</button>' +
        '<button onclick="KIDS.breathingExercise()" style="flex:1;padding:.5rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:Josefin Sans,sans-serif;font-size:.5rem;cursor:pointer">🌬 Respirer</button>' +
      '</div>' +

      '<div style="display:flex;gap:.4rem">' +
        '<input type="text" id="kids-lang" placeholder="Apprendre quelle langue ? Ex: serbe, japonais..." style="flex:1"/>' +
        '<button onclick="KIDS.learnLanguage(document.getElementById(\'kids-lang\').value,window.CFG&&window.CFG.CLAUDE_KEY)" style="padding:.5rem .7rem;background:var(--gold);color:var(--dark);border:none;font-size:.5rem;cursor:pointer">🌍 Apprendre</button>' +
      '</div>' +

      '<div style="background:rgba(239,83,80,.06);border:1px solid rgba(239,83,80,.15);padding:.6rem">' +
        '<div style="font-size:.5rem;color:#ef5350;margin-bottom:.3rem">🆘 Urgence enfant</div>' +
        '<div style="display:flex;gap:.4rem">' +
          '<a href="tel:119" style="flex:1;padding:.4rem;background:rgba(239,83,80,.15);border:1px solid rgba(239,83,80,.3);color:#ef5350;text-decoration:none;text-align:center;font-family:Josefin Sans,sans-serif;font-size:.54rem">119 — Enfance en danger</a>' +
          '<button onclick="KIDS.breathingExercise()" style="flex:1;padding:.4rem;background:rgba(129,199,132,.1);border:1px solid rgba(129,199,132,.3);color:#81c784;font-family:Josefin Sans,sans-serif;font-size:.5rem;cursor:pointer">🌬 Respirer ensemble</button>' +
        '</div>' +
      '</div>' +

      (alerts.length > 0 ? (
        '<div style="background:rgba(239,83,80,.05);border:1px solid rgba(239,83,80,.15);padding:.6rem">' +
          '<div style="font-size:.5rem;color:#ef5350;margin-bottom:.3rem">⚠ ' + alerts.length + ' alerte(s) sauvegardee(s) — disponibles comme preuves</div>' +
          '<div style="font-size:.44rem;color:var(--muted)">' + alerts[0].dateStr + ' — ' + alerts[0].type + '</div>' +
        '</div>'
      ) : '') +

    '</div>';
  },

  TALES_BY_CULTURE: {
    'Congo': ['Mami Wata la sirene des fleuves','Le lion et la tortue sage','La princesse de la foret du Congo','Les esprits de la riviere Lualaba'],
    'Senegal': ['Leuk le lievre malicieux','La fille des eaux','La princesse Fatima et le baobab magique','Koumen le berger peul'],
    'Liban': ['Juha et son ane','Les cedres du Liban et le genie','La princesse de la montagne','Sindbad le marin jeune'],
    'Maroc': ['La fille du sultan et le tapis volant','Le marchand de Marrakech','Les gnaoua et la musique magique','Aladdin version berbere'],
    'Cote d Ivoire': ['Anansi l araignee qui voulait toutes les histoires','La tortue et le leopard','Le roi des dieux Nyame','La danse des masques Goli'],
    'Cameroun': ['La panthere et le python','Le genie de la montagne Cameroun','Ngoso le chasseur brave','La legende du Mont Fako'],
    'Mali': ['Soundiata Keita l enfant lion','La griot Soumba','Le pecheur et le genie du Niger','La cite de Tombouctou et ses secrets'],
    'Algerie': ['La fee Tafat de Kabylie','Le geant Jugurtha','La princesse berbere et l aigle','Les contes de la casbah'],
    'Tunisie': ['Dido la reine fondatrice de Carthage','Le genie de Sidi Bou Said','La lampe de Tunis','Les enfants de la medina'],
    'Madagascar': ['Ibonia le heros malgache','La fille de la lune','Le zebu magique','Les vazimba les premiers habitants'],
    'Benin': ['Dan Ayido Hwedo le serpent arc-en-ciel','La princesse d Abomey','Legba le gardien des chemins','La reine Tassi Hangbe guerriere'],
    'Rwanda': ['Gihanga le fondateur','La princesse Nyirarucyaba','Le berger et le roi de la pluie','Les collines aux mille secrets'],
    'Haiti': ['Ti Jean Horizon le malin','Baron Samedi protecteur des enfants','La sirene Lasirenn','Bouki et Malice les deux amis'],
    'Martinique': ['Compere Lapin et ses ruses','La diablesse de la route','Manman Dlo la mere des eaux','Le zombi et le jardinier courageux'],
    'Vietnam': ['La legende du lac restitue','La fee aux plumes de phenix','Le fils du dragon et la fee','Con Rong Chau Tien les descendants du dragon'],
    'Japon': ['Momotaro le garcon peche','Kaguya-hime la princesse de la lune','Issun Boshi le petit pouce japonais','Urashima Taro et le palais sous la mer'],
    'Inde': ['Rama et Sita la victoire du bien','Ganesh et la course autour du monde','La petite Krishna et le beurre','Birbal le ministre le plus intelligent'],
    'Chine': ['Mulan la guerriere courageuse','Le singe roi Sun Wukong','La fee tisserande et le bouvier','Nezha l enfant aux lotus'],
    'Serbie': ['Zmaj le dragon protecteur','La Belle et le Serpent dore','Le heros Milos Obilic','La fille plus sage que le roi'],
    'Grece': ['Ulysse et le cyclope version enfant','Persephone et les quatre saisons','Icare et ses ailes','Thesee et le labyrinthe'],
    'France': ['Le Petit Prince revisite','La Belle au Bois Dormant d origine','Cendrillon et sa citrouille magique','Le Petit Chaperon Rouge version moderne'],
    'Belgique': ['Manneken Pis et sa legende','Le geant de Ath','Tchaantches le heros liegeois','Les lutins de la foret ardennaise'],
  },

  async generateTale(culture, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const d = this.get();
    const tales = this.TALES_BY_CULTURE[culture] || [];
    const tale = tales.length > 0 ? tales[Math.floor(Math.random()*tales.length)] : 'un conte traditionnel de ' + culture;
    const ag = this.AGE_GROUPS[d.ageGroup];
    const name = d.childName || 'le petit heros';
    if (window.addChatMsg) addChatMsg('assistant', 'Je te raconte ' + tale + '...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:800,
          messages:[{ role:'user', content:
            'Raconte le conte ' + tale + ' de ' + culture + ' pour un enfant de ' + ag.label + '. Prenom : ' + name + '. Integre ' + name + ' comme personnage secondaire. Reste fidele a la culture. Langage simple. Termine par la morale. 15 phrases maximum.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  async financeLesson(claudeKey) {
    const d = this.get();
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const ag = this.AGE_GROUPS[d.ageGroup];
    const name = d.childName || 'champion';
    const lessons = {
      petit: 'Expliquer simplement que l argent sert a acheter des choses. Exemple avec 2 pieces et 1 bonbon. Tres simple et concret.',
      moyen: 'Expliquer l epargne — si tu gardes 1 piece sur 2, en 5 jours tu as 5 pieces. Un tableau simple. Le principe de mettre de cote.',
      grand: 'Expliquer budget, revenus et depenses. Si tu as 10 euros d argent de poche — 5 pour aujourd hui, 5 pour plus tard. Reve avec tes economies.',
    };
    if (window.addChatMsg) addChatMsg('assistant','Lecon d argent pour ' + name + '...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:500,
          messages:[{ role:'user', content:
            'Cree une mini lecon d education financiere pour ' + name + ' age de ' + ag.label + '. ' + lessons[d.ageGroup] + ' Exemples concrets. Amusant. Pose une question a la fin.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },




  FAMILY_SITUATIONS: {
    maman_solo:   'Avec maman',
    papa_solo:    'Avec papa',
    deux_parents: 'Avec mes deux parents',
    mamie_papi:   'Chez mamie et papi',
    oncle_tante:  'Chez mon oncle et ma tante',
    recomposee:   'Famille recomposee',
    seul:         'Je me garde tout seul',
  },

  ENVIRONMENTS: {
    appartement:   'Appartement',
    maison_jardin: 'Maison avec jardin',
    quartier_parc: 'Quartier avec parc',
    campagne:      'A la campagne',
  },

  BUDGETS: {
    petit: 'Petit budget - activites gratuites ou avec ce qu on a',
    moyen: 'Budget moyen',
    libre: 'Pas de contrainte de budget',
  },

  KITCHEN: {
    complet: 'Cuisine complete avec four',
    plaques:  'Plaques seulement sans four',
    aucun:    'Sans cuisine disponible',
  },

  DIET: {
    omnivore: 'On mange de tout',
    vegetarien: 'Vegetarien - pas de viande',
    vegan: 'Vegan - rien d origine animale',
    halal: 'Halal',
    casher: 'Casher',
    sans_gluten: 'Sans gluten',
    sans_lactose: 'Sans lactose',
    allergie_noix: 'Allergie aux noix',
    allergie_oeuf: 'Allergie aux oeufs',
  },

  getActivities: function(profile) {
    const situation = profile.situation || 'deux_parents';
    const env = profile.environment || 'appartement';
    const budget = profile.budget || 'moyen';
    const kitchen = profile.kitchen || 'complet';
    const isOutdoor = env === 'maison_jardin' || env === 'quartier_parc' || env === 'campagne';
    const isFree = budget === 'petit';
    const hasFour = kitchen === 'complet';
    const hasPlaques = kitchen === 'complet' || kitchen === 'plaques';
    const isSeul = situation === 'seul';
    const isQuiet = situation === 'maman_solo' || situation === 'papa_solo';

    var activities = [];

    if (isQuiet) {
      activities.push('Dessiner ou colorier en silence');
      activities.push('Lire un livre ou une BD');
      activities.push('Origami - plier du papier en animaux');
      activities.push('Ecrire ou illustrer sa propre histoire');
    }
    if (isSeul) {
      activities.push('Construire avec des legumes ou de l argile');
      activities.push('Faire un journal illustre de sa journee');
      activities.push('Apprendre une chanson par coeur');
      activities.push('Jeu de construction - legos, boites, kaplas');
    }
    if (isOutdoor) {
      activities.push('Course entre deux arbres');
      activities.push('Observer les insectes et les noter dans un carnet');
      activities.push('Faire un petit jardin dans un pot');
    } else {
      activities.push('Parcours d obstacles avec les coussins');
      activities.push('Danse dans le salon - 3 chansons non-stop');
      activities.push('Jonglerie avec des chaussettes roulees');
    }
    if (hasFour) {
      activities.push('Muffins simples - farine sucre oeuf beurre');
    } else if (hasPlaques) {
      activities.push('Crepes a la poele');
    } else {
      activities.push('Salade de fruits coloriee');
      activities.push('Smoothie sans cuisson');
    }
    if (isFree) {
      activities.push('Theatre de marionnettes avec des chaussettes');
      activities.push('Musique avec des objets de la maison');
    }

    return activities.slice(0, 6);
  },

  getDietNote: function(diet) {
    var notes = {
      vegan: 'Recette adaptee - sans produits animaux',
      vegetarien: 'Recette adaptee - sans viande',
      sans_gluten: 'Recette adaptee - sans gluten',
      sans_lactose: 'Recette adaptee - sans lactose',
      allergie_noix: 'ATTENTION - sans noix',
      allergie_oeuf: 'Recette adaptee - sans oeufs',
      halal: 'Recette halal',
      casher: 'Recette casher',
    };
    return notes[diet] || '';
  },



  AGE_BABY: { label:'Moins de 3 ans', icon:'🍼', noScreen:true },

  EYE_YOGA: [
    { name:'Loin Pres', desc:'Regarde au loin 5 secondes puis le bout de ton doigt 5 secondes. 5 fois.', seconds:60 },
    { name:'Palming', desc:'Frotte tes paumes. Pose-les sur tes yeux fermes 30 secondes.', seconds:30 },
    { name:'Cercles', desc:'Yeux fermes - cercles doux 5 fois dans chaque sens.', seconds:30 },
    { name:'Clignements', desc:'Cligne 10 fois vite. Ferme les yeux 10 secondes. Repete 3 fois.', seconds:40 },
  ],

  LISTENING_EXERCISES: [
    { name:'Combien de sons', desc:'Ferme les yeux. Ecoute. Combien de sons tu entends autour de toi ?', age:'petit' },
    { name:'D ou ca vient', desc:'Ferme les yeux. Pointe du doigt d ou vient le son.', age:'petit' },
    { name:'Repete apres moi', desc:'Repete cette suite : pa-ta-ka. Plus vite. A l envers : ka-ta-pa.', age:'moyen' },
  ],

  DETECTION_SIGNALS: {
    dyslexie: ['confond b et d','confond p et q','lit tres lentement','saute des mots'],
    dyscalculie: ['compte sur les doigts apres 8 ans','confond les chiffres','perd le fil des suites'],
    tdah: ['abandonne avant la fin','repond sans reflechir','tres agite','change de sujet'],
    vision: ['plisse les yeux','se rapproche de l ecran','se frotte les yeux','mal de tete apres lecture'],
  },

  getParentMessage: function(detected) {
    var messages = {
      dyslexie: 'Certains enfants lisent differemment - ce n est pas un manque d intelligence. Un orthophoniste peut faire un bilan et proposer des exercices qui aident vraiment.',
      dyscalculie: 'Certains cerveaux traitent les chiffres differemment. Un orthophoniste ou un psychologue scolaire peut aider avec des outils adaptes.',
      tdah: 'Certains enfants ont une attention qui fonctionne differemment. Un pediatre peut evaluer et proposer des strategies tres efficaces.',
      vision: 'Ton enfant semble avoir des difficultes visuelles. Un opticien peut faire un bilan en 15 minutes. Or Eille AI a agrandi le texte en attendant.',
    };
    return messages[detected] || '';
  },

  async generateBabyStory(childName, cultures, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const name = childName || 'le petit';
    const culture = cultures && cultures.length > 0 ? cultures.slice(0,2).join(' et ') : '';
    if (window.addChatMsg) addChatMsg('assistant','Histoire pour ' + name + ' a lire a voix haute...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:400,
          messages:[{ role:'user', content: 'Ecris une histoire tres courte pour un enfant de moins de 3 ans. Le heros s appelle ' + name + (culture ? ' et sa famille vient de ' + culture : '') + '. Phrases tres courtes. Mots simples. Beaucoup de repetitions. Rythme de berceuse. 8 phrases maximum. A lire a voix haute par un parent.' }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text + ' [Histoire a imprimer ou lire sur votre telephone - pas en face de l enfant]');
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  async generatePrintableActivity(childName, ageGroup, situation, environment, budget, diet, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const name = childName || 'votre enfant';
    const ag = this.AGE_GROUPS[ageGroup] || this.AGE_GROUPS.moyen;
    const sit = this.FAMILY_SITUATIONS[situation] || '';
    const env = this.ENVIRONMENTS[environment] || '';
    const bud = this.BUDGETS[budget] || '';
    const dit = this.DIET[diet] || '';
    if (window.addChatMsg) addChatMsg('assistant','Preparation des activites pour ' + name + '...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:600,
          messages:[{ role:'user', content: 'Propose 5 activites concretes pour un enfant de ' + ag.label + ' qui s appelle ' + name + '. Situation familiale : ' + sit + '. Environnement : ' + env + '. Budget : ' + bud + (dit ? '. Regime alimentaire : ' + dit : '') + '. Activites sans ecran. Concretes. Avec ce qu on a. Chaque activite en 2 lignes max. Ton bienveillant.' }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  async generateDietRecipe(childName, ageGroup, diet, kitchen, budget, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const name = childName || 'votre enfant';
    const ag = this.AGE_GROUPS[ageGroup] || this.AGE_GROUPS.moyen;
    const dit = this.DIET[diet] || 'omnivore';
    const kit = this.KITCHEN[kitchen] || 'complet';
    const bud = this.BUDGETS[budget] || '';
    if (window.addChatMsg) addChatMsg('assistant','Recette pour ' + name + ' - ' + dit + '...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:400,
          messages:[{ role:'user', content: 'Propose une recette simple pour un enfant de ' + ag.label + '. Regime : ' + dit + '. Cuisine disponible : ' + kit + '. Budget : ' + bud + '. L enfant peut participer a la preparation. Instructions simples etape par etape. Ingredients accessibles.' }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },


};

window.KIDS = KIDS;
