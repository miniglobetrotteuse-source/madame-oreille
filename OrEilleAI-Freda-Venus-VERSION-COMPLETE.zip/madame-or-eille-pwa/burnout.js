// ═══════════════════════════════════════════════════
//  PREVENTION BURNOUT CREATIF — Or Eille AI v1.0
//  Detecter avant que ca casse
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const BURNOUT = {
  KEY: 'moe_burnout',
  SESSION_KEY: 'moe_session_start',

  SIGNALS: [
    { id:1, label:'Je refais le meme contenu en boucle sans inspiration', weight:3 },
    { id:2, label:'Je procrastine plus que d habitude', weight:2 },
    { id:3, label:'Je ne suis plus enthousiaste quand je publie', weight:3 },
    { id:4, label:'Je compare mes resultats negativement aux autres', weight:2 },
    { id:5, label:'Je publie par obligation pas par envie', weight:3 },
    { id:6, label:'Je n ai pas pris de vrai repos depuis plus de 2 semaines', weight:3 },
    { id:7, label:'J ai l impression que tout ce que je fais est nul', weight:3 },
    { id:8, label:'Je pense a tout arreter', weight:4 },
    { id:9, label:'Mon corps me dit stop — fatigue, tensions, maux de tete', weight:3 },
    { id:10, label:'Je n ai plus de nouvelles idees', weight:2 },
  ],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { selected: [], checks: [] }; }
    catch { return { selected: [], checks: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  toggle(id) {
    const d = this.get();
    const idx = d.selected.indexOf(id);
    if (idx > -1) d.selected.splice(idx, 1);
    else d.selected.push(id);
    this.save(d);
    document.getElementById('burnoutContent').innerHTML = BURNOUT.renderPanel();
  },

  async analyze(claudeKey) {
    const d = this.get();
    const selected = this.SIGNALS.filter(function(s) { return d.selected.includes(s.id); });
    const score = selected.reduce(function(sum, s) { return sum + s.weight; }, 0);

    let level, color, message;
    if (score === 0) { level = 'Vous allez bien'; color = '#81c784'; message = 'Aucun signal de burnout detecte. Continuez comme ca et prenez quand meme des pauses regulieres.'; }
    else if (score <= 4) { level = 'Fatigue legere'; color = '#F5A623'; message = 'Quelques signaux. Prenez une journee sans creer. Rechargez.'; }
    else if (score <= 8) { level = 'Burnout qui approche'; color = '#ef5350'; message = 'Attention. Arretez de publier 3-4 jours. Ce n est pas de la paresse — c est de la survie creatrice.'; }
    else { level = 'Burnout serieux'; color = '#ef5350'; message = 'Stop. Maintenant. Votre creativite a besoin de vous en bonne sante pour exister. Prenez au moins une semaine. Completer. Et parlez a quelqu un de confiance.'; }

    if (window.addChatMsg) addChatMsg('assistant', level + ' — Score: ' + score + '\n\n' + message);

    if (claudeKey && selected.length > 0) {
      const signals = selected.map(function(s) { return '- ' + s.label; }).join('\n');
      try {
        const r = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
          body: JSON.stringify({
            model: 'claude-sonnet-4-20250514', max_tokens: 600,
            messages: [{ role: 'user', content: 'Un createur montre ces signes de burnout :\n' + signals + '\n\nDonne-lui un plan de recuperation concret et bienveillant. 5 actions simples. Mentionne que Madame Or Eille propose des seances d ecoute si besoin.' }]
          })
        });
        const data = await r.json();
        if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
        if (window.addChatMsg) addChatMsg('assistant', 'Et si vous avez besoin d une vraie ecoute humaine — Madame Or Eille est la. Vos mots ont de la valeur. Vous aussi.\n👉 ' + (window.CFG && window.CFG.MADAME_OR_EILLE_URL ? window.CFG.MADAME_OR_EILLE_URL : 'madame-or-eille.com'));
      } catch(e) {}
    }

    d.checks.unshift({ score, level, at: new Date().toISOString() });
    d.checks = d.checks.slice(0, 20);
    this.save(d);
  },

  renderPanel: function() {
    const d = this.get();
    const score = this.SIGNALS.filter(function(s) { return d.selected.includes(s.id); }).reduce(function(sum, s) { return sum + s.weight; }, 0);
    const scoreColor = score === 0 ? '#81c784' : score <= 4 ? '#F5A623' : '#ef5350';

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🧠 Prevention du burnout creatif</div>' +
      '<p class="note">Le burnout creatif ca ne previent pas. Ou il detecte et agit avant que ca casse.</p>' +
      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">Votre creativite a besoin de vous en bonne sante pour exister. Cochez ce que vous ressentez — pas de jugement. Juste de la bienveillance.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +
      (score > 0 ? '<div style="text-align:center;padding:.5rem;background:rgba(' + (score<=4?'245,166,35':'239,83,80') + ',.1);border:1px solid ' + scoreColor + '"><div style="font-size:.6rem;color:' + scoreColor + '">' + score + ' points</div></div>' : '') +
      this.SIGNALS.map(function(s) {
        const sel = d.selected.includes(s.id);
        return '<label style="display:flex;align-items:center;gap:.5rem;padding:.5rem;border:1px solid ' + (sel?'rgba(239,83,80,.4)':'var(--border)') + ';background:' + (sel?'rgba(239,83,80,.06)':'var(--dark-mid)') + ';cursor:pointer;margin-bottom:.2rem">' +
          '<input type="checkbox" ' + (sel?'checked':'') + ' onchange="BURNOUT.toggle(' + s.id + ')" style="accent-color:#ef5350"/>' +
          '<span style="font-size:.54rem;color:' + (sel?'#ef5350':'var(--muted)') + '">' + s.label + '</span>' +
        '</label>';
      }).join('') +
      '<button class="btn btn-gold" onclick="BURNOUT.analyze(window.CFG&&window.CFG.CLAUDE_KEY)">🧠 Analyser et recevoir un plan de recuperation</button>' +
      '<button class="btn btn-ghost" onclick="const d=BURNOUT.get();d.selected=[];BURNOUT.save(d);document.getElementById(\'burnoutContent\').innerHTML=BURNOUT.renderPanel()">Tout decocher</button>' +
    '</div>';
  },

  LOCK_KEY: 'moe_burnout_lock',

  getLock() {
    try { return JSON.parse(localStorage.getItem(this.LOCK_KEY)) || { active: false }; }
    catch { return { active: false }; }
  },

  isLocked() {
    const lock = this.getLock();
    if (!lock.active) return false;
    if (new Date() >= new Date(lock.unlockAt)) {
      localStorage.removeItem(this.LOCK_KEY);
      return false;
    }
    return true;
  },

  async setLock(hours) {
    const unlockAt = new Date(Date.now() + hours * 3600 * 1000);
    const lock = { active: true, unlockAt: unlockAt.toISOString(), hours };
    localStorage.setItem(this.LOCK_KEY, JSON.stringify(lock));

    // Sync Supabase
    const cfg = window.CFG;
    if (cfg && cfg.SUPABASE_URL && !cfg.SUPABASE_URL.includes('METTRE')) {
      try {
        const userId = localStorage.getItem('moe_user_id') || 'user';
        await fetch(cfg.SUPABASE_URL + '/rest/v1/burnout_locks', {
          method: 'POST',
          headers: { 'apikey': cfg.SUPABASE_KEY, 'Authorization': 'Bearer ' + cfg.SUPABASE_KEY, 'Content-Type': 'application/json', 'Prefer': 'resolution=merge-duplicates' },
          body: JSON.stringify({ user_id: userId, active: true, unlock_at: unlockAt.toISOString(), updated_at: new Date().toISOString() })
        });
      } catch(e) {}
    }

    if (window.addChatMsg) addChatMsg('assistant', 'Verrou active ' + hours + 'h sur tous vos appareils. Jusqu a ' + unlockAt.toLocaleString('fr-FR') + '. Rien ne sera perdu. Tout vous attend. Allez vous reposer.');
    document.getElementById('burnoutContent').innerHTML = BURNOUT.renderPanel();
  },

  async checkRemoteLock() {
    const cfg = window.CFG;
    if (!cfg || !cfg.SUPABASE_URL || cfg.SUPABASE_URL.includes('METTRE')) return;
    try {
      const userId = localStorage.getItem('moe_user_id') || 'user';
      const r = await fetch(cfg.SUPABASE_URL + '/rest/v1/burnout_locks?user_id=eq.' + userId, {
        headers: { 'apikey': cfg.SUPABASE_KEY, 'Authorization': 'Bearer ' + cfg.SUPABASE_KEY }
      });
      const data = await r.json();
      if (data && data[0] && data[0].active) {
        const lock = { active: true, unlockAt: data[0].unlock_at, hours: 2 };
        localStorage.setItem(this.LOCK_KEY, JSON.stringify(lock));
      }
    } catch(e) {}
  },

  showLockMessage() {
    const lock = this.getLock();
    if (!lock.active) return;
    const unlockAt = new Date(lock.unlockAt);
    const now = new Date();
    const remaining = Math.ceil((unlockAt - now) / 60000);
    const modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.96);z-index:99999;display:flex;align-items:center;justify-content:center;padding:1.5rem';
    modal.innerHTML =
      '<div style="max-width:360px;width:100%;text-align:center">' +
        '<img src="/logo.png" style="width:80px;height:80px;object-fit:contain;filter:drop-shadow(0 0 15px rgba(196,153,58,.5));margin-bottom:1rem"/>' +
        '<div style="font-family:Cormorant Garamond,serif;font-style:italic;color:#C4993A;font-size:1.1rem;margin-bottom:.8rem">Pause bien meritee</div>' +
        '<p style="font-size:.56rem;color:rgba(240,232,216,.8);line-height:1.9;margin-bottom:1.2rem">' +
          'Les outils de creation sont en pause pour encore ' + remaining + ' minutes.<br/><br/>' +
          'Rien ne sera perdu. Tout vous attend.<br/>' +
          'Votre sante est votre bien le plus precieux.' +
        '</p>' +
        '<button onclick="this.parentElement.parentElement.remove()" style="padding:.7rem 2rem;background:transparent;border:1px solid rgba(196,153,58,.4);color:rgba(196,153,58,.7);font-family:Josefin Sans,sans-serif;font-size:.5rem;cursor:pointer">Compris</button>' +
      '</div>';
    document.body.appendChild(modal);
  }

};

window.BURNOUT = BURNOUT;
