// ═══════════════════════════════════════════════════
//  ANALYSE NICHE & TENDANCES — Or Eille AI v1.0
//  Recherche web — tendances — angles uniques
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const COMPETITOR = {
  KEY: 'moe_competitor',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { analyses: [] }; }
    catch { return { analyses: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async analyze(niche, myProfile, myStrengths, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant', 'Cle API requise.'); return; }
    if (!niche) { if (window.addChatMsg) addChatMsg('assistant', 'Decrivez votre niche.'); return; }
    if (window.addChatMsg) addChatMsg('assistant', 'Recherche des tendances dans la niche "' + niche + '" et de vos angles de differenciation...');

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 1500,
          tools: [{ type: 'web_search_20250305', name: 'web_search' }],
          messages: [{
            role: 'user',
            content: 'Fais une recherche sur les tendances actuelles de la niche "' + niche + '" sur les reseaux sociaux francophones.\n\nProfil du createur : ' + (myProfile || 'creatrice francophone') + '\nForces : ' + (myStrengths || 'authenticite, diversite culturelle') + '\n\nApres ta recherche, donne :\n1. Les tendances actuelles dans cette niche\n2. Ce qui manque — les angles non explores\n3. Comment CE createur peut se differencier avec SON profil unique — pas de copie, une transformation\n4. 3 idees de contenu originales que personne ne fait encore\n\nSois concret et inspire.'
          }]
        })
      });
      const data = await r.json();
      const result = data.content.map(function(c) { return c.text || ''; }).filter(Boolean).join('\n');
      const d = this.get();
      d.analyses.unshift({ niche, myProfile, result, at: new Date().toISOString() });
      d.analyses = d.analyses.slice(0, 20);
      this.save(d);
      if (window.addChatMsg) addChatMsg('assistant', result);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant', 'Erreur. Verifiez votre connexion.'); }
  },

  renderPanel: function() {
    const d = this.get();
    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🔭 Analyse de ma niche</div>' +
      '<p class="note">Or Eille AI recherche les tendances publiques de votre niche. Il analyse et propose vos angles de differenciation uniques. Pas de copie — votre angle a vous.</p>' +
      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem;position:relative;overflow:hidden">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none"><div style="font-size:8rem;opacity:.04;color:#C4993A;transform:rotate(-15deg)">👂</div></div>' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8;position:relative;z-index:1">Recherche sur les tendances publiques de votre niche. Ce qui cartonne, ce qui manque, ce qui emerge. Et surtout — comment VOUS, avec votre profil unique, vous pouvez faire quelque chose que personne ne fait encore.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;margin-top:.4rem;font-style:italic;position:relative;z-index:1">— Madame Or Eille Studios</p>' +
      '</div>' +
      '<input type="text" id="comp-niche" placeholder="Votre niche — ex: beaute naturelle afro, cuisine africaine, developpement personnel..."/>' +
      '<input type="text" id="comp-profile" placeholder="Votre profil — ex: femme afro-caribéenne, homme senegalais a Paris..."/>' +
      '<input type="text" id="comp-strengths" placeholder="Vos forces — ex: authenticite, humour, expertise, culture mixte..."/>' +
      '<button class="btn btn-gold" onclick="COMPETITOR.analyze(document.getElementById(\'comp-niche\').value,document.getElementById(\'comp-profile\').value,document.getElementById(\'comp-strengths\').value,window.CFG&&window.CFG.CLAUDE_KEY)">🔭 Analyser ma niche et trouver mes angles</button>' +
      '<p style="font-size:.46rem;color:var(--muted);line-height:1.6">Analyse basee sur les tendances publiques disponibles sur le web. Acces aux donnees directes des concurrents — version future apres approbation Meta.</p>' +
      (d.analyses.length > 0 ? '<div class="sec-title">Analyses recentes</div>' + d.analyses.slice(0,3).map(function(a) { return '<div style="padding:.5rem;border:1px solid var(--border);margin-bottom:.3rem;cursor:pointer" onclick="if(window.addChatMsg)addChatMsg(\'assistant\',\'' + a.result.substring(0,200).replace(/'/g,"") + '...\')">' + a.niche + ' — ' + new Date(a.at).toLocaleDateString('fr-FR') + '</div>'; }).join('') : '') +
    '</div>';
  }
};

window.COMPETITOR = COMPETITOR;
