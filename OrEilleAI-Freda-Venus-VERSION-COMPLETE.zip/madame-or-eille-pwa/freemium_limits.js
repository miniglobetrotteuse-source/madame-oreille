// ═══════════════════════════════════════════════════
//  LIMITES FREEMIUM — Or Eille AI
//  Gratuit vs Payant 18€/mois
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const FREEMIUM_LIMITS = {

  KEY: 'moe_fl',

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || this._default(); }
    catch { return this._default(); }
  },

  _default() {
    return {
      plan: 'free',
      legends_today: [],
      last_driving: null,
      last_language: null,
      active_language: null,
      impressions_week: [],
      recipes_today: [],
    };
  },

  save(d) {
    try { localStorage.setItem(this.KEY, JSON.stringify(d)); } catch {}
  },

  isPaid() { return this.get().plan === 'paid'; },

  setPaid() {
    const d = this.get();
    d.plan = 'paid';
    this.save(d);
  },

  // ─── Téléprompter ─────────────────────────────
  canTeleprompter() {
    if (this.isPaid()) return { ok: true };
    return { ok: false, msg: 'Le téléprompter est disponible en version payante (18€/mois). Il vous libère les mains pour filmer seul(e).' };
  },

  // ─── Légendes ─────────────────────────────────
  canLegend() {
    if (this.isPaid()) return { ok: true };
    const d = this.get();
    const today = new Date().toDateString();
    const count = (d.legends_today || []).filter(t => t === today).length;
    if (count >= 3) return { ok: false, msg: 'Vous avez utilisé vos 3 légendes gratuites aujourd\'hui. Revenez demain ou passez à 18€/mois pour des légendes illimitées.' };
    return { ok: true, remaining: 3 - count };
  },

  logLegend() {
    const d = this.get();
    const today = new Date().toDateString();
    d.legends_today = [...(d.legends_today || []).filter(t => t === today), today];
    this.save(d);
  },

  // ─── Recettes / DIY / Astuces ─────────────────
  canRecipe() {
    if (this.isPaid()) return { ok: true };
    const d = this.get();
    const today = new Date().toDateString();
    const count = (d.recipes_today || []).filter(t => t === today).length;
    if (count >= 3) return { ok: false, msg: 'Vous avez utilisé vos 3 recettes/astuces gratuites aujourd\'hui. Revenez demain ou passez à 18€/mois.' };
    return { ok: true, remaining: 3 - count };
  },

  logRecipe() {
    const d = this.get();
    const today = new Date().toDateString();
    d.recipes_today = [...(d.recipes_today || []).filter(t => t === today), today];
    this.save(d);
  },

  // ─── Impression ───────────────────────────────
  canPrint() {
    if (this.isPaid()) return { ok: true, langues: null }; // illimité, toutes langues
    const d = this.get();
    const weekStart = this._weekStart();
    const count = (d.impressions_week || []).filter(t => t >= weekStart).length;
    if (count >= 2) return { ok: false, msg: 'Vous avez utilisé vos 2 impressions gratuites cette semaine. Revenez lundi ou passez à 18€/mois pour des impressions illimitées en toutes langues.' };
    return { ok: true, remaining: 2 - count, langues: 1 };
  },

  logPrint() {
    const d = this.get();
    const now = Date.now();
    d.impressions_week = [...(d.impressions_week || []).filter(t => t >= this._weekStart()), now];
    this.save(d);
  },

  _weekStart() {
    const now = new Date();
    const day = now.getDay();
    const diff = now.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(now.setDate(diff)).setHours(0,0,0,0);
  },

  // ─── Code de la route ─────────────────────────
  canDriving() {
    if (this.isPaid()) return { ok: true };
    const d = this.get();
    if (!d.last_driving) return { ok: true };
    const daysSince = (Date.now() - new Date(d.last_driving).getTime()) / (1000 * 3600 * 24);
    if (daysSince < 2) {
      const hoursLeft = Math.ceil((2 * 24) - daysSince * 24);
      return { ok: false, msg: `Prochain examen disponible dans ${hoursLeft}h. Passez à 18€/mois pour un accès illimité.` };
    }
    return { ok: true };
  },

  logDriving() {
    const d = this.get();
    d.last_driving = new Date().toISOString();
    this.save(d);
  },

  // ─── Cours de langue ──────────────────────────
  canLanguage(langue) {
    if (this.isPaid()) return { ok: true };
    const d = this.get();

    // Une seule langue à la fois
    if (d.active_language && d.active_language !== langue) {
      return { ok: false, msg: `En version gratuite, vous apprenez une seule langue à la fois. Vous apprenez actuellement : ${d.active_language}. Passez à 18€/mois pour toutes les langues simultanément.` };
    }

    // Un cours tous les 2 jours
    if (d.last_language) {
      const daysSince = (Date.now() - new Date(d.last_language).getTime()) / (1000 * 3600 * 24);
      if (daysSince < 2) {
        const hoursLeft = Math.ceil((2 * 24) - daysSince * 24);
        return { ok: false, msg: `Prochain cours disponible dans ${hoursLeft}h. Passez à 18€/mois pour des cours illimités.` };
      }
    }

    return { ok: true };
  },

  logLanguage(langue) {
    const d = this.get();
    d.active_language = langue;
    d.last_language = new Date().toISOString();
    this.save(d);
  },

  // ─── Bloquer avec message payant ──────────────
  showPaywall(msg) {
    const modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:99999;display:flex;align-items:center;justify-content:center;padding:1.5rem';
    modal.innerHTML = `
      <div style="max-width:340px;width:100%;background:#1A1610;border:1px solid var(--gold);padding:1.5rem;text-align:center">
        <div style="font-size:1.5rem;margin-bottom:.8rem">⭐</div>
        <div style="font-size:.7rem;color:var(--gold);margin-bottom:.6rem;font-family:'Cormorant Garamond',serif;font-style:italic">Version payante</div>
        <p style="font-size:.58rem;color:var(--text);line-height:1.7;margin-bottom:1rem">${msg}</p>
        <button onclick="FREEMIUM.goToPay()" 
          style="width:100%;padding:.7rem;background:var(--gold);color:var(--dark);border:none;font-family:inherit;font-size:.62rem;font-weight:700;cursor:pointer;margin-bottom:.4rem">
          Passer à 18€/mois
        </button>
        <button onclick="this.closest('div').closest('div').remove()"
          style="width:100%;padding:.5rem;background:transparent;color:var(--muted);border:1px solid var(--border);font-family:inherit;font-size:.55rem;cursor:pointer">
          Continuer en gratuit
        </button>
      </div>`;
    document.body.appendChild(modal);
  },
};

window.FREEMIUM_LIMITS = FREEMIUM_LIMITS;
