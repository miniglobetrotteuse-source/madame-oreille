// ============================================================
// NDEKO 🇨🇬🇨🇩 — Or Eille AI v20
// Annuaire solidaire mondial
// "Ndeko recommande, mais ton instinct décide toujours."
// © 2026 Madame Or Eille Studios
// ============================================================

const NDEKO = {

  adresses: [

    // EUROPE — Hébergements
    { id:'hostelle-ams', nom:'Hostelle Amsterdam', type:'hébergement', sousType:'hostel women-only', ville:'Amsterdam', pays:'🇳🇱 Pays-Bas', region:'Europe', tags:['women-only','black-woman-owned','budget'], proprio:'Bianca Brasdorp', budget:'€', description:'Premier hostel women-only Black-owned d\'Amsterdam. 15 min du centre. Événements communautaires réguliers.', contact:'hostelle.com', source:'Travel Noire', verifie:true, temoignages:8 },
    { id:'hostelle-bcn', nom:'Hostelle Barcelona', type:'hébergement', sousType:'hostel women-only', ville:'Barcelona', pays:'🇪🇸 Espagne', region:'Europe', tags:['women-only','black-woman-owned','budget'], proprio:'Bianca Brasdorp', budget:'€', description:'Women-only. Soirées sangria et peinture, ambiance sœurs du monde.', contact:'hostelle.com', source:'Hostelworld', verifie:true, temoignages:6 },
    { id:'hostelle-lon', nom:'Hostelle London', type:'hébergement', sousType:'hostel women-only', ville:'Londres', pays:'🇬🇧 Royaume-Uni', region:'Europe', tags:['women-only','black-woman-owned','budget'], proprio:'Bianca Brasdorp', budget:'€€', description:'Women-only dans Londres. High tea entre voyageuses, bibliothèque, outils coiffure.', contact:'hostelle.com', source:'Hostelworld', verifie:true, temoignages:7 },
    { id:'woh-prague', nom:'WOH! Women\'s Only Hostel', type:'hébergement', sousType:'hostel women-only', ville:'Prague', pays:'🇨🇿 République Tchèque', region:'Europe', tags:['women-only','budget','communauté'], proprio:'Équipe féminine', budget:'€', description:'Centre ville. Pancakes gratuits, soirées films, cuisine commune. Ambiance sœurs du monde.', contact:'wohprague.cz', source:'WOH Prague', verifie:true, temoignages:9 },
    { id:'josephines-zurich', nom:'Josephine\'s Guesthouse', type:'hébergement', sousType:'guesthouse women-only', ville:'Zurich', pays:'🇨🇭 Suisse', region:'Europe', tags:['women-only','budget-pour-zurich','LGBTQ-friendly'], proprio:'5 femmes fondatrices, structure non-profit', budget:'€€', description:'Seul hôtel women-only de Zurich. Fondé par 5 femmes en 1998. Non-profit. LGBTQ+ friendly.', contact:'josephines-guesthouse.ch', source:'Alex Getting Lost', verifie:true, temoignages:6 },
    { id:'hostella-rome', nom:'Hostella Female Only', type:'hébergement', sousType:'guesthouse women-only', ville:'Rome', pays:'🇮🇹 Italie', region:'Europe', tags:['women-only','budget'], proprio:'Équipe féminine', budget:'€', description:'Immeuble 19e siècle près de Termini. Terrasse, cuisine commune, petit-déjeuner.', contact:'Chercher Hostella Female Only Rome', source:'TripAdvisor', verifie:true, temoignages:5 },
    { id:'guesthouse-kreuzberg', nom:'Guesthouse Kreuzberg', type:'hébergement', sousType:'guesthouse women-only', ville:'Berlin', pays:'🇩🇪 Allemagne', region:'Europe', tags:['women-only','quartier-vivant'], proprio:'Femme locale', budget:'€€', description:'Women-only à Kreuzberg, quartier le plus vivant de Berlin.', contact:'HerTripGuide.com', source:'HerTripGuide 2026', verifie:true, temoignages:5 },
    { id:'kumho-seoul', nom:'Kumho Ryokan', type:'hébergement', sousType:'guesthouse women-only', ville:'Seoul', pays:'🇰🇷 Corée du Sud', region:'Asie', tags:['women-only','safe','solo-femme'], proprio:'Direction féminine', budget:'€€', description:'Ouvert 2025. Strictement women-only. Style ryokan, ambiance zen. 3 min de Geumho Station.', contact:'Chercher Kumho Ryokan Seoul Dongdaemun', source:'Trip.com', verifie:true, temoignages:5 },

    // EUROPE — Restos
    { id:'chishuru-london', nom:'Chishuru', type:'restaurant', sousType:'restaurant gastronomique', ville:'Londres', pays:'🇬🇧 Royaume-Uni', region:'Europe', tags:['black-woman-owned','etoile-michelin','west-african'], proprio:'Chef Adejoké Bakare', budget:'€€€', description:'Première femme noire étoilée Michelin au Royaume-Uni (2024). Cuisine West African. Meilleur restaurant Time Out Londres 2022.', contact:'chishuru.com', source:'Wikipedia/Michelin', verifie:true, temoignages:10 },
    { id:'waly-fay-paris', nom:'Waly-Fay', type:'restaurant', sousType:'restaurant africain', ville:'Paris', pays:'🇫🇷 France', region:'Europe', tags:['black-owned','cuisine-africaine'], proprio:'Olivier Thimothée', budget:'€€', description:'"Là où mangent les vrais Parisiens." Réservation obligatoire — toujours plein.', contact:'Chercher Waly-Fay Paris', source:'Paris Zigzag', verifie:true, temoignages:8 },
    { id:'diasporas-paris', nom:'Diasporâs', type:'restaurant', sousType:'restaurant + espace culturel', ville:'Paris 2e', pays:'🇫🇷 France', region:'Europe', tags:['black-owned','panafricain','coiffure','librairie'], proprio:'Collectif', budget:'€€', description:'Restaurant + café + librairie + salon de coiffure. Cuisine africaine et afro-descendante. Espace panafricain unique à Paris.', contact:'diasporas-diasporas.com', source:'Mapstr', verifie:true, temoignages:6 },
    { id:'libala-lyon', nom:'Libala', type:'restaurant', sousType:'restaurant africain', ville:'Lyon', pays:'🇫🇷 France', region:'Europe', tags:['black-owned','institution','lingala'], proprio:'Propriétaire congolais', budget:'€€', description:'"Libala" = mariage en lingala 🇨🇬🇨🇩. Institution depuis plus de 20 ans à Lyon.', contact:'Chercher Libala Lyon', source:'Petit Futé', verifie:true, temoignages:8 },
    { id:'madinina-berlin', nom:'Madinina Délice Créole', type:'restaurant', sousType:'restaurant caribéen', ville:'Berlin', pays:'🇩🇪 Allemagne', region:'Europe', tags:['black-owned','caribéen','martinique'], proprio:'Eric Milia (Martinique)', budget:'€€', description:'20 ans à Berlin. Une des rares adresses caribéennes authentiques d\'Allemagne.', contact:'Chercher Madinina Berlin', source:'Travel Noire', verifie:true, temoignages:6 },
    { id:'african-kitchen-ams', nom:'African Kitchen', type:'restaurant', sousType:'restaurant west african', ville:'Amsterdam', pays:'🇳🇱 Pays-Bas', region:'Europe', tags:['black-owned','west-african','soirées-vendredi'], proprio:'Elda Thorisson-Faurelien', budget:'€', description:'Depuis 2004. Soupe west africaine, poisson grillé, jollof rice. Soirées le vendredi. "Je veux que tout le monde se sente chez soi."', contact:'Chercher African Kitchen Amsterdam Zuidoost', source:'Travel Noire', verifie:true, temoignages:8 },
    { id:'lalibela-vienne', nom:'Lalibela', type:'restaurant', sousType:'restaurant éthiopien', ville:'Vienne', pays:'🇦🇹 Autriche', region:'Europe', tags:['black-owned','éthiopien','familial'], proprio:'Famille éthiopienne', budget:'€€', description:'Restaurant familial éthiopien Vienne 18e. "Les gens les plus accueillants qu\'on ait rencontrés à Vienne."', contact:'Chercher Lalibela Wien 18', source:'Vienna Würstelstand', verifie:true, temoignages:7 },
    { id:'cafe-haiti-reykjavik', nom:'Café Haïti', type:'restaurant', sousType:'café haïtien', ville:'Reykjavik', pays:'🇮🇸 Islande', region:'Europe', tags:['black-woman-owned','haïtien','unique'], proprio:'Elda Thorisson-Faurelien', budget:'€', description:'Probablement la seule adresse haïtienne d\'Islande. Café traditionnel haïtien, desserts, petits plats.', contact:'Chercher Café Haïti Reykjavik', source:'Travel Noire', verifie:true, temoignages:6 },
    { id:'salone-berlin', nom:'Salone Market', type:'restaurant', sousType:'épicerie + cuisine africaine', ville:'Berlin Wedding', pays:'🇩🇪 Allemagne', region:'Europe', tags:['black-owned','west-african','abordable'], proprio:'Propriétaire africain', budget:'€', description:'Épicerie africaine + plats chauds. Riz sauce arachide, poisson plantain dès 6€.', contact:'Chercher Salone Market Berlin Wedding', source:'Trippin', verifie:true, temoignages:5 },
    { id:'rouge-nimes', nom:'Restaurant Rouge', type:'restaurant', sousType:'restaurant gastronomique', ville:'Nîmes', pays:'🇫🇷 France', region:'Europe', tags:['black-woman-owned','etoile-michelin','béninoise'], proprio:'Chef Georgiana Viou (Bénin)', budget:'€€€', description:'Première femme africaine étoilée Michelin au monde (2023). Née à Cotonou, autodidacte. Cuisine méditerranéenne avec touches béninoises. Également carte de la brasserie L\'Ami au Sofitel Cotonou.', contact:'georgianaviou.com', source:'Forbes Afrique/Michelin', verifie:true, temoignages:10 },
    { id:'dakar-madrid', nom:'Dakar Restaurant', type:'restaurant', sousType:'restaurant sénégalais', ville:'Madrid Lavapiés', pays:'🇪🇸 Espagne', region:'Europe', tags:['black-owned','sénégalais','quartier-africain'], proprio:'Propriétaire sénégalais', budget:'€', description:'Calle Amparo 61, Lavapiés — le quartier africain de Madrid. Cuisine sénégalaise authentique.', contact:'Calle Amparo 61 Madrid Lavapiés', source:'Guía Repsol', verifie:true, temoignages:5 },

    // EUROPE — Salons
    { id:'afrosoins-paris', nom:'Afro Soins', type:'salon', sousType:'salon de coiffure afro', ville:'Paris 18e', pays:'🇫🇷 France', region:'Europe', tags:['black-woman-owned','institution','depuis-1981'], proprio:'Josie (depuis 1981)', budget:'€', description:'47 rue Championnet. Tenu par Josie depuis 1981. Institution du quartier. 44 ans d\'expertise cheveux afro.', contact:'47 rue Championnet 75018 Paris', source:'Afrosoins.org', verifie:true, temoignages:9 },
    { id:'miss-clamann-paris', nom:'Miss Clamann', type:'salon', sousType:'salon coiffure afro', ville:'Paris 18e', pays:'🇫🇷 France', region:'Europe', tags:['black-woman-owned','coupe-courte'], proprio:'Miss Clamann', budget:'€€', description:'102 av. de St-Ouen. Spécialiste coupe courte afro, pixie bouclé. Lun-Ven 10h30-19h, Sam 9h30-19h.', contact:'missclamann.com | 0189166626', source:'TikTok', verifie:true, temoignages:7 },
    { id:'le-50-aline', nom:'Le 50 by Aline', type:'salon', sousType:'salon coiffure afro', ville:'Paris 11e', pays:'🇫🇷 France', region:'Europe', tags:['black-woman-owned','abordable'], proprio:'Aline', budget:'€', description:'50 Rue Alexandre Dumas. Shampooing + soins + coiffure 45€. Coiffe depuis ses 17 ans.', contact:'50 Rue Alexandre Dumas 75011', source:'TikTok', verifie:true, temoignages:6 },
    { id:'belle-dame-barcelona', nom:'Belle Dame', type:'salon', sousType:'salon coiffure afro', ville:'Barcelona', pays:'🇪🇸 Espagne', region:'Europe', tags:['black-woman-owned','sénégalaise','20-ans'], proprio:'Mareme Sarr (Sénégal)', budget:'€', description:'Calle del Carme 85. Mareme Sarr, sénégalaise, formée aux techniques africaines. Plus de 20 ans d\'expérience.', contact:'Calle del Carme 85 Barcelona', source:'ShBarcelona', verifie:true, temoignages:8 },
    { id:'afromaricruz-madrid', nom:'Afromaricruz', type:'salon', sousType:'salon coiffure afro', ville:'Madrid', pays:'🇪🇸 Espagne', region:'Europe', tags:['black-woman-owned','depuis-1994','institution'], proprio:'Mari Cruz', budget:'€', description:'Depuis 1994. Institution de la communauté afro à Madrid. Mar-Sam 10h30-19h.', contact:'@afromaricruz Instagram', source:'Afromaricruz.com', verifie:true, temoignages:9 },
    { id:'nubians-madrid', nom:'NUBIANS', type:'salon', sousType:'salon curly + afro', ville:'Madrid Malasaña', pays:'🇪🇸 Espagne', region:'Europe', tags:['black-owned','curly','2022'], proprio:'Équipe Nubians', budget:'€€', description:'Ouvert 2022 à Malasaña. Très attendu par la communauté curly et afro hair de Madrid.', contact:'Chercher NUBIANS Malasaña Madrid', source:'Afroféminas', verifie:true, temoignages:5 },
    { id:'black-lady-bale', nom:'Black Lady Salon', type:'salon', sousType:'salon coiffure afro', ville:'Bâle', pays:'🇨🇭 Suisse', region:'Europe', tags:['black-woman-owned','depuis-1995'], proprio:'Propriétaire black', budget:'€€', description:'Depuis 1995. Clients de Suisse, France ET Allemagne. Institution en Suisse.', contact:'Chercher Black Lady Salon Basel', source:'Travel Noire', verifie:true, temoignages:8 },
    { id:'cynthia-vienne', nom:'Cynthia\'s Hair Couture', type:'salon', sousType:'salon coiffure afro', ville:'Vienne 3e', pays:'🇦🇹 Autriche', region:'Europe', tags:['black-woman-owned','dreadlocks'], proprio:'Cynthia Ngoy', budget:'€€', description:'Dreadlocks, weaves, cornrows. Coupes femmes, hommes, enfants.', contact:'Chercher Cynthia Hair Couture Vienna', source:'Vienna Würstelstand', verifie:true, temoignages:6 },
    { id:'afro-barbershop-belgrade', nom:'Afro Barbershop Belgrade', type:'salon', sousType:'barbershop afro', ville:'Belgrade', pays:'🇷🇸 Serbie', region:'Europe', tags:['black-owned','afro-caribéen','visite-domicile'], proprio:'Propriétaire afro', budget:'€', description:'Meilleur salon afro/caribéen de Belgrade. Visites à domicile possibles. 2500 dinars.', contact:'afrobarbershopbelgrade.com', source:'Facebook', verifie:true, temoignages:5 },

    // ASIE — Salons
    { id:'afrocurlys-tokyo', nom:'AfroCurly\'s Hair Salon', type:'salon', sousType:'salon natural hair', ville:'Tokyo', pays:'🇯🇵 Japon', region:'Asie', tags:['black-woman-owned','premier-japon','certified'], proprio:'Mina Wilson (Ghana)', budget:'€€', description:'Premier et seul salon certifié natural hair au Japon. Arrivée étudiante il y a 20 ans, a commencé en tressant pour payer ses études.', contact:'@afrocurlystokyo Instagram', source:'Savvy Tokyo', verifie:true, temoignages:8 },
    { id:'emmy-tokyo', nom:'Emmy Najima Afro Hair Salon', type:'salon', sousType:'salon tressage africain', ville:'Tokyo', pays:'🇯🇵 Japon', region:'Asie', tags:['woman-owned','tressage-africain','ateliers'], proprio:'Emmy Najima (Japonaise formée NYC)', budget:'€€', description:'20 ans d\'expérience en tressage africain. Ateliers pour mères d\'enfants afro-texturés. Produits introuvables ailleurs au Japon.', contact:'Chercher Emmy Najima Tokyo', source:'Savvy Tokyo', verifie:true, temoignages:7 },
    { id:'grace-braiding-seoul', nom:'Grace Hair Braiding', type:'salon', sousType:'salon tressage', ville:'Seoul Itaewon', pays:'🇰🇷 Corée du Sud', region:'Asie', tags:['african-owned','knotless','box-braids'], proprio:'Grace (Africaine)', budget:'€', description:'African-owned à Itaewon. Knotless braids, box braids, cornrows, locs, styles Fulani.', contact:'Chercher Grace Hair Braiding Itaewon', source:'10mag.com', verifie:true, temoignages:7 },
    { id:'curls-ria-seoul', nom:'Curls by Ria', type:'salon', sousType:'salon curly + afro', ville:'Seoul', pays:'🇰🇷 Corée du Sud', region:'Asie', tags:['woman-owned','premier-corée','curly'], proprio:'Ria', budget:'€€', description:'Premier salon curly hair de Corée du Sud. Pionnier dans un pays où les salons disaient "We don\'t do this hair."', contact:'Chercher Curls by Ria Seoul', source:'10mag.com', verifie:true, temoignages:6 },

    // ASIE — Restos
    { id:'soul-food-house-tokyo', nom:'Soul Food House', type:'restaurant', sousType:'restaurant soul food', ville:'Tokyo', pays:'🇯🇵 Japon', region:'Asie', tags:['black-owned','soul-food','cajun'], proprio:'LaTonya + David Whitaker', budget:'€€', description:'Fondé 2015. Cuisine sudiste et cajun à Azabu-Juban. Gumbo, catfish, Nashville hot chicken. LaTonya dirige aussi Legacy Foundation Japan.', contact:'soulfoodhouse.com | Azabujuban 2-8-10', source:'Travel Noire', verifie:true, temoignages:9 },
    { id:'calabash-tokyo', nom:'Calabash', type:'restaurant', sousType:'restaurant west african', ville:'Tokyo', pays:'🇯🇵 Japon', region:'Asie', tags:['black-owned','mali','sénégal','côte-divoire'], proprio:'Propriétaire africain', budget:'€€', description:'Ingrédients importés directement d\'Afrique. Menu par pays : Mali, Sénégal, Côte d\'Ivoire. Thiéboudienne, yassa, maafé.', contact:'calabash.co.jp | Hamamatsucho', source:'Arigato Japan', verifie:true, temoignages:8 },
    { id:'happy-home-seoul', nom:'Happy Home Restaurant', type:'restaurant', sousType:'restaurant nigérian', ville:'Seoul Itaewon', pays:'🇰🇷 Corée du Sud', region:'Asie', tags:['nigerian-owned','fufu','jollof'], proprio:'Propriétaire nigérian', budget:'€', description:'Le plus authentique de Seoul. Fufu, jollof rice, egusi soup, fried plantain.', contact:'Itaewon-ro 20-gil Seoul', source:'10mag.com', verifie:true, temoignages:9 },
    { id:'jak-restaurant-seoul', nom:'JAK Restaurant', type:'restaurant', sousType:'restaurant gambien + sénégalais', ville:'Seoul Itaewon', pays:'🇰🇷 Corée du Sud', region:'Asie', tags:['african-owned','gambien','sénégalais'], proprio:'Propriétaire africain', budget:'€', description:'Cuisine gambienne et sénégalaise. Jollof rice, chicken yassa, jus de bissap.', contact:'Chercher JAK Restaurant Itaewon Seoul', source:'10mag.com', verifie:true, temoignages:6 },

    // AFRIQUE
    { id:'jnane-tamsna', nom:'Jnane Tamsna', type:'hébergement', sousType:'hôtel boutique', ville:'Marrakech', pays:'🇲🇦 Maroc', region:'Afrique', tags:['black-woman-owned','michelin','luxe'], proprio:'Meryanne Loum-Martin (Côte d\'Ivoire/Sénégal/Antilles)', budget:'€€€', description:'Seule femme noire propriétaire d\'hôtel au Maroc. Avocate parisienne reconvertie. 8 hectares, 24 chambres, 5 piscines, jardins bio. Guide Michelin Hotels. Construit en moins d\'un an sur terrain brut en 2000.', contact:'jnanetamsna.com', source:'Essence/Michelin', verifie:true, temoignages:10 },
    { id:'ywca-nairobi', nom:'YWCA Nairobi', type:'hébergement', sousType:'résidence women-only', ville:'Nairobi', pays:'🇰🇪 Kenya', region:'Afrique', tags:['women-only','très-abordable','sûr'], proprio:'YWCA Kenya', budget:'€', description:'Hébergement women-only sûr et très abordable. Restaurant sur place.', contact:'ywcakenya.org', source:'YWCA Kenya', verifie:true, temoignages:6 },
    { id:'curiocity-joburg', nom:'Curiocity Johannesburg', type:'hébergement', sousType:'hostel', ville:'Johannesburg', pays:'🇿🇦 Afrique du Sud', region:'Afrique', tags:['black-owned','expériences-locales'], proprio:'Bheki Dube (fondé à 21 ans)', budget:'€', description:'Fondé à 21 ans. Expériences locales authentiques. Aussi à Cape Town.', contact:'curiocityhostels.com', source:'Hostelworld', verifie:true, temoignages:9 },

    // AMÉRIQUES — USA
    { id:'wanderstay-houston', nom:'Wanderstay Boutique Hotel', type:'hébergement', sousType:'hôtel boutique', ville:'Houston TX', pays:'🇺🇸 États-Unis', region:'Amérique du Nord', tags:['black-woman-owned','premier-usa','boutique'], proprio:'Deidre Mathis', budget:'€€', description:'Premier hostel Black-owned des USA (2018). Devenu hôtel boutique 10 chambres. Plus de 15 000 voyageurs de 31 pays.', contact:'wanderstayhouston.com', source:'Face2Face Africa', verifie:true, temoignages:10 },
    { id:'akwaaba-brooklyn', nom:'Akwaaba Mansion', type:'hébergement', sousType:'B&B', ville:'Brooklyn NY', pays:'🇺🇸 États-Unis', region:'Amérique du Nord', tags:['black-woman-owned','historique'], proprio:'Monique Greenwood (ex-rédactrice Essence)', budget:'€€€', description:'B&B historique à Brooklyn. Aussi à Philadelphia, Cape May, Washington DC.', contact:'akwaaba.com', source:'TripAdvisor/Essence', verifie:true, temoignages:9 },
    { id:'la-maison-houston', nom:'La Maison in Midtown', type:'hébergement', sousType:'B&B', ville:'Houston TX', pays:'🇺🇸 États-Unis', region:'Amérique du Nord', tags:['black-woman-owned','style-européen'], proprio:'Genora Boykins + Sharon Owens', budget:'€€', description:'B&B black AND women-owned. 7 chambres, style européen. Petit-déjeuner cuisiné chaque matin.', contact:'Chercher La Maison Midtown Houston', source:'Essence', verifie:true, temoignages:8 },
    { id:'magnolia-house-va', nom:'Magnolia House Inn', type:'hébergement', sousType:'B&B historique', ville:'Hampton VA', pays:'🇺🇸 États-Unis', region:'Amérique du Nord', tags:['black-owned','jim-crow-era','historique'], proprio:'Propriétaire Black', budget:'€€', description:'Sur le Registre National des Lieux Historiques. Refuge pour voyageurs noirs depuis l\'ère Jim Crow. Biscuits à la patate douce au petit-déjeuner.', contact:'Chercher Magnolia House Inn Hampton VA', source:'Black Hotel Guide', verifie:true, temoignages:7 },
    { id:'bens-chili-bowl', nom:'Ben\'s Chili Bowl', type:'restaurant', sousType:'institution soul food', ville:'Washington DC', pays:'🇺🇸 États-Unis', region:'Amérique du Nord', tags:['black-owned','institution-60-ans','hot-dogs'], proprio:'Famille Ben Ali', budget:'€', description:'Institution depuis 60 ans. Hot dogs et chili légendaires. 6 adresses DC + Virginie + Maryland. Visité par Obama.', contact:'benschilibowl.com', source:'Tasting Table', verifie:true, temoignages:12 },
    { id:'slutty-vegan', nom:'Slutty Vegan', type:'restaurant', sousType:'restaurant vegan', ville:'Atlanta GA', pays:'🇺🇸 États-Unis', region:'Amérique du Nord', tags:['black-woman-owned','vegan','11-adresses'], proprio:'Pinky Cole', budget:'€', description:'Fondé dans son appartement 2018. 11 adresses : Atlanta, Alabama, Texas, New York.', contact:'sluttyveganatl.com', source:'Tasting Table', verifie:true, temoignages:10 },
    { id:'dakar-nola', nom:'Dakar NOLA', type:'restaurant', sousType:'restaurant sénégalais', ville:'New Orleans LA', pays:'🇺🇸 États-Unis', region:'Amérique du Nord', tags:['black-owned','sénégalais','james-beard-award'], proprio:'Chef Serigne Mbaye', budget:'€€€', description:'James Beard Award Meilleur Nouveau Restaurant 2024. Le chef ouvre chaque soir en wolof : "Na nga def."', contact:'dakarnola.com', source:'James Beard Foundation', verifie:true, temoignages:9 },

    // AMÉRIQUES — Canada
    { id:'ode-toronto', nom:'Ode Toronto', type:'hébergement', sousType:'hôtel boutique', ville:'Toronto', pays:'🇨🇦 Canada', region:'Amérique du Nord', tags:['black-owned','boutique','art'], proprio:'Famille black', budget:'€€', description:'Hôtel boutique black-owned à Little Portugal. 8 chambres créées avec des artistes locaux.', contact:'Chercher Ode Toronto Hotel', source:'Destination Toronto', verifie:true, temoignages:6 },
    { id:'azans-toronto', nom:'Azan\'s Beauty Salon', type:'salon', sousType:'salon coiffure', ville:'Toronto', pays:'🇨🇦 Canada', region:'Amérique du Nord', tags:['black-owned','50-ans','célébrités'], proprio:'Famille Azan', budget:'€€', description:'Un des premiers salons Black-owned de Toronto. Plus de 50 ans. Yorkville. Clients célébrités.', contact:'Davenport Avenue Toronto Yorkville', source:'Destination Toronto', verifie:true, temoignages:8 },
    { id:'simply-irie-calgary', nom:'Simply Irie', type:'restaurant', sousType:'restaurant caribéen', ville:'Calgary', pays:'🇨🇦 Canada', region:'Amérique du Nord', tags:['black-woman-owned','jamaïcain','10-ans'], proprio:'Fay', budget:'€', description:'Plus de 10 ans. Cuisine jamaïcaine. Doubles, oxtail, snapper escovitch, curry tofu. Reggae, ambiance chaleureuse.', contact:'Chercher Simply Irie Calgary', source:'Curiocity', verifie:true, temoignages:8 },
    { id:'kwizinn-montreal', nom:'Kwizinn', type:'restaurant', sousType:'restaurant caribéen', ville:'Montréal', pays:'🇨🇦 Canada', region:'Amérique du Nord', tags:['black-owned','caribéen'], proprio:'Propriétaire black', budget:'€€', description:'Fusion caribéenne à Montréal. Institution de la communauté black.', contact:'Chercher Kwizinn Montreal', source:'datenight.com', verifie:true, temoignages:6 },

    // AMÉRIQUES — Brésil
    { id:'ackee-pousada', nom:'Ackee Pousada', type:'hébergement', sousType:'pousada', ville:'São Paulo', pays:'🇧🇷 Brésil', region:'Amérique Latine', tags:['black-woman-owned','afro-brésilien','art'], proprio:'Carol Damiá', budget:'€', description:'Un des rares hébergements Black woman-owned au Brésil. Chaque chambre est une œuvre d\'art.', contact:'Chercher Ackee Pousada São Paulo', source:'Travel Noire', verifie:true, temoignages:7 },
    { id:'nega-maluca', nom:'Nega Maluca Guesthouse', type:'hébergement', sousType:'guesthouse familiale', ville:'Salvador de Bahia', pays:'🇧🇷 Brésil', region:'Amérique Latine', tags:['black-owned','familial','communauté'], proprio:'Propriétaire black baiana', budget:'€', description:'"Nega Maluca" = la folle noire. Ce n\'est pas une guesthouse — c\'est une maison de famille. "Il n\'y a pas de clients ici, on est tous en famille."', contact:'Chercher Nega Maluca Guesthouse Salvador', source:'Hostelworld', verifie:true, temoignages:8 },
    { id:'centro-bispo', nom:'Centro Cultural Do Bispo', type:'hébergement', sousType:'guesthouse culturelle', ville:'Salvador de Bahia', pays:'🇧🇷 Brésil', region:'Amérique Latine', tags:['women-owned','candomblé','unique'], proprio:'Mãe Santo Denise de Oliveira', budget:'€', description:'On dort chez une prêtresse du Candomblé. Elle partage les secrets du Candomblé ou lit l\'avenir. Cuisine vegan baiana. Unique au monde.', contact:'Chercher Centro Cultural Bispo Salvador', source:'Hostelz', verifie:true, temoignages:6 },
    { id:'odara-salvador', nom:'Odara Hostel', type:'hébergement', sousType:'hostel culturel', ville:'Salvador de Bahia', pays:'🇧🇷 Brésil', region:'Amérique Latine', tags:['black-owned','culture-bahianaise','ateliers'], proprio:'Équipe locale', budget:'€', description:'"Odara" = belle en yoruba. Culture bahianaise, cours de cuisine, ateliers culturels. Accès direct Pelourinho.', contact:'Chercher Odara Hostel Salvador', source:'Hostelz', verifie:true, temoignages:7 },

    // AMÉRIQUES — Pérou
    { id:'rincon-lima', nom:'El Rincón Que No Conoces', type:'restaurant', sousType:'restaurant afro-péruvien', ville:'Lima', pays:'🇵🇪 Pérou', region:'Amérique Latine', tags:['black-woman-owned','institution-1978'], proprio:'Fondé par Doña Teresa Izquierdo (1978)', budget:'€', description:'Institution depuis 1978. Cuisine afro-péruvienne authentique. Toujours plein — arriver tôt ou réserver.', contact:'Chercher El Rincon Que No Conoces Lima', source:'Travel Noire', verifie:true, temoignages:10 },
    { id:'mamaïne-chincha', nom:'Mamainé Restaurant', type:'restaurant', sousType:'restaurant afro-péruvien', ville:'El Carmen, Chincha', pays:'🇵🇪 Pérou', region:'Amérique Latine', tags:['black-woman-owned','reine-cuisine','musique-danse'], proprio:'Mamainé', budget:'€', description:'"La Reine de la cuisine afro-péruvienne." Danse, musique, carapulcra con sopa seca. Recettes transmises depuis l\'esclavage.', contact:'Chercher Mamaïné Restaurant El Carmen Chincha', source:'An American in Lima', verifie:true, temoignages:9 },
    { id:'prieta-peru', nom:'Prieta Perú', type:'salon', sousType:'salon coiffure afro', ville:'Lima', pays:'🇵🇪 Pérou', region:'Amérique Latine', tags:['black-owned','afro','boucles'], proprio:'Équipe Prieta Perú', budget:'€', description:'Salon afro à Lima. Spécialiste boucles et afros. Un des rares salons afro du Pérou.', contact:'@prietaperu Instagram', source:'Travel Noire', verifie:true, temoignages:5 },

    // CARAÏBES — Cuba
    { id:'casa-sanchana', nom:'Casa Sanchana', type:'hébergement', sousType:'casa particular', ville:'La Havane', pays:'🇨🇺 Cuba', region:'Caraïbes', tags:['black-woman-owned','colonial','vedado'], proprio:'Doña Alvara', budget:'€', description:'Maison coloniale magnifique à Vedado. 3 chambres spacieuses. Recommandée depuis des années.', contact:'Chercher Casa Sanchana Vedado Havana', source:'Cuba Educational Travel', verifie:true, temoignages:7 },
    { id:'corpus-habana', nom:'Corpus Habana', type:'salon', sousType:'spa + bien-être', ville:'La Havane', pays:'🇨🇺 Cuba', region:'Caraïbes', tags:['women-owned','spa','médecine'], proprio:'Dr. Suney Peña Corrales + équipe féminine', budget:'€', description:'Spa fondé par une médecin + maître reiki. Équipe entièrement féminine. "Jeunes rêveuses et combattantes."', contact:'Chercher Corpus Habana Vedado', source:'Cuba Educational Travel', verifie:true, temoignages:6 },

    // ASIE — Hébergements
    { id:'hotel-sages-bali', nom:'Hotel Sages Bali', type:'hébergement', sousType:'hôtel boutique', ville:'Canggu Bali', pays:'🇮🇩 Indonésie', region:'Asie', tags:['black-owned','retraite-artistique'], proprio:'Propriétaire Black', budget:'€€€', description:'Né pendant la pandémie. Un des hébergements les plus recherchés de Canggu. Arches, cours intérieures, mindfulness.', contact:'Chercher Hotel Sages Canggu Bali', source:'Travel Noire', verifie:true, temoignages:8 },
    { id:'africa-guesthouse-seoul', nom:'Africa Guesthouse', type:'hébergement', sousType:'guesthouse', ville:'Seoul', pays:'🇰🇷 Corée du Sud', region:'Asie', tags:['african-owned','communauté'], proprio:'Propriétaire africain', budget:'€', description:'Guesthouse africaine à Seoul. Ambiance communauté diaspora.', contact:'Chercher Africa Guesthouse Seoul', source:'Traveloka', verifie:false, temoignages:3 },

    // ASIE — Restos supplémentaires Tokyo
    { id:'queen-sheba-tokyo', nom:'Queen Sheba', type:'restaurant', sousType:'restaurant éthiopien', ville:'Tokyo Nakameguro', pays:'🇯🇵 Japon', region:'Asie', tags:['black-owned','éthiopien','musique-live'], proprio:'Propriétaire éthiopien', budget:'€€', description:'Cuisine éthiopienne avec ingrédients importés d\'Afrique. Musique africaine et traditionnelle live. Ouvert 7j/7 soir.', contact:'queensheba.info | Higashiyama Meguro-ku Tokyo', source:'Arigato Japan', verifie:true, temoignages:7 },
    { id:'kyles-tokyo', nom:'Kyle\'s Good Finds', type:'restaurant', sousType:'boulangerie américaine', ville:'Tokyo Nakano', pays:'🇯🇵 Japon', region:'Asie', tags:['black-owned','boulangerie','nostalgie'], proprio:'Kyle Sexton (York PA, 35 ans au Japon)', budget:'€', description:'Boulangerie black-owned à Tokyo. Produits américains faits maison. "Chaque bouchée te transporte en Amérique."', contact:'Chercher Kyle\'s Good Finds Tokyo Nakano', source:'Arigato Japan', verifie:true, temoignages:6 },

    // ASIE — Restos Seoul supplémentaires
    { id:'braai-republic-seoul', nom:'Braai Republic', type:'restaurant', sousType:'restaurant sud-africain', ville:'Seoul Itaewon', pays:'🇰🇷 Corée du Sud', region:'Asie', tags:['south-african','boerewors','lamb'], proprio:'Propriétaire sud-africain', budget:'€€', description:'Cuisine sud-africaine authentique. Boerewors, lamb chops, meat pies maison. Vins sud-africains exclusivement.', contact:'Chercher Braai Republic Itaewon Seoul', source:'TripAdvisor', verifie:true, temoignages:7 },
    { id:'maison-de-fae', nom:'Maison de Fae', type:'restaurant', sousType:'restaurant west african', ville:'Pyeongtaek', pays:'🇰🇷 Corée du Sud', region:'Asie', tags:['african-owned','west-african','brunch'], proprio:'Propriétaire africain', budget:'€', description:'Brunch West African. Fufu, egusi, jollof rice, omelettes. Près de Camp Humphreys.', contact:'Chercher Maison de Fae Pyeongtaek Korea', source:'ppalippaliexpress.com', verifie:true, temoignages:5 },

    // ASIE — Salons supplémentaires Seoul
    { id:'grace-hair-seoul', nom:'Grace Hair Braiding', type:'salon', sousType:'salon tresses africaines', ville:'Seoul Itaewon', pays:'🇰🇷 Corée du Sud', region:'Asie', tags:['african-owned','tresses','knotless'], proprio:'Propriétaire africaine', budget:'€€', description:'Salon African-owned à Itaewon. Knotless braids, box braids, cornrows, locs, styles Fulani. Recommandé par toute la communauté.', contact:'Itaewon-ro 14-gil Yongsan-gu Seoul', source:'10mag.com', verifie:true, temoignages:9 },
    { id:'curls-by-ria-seoul', nom:'Curls by Ria', type:'salon', sousType:'salon cheveux bouclés et afro', ville:'Seoul', pays:'🇰🇷 Corée du Sud', region:'Asie', tags:['first-curly-salon-korea','afro','bouclés'], proprio:'Ria', budget:'€€', description:'PREMIER salon curly hair de toute la Corée du Sud. Spécialiste afro hair. Pionière.', contact:'Chercher Curls by Ria Seoul', source:'TikTok/10mag', verifie:true, temoignages:8 },
    { id:'yana-delho-seoul', nom:'Yana Delho Beauty', type:'salon', sousType:'salon afro + conseil beauté', ville:'Seoul', pays:'🇰🇷 Corée du Sud', region:'Asie', tags:['congolaise','french-diaspora','natural-hair'], proprio:'Yana Delho (Congo 🇨🇬, Paris → Seoul)', budget:'€€', description:'Entrepreneuse française d\'origine congolaise installée à Seoul. Beauté afro, soins naturels. A conduit une étude de marché avec la Chambre franco-coréenne pour la communauté black de Seoul.', contact:'Chercher Yana Delho Beauty Seoul', source:'Korea Times 2026', verifie:true, temoignages:5 },

    // ASIE — Salons Tokyo supplémentaires
    { id:'emmy-najima-tokyo', nom:'Emmy Najima Afro Hair Salon', type:'salon', sousType:'salon afro + ateliers', ville:'Tokyo', pays:'🇯🇵 Japon', region:'Asie', tags:['japanaise','african-braiding','ateliers'], proprio:'Emmy Najima (Japonaise, 20 ans d\'expérience)', budget:'€€', description:'Japonaise formée à New York. 20 ans d\'expérience en tressage africain. Ateliers pour mères d\'enfants afro-texturés. Produits black hair introuvables ailleurs au Japon. Barbies noires en vitrine.', contact:'Chercher Emmy Najima Tokyo Afro Hair', source:'Savvy Tokyo', verifie:true, temoignages:8 },

    // EUROPE — Salons et restos supplémentaires
    { id:'salone-market-berlin', nom:'Salone Market', type:'restaurant', sousType:'épicerie + cantine africaine', ville:'Berlin Wedding', pays:'🇩🇪 Allemagne', region:'Europe', tags:['black-owned','west-african','très-abordable'], proprio:'Propriétaire africaine', budget:'€', description:'Point de rencontre multiculturel à Berlin Wedding. Cuisine africaine + épicerie tropicale. Riz sauce arachide, poisson, plantain. Menus dès 6€.', contact:'Chercher Salone Market Berlin Wedding', source:'Trippin World', verifie:true, temoignages:7 },
    { id:'west-african-neukolln', nom:'West African Kitchen', type:'restaurant', sousType:'restaurant west african', ville:'Berlin Neukölln', pays:'🇩🇪 Allemagne', region:'Europe', tags:['black-owned','west-african','vegan-options'], proprio:'Propriétaire africain', budget:'€', description:'Tilapia, jollof rice, igname frite, banku avec soupe de cacahuète. Options vegan. Neukölln, quartier le plus cosmopolite de Berlin.', contact:'Chercher West African Kitchen Berlin Neukölln', source:'Trippin World', verifie:true, temoignages:6 },
    { id:'barbara-holmes-munich', nom:'Haarkunst', type:'salon', sousType:'salon coiffure afro', ville:'Munich', pays:'🇩🇪 Allemagne', region:'Europe', tags:['black-owned','afro','munich'], proprio:'Barbara Holmes', budget:'€€', description:'Salon black-owned à Munich. Spécialiste cheveux afro dans une ville où la communauté noire est peu visible.', contact:'Chercher Barbara Holmes Haarkunst Munich', source:'UGA Journalism', verifie:true, temoignages:5 },
    { id:'queen-idia-zurich', nom:'Queen Idia African Restaurant', type:'restaurant', sousType:'restaurant nigérian', ville:'Zurich', pays:'🇨🇭 Suisse', region:'Europe', tags:['black-owned','nigérian','west-african'], proprio:'Michael Anukege + sa mère', budget:'€€', description:'Fondé par Michael et sa mère en 2015. Cuisine nigériane et West African. Institution de la diaspora africaine à Zurich.', contact:'Chercher Queen Idia Restaurant Zurich', source:'Travel Noire', verifie:true, temoignages:7 },
    { id:'suya-zurich', nom:'SUYA', type:'restaurant', sousType:'restaurant kényan', ville:'Zurich', pays:'🇨🇭 Suisse', region:'Europe', tags:['african-owned','kényan','authentique'], proprio:'Propriétaire kényan', budget:'€€', description:'Cuisine kényane authentique à Zurich. "Avec beaucoup de dédication."', contact:'Chercher SUYA Restaurant Zurich', source:'curlish.ch', verifie:true, temoignages:5 },
    { id:'cantinho-aziz-lisbon', nom:'Cantinho do Aziz', type:'restaurant', sousType:'restaurant mozambicain', ville:'Lisbonne Mouraria', pays:'🇵🇹 Portugal', region:'Europe', tags:['black-owned','mozambicain','historique'], proprio:'Aziz (Mozambique)', budget:'€€', description:'Cuisine mozambicaine dans le quartier historique Mouraria. Agneau, riz coco, fruits de mer, banane frite. Piri Piri Bakra — spécialité maison.', contact:'Chercher Cantinho Aziz Lisbon Mouraria', source:'Travel Noire', verifie:true, temoignages:8 },
    { id:'nubians-madrid', nom:'NUBIANS', type:'salon', sousType:'salon curly + afro', ville:'Madrid Malasaña', pays:'🇪🇸 Espagne', region:'Europe', tags:['black-owned','curly','madrid','très-attendu'], proprio:'Propriétaire black', budget:'€€', description:'Très attendu par toute la communauté curly et afro de Madrid. Ouvert 2022, en plein cœur de Malasaña.', contact:'@nubiansmadrid Instagram', source:'Afroféminas', verifie:true, temoignages:7 },
    { id:'samvina-barcelona', nom:'Samvina', type:'salon', sousType:'salon afro', ville:'Barcelona Sant Antoni', pays:'🇪🇸 Espagne', region:'Europe', tags:['first-afro-salon-cataluña','extensions','cornrows'], proprio:'Propriétaire africaine', budget:'€€', description:'PREMIÈRE peluquería afro de Catalogne. Extensions Cornrow, tresses multiples, Curly, rastras. Calle Viladomat 1.', contact:'Calle Viladomat 1 Barcelona', source:'ShBarcelona', verifie:true, temoignages:7 },
    { id:'mel-y-trenzas', nom:'Mel y Trenzas', type:'salon', sousType:'salon tresses', ville:'Barcelona', pays:'🇪🇸 Espagne', region:'Europe', tags:['african-family','tresses','crochet'], proprio:'Famille africaine', budget:'€€', description:'Entreprise familiale africaine. 20 ans d\'expérience. Spécialité tresses crochet. Plus de 11 000 abonnés Instagram.', contact:'Chercher Mel y Trenzas Barcelona', source:'Time Out Barcelona', verifie:true, temoignages:8 },
    { id:'la-senegalesa-madrid', nom:'La Senegalesa Afro Peluquería', type:'salon', sousType:'salon afro sénégalais', ville:'Madrid', pays:'🇪🇸 Espagne', region:'Europe', tags:['sénégalaise','afro','madrid'], proprio:'Propriétaire sénégalaise', budget:'€', description:'Salon afro sénégalais à Madrid. Quartier Cdad. Lineal.', contact:'Calle del Lago Constanza 1 Madrid', source:'Fresha', verifie:true, temoignages:5 },
    { id:'dakar-lavapiés', nom:'Dakar Restaurant', type:'restaurant', sousType:'restaurant sénégalais', ville:'Madrid Lavapiés', pays:'🇪🇸 Espagne', region:'Europe', tags:['sénégalais','communauté-africaine','lavapiés'], proprio:'Propriétaire sénégalais', budget:'€', description:'Cœur du quartier africain de Madrid. Cuisine sénégalaise authentique. Tout Lavapiés est un hub africain : restaurants, salons, mode.', contact:'Calle Amparo 61 Madrid Lavapiés', source:'Guía Repsol', verifie:true, temoignages:6 },

    // AMÉRIQUE LATINE — Colombie
    { id:'palenque-medellin', nom:'Restaurant Palenque', type:'restaurant', sousType:'restaurant afro-colombien', ville:'Medellín', pays:'🇨🇴 Colombie', region:'Amérique Latine', tags:['afro-colombien','pacifique','recettes-ancestrales'], proprio:'Propriétaire afro-colombien', budget:'€', description:'Cuisine de la côte Pacifique colombienne. Recettes transmises depuis des générations, héritage des communautés marronnes (Palenque). Plats aux fruits de mer et saveurs du Chocó.', contact:'Chercher Restaurant Palenque Medellin afro colombiano', source:'Eileen\'s Epic 2026', verifie:false, temoignages:4 },

    // PÉROU — Hébergements
    { id:'black-llama-cusco', nom:'Black Llama Hostel', type:'hébergement', sousType:'hostel', ville:'Cusco', pays:'🇵🇪 Pérou', region:'Amérique Latine', tags:['women-dorm','primé','petit-dej-gratuit'], proprio:'Équipe locale', budget:'€', description:'Hostel primé à Cusco. Dortoir women-only, petit-déjeuner gratuit, café spécialisé, bar panoramique. Recommandé par des voyageuses noires solo.', contact:'blackllamahostels.com', source:'Black Solo Female Travel Guide Peru', verifie:true, temoignages:8 },

    // MAROC
    { id:'jnane-tamsna-maroc', nom:'Jnane Tamsna', type:'hébergement', sousType:'hôtel boutique de luxe', ville:'Marrakech Palmeraie', pays:'🇲🇦 Maroc', region:'Afrique', tags:['black-woman-owned','michelin','seule-femme-noire-maroc','luxe'], proprio:'Meryanne Loum-Martin (Côte d\'Ivoire / Sénégal / Antilles)', budget:'€€€€', description:'Seule femme noire propriétaire d\'hôtel au Maroc. Avocate parisienne reconvertie. Née en Côte d\'Ivoire, père sénégalais diplomate, mère antillaise avocate. Enfance à Abidjan, Accra, Londres, Moscou. A construit l\'hôtel elle-même, sur terrain brut, en moins d\'un an en 2000. 8 hectares, 24 chambres, 5 piscines, jardins bio, bibliothèque. Guide Michelin Hotels. Clients : Brad Pitt, Nicole Kidman, David Bowie, Giorgio Armani. Aujourd\'hui cogérée avec sa fille Thaïs.', contact:'jnanetamsna.com', source:'Essence/Michelin/Face2Face Africa', verifie:true, temoignages:12 },

    // CARAÏBES — Guadeloupe
    { id:'la-creole-guadeloupe', nom:'La Créole Beach Hotel & Spa', type:'hébergement', sousType:'hôtel resort', ville:'Gosier', pays:'🇬🇵 Guadeloupe', region:'Caraïbes', tags:['black-owned','créole','culture-locale'], proprio:'Propriétaire guadeloupéen', budget:'€€€', description:'Hôtel resort qui infuse la culture créole dans chaque détail. Restaurant Le Zawag — fruits de mer, cuisine créole locale. Atelier Gwoka, cours de cuisine créole, promenade en charrette à bœufs.', contact:'Chercher La Creole Beach Hotel Gosier Guadeloupe', source:'Travel Noire', verifie:true, temoignages:7 },

  ],

  // MÉMOIRES
  memoires: [
    {
      id:'ulcinj',
      titre:'Les "Arapë" d\'Ulcinj — La communauté africaine oubliée du Monténégro',
      pays:'🇲🇪 Monténégro',
      periode:'17e siècle — aujourd\'hui',
      resume:'Ulcinj, ville côtière du Monténégro, était au 17e siècle un marché d\'esclaves et repaire de pirates ottomans. Des Africains venus du Zanzibar, du Kenya, du Soudan, du Nigeria et de la Libye ont été capturés et amenés là. Ils sont devenus libres, ont appris l\'albanais, pratiqué l\'islam, certains sont devenus marins, capitaines, commerçants. On les appelait "Arapë" — les Arabes — à cause de leur couleur. La communauté a compté jusqu\'à 500 personnes. Puis 100. Puis 60.',
      figure:'Rizo Šurla — photographe, figure légendaire d\'Ulcinj. Son père avait été amené de Tripoli à l\'âge de 12 ans. Rizo est mort le 11 février 2003. La ville lui a fait une fresque murale à Pristan.',
      aujourd_hui:'Il reste aujourd\'hui sa sœur — dernière descendante directe de cette communauté africaine en Europe. Nous n\'avons pas encore eu l\'honneur de la rencontrer, mais nous voulions lui rendre hommage de son vivant. Quand elle partira, cette mémoire partira avec elle.',
      note:'L\'esclavage ottoman a pris fin en Europe du Sud-Est en 1945. Des communautés afro-ottomanes similaires subsistent en Turquie (Afro-Turcs, ~20 000 personnes) et en Albanie.'
    },
    {
      id:'baianas',
      titre:'Les Baianas de Acarajé — Salvador de Bahia, Brésil',
      pays:'🇧🇷 Brésil',
      periode:'19e siècle — aujourd\'hui',
      resume:'Les Baianas sont des femmes afro-brésiliennes qui vendent l\'acarajé dans les rues de Salvador depuis le 19e siècle. Robe blanche en dentelle, colliers de perles, foulard coloré. Chacune a sa recette transmise oralement depuis des générations, souvent depuis l\'époque de l\'esclavage. L\'acarajé — boulette de haricots noirs frite dans l\'huile de palme — est aussi une offrande à Iansã dans le Candomblé.',
      figure:'Ivana Muzenza — Baiana à Itapuã. Son arrière-arrière-grand-mère est arrivée à la fin de la traite négrière. Elle perpétue la tradition au quotidien. "C\'est notre signe de résistance."',
      aujourd_hui:'Salvador de Bahia est la ville avec la plus grande population afrodescendante en dehors de l\'Afrique (2,9 millions). Ces femmes se battent contre les restaurants touristiques qui reproduisent leur recette sans leur reverser rien. Le 25 novembre est la Journée Nationale de l\'Acarajé.',
      note:'La cuisine créole du Pérou — anticuchos, picarones, tamales — a également été inventée par des femmes afro-descendantes dont l\'histoire reste largement invisible.'
    }
  ],

  state:{ filtre:'tout', region:'tout', budget:'tout', recherche:'', vue:'liste' },

  init() {
    this.renderPanel();
    console.log('✅ Ndeko — '+this.adresses.length+' adresses, '+this.memoires.length+' mémoires');
  },

  renderPanel() {
    const panel=document.getElementById('panel-ndeko');
    if(!panel)return;
    panel.innerHTML=`<div class="ndeko-container">
      <div class="ndeko-header">
        <div class="ndeko-title">🤝 NDEKO 🇨🇬🇨🇩</div>
        <div class="ndeko-subtitle">Hébergements · Restos · Salons — women-owned, black-owned, alliés vérifiés.</div>
        <div class="ndeko-devise">"Ndeko recommande, mais ton instinct décide toujours."</div>
      </div>
      <div class="ndeko-nav">
        <button class="ndeko-nav-btn ${this.state.vue==='liste'?'active':''}" id="ndeko-liste">🗺️ Annuaire</button>
        <button class="ndeko-nav-btn ${this.state.vue==='memoires'?'active':''}" id="ndeko-memoires">📖 Mémoires</button>
        <button class="ndeko-nav-btn ${this.state.vue==='soumettre'?'active':''}" id="ndeko-soumettre">➕ Proposer</button>
      </div>
      <div id="ndeko-content">${this.renderVue()}</div>
    </div>`;
    this.attachEvents();
  },

  renderVue() {
    if(this.state.vue==='memoires')return this.renderMemoires();
    if(this.state.vue==='soumettre')return this.renderFormulaire();
    return this.renderListe();
  },

  renderListe() {
    const filtrees=this.filtrer();
    const regions=['tout','Europe','Afrique','Amérique du Nord','Amérique Latine','Caraïbes','Asie'];
    const types=['tout','hébergement','restaurant','salon'];
    return `<div class="ndeko-filtres">
      <input type="text" id="ndeko-search" class="ndeko-search" placeholder="🔍 Ville, pays, nom..." value="${this.state.recherche}"/>
      <div class="ndeko-filtre-groupe"><div class="ndeko-filtre-label">Type</div><div class="ndeko-tags-filtres">${types.map(t=>`<button class="ndeko-filtre-btn ${this.state.filtre===t?'active':''}" data-filtre="${t}">${t==='tout'?'🌍 Tout':t}</button>`).join('')}</div></div>
      <div class="ndeko-filtre-groupe"><div class="ndeko-filtre-label">Région</div><div class="ndeko-tags-filtres">${regions.map(r=>`<button class="ndeko-region-btn ${this.state.region===r?'active':''}" data-region="${r}">${r==='tout'?'🌍 Tout':r}</button>`).join('')}</div></div>
      <div class="ndeko-filtre-groupe"><div class="ndeko-filtre-label">Budget</div><div class="ndeko-tags-filtres">${['tout','€','€€','€€€'].map(b=>`<button class="ndeko-budget-btn ${this.state.budget===b?'active':''}" data-budget="${b}">${b==='tout'?'Tous':b}</button>`).join('')}</div></div>
    </div>
    <div class="ndeko-count">${filtrees.length} adresse${filtrees.length>1?'s':''} trouvée${filtrees.length>1?'s':''}</div>
    <div class="ndeko-avertissement">⚠️ Ces adresses sont recommandées par la communauté. Ndeko ne garantit rien. <strong>Ton instinct d\'abord.</strong></div>
    <div class="ndeko-grid">${filtrees.length>0?filtrees.map(a=>this.renderCarte(a)).join(''):'<div class="ndeko-vide">Aucune adresse. Tu en connais une ? Propose-la !</div>'}</div>`;
  },

  renderCarte(a) {
    const tc={'women-only':'#c0392b','black-woman-owned':'#8e44ad','black-owned':'#2980b9','budget':'#27ae60','etoile-michelin':'#f39c12','institution':'#d35400','communauté':'#f39c12','depuis-1981':'#d35400','depuis-1994':'#d35400','depuis-1995':'#d35400','jim-crow-era':'#7f8c8d','candomblé':'#8e44ad'};
    return `<div class="ndeko-carte">
      <div class="ndeko-carte-top"><div class="ndeko-carte-type">${a.sousType}</div><div class="ndeko-carte-budget">${a.budget}</div></div>
      <div class="ndeko-carte-nom">${a.nom}</div>
      <div class="ndeko-carte-lieu">📍 ${a.ville} — ${a.pays}</div>
      ${a.proprio?`<div class="ndeko-carte-proprio">✊ ${a.proprio}</div>`:''}
      <div class="ndeko-carte-desc">${a.description}</div>
      <div class="ndeko-carte-tags">${a.tags.slice(0,4).map(t=>`<span class="ndeko-tag" style="background:${tc[t]||'#555'}">${t.replace(/-/g,' ')}</span>`).join('')}</div>
      <div class="ndeko-carte-footer"><span>💬 ${a.temoignages} témoignage${a.temoignages>1?'s':''}</span><span>Source: ${a.source}</span></div>
      ${a.contact?`<div class="ndeko-carte-contact">🔗 ${a.contact}</div>`:''}
    </div>`;
  },

  renderMemoires() {
    return `<div class="ndeko-memoires">

      <div class="ndeko-memoires-intro">
        Ces histoires ne sont pas des adresses.<br>
        Ce sont des mémoires — de femmes, de communautés, de résistances — qui risquent de disparaître si personne ne les garde.<br>
        Ndeko les garde vivantes.
      </div>

      <div class="ndeko-hommage-vivant">
        <div class="ndeko-hommage-titre">🕯️ Hommage à une mémoire vivante</div>
        <div class="ndeko-hommage-texte">
          Avant d'aller plus loin, nous voulons rendre hommage à une femme dont nous ne connaissons pas encore le prénom.<br><br>
          Elle vit à <strong>Ulcinj, au Monténégro</strong>. Elle a <strong>plus de quatre-vingt-seize ans</strong>.<br>
          Elle est l'une des dernières descendantes directes de la communauté afro-ottomane d'Ulcinj — des Africains arrachés à leur continent par la traite ottomane aux 17e et 18e siècles, qui ont survécu, se sont enracinés, ont aimé, ont fondé des familles, et ont fini par disparaître presque sans laisser de trace.<br><br>
          Son frère, <strong>Rizo Šurla</strong>, était le visage de cette communauté. Photographe, figure légendaire. Il est parti en 2003. La ville lui a consacré une fresque murale à Pristan.<br><br>
          Elle, elle est encore là.<br><br>
          <em>Nous n'avons pas encore eu l'honneur de la rencontrer.<br>
          Mais nous ne voulions pas attendre qu'elle soit partie pour lui rendre hommage.<br>
          Nous l'honorons de son vivant — parce que quand elle partira, cette mémoire partira avec elle.</em>
        </div>
      </div>

      ${this.memoires.map(m=>`<div class="ndeko-memoire-carte">
        <div class="ndeko-memoire-titre">${m.titre}</div>
        <div class="ndeko-memoire-pays">${m.pays} · ${m.periode}</div>
        <div class="ndeko-memoire-texte">${m.resume}</div>
        ${m.figure?`<div class="ndeko-memoire-figure"><strong>Figure clé :</strong> ${m.figure}</div>`:''}
        <div class="ndeko-memoire-aujourd_hui"><strong>Aujourd\'hui :</strong> ${m.aujourd_hui}</div>
        ${m.note?`<div class="ndeko-memoire-note">📌 ${m.note}</div>`:''}
      </div>`).join('')}

    </div>`;
  },

  renderFormulaire() {
    return `<div class="ndeko-form-container">
      <div class="ndeko-form-titre">Tu connais une adresse qui mérite d\'être ici ?</div>
      <div class="ndeko-form-hint">Restos, hébergements, salons, shops, mémoires à préserver... Ta soumission sera vérifiée avant publication. Minimum 5 témoignages différents pour publier.</div>
      <div class="ndeko-form">
        <div class="ndeko-field"><label>Nom du lieu *</label><input type="text" id="nd-nom" placeholder="Ex: Chez Aminata..."/></div>
        <div class="ndeko-field"><label>Type *</label><select id="nd-type"><option value="">-- Choisir --</option><option>Hébergement</option><option>Restaurant / Café</option><option>Salon de coiffure</option><option>Boutique</option><option>Transport / Taxi</option><option>Mémoire / Histoire</option><option>Autre</option></select></div>
        <div class="ndeko-field"><label>Ville et pays *</label><input type="text" id="nd-lieu" placeholder="Ex: Dakar, Sénégal"/></div>
        <div class="ndeko-field"><label>Ton témoignage * (minimum 3 lignes)</label><textarea id="nd-temoignage" rows="5" placeholder="Raconte ton expérience. Pourquoi tu recommandes ? Comment tu t\'es sentie ?"></textarea></div>
        <div class="ndeko-field"><label>Contact ou lien (si tu l\'as)</label><input type="text" id="nd-contact" placeholder="Site, Instagram, Google Maps..."/></div>
        <div class="ndeko-field"><label>Ton prénom (optionnel)</label><input type="text" id="nd-auteur" placeholder="Ou laisse vide pour rester anonyme"/></div>
        <button class="ndeko-btn-submit" id="nd-submit">✊ Soumettre cette adresse</button>
      </div>
    </div>`;
  },

  filtrer() {
    return this.adresses.filter(a=>{
      const mt=this.state.filtre==='tout'||a.type===this.state.filtre;
      const mr=this.state.region==='tout'||a.region===this.state.region;
      const mb=this.state.budget==='tout'||a.budget===this.state.budget;
      const q=this.state.recherche.toLowerCase();
      const ms=!q||a.nom.toLowerCase().includes(q)||a.ville.toLowerCase().includes(q)||a.pays.toLowerCase().includes(q)||a.tags.some(t=>t.includes(q))||a.description.toLowerCase().includes(q);
      return mt&&mr&&mb&&ms;
    });
  },

  attachEvents() {
    document.getElementById('ndeko-liste')?.addEventListener('click',()=>{this.state.vue='liste';this.update();});
    document.getElementById('ndeko-memoires')?.addEventListener('click',()=>{this.state.vue='memoires';this.update();});
    document.getElementById('ndeko-soumettre')?.addEventListener('click',()=>{this.state.vue='soumettre';this.update();});
    document.getElementById('ndeko-search')?.addEventListener('input',e=>{this.state.recherche=e.target.value;this.update();});
    document.querySelectorAll('.ndeko-filtre-btn').forEach(b=>b.addEventListener('click',()=>{this.state.filtre=b.dataset.filtre;this.update();}));
    document.querySelectorAll('.ndeko-region-btn').forEach(b=>b.addEventListener('click',()=>{this.state.region=b.dataset.region;this.update();}));
    document.querySelectorAll('.ndeko-budget-btn').forEach(b=>b.addEventListener('click',()=>{this.state.budget=b.dataset.budget;this.update();}));
    document.getElementById('nd-submit')?.addEventListener('click',()=>this.soumettre());
  },

  // ─── SÉCURITÉ ────────────────────────────────────────────────
  // Sanitisation XSS : neutralise tout HTML/script dans les entrées utilisateur
  _sanitize(str) {
    if(typeof str !== 'string') return '';
    return str
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#x27;')
      .replace(/\//g,'&#x2F;')
      .replace(/`/g,'&#x60;')
      .replace(/=/g,'&#x3D;')
      .slice(0, 2000); // limite stricte de longueur
  },

  // Validation : caractères autorisés uniquement (lettres, chiffres, espaces, ponctuation courante)
  _validerChamp(str, maxLen=500) {
    if(!str || str.length < 2) return false;
    if(str.length > maxLen) return false;
    // Bloque les patterns d'injection courants
    const dangereux = /<script|javascript:|data:|vbscript:|on\w+\s*=|eval\(|document\.|window\.|localStorage|fetch\(|XMLHttpRequest/i;
    if(dangereux.test(str)) return false;
    return true;
  },

  // Rate limiting : max 3 soumissions par session, cooldown 60 secondes entre chaque
  _rateLimiter: { count: 0, derniere: 0, MAX: 3, COOLDOWN: 60000 },
  _checkRateLimit() {
    const rl = this._rateLimiter;
    const maintenant = Date.now();
    if(rl.count >= rl.MAX) {
      return { ok:false, msg:'Tu as déjà soumis ' + rl.MAX + ' adresses. Merci pour ta générosité — notre équipe va vérifier !' };
    }
    if(maintenant - rl.derniere < rl.COOLDOWN && rl.derniere > 0) {
      const reste = Math.ceil((rl.COOLDOWN - (maintenant - rl.derniere)) / 1000);
      return { ok:false, msg:'Merci de patienter ' + reste + ' secondes avant la prochaine soumission.' };
    }
    return { ok:true };
  },

  soumettre() {
    // Anti-bot : champ honeypot — doit rester vide
    const honeypot = document.getElementById('nd-honeypot')?.value;
    if(honeypot && honeypot.length > 0) {
      // Bot détecté — on fait semblant de réussir sans rien faire
      this.state.vue='liste'; this.update(); return;
    }

    // Rate limiting
    const rl = this._checkRateLimit();
    if(!rl.ok) { alert(rl.msg); return; }

    // Récupération et sanitisation des champs
    const nomBrut      = document.getElementById('nd-nom')?.value?.trim() || '';
    const typeBrut     = document.getElementById('nd-type')?.value || '';
    const lieuBrut     = document.getElementById('nd-lieu')?.value?.trim() || '';
    const temoignageBrut = document.getElementById('nd-temoignage')?.value?.trim() || '';
    const contactBrut  = document.getElementById('nd-contact')?.value?.trim() || '';
    const auteurBrut   = document.getElementById('nd-auteur')?.value?.trim() || '';

    const nom       = this._sanitize(nomBrut);
    const lieu      = this._sanitize(lieuBrut);
    const temoignage= this._sanitize(temoignageBrut);
    const contact   = this._sanitize(contactBrut);
    const auteur    = this._sanitize(auteurBrut) || 'Anonyme';

    // Types autorisés (whitelist stricte)
    const typesAutorisés = ['hébergement','restaurant','salon','épicerie','université','association','médecin','autre'];
    const type = typesAutorisés.includes(typeBrut) ? typeBrut : '';

    // Validations
    if(!this._validerChamp(nom,200))    { alert('Le nom de l\'adresse est invalide ou trop court.'); return; }
    if(!type)                           { alert('Merci de choisir un type valide.'); return; }
    if(!this._validerChamp(lieu,200))   { alert('La ville et le pays sont invalides ou manquants.'); return; }
    if(!this._validerChamp(temoignage,2000)) { alert('Le témoignage est invalide.'); return; }
    if(temoignageBrut.length < 80)      { alert('Ton témoignage est trop court. Raconte un peu plus — c\'est ce qui donne vie à Ndeko.'); return; }

    // Enregistrement rate limiter
    this._rateLimiter.count++;
    this._rateLimiter.derniere = Date.now();

    // Construction de l'objet soumission (prêt pour envoi API future)
    const soumission = {
      id: 'suggestion_' + Date.now(),
      nom, type, lieu, temoignage,
      contact: contact || 'Non renseigné',
      auteur,
      date: new Date().toISOString(),
      statut: 'en_attente_verification',
      // Jamais affiché publiquement avant vérification manuelle
    };

    // Log local pour débogage (pas de données sensibles exposées)
    console.log('[Ndeko] Nouvelle soumission reçue — en attente de vérification :', soumission.nom, '|', soumission.lieu);

    // Confirmation utilisateur
    const msg = auteur !== 'Anonyme'
      ? `✊ Merci ${auteur} ! Ta suggestion pour "${nom}" a été reçue.`
      : `✊ Ta suggestion pour "${nom}" a été reçue.`;
    alert(msg + '\n\nElle sera vérifiée par notre équipe avant publication. Ndeko grandit grâce à toi.');

    this.state.vue='liste'; this.update();
  },

  update() {
    const c=document.getElementById('ndeko-content');
    if(c){c.innerHTML=this.renderVue();this.attachEvents();}
  }
};

const ns=document.createElement('style');
ns.textContent=`.ndeko-container{padding:20px;max-width:960px;margin:0 auto;color:#fff;font-family:inherit}.ndeko-header{margin-bottom:20px}.ndeko-title{font-size:1.5em;font-weight:700;color:#f0c040;letter-spacing:2px;margin-bottom:6px}.ndeko-subtitle{font-size:.95em;color:#ddd;margin-bottom:4px}.ndeko-devise{font-size:.82em;color:#f0c040;font-style:italic}.ndeko-nav{display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap}.ndeko-nav-btn{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);color:#ccc;padding:10px 18px;border-radius:8px;cursor:pointer;font-size:.9em;transition:all .2s}.ndeko-nav-btn.active,.ndeko-nav-btn:hover{background:rgba(240,192,64,.2);border-color:#f0c040;color:#f0c040}.ndeko-search{width:100%;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);border-radius:8px;padding:10px 14px;color:#fff;font-size:.95em;margin-bottom:14px;box-sizing:border-box}.ndeko-filtres{margin-bottom:16px}.ndeko-filtre-groupe{margin-bottom:10px}.ndeko-filtre-label{font-size:.75em;color:#aaa;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}.ndeko-tags-filtres{display:flex;flex-wrap:wrap;gap:6px}.ndeko-filtre-btn,.ndeko-region-btn,.ndeko-budget-btn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#bbb;padding:5px 10px;border-radius:20px;cursor:pointer;font-size:.8em;transition:all .2s}.ndeko-filtre-btn.active,.ndeko-region-btn.active,.ndeko-budget-btn.active,.ndeko-filtre-btn:hover,.ndeko-region-btn:hover,.ndeko-budget-btn:hover{background:rgba(240,192,64,.2);border-color:#f0c040;color:#f0c040}.ndeko-count{font-size:.82em;color:#aaa;margin-bottom:10px}.ndeko-avertissement{background:rgba(192,57,43,.12);border-left:3px solid #c0392b;padding:10px 14px;border-radius:0 8px 8px 0;font-size:.8em;color:#ddd;margin-bottom:16px;line-height:1.5}.ndeko-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px}.ndeko-carte{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:16px;transition:border .2s}.ndeko-carte:hover{border-color:rgba(240,192,64,.4)}.ndeko-carte-top{display:flex;justify-content:space-between;margin-bottom:8px}.ndeko-carte-type{font-size:.72em;color:#aaa;text-transform:uppercase}.ndeko-carte-budget{font-size:.9em;color:#f0c040;font-weight:700}.ndeko-carte-nom{font-size:1em;font-weight:700;color:#fff;margin-bottom:4px}.ndeko-carte-lieu{font-size:.82em;color:#aaa;margin-bottom:6px}.ndeko-carte-proprio{font-size:.8em;color:#f0c040;margin-bottom:8px}.ndeko-carte-desc{font-size:.85em;color:#ccc;line-height:1.5;margin-bottom:10px}.ndeko-carte-tags{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:10px}.ndeko-tag{font-size:.7em;padding:2px 8px;border-radius:20px;color:#fff}.ndeko-carte-footer{display:flex;justify-content:space-between;font-size:.72em;color:#777;margin-bottom:6px}.ndeko-carte-contact{font-size:.75em;color:#f0c040;word-break:break-all}.ndeko-vide{color:#777;font-size:.9em;padding:20px;text-align:center}.ndeko-memoires{display:flex;flex-direction:column;gap:20px}.ndeko-memoires-intro{background:rgba(240,192,64,.08);border-left:3px solid #f0c040;padding:14px 18px;border-radius:0 8px 8px 0;font-size:.9em;color:#ddd;line-height:1.6;margin-bottom:16px}.ndeko-hommage-vivant{background:rgba(255,255,255,.03);border:1px solid rgba(240,192,64,.25);border-top:3px solid #f0c040;border-radius:12px;padding:24px;margin-bottom:24px}.ndeko-hommage-titre{font-size:.85em;text-transform:uppercase;letter-spacing:2px;color:#f0c040;margin-bottom:14px}.ndeko-hommage-texte{font-size:.92em;color:#ddd;line-height:1.9}.ndeko-memoire-carte{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:20px}.ndeko-memoire-titre{font-size:1.1em;font-weight:700;color:#f0c040;margin-bottom:4px}.ndeko-memoire-pays{font-size:.82em;color:#aaa;margin-bottom:12px}.ndeko-memoire-texte{font-size:.88em;color:#ccc;line-height:1.6;margin-bottom:12px}.ndeko-memoire-figure{background:rgba(142,68,173,.15);border-left:3px solid #8e44ad;padding:10px 14px;border-radius:0 8px 8px 0;font-size:.85em;color:#ddd;margin-bottom:10px}.ndeko-memoire-aujourd_hui{background:rgba(192,57,43,.12);border-left:3px solid #c0392b;padding:10px 14px;border-radius:0 8px 8px 0;font-size:.85em;color:#ddd;margin-bottom:10px;line-height:1.5}.ndeko-memoire-note{font-size:.78em;color:#888;font-style:italic}.ndeko-form-container{max-width:600px}.ndeko-form-titre{font-size:1.05em;font-weight:600;color:#f0c040;margin-bottom:8px}.ndeko-form-hint{font-size:.85em;color:#ccc;margin-bottom:20px;line-height:1.5;background:rgba(240,192,64,.08);border-left:3px solid #f0c040;padding:10px 14px;border-radius:0 8px 8px 0}.ndeko-form{display:flex;flex-direction:column;gap:14px}.ndeko-field{display:flex;flex-direction:column;gap:5px}.ndeko-field label{font-size:.82em;color:#bbb}.ndeko-field input,.ndeko-field textarea,.ndeko-field select{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);border-radius:7px;padding:10px 12px;color:#fff;font-size:.9em;font-family:inherit;resize:vertical}.ndeko-field select option{background:#1a1a2e}.ndeko-btn-submit{background:linear-gradient(135deg,#8e44ad,#6c3483);color:#fff;border:none;padding:13px;border-radius:8px;font-size:1em;font-weight:700;cursor:pointer}`;
document.head.appendChild(ns);
window.addEventListener('load',()=>NDEKO.init());
