// ═══════════════════════════════════════════════════
//  GPS OPENSTREETMAP — Or Eille AI v1.0
//  Gratuit, indépendant, mis à jour par la communauté
//  Profil véhicule + signalements terrain
// ═══════════════════════════════════════════════════

const GPS = {
  KEY: 'moe_gps',
  map: null,
  routing: null,
  userMarker: null,
  watchId: null,

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      vehicle: 'car',
      height: null, weight: null, width: null,
      reports: [], favorites: [],
      lastPosition: null,
    }; } catch { return {}; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Initialiser la carte ─────────────────────
  initMap(containerId) {
    if (typeof L === 'undefined') {
      this.loadLeaflet(() => this.initMap(containerId));
      return;
    }
    const container = document.getElementById(containerId);
    if (!container || this.map) return;

    this.map = L.map(containerId, { zoomControl: true, attributionControl: true });

    // OpenStreetMap — gratuit, indépendant
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 19
    }).addTo(this.map);

    // Centrer sur position de l'utilisateur
    this.centerOnUser();

    // Ajouter les signalements de la communauté
    this.showCommunityReports();
  },

  // ─── Charger Leaflet dynamiquement ────────────
  loadLeaflet(callback) {
    if (document.getElementById('leaflet-css')) { if(callback) callback(); return; }

    const css = document.createElement('link');
    css.id = 'leaflet-css';
    css.rel = 'stylesheet';
    css.href = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';
    document.head.appendChild(css);

    const js = document.createElement('script');
    js.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';
    js.onload = () => {
      // Charger le plugin de routage
      const routing = document.createElement('script');
      routing.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet-routing-machine/3.2.12/leaflet-routing-machine.min.js';
      routing.onload = callback;
      document.head.appendChild(routing);
    };
    document.head.appendChild(js);
  },

  // ─── Centrer sur l'utilisateur ────────────────
  centerOnUser() {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(pos => {
      const { latitude: lat, longitude: lng } = pos.coords;
      const d = this.get();
      d.lastPosition = { lat, lng };
      this.save(d);

      if (this.map) {
        this.map.setView([lat, lng], 15);
        if (this.userMarker) this.map.removeLayer(this.userMarker);
        this.userMarker = L.circleMarker([lat, lng], {
          radius: 10, fillColor: '#C4993A', color: '#fff',
          weight: 2, opacity: 1, fillOpacity: 0.9
        }).addTo(this.map).bindPopup('Vous êtes ici');
      }
    }, null, { enableHighAccuracy: true });
  },

  // ─── Calculer un itinéraire ────────────────────
  async route(destination, voiceGuidance = true) {
    if (!this.map) return;
    const d = this.get();
    if (!d.lastPosition) { await this.centerOnUser(); }

    // Géocoder la destination via Nominatim (OpenStreetMap)
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(destination)}&format=json&limit=1`,
        { headers: { 'Accept-Language': 'fr' } }
      );
      const results = await response.json();
      if (!results.length) {
        if (window.addChatMsg) addChatMsg('assistant', `Je n'ai pas trouvé "${destination}". Essayez avec une adresse plus précise.`);
        return;
      }

      const dest = { lat: parseFloat(results[0].lat), lng: parseFloat(results[0].lon) };
      const origin = d.lastPosition;

      // Supprimer l'ancien itinéraire
      if (this.routing) this.map.removeControl(this.routing);

      // Calculer l'itinéraire via OSRM (gratuit)
      const profile = d.vehicle === 'bicycle' ? 'bike' : d.vehicle === 'foot' ? 'foot' : 'car';
      this.routing = L.Routing.control({
        waypoints: [L.latLng(origin.lat, origin.lng), L.latLng(dest.lat, dest.lng)],
        router: L.Routing.osrmv1({ serviceUrl: `https://router.project-osrm.org/route/v1`, profile }),
        lineOptions: { styles: [{ color: '#C4993A', weight: 4 }] },
        createMarker: (i, wp) => {
          return L.marker(wp.latLng, {
            icon: L.divIcon({
              html: `<div style="background:${i===0?'#C4993A':'#1B4F8A'};color:#fff;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:Josefin Sans;font-size:.7rem;font-weight:bold">${i===0?'A':'B'}</div>`,
              iconSize: [28,28], iconAnchor: [14,14]
            })
          });
        },
        show: true,
        addWaypoints: false,
        routeWhileDragging: false,
      }).addTo(this.map);

      // Guidance vocale
      if (voiceGuidance) {
        this.routing.on('routesfound', e => {
          const route = e.routes[0];
          const dist = (route.summary.totalDistance / 1000).toFixed(1);
          const time = Math.round(route.summary.totalTime / 60);
          const msg = `Itinéraire trouvé vers ${results[0].display_name.split(',')[0]}. Distance : ${dist} kilomètres. Durée estimée : ${time} minutes.`;
          if (window.speak) speak(msg);
          if (window.addChatMsg) addChatMsg('assistant', `🗺 ${msg}`);

          // Vérifier les restrictions pour ce véhicule
          this.checkVehicleRestrictions(route, d);
        });
      }

    } catch(e) {
      if (window.addChatMsg) addChatMsg('assistant', 'Erreur de calcul d\'itinéraire. Vérifiez votre connexion.');
    }
  },

  // ─── Vérifier restrictions véhicule ───────────
  checkVehicleRestrictions(route, profile) {
    if (profile.vehicle !== 'truck') return;
    const d = this.get();
    const reports = d.reports.filter(r => r.type === 'restriction');

    // Vérifier si des signalements existent sur cet itinéraire
    if (reports.length > 0 && profile.height) {
      const warnings = reports.filter(r =>
        r.maxHeight && parseFloat(r.maxHeight) < parseFloat(profile.height)
      );
      if (warnings.length > 0) {
        const msg = `⚠ Attention ! Des restrictions ont été signalées sur cet itinéraire pour les véhicules de plus de ${profile.height}m de hauteur. Vérifiez avant de partir.`;
        if (window.speak) speak(msg);
        if (window.addChatMsg) addChatMsg('assistant', msg);
      }
    }
  },

  // ─── Signalement communautaire ────────────────
  addReport(type, description, position) {
    const d = this.get();
    const pos = position || d.lastPosition;
    if (!pos) return;

    const report = {
      id: Date.now().toString(),
      type, // 'restriction', 'road_change', 'closure', 'narrow', 'low_bridge', 'info'
      description,
      lat: pos.lat, lng: pos.lng,
      reportedAt: new Date().toISOString(),
      confirmedBy: 1,
    };

    d.reports.push(report);
    this.save(d);
    this.showCommunityReports();

    if (window.addChatMsg) addChatMsg('assistant', `✓ Signalement enregistré et partagé avec la communauté Or Eille AI. Merci !`);
  },

  // ─── Afficher signalements sur la carte ───────
  showCommunityReports() {
    if (!this.map) return;
    const d = this.get();

    const icons = {
      restriction: '⚠', road_change: '🔄', closure: '🚫',
      narrow: '↔', low_bridge: '🌉', info: 'ℹ'
    };

    d.reports.forEach(r => {
      L.marker([r.lat, r.lng], {
        icon: L.divIcon({
          html: `<div style="background:#1B4F8A;color:#fff;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.9rem;border:2px solid #C4993A">${icons[r.type]||'📍'}</div>`,
          iconSize: [28,28], iconAnchor: [14,14]
        })
      }).addTo(this.map).bindPopup(`
        <b>${r.description}</b><br/>
        <small>Signalé le ${new Date(r.reportedAt).toLocaleDateString('fr-FR')}</small><br/>
        <small>Confirmé par ${r.confirmedBy} utilisateur(s)</small>
      `);
    });
  },

  // ─── Recherche vocale de destination ──────────
  voiceDestination() {
    WHISPER.start(text => {
      if (window.addChatMsg) addChatMsg('assistant', `🗺 Calcul de l'itinéraire vers "${text}"...`);
      this.route(text);
    });
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    return `
    <div style="display:flex;flex-direction:column;flex:1;overflow:hidden">

      <!-- Barre de recherche -->
      <div style="padding:.7rem;border-bottom:1px solid var(--border);display:flex;gap:.4rem;background:var(--dark)">
        <input type="text" id="gps-dest" placeholder="Où voulez-vous aller ?" style="flex:1;font-size:.6rem"/>
        <button onclick="GPS.route(document.getElementById('gps-dest').value)" style="padding:.5rem .8rem;background:var(--gold);color:var(--dark);border:none;font-family:'Josefin Sans',sans-serif;font-size:.55rem;cursor:pointer">▶</button>
        <button onclick="GPS.voiceDestination()" style="padding:.5rem .7rem;background:transparent;border:1px solid var(--gold);color:var(--gold);font-size:.8rem;cursor:pointer">🎙</button>
      </div>

      <!-- Profil véhicule -->
      <div style="padding:.5rem .7rem;border-bottom:1px solid var(--border);display:flex;gap:.4rem;align-items:center;flex-wrap:wrap">
        ${[{v:'car',e:'🚗',l:'Voiture'},{v:'truck',e:'🚛',l:'Camion'},{v:'bicycle',e:'🚴',l:'Vélo'},{v:'foot',e:'🚶',l:'Piéton'}].map(({v,e,l}) => `
          <button onclick="GPS.setVehicle('${v}')" style="padding:.3rem .6rem;background:${d.vehicle===v?'var(--gold)':'var(--dark-mid)'};color:${d.vehicle===v?'var(--dark)':'var(--muted)'};border:1px solid ${d.vehicle===v?'var(--gold)':'var(--border)'};font-family:'Josefin Sans',sans-serif;font-size:.5rem;cursor:pointer">${e} ${l}</button>
        `).join('')}
        ${d.vehicle === 'truck' ? `
          <div style="display:flex;gap:.3rem;margin-top:.3rem;width:100%">
            <input type="number" placeholder="Hauteur (m)" value="${d.height||''}" onchange="GPS.setDimension('height',this.value)" style="flex:1;font-size:.55rem"/>
            <input type="number" placeholder="Poids (t)" value="${d.weight||''}" onchange="GPS.setDimension('weight',this.value)" style="flex:1;font-size:.55rem"/>
            <input type="number" placeholder="Largeur (m)" value="${d.width||''}" onchange="GPS.setDimension('width',this.value)" style="flex:1;font-size:.55rem"/>
          </div>
        ` : ''}
      </div>

      <!-- Carte -->
      <div id="gps-map" style="flex:1;min-height:300px"></div>

      <!-- Signalement -->
      <div style="padding:.6rem;border-top:1px solid var(--border);display:flex;gap:.4rem;flex-wrap:wrap">
        <span style="font-size:.52rem;color:var(--muted);width:100%;margin-bottom:.2rem">Signaler un problème :</span>
        ${[{t:'narrow',l:'Rue étroite'},{t:'low_bridge',l:'Pont bas'},{t:'road_change',l:'Route modifiée'},{t:'closure',l:'Route fermée'},{t:'info',l:'Info utile'}].map(({t,l}) => `
          <button onclick="GPS.promptReport('${t}','${l}')" style="padding:.3rem .5rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:'Josefin Sans',sans-serif;font-size:.48rem;cursor:pointer">${l}</button>
        `).join('')}
      </div>
    </div>`;
  },

  setVehicle(v) {
    const d = this.get(); d.vehicle = v; this.save(d);
    document.getElementById('gpsContent').innerHTML = this.renderPanel();
    setTimeout(() => this.initMap('gps-map'), 100);
  },

  setDimension(key, val) {
    const d = this.get(); d[key] = val; this.save(d);
  },

  promptReport(type, label) {
    const desc = prompt(`Décrivez le problème (${label}) :`);
    if (desc) this.addReport(type, desc, null);
  }
};

window.GPS = GPS;
