// ═══════════════════════════════════════════════════
//  POLICES & TYPOGRAPHIE — Or Eille AI v1.0
//  Bibliothèque complète, création depuis écriture manuscrite
//  Tous alphabets, mémoire de style
// ═══════════════════════════════════════════════════

const FONTS = {
  KEY: 'moe_fonts',

  // Polices open source complètes — tous alphabets
  LIBRARY: [
    // Sans-serif modernes
    { name: 'Josefin Sans', url: 'Josefin+Sans:wght@200;300;400;600', category: 'moderne', supports: 'latin,étendu' },
    { name: 'Montserrat', url: 'Montserrat:wght@300;400;600;700', category: 'moderne', supports: 'latin,cyrillique' },
    { name: 'Raleway', url: 'Raleway:wght@300;400;600', category: 'élégant', supports: 'latin' },
    { name: 'Oswald', url: 'Oswald:wght@300;400;600', category: 'percutant', supports: 'latin,cyrillique' },
    { name: 'Poppins', url: 'Poppins:wght@300;400;600', category: 'moderne', supports: 'latin,devanagari' },

    // Serif élégants
    { name: 'Cormorant Garamond', url: 'Cormorant+Garamond:ital,wght@0,300;0,400;1,300;1,400', category: 'élégant', supports: 'latin,cyrillique' },
    { name: 'Playfair Display', url: 'Playfair+Display:ital,wght@0,400;0,700;1,400', category: 'luxe', supports: 'latin,cyrillique' },
    { name: 'Libre Baskerville', url: 'Libre+Baskerville:wght@400;700', category: 'classique', supports: 'latin' },

    // Support universel
    { name: 'Noto Sans', url: 'Noto+Sans:wght@300;400;600', category: 'universel', supports: 'TOUS les alphabets du monde' },
    { name: 'Noto Serif', url: 'Noto+Serif:wght@400;700', category: 'universel', supports: 'TOUS les alphabets du monde' },
    { name: 'Ubuntu', url: 'Ubuntu:wght@300;400;700', category: 'africain', supports: 'latin,cyrillique,grec,africain' },

    // Arabe et RTL
    { name: 'Amiri', url: 'Amiri:wght@400;700', category: 'arabe', supports: 'arabe,latin' },
    { name: 'Scheherazade New', url: 'Scheherazade+New:wght@400;700', category: 'arabe', supports: 'arabe' },

    // Asiatique
    { name: 'Noto Sans SC', url: 'Noto+Sans+SC:wght@300;400;700', category: 'chinois', supports: 'chinois simplifié' },
    { name: 'Noto Sans JP', url: 'Noto+Sans+JP:wght@300;400;700', category: 'japonais', supports: 'japonais' },
    { name: 'Noto Sans KR', url: 'Noto+Sans+KR:wght@300;400;700', category: 'coréen', supports: 'coréen' },

    // Créatif et décalé
    { name: 'Pacifico', url: 'Pacifico', category: 'fun', supports: 'latin,cyrillique' },
    { name: 'Abril Fatface', url: 'Abril+Fatface', category: 'impactant', supports: 'latin' },
    { name: 'Dancing Script', url: 'Dancing+Script:wght@400;700', category: 'manuscrit', supports: 'latin' },
    { name: 'Sacramento', url: 'Sacramento', category: 'calligraphie', supports: 'latin' },
  ],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      preferredFont: 'Josefin Sans', customFonts: [],
      handwritingFont: null, lastUsed: []
    }; } catch { return {}; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Charger une police Google Fonts ──────────
  loadFont(fontName, fontUrl) {
    if (document.getElementById(`font-${fontName.replace(/\s/g,'-')}`)) return;
    const link = document.createElement('link');
    link.id = `font-${fontName.replace(/\s/g,'-')}`;
    link.rel = 'stylesheet';
    link.href = `https://fonts.googleapis.com/css2?family=${fontUrl}&display=swap`;
    document.head.appendChild(link);
  },

  // ─── Définir la police préférée ───────────────
  setPreferred(fontName) {
    const d = this.get();
    d.preferredFont = fontName;
    if (!d.lastUsed.includes(fontName)) d.lastUsed.unshift(fontName);
    d.lastUsed = d.lastUsed.slice(0, 5);
    this.save(d);

    // Charger la police
    const font = this.LIBRARY.find(f => f.name === fontName);
    if (font) this.loadFont(font.name, font.url);

    if (window.addChatMsg) addChatMsg('assistant', `✓ Police "${fontName}" sélectionnée et mémorisée.`);
  },

  // ─── Upload police personnelle ─────────────────
  uploadCustomFont(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      const fontName = file.name.replace(/\.[^.]+$/, '').replace(/[-_]/g, ' ');
      const style = document.createElement('style');
      style.textContent = `@font-face { font-family: '${fontName}'; src: url('${e.target.result}'); }`;
      document.head.appendChild(style);

      const d = this.get();
      d.customFonts.push({ name: fontName, addedAt: new Date().toISOString() });
      this.save(d);

      if (window.addChatMsg) addChatMsg('assistant', `✅ Police "${fontName}" uploadée et disponible dans toute l'appli.`);
      document.getElementById('fontsContent').innerHTML = FONTS.renderPanel();
    };
    reader.readAsDataURL(file);
  },

  // ─── Créer police depuis écriture manuscrite ──
  async createFromHandwriting(imageDataUrl, claudeKey) {
    if (!claudeKey) return;
    if (window.addChatMsg) addChatMsg('assistant', '🔍 Analyse de votre écriture manuscrite en cours...');

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 600,
          messages: [{
            role: 'user',
            content: [
              { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: imageDataUrl.split(',')[1] } },
              { type: 'text', text: `Analyse cette écriture manuscrite. Identifie:
1. Quelles lettres sont clairement lisibles (liste-les)
2. Le style général (penchée, droite, ronde, anguleuse, etc.)
3. Les caractéristiques distinctives (boucles, liaisons, décoration des i et j, etc.)
4. Les lettres manquantes ou illisibles
5. Si tu vois des chiffres

Réponds de façon structurée pour que je puisse guider la personne dans la création de sa police.` }
            ]
          }]
        })
      });
      const data = await r.json();
      const analysis = data.content[0].text;

      if (window.addChatMsg) addChatMsg('assistant', `📝 Analyse de votre écriture :\n\n${analysis}\n\nJe vais maintenant vous guider lettre par lettre pour compléter votre police personnelle.`);

      // Stocker l'analyse et guider la suite
      const d = this.get();
      d.handwritingAnalysis = analysis;
      d.handwritingImage = imageDataUrl;
      this.save(d);

      // Guider vers Calligraphr pour finaliser
      setTimeout(() => {
        if (window.addChatMsg) addChatMsg('assistant', `✅ Prochaine étape : Je vais générer un gabarit avec les lettres manquantes pour que vous les complétiez. Souhaitez-vous continuer ?`);
      }, 2000);

      return analysis;
    } catch { return null; }
  },

  // ─── Générer gabarit pour les lettres manquantes ─
  generateTemplate(missingLetters) {
    const canvas = document.createElement('canvas');
    canvas.width = 800; canvas.height = 600;
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = '#CCCCCC';
    ctx.lineWidth = 1;

    const letters = missingLetters || 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
    const cellW = 80, cellH = 100;
    const cols = Math.floor(canvas.width / cellW);

    letters.forEach((letter, i) => {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const x = col * cellW + 5;
      const y = row * cellH + 5;

      ctx.strokeRect(x, y, cellW - 10, cellH - 10);
      ctx.fillStyle = '#CCCCCC';
      ctx.font = '12px Arial';
      ctx.fillText(letter, x + 5, y + 15);
    });

    return canvas.toDataURL();
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div class="sec-title">🔤 Ma police préférée</div>
      <p class="note">Configurée une fois — utilisée partout dans Or Eille AI.</p>

      <div style="padding:.6rem;border:1px solid var(--gold);background:rgba(196,153,58,.08)">
        <div style="font-size:.56rem;color:var(--muted)">Police actuelle</div>
        <div style="font-size:1.1rem;color:var(--text);font-family:'${d.preferredFont}',sans-serif">${d.preferredFont}</div>
      </div>

      <!-- Bibliothèque par catégorie -->
      ${['universel','moderne','élégant','luxe','africain','arabe','chinois','japonais','coréen','fun','manuscrit','calligraphie','percutant','classique'].map(cat => {
        const fonts = this.LIBRARY.filter(f => f.category === cat);
        if (!fonts.length) return '';
        return `
          <div>
            <div style="font-size:.5rem;color:var(--cobalt);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.3rem">${cat}</div>
            <div style="display:flex;flex-wrap:wrap;gap:.3rem">
              ${fonts.map(f => `
                <button onclick="FONTS.setPreferred('${f.name}');FONTS.loadFont('${f.name}','${f.url}')" 
                  style="padding:.4rem .7rem;background:${d.preferredFont===f.name?'var(--gold)':'var(--dark-mid)'};color:${d.preferredFont===f.name?'var(--dark)':'var(--muted)'};border:1px solid ${d.preferredFont===f.name?'var(--gold)':'var(--border)'};font-family:'${f.name}',sans-serif;font-size:.6rem;cursor:pointer"
                  title="${f.supports}">
                  ${f.name}
                </button>
              `).join('')}
            </div>
          </div>
        `;
      }).join('')}

      <!-- Polices personnalisées -->
      ${d.customFonts.length > 0 ? `
        <div>
          <div style="font-size:.5rem;color:var(--gold);letter-spacing:.1em;text-transform:uppercase;margin-bottom:.3rem">Mes polices</div>
          <div style="display:flex;flex-wrap:wrap;gap:.3rem">
            ${d.customFonts.map(f => `
              <button onclick="FONTS.setPreferred('${f.name}')" style="padding:.4rem .7rem;background:${d.preferredFont===f.name?'var(--gold)':'var(--dark-mid)'};color:${d.preferredFont===f.name?'var(--dark)':'var(--muted)'};border:1px solid var(--gold);font-family:'${f.name}',sans-serif;font-size:.6rem;cursor:pointer">
                ★ ${f.name}
              </button>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <div class="sep"></div>
      <div class="sec-title">📤 Uploader ma police</div>
      <p class="note">Formats acceptés : .ttf, .otf, .woff, .woff2</p>
      <input type="file" accept=".ttf,.otf,.woff,.woff2" onchange="FONTS.uploadCustomFont(this.files[0])" style="font-size:.56rem;color:var(--muted)"/>

      <div class="sep"></div>
      <div class="sec-title">✍ Créer ma police manuscrite</div>
      <p class="note">Prenez une photo de 3 lignes de votre écriture naturelle — liste de courses, cahier, lettre. Or Eille AI analyse et crée votre police unique.</p>
      <input type="file" accept="image/*" onchange="FONTS.handleHandwritingPhoto(this)" style="font-size:.56rem;color:var(--muted)"/>
      ${d.handwritingAnalysis ? `
        <div style="padding:.5rem;border:1px solid rgba(196,153,58,.3);background:rgba(196,153,58,.05)">
          <div style="font-size:.5rem;color:var(--gold);margin-bottom:.2rem">✓ Écriture analysée</div>
          <div style="font-size:.48rem;color:var(--muted);line-height:1.5">${d.handwritingAnalysis.substring(0,150)}...</div>
        </div>
      ` : ''}
    </div>`;
  },

  handleHandwritingPhoto(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => this.createFromHandwriting(e.target.result, window.CFG?.CLAUDE_KEY);
    reader.readAsDataURL(file);
  }
};

window.FONTS = FONTS;

// Charger la police préférée au démarrage
window.addEventListener('load', () => {
  setTimeout(() => {
    const d = FONTS.get();
    if (d.preferredFont) {
      const font = FONTS.LIBRARY.find(f => f.name === d.preferredFont);
      if (font) FONTS.loadFont(font.name, font.url);
    }
    // Toujours charger Noto Sans pour le support universel
    FONTS.loadFont('Noto Sans', 'Noto+Sans:wght@300;400;600');
  }, 1000);
});
