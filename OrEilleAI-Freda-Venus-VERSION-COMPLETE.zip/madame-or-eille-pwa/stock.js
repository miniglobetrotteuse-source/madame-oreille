// ═══════════════════════════════════════════════════
//  GESTIONNAIRE DE STOCK — Or Eille AI v1.0
//  Stock domestique et professionnel
//  Alertes intelligentes, suggestions contextuelles
// ═══════════════════════════════════════════════════

const STOCK = {
  KEY: 'moe_stock',

  // Durées de vie typiques en jours
  LIFESPANS: {
    lait: 7, pain: 3, légumes: 5, fruits: 7, viande: 3, poisson: 2,
    yaourt: 14, fromage: 21, oeufs: 28, beurre: 30, farine: 180,
    pâtes: 730, riz: 730, huile: 365, sel: 1825, sucre: 1825,
    café: 180, thé: 365, chocolat: 180, conserves: 1095,
    shampoing: 365, gel_douche: 365, dentifrice: 365,
    lessive: 365, liquide_vaisselle: 365, papier_toilette: 90,
    white_spirit: 1825, peinture: 1095, vis: 3650, ampoule: 1825,
    pile: 1825, médicament: 365,
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || { items: [] }; }
    catch { return { items: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Ajouter un article ───────────────────────
  addItem(name, quantity, unit, category) {
    const d = this.get();
    const key = name.toLowerCase().replace(/\s+/g, '_');
    const lifespan = this.LIFESPANS[key] || 30;

    const existing = d.items.find(i => i.name.toLowerCase() === name.toLowerCase());
    if (existing) {
      existing.quantity += parseFloat(quantity) || 1;
      existing.lastPurchased = new Date().toISOString();
      existing.expiresAt = new Date(Date.now() + lifespan * 86400000).toISOString();
    } else {
      d.items.push({
        id: Date.now().toString(),
        name, quantity: parseFloat(quantity) || 1,
        unit: unit || 'unité',
        category: category || 'général',
        lifespan,
        addedAt: new Date().toISOString(),
        lastPurchased: new Date().toISOString(),
        expiresAt: new Date(Date.now() + lifespan * 86400000).toISOString(),
        minQuantity: 1,
        alertSent: false,
      });
    }
    this.save(d);
    return this.getAlerts();
  },

  // ─── Utiliser un article ──────────────────────
  useItem(name, quantity) {
    const d = this.get();
    const item = d.items.find(i => i.name.toLowerCase() === name.toLowerCase());
    if (!item) {
      if (window.addChatMsg) addChatMsg('assistant', `"${name}" n'est pas dans votre stock. Voulez-vous l'ajouter ?`);
      return;
    }
    item.quantity = Math.max(0, item.quantity - (parseFloat(quantity) || 1));
    item.alertSent = false;
    this.save(d);

    if (item.quantity <= item.minQuantity) {
      return { alert: true, item };
    }
    return { alert: false, item };
  },

  // ─── Vérifier les alertes ─────────────────────
  getAlerts() {
    const d = this.get();
    const now = new Date();
    const alerts = [];

    d.items.forEach(item => {
      // Stock bas
      if (item.quantity <= item.minQuantity) {
        alerts.push({ type: 'low_stock', item, message: `Il ne reste que ${item.quantity} ${item.unit} de ${item.name}.` });
      }

      // Expiration proche (7 jours)
      if (item.expiresAt) {
        const daysLeft = Math.round((new Date(item.expiresAt) - now) / 86400000);
        if (daysLeft <= 7 && daysLeft > 0) {
          alerts.push({ type: 'expiring', item, daysLeft, message: `${item.name} expire dans ${daysLeft} jour(s).` });
        } else if (daysLeft <= 0) {
          alerts.push({ type: 'expired', item, message: `${item.name} a peut-être expiré — vérifiez.` });
        }
      }

      // Article acheté depuis longtemps — vérification
      if (item.lifespan > 365 && item.lastPurchased) {
        const monthsSince = Math.round((now - new Date(item.lastPurchased)) / (30 * 86400000));
        if (monthsSince > 6) {
          alerts.push({ type: 'check', item, monthsSince, message: `${item.name} acheté il y a ${monthsSince} mois — avez-vous vérifié s'il en reste encore ?` });
        }
      }
    });

    return alerts;
  },

  // ─── Suggestion avant achat ───────────────────
  checkBeforeBuying(name) {
    const d = this.get();
    const item = d.items.find(i => i.name.toLowerCase().includes(name.toLowerCase()));
    if (!item) return null;

    const monthsSince = Math.round((new Date() - new Date(item.lastPurchased)) / (30 * 86400000));
    const daysLeft = item.expiresAt ? Math.round((new Date(item.expiresAt) - new Date()) / 86400000) : null;

    if (item.quantity > item.minQuantity) {
      return {
        hasStock: true,
        message: `Vous avez encore ${item.quantity} ${item.unit} de ${item.name}${monthsSince > 0 ? `, acheté il y a ${monthsSince} mois` : ''}. ${daysLeft ? `Expire dans ${daysLeft} jours.` : ''} Êtes-vous sûr(e) d'en avoir besoin ?`
      };
    }
    return { hasStock: false };
  },

  // ─── Saisie vocale ────────────────────────────
  voiceAdd() {
    WHISPER.start(text => {
      // Parser "j'ai acheté 6 bouteilles d'eau"
      const nums = text.match(/(\d+(?:[.,]\d+)?)/g);
      const quantity = nums ? parseFloat(nums[0]) : 1;
      const cleaned = text.toLowerCase()
        .replace(/j'ai acheté|j'ai pris|acheté|pris|ajout|ajoute/g, '')
        .replace(/\d+/g, '').replace(/bouteille[s]?|paquet[s]?|kilo[s]?|litre[s]?|boîte[s]?/g, '')
        .replace(/d[e']?|du|de la|des|un|une/g, '').trim();

      if (cleaned) {
        this.addItem(cleaned, quantity, 'unité', 'général');
        if (window.addChatMsg) addChatMsg('assistant', `✓ Ajouté : ${quantity} × ${cleaned}`);
        document.getElementById('stockContent').innerHTML = this.renderPanel();
      }
    });
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    const alerts = this.getAlerts();

    const categories = [...new Set(d.items.map(i => i.category))];

    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <!-- Alertes -->
      ${alerts.length > 0 ? `
        <div style="border:1px solid rgba(239,83,80,.4);padding:.7rem;background:rgba(239,83,80,.05)">
          <div style="font-size:.55rem;color:#ef5350;letter-spacing:.1em;text-transform:uppercase;margin-bottom:.4rem">⚠ ${alerts.length} alerte(s)</div>
          ${alerts.slice(0,3).map(a => `
            <div style="font-size:.54rem;color:var(--muted);padding:.3rem 0;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center">
              <span>${a.message}</span>
              ${a.type === 'low_stock' ? `<button onclick="SHOPPING.addToList('${a.item.name}')" style="padding:.2rem .4rem;background:var(--gold);color:var(--dark);border:none;font-size:.44rem;cursor:pointer">+ Liste</button>` : ''}
            </div>
          `).join('')}
        </div>
      ` : '<div style="font-size:.54rem;color:#81c784;padding:.4rem 0">✓ Tout est en ordre dans votre stock.</div>'}

      <!-- Ajouter -->
      <div class="sec-title">Ajouter au stock</div>
      <div style="display:flex;gap:.4rem">
        <input type="text" id="stock-name" placeholder="Article" style="flex:3"/>
        <input type="number" id="stock-qty" placeholder="Qté" value="1" style="flex:1"/>
        <button onclick="STOCK.addItem(document.getElementById('stock-name').value,document.getElementById('stock-qty').value,'unité','général');document.getElementById('stockContent').innerHTML=STOCK.renderPanel()" style="padding:.5rem;background:var(--gold);color:var(--dark);border:none;font-size:.7rem;cursor:pointer">+</button>
      </div>
      <button class="btn btn-ghost" onclick="STOCK.voiceAdd()">🎙 Dicter un achat</button>

      <!-- Stock par catégorie -->
      ${d.items.length === 0 ? `
        <div style="text-align:center;padding:2rem;color:var(--muted);font-size:.56rem">
          Votre stock est vide.<br/>Ajoutez vos premiers articles.
        </div>
      ` : categories.map(cat => `
        <div>
          <div style="font-size:.5rem;color:var(--gold);letter-spacing:.15em;text-transform:uppercase;margin-bottom:.3rem">${cat}</div>
          ${d.items.filter(i => i.category === cat).map(item => `
            <div style="display:flex;align-items:center;gap:.4rem;padding:.4rem 0;border-bottom:1px solid var(--border)">
              <div style="flex:1">
                <div style="font-size:.58rem;color:var(--text)">${item.name}</div>
                <div style="font-size:.48rem;color:var(--muted)">${item.quantity} ${item.unit}</div>
              </div>
              <button onclick="STOCK.useItem('${item.name}',1);document.getElementById('stockContent').innerHTML=STOCK.renderPanel()" style="padding:.2rem .5rem;background:transparent;border:1px solid var(--border);color:var(--muted);font-size:.5rem;cursor:pointer">-1</button>
              <button onclick="STOCK.addItem('${item.name}',1,'${item.unit}','${item.category}');document.getElementById('stockContent').innerHTML=STOCK.renderPanel()" style="padding:.2rem .5rem;background:transparent;border:1px solid var(--border);color:var(--muted);font-size:.5rem;cursor:pointer">+1</button>
              <button onclick="if(confirm('Supprimer ${item.name} ?')){const d=STOCK.get();d.items=d.items.filter(i=>i.id!=='${item.id}');STOCK.save(d);document.getElementById('stockContent').innerHTML=STOCK.renderPanel()}" style="padding:.2rem .4rem;background:transparent;border:none;color:rgba(239,83,80,.6);font-size:.6rem;cursor:pointer">×</button>
            </div>
          `).join('')}
        </div>
      `).join('')}
    </div>`;
  }
};

window.STOCK = STOCK;

// Vérifier les alertes au chargement
window.addEventListener('load', () => {
  setTimeout(() => {
    const alerts = STOCK.getAlerts();
    if (alerts.length > 0 && window.addChatMsg) {
      const urgent = alerts.filter(a => a.type === 'low_stock' || a.type === 'expired');
      if (urgent.length > 0) {
        addChatMsg('assistant', `📦 ${urgent.length} alerte(s) de stock : ${urgent[0].message}${urgent.length > 1 ? ` (+${urgent.length-1} autres)` : ''}`);
      }
    }
  }, 3000);
});
