// ═══════════════════════════════════════════════════
//  DICTÉE VOCALE WHISPER — Or Eille AI v1.0
//  Meilleure reconnaissance vocale — via Replicate
//  Comprend français, accents africains, mélanges
//  Clé : CFG.REPLICATE_KEY (déjà configurée)
// ═══════════════════════════════════════════════════

const WHISPER = {
  recording: false,
  mediaRecorder: null,
  audioChunks: [],
  stream: null,
  activeCallback: null,

  // ─── Démarrer l'enregistrement ────────────────
  async start(onResult, onError) {
    if (this.recording) { this.stop(); return; }
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      this.audioChunks = [];
      this.activeCallback = onResult;

      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : 'audio/mp4';

      this.mediaRecorder = new MediaRecorder(this.stream, { mimeType });

      this.mediaRecorder.ondataavailable = e => {
        if (e.data && e.data.size > 0) this.audioChunks.push(e.data);
      };

      this.mediaRecorder.onstop = async () => {
        try {
          const audioBlob = new Blob(this.audioChunks, { type: mimeType });
          const text = await this.transcribe(audioBlob);
          if (text && this.activeCallback) this.activeCallback(text.trim());
        } catch(e) {
          if (onError) onError(e);
          this.fallbackNative(onResult);
        } finally {
          this.stream?.getTracks().forEach(t => t.stop());
          this.recording = false;
        }
      };

      this.mediaRecorder.start(250);
      this.recording = true;
      this.showIndicator();

    } catch(e) {
      // Pas de microphone ou permission refusée — fallback natif
      console.warn('Whisper: microphone indisponible, fallback natif', e);
      this.fallbackNative(onResult);
    }
  },

  // ─── Arrêter ──────────────────────────────────
  stop() {
    if (this.mediaRecorder && this.recording) {
      this.mediaRecorder.stop();
      this.recording = false;
      this.hideIndicator();
    }
  },

  // ─── Transcrire via Replicate Whisper ─────────
  async transcribe(audioBlob) {
    const key = window.CFG?.REPLICATE_KEY;

    // Fallback natif si pas de clé
    if (!key || key.includes('METTRE_ICI')) {
      return new Promise((resolve) => {
        this.fallbackNative(text => resolve(text));
      });
    }

    try {
      // Convertir en base64
      const base64 = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result.split(',')[1]);
        reader.onerror = reject;
        reader.readAsDataURL(audioBlob);
      });

      // Appel Replicate Whisper
      const response = await fetch('https://api.replicate.com/v1/predictions', {
        method: 'POST',
        headers: {
          'Authorization': `Token ${key}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          version: 'e39e354773f9a7c9c12f9a55e8e6ea44b59f96fb7a8f0aa06de0ad3fc0f5a2e7',
          input: {
            audio: `data:audio/webm;base64,${base64}`,
            language: 'fr',
            translate: false,
            temperature: 0,
          }
        })
      });

      if (!response.ok) throw new Error('Replicate error');

      const prediction = await response.json();

      // Attendre le résultat (polling)
      let result = null;
      let attempts = 0;
      while (!result && attempts < 30) {
        await new Promise(r => setTimeout(r, 1000));
        const poll = await fetch(`https://api.replicate.com/v1/predictions/${prediction.id}`, {
          headers: { 'Authorization': `Token ${key}` }
        });
        const data = await poll.json();
        if (data.status === 'succeeded') {
          result = data.output?.transcription || data.output || '';
        } else if (data.status === 'failed') {
          throw new Error('Transcription failed');
        }
        attempts++;
      }

      return result || '';

    } catch(e) {
      console.warn('Whisper Replicate failed, fallback natif:', e);
      return new Promise((resolve) => {
        this.fallbackNative(text => resolve(text));
      });
    }
  },

  // ─── Fallback reconnaissance native ───────────
  fallbackNative(onResult) {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      if (window.addChatMsg) addChatMsg('assistant', 'Dictée vocale non disponible sur cet appareil. Veuillez taper votre message.');
      return;
    }
    const r = new SR();
    r.lang = 'fr-FR';
    r.continuous = false;
    r.interimResults = false;
    r.onresult = e => {
      const text = e.results[0][0].transcript;
      if (onResult) onResult(text);
    };
    r.onerror = () => {
      if (window.addChatMsg) addChatMsg('assistant', 'Microphone non accessible. Tapez votre message.');
    };
    r.start();
  },

  // ─── Indicateur visuel d'enregistrement ───────
  showIndicator() {
    let el = document.getElementById('whisper-indicator');
    if (!el) {
      el = document.createElement('div');
      el.id = 'whisper-indicator';
      el.style.cssText = `
        position:fixed;top:16px;left:50%;transform:translateX(-50%);
        background:rgba(196,153,58,.95);color:#0F0F0F;
        padding:.4rem 1rem;border-radius:20px;
        font-family:'Josefin Sans',sans-serif;font-size:.55rem;
        letter-spacing:.1em;text-transform:uppercase;
        z-index:99990;display:flex;align-items:center;gap:.4rem;
        animation:pulse 1s infinite;
      `;
      el.innerHTML = `<span style="width:8px;height:8px;background:#c00;border-radius:50%;display:inline-block;animation:blink 1s infinite"></span> Enregistrement en cours — Appuyez pour arrêter`;
      el.onclick = () => this.stop();
      document.body.appendChild(el);
    }
    el.style.display = 'flex';
  },

  hideIndicator() {
    const el = document.getElementById('whisper-indicator');
    if (el) el.style.display = 'none';
  },

  // ─── Bouton de dictée universel ───────────────
  // Utilisé partout dans l'appli
  createButton(targetInputId, label) {
    return `<button 
      onclick="WHISPER.toggleForInput('${targetInputId}')"
      id="whisper-btn-${targetInputId}"
      style="padding:.45rem .7rem;background:transparent;border:1px solid var(--gold);color:var(--gold);font-family:'Josefin Sans',sans-serif;font-size:.52rem;letter-spacing:.08em;cursor:pointer;display:flex;align-items:center;gap:.3rem"
      title="${label || 'Dicter'}">
      🎙 ${label || 'Dicter'}
    </button>`;
  },

  toggleForInput(inputId) {
    if (this.recording) {
      this.stop();
      return;
    }
    this.start(text => {
      const el = document.getElementById(inputId);
      if (el) {
        el.value = (el.value ? el.value + ' ' : '') + text;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      }
    });
  }
};

window.WHISPER = WHISPER;

// Remplacer tous les boutons voice-btn existants par Whisper
window.addEventListener('load', () => {
  setTimeout(() => {
    // Redéfinir la fonction speak globale pour utiliser la voix système
    if (!window.speak) {
      window.speak = (text, lang) => {
        if (!window.speechSynthesis) return;
        const utt = new SpeechSynthesisUtterance(text);
        utt.lang = lang || 'fr-FR';
        utt.rate = 0.9;
        utt.volume = 1;
        window.speechSynthesis.cancel();
        window.speechSynthesis.speak(utt);
      };
    }
  }, 500);
});
