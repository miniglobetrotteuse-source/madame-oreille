// ═══════════════════════════════════════════════════
//  NEWSLETTER & CONTENU — Or Eille AI v1.0
//  Style culturel, style personnel, mémoire permanente
//  Génération complète — pas un template vide
// ═══════════════════════════════════════════════════

const NEWSLETTER = {
  KEY: 'moe_newsletter',

  CULTURAL_STYLES: {
    alice: { name: 'Alice au Pays des Merveilles', keywords: 'merveilles, curiosité, lapin blanc, terrier, Reine de Cœur, Chapelier fou, étrange et extraordinaire', tone: 'poétique et surréaliste' },
    starwars: { name: 'Star Wars', keywords: 'galaxie, Force, côté obscur, Jedi, aventure épique, destinée', tone: 'épique et dramatique' },
    petit_prince: { name: 'Le Petit Prince', keywords: 'étoiles, rose, renard, essentiel invisible, planète, apprivoiser', tone: 'poétique et philosophique' },
    mille_nuits: { name: 'Les Mille et Une Nuits', keywords: 'contes, magie, Shéhérazade, palais, djinn, tapis volant', tone: 'envoûtant et mystérieux' },
    afrofuturisme: { name: 'Afrofuturisme', keywords: 'futur africain, technologie et tradition, ancestralité, puissance, renaissance', tone: 'puissant et visionnaire' },
    harry_potter: { name: 'Harry Potter', keywords: 'magie, Poudlard, sorts, chapeau, sorcier, monde parallèle', tone: 'magique et aventureux' },
    custom: { name: 'Style personnalisé', keywords: '', tone: '' }
  },

  FORMATS: {
    weekly: 'Newsletter hebdomadaire',
    monthly: 'Newsletter mensuelle',
    promo: 'Annonce promotionnelle',
    event: 'Invitation événement',
    launch: 'Lancement produit',
    thanks: 'Remerciement clients',
    news: 'Actualité du studio'
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      style: null, culturalStyle: null, customStyleDescription: null,
      tone: null, brandColors: null, businessType: null,
      history: [], templates: []
    }; } catch { return {}; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  // ─── Analyser l'univers depuis une photo ──────
  async analyzeBusinessPhoto(imageDataUrl, claudeKey) {
    if (!claudeKey || !imageDataUrl) return null;
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 400,
          messages: [{
            role: 'user',
            content: [
              { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: imageDataUrl.split(',')[1] } },
              { type: 'text', text: `Analyse cette photo de l'univers créatif ou du commerce de cette personne. Décris:
1. L'ambiance générale (3 mots)
2. Les couleurs dominantes
3. Le style (bohème, moderne, vintage, élégant, naturel, etc.)
4. Les éléments caractéristiques
5. La tonalité émotionnelle (chaleureux, sophistiqué, joyeux, sérieux, etc.)
6. Comment écrire une newsletter qui reflète parfaitement cet univers

Réponds de façon concise et pratique.` }
            ]
          }]
        })
      });
      const data = await r.json();
      const analysis = data.content[0].text;
      const d = this.get();
      d.customStyleDescription = analysis;
      d.style = 'photo_analyzed';
      this.save(d);
      return analysis;
    } catch { return null; }
  },

  // ─── Documenter un style culturel inconnu ─────
  async learnCulturalStyle(cultureName, claudeKey) {
    if (!claudeKey) return null;
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 500,
          tools: [{ type: 'web_search_20250305', name: 'web_search' }],
          messages: [{
            role: 'user',
            content: `Recherche des informations sur "${cultureName}" comme style narratif ou culturel. 
Trouve: les thèmes typiques, les personnages ou figures emblématiques, le style d'écriture, les expressions caractéristiques, la musicalité de la langue si applicable.
Si c'est peu documenté, dis-le clairement.
Si tu trouves des informations, explique comment écrire dans ce style de façon respectueuse et authentique.`
          }]
        })
      });
      const data = await r.json();
      return data.content.filter(b => b.type === 'text').map(b => b.text).join('');
    } catch { return null; }
  },

  // ─── Générer une newsletter complète ──────────
  async generate(params, claudeKey) {
    const { subject, format, culturalStyle, customStyle, platform, audienceInfo } = params;
    const d = this.get();
    const savedStyle = d.customStyleDescription || customStyle;
    const style = this.CULTURAL_STYLES[culturalStyle];

    if (!claudeKey) {
      if (window.addChatMsg) addChatMsg('assistant', 'Clé API requise pour la génération.');
      return null;
    }

    if (window.addChatMsg) addChatMsg('assistant', '✍ Génération de votre newsletter en cours...');

    let stylePrompt = '';
    if (culturalStyle && culturalStyle !== 'custom' && style) {
      stylePrompt = `Style narratif: ${style.name}. Univers: ${style.keywords}. Ton: ${style.tone}. Intègre subtilement des références à cet univers sans perdre le message commercial.`;
    } else if (savedStyle) {
      stylePrompt = `Style basé sur l'analyse de l'univers visuel de la créatrice: ${savedStyle}`;
    }

    const platformGuidelines = {
      mailchimp: 'Format HTML compatible Mailchimp, largeur 600px',
      brevo: 'Format Brevo/Sendinblue, texte structuré',
      substack: 'Format Substack, ton plus personnel et conversationnel',
      general: 'Format texte universel, facile à copier-coller'
    };

    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': claudeKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514', max_tokens: 1000,
          system: window.OR_EILLE_SYSTEM_PROMPT || 'Tu es un expert en copywriting et marketing de contenu. Tu génères des newsletters complètes, engageantes et authentiques.',
          messages: [{
            role: 'user',
            content: `Génère une newsletter complète pour:
Sujet: ${subject}
Format: ${this.FORMATS[format] || format}
${stylePrompt ? 'Style: ' + stylePrompt : ''}
Audience: ${audienceInfo || 'communauté de la créatrice'}
Plateforme: ${platformGuidelines[platform] || platformGuidelines.general}

La newsletter doit inclure:
1. UN objet email accrocheur (pas générique)
2. Une introduction qui accroche immédiatement
3. Le corps du message — complet, pas de placeholder
4. Un appel à l'action clair
5. Une signature personnalisée

IMPORTANT: Génère le contenu COMPLET. Pas de "[Votre texte ici]" ou "[À compléter]". Tout doit être écrit et prêt à envoyer.`
          }]
        })
      });
      const data = await r.json();
      const newsletter = data.content[0].text;

      // Enregistrer dans l'historique
      const d2 = this.get();
      d2.history.unshift({ subject, format, newsletter, generatedAt: new Date().toISOString(), culturalStyle });
      d2.history = d2.history.slice(0, 20);
      this.save(d2);

      if (window.addChatMsg) addChatMsg('assistant', `✅ Newsletter générée !\n\n${newsletter}`);
      return newsletter;
    } catch {
      if (window.addChatMsg) addChatMsg('assistant', 'Erreur de génération. Vérifiez votre connexion.');
      return null;
    }
  },

  // ─── Rendu panel ──────────────────────────────
  renderPanel() {
    const d = this.get();
    return `
    <div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">

      <div class="sec-title">✍ Créer une newsletter</div>

      <textarea id="nl-subject" placeholder="Sujet de votre newsletter — décrivez en quelques mots" style="min-height:60px"></textarea>
      <button class="voice-btn" onclick="WHISPER.start(t=>document.getElementById('nl-subject').value=t)">🎙 Dicter le sujet</button>

      <div>
        <span class="klabel">Format</span>
        <select id="nl-format" style="width:100%;margin-top:.3rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.58rem;padding:.45rem;outline:none">
          ${Object.entries(this.FORMATS).map(([k,v]) => `<option value="${k}">${v}</option>`).join('')}
        </select>
      </div>

      <div>
        <span class="klabel">Style narratif</span>
        <select id="nl-style" style="width:100%;margin-top:.3rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.58rem;padding:.45rem;outline:none" onchange="document.getElementById('nl-custom-style').style.display=this.value==='custom'?'block':'none'">
          <option value="">Aucun style particulier</option>
          ${Object.entries(this.CULTURAL_STYLES).map(([k,v]) => `<option value="${k}">${v.name}</option>`).join('')}
        </select>
        <input type="text" id="nl-custom-style" placeholder="Décrivez votre style culturel personnalisé..." style="display:none;margin-top:.3rem"/>
      </div>

      <div>
        <span class="klabel">Plateforme d'envoi</span>
        <select id="nl-platform" style="width:100%;margin-top:.3rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:'Josefin Sans',sans-serif;font-size:.58rem;padding:.45rem;outline:none">
          <option value="general">Universel (copier-coller)</option>
          <option value="mailchimp">Mailchimp</option>
          <option value="brevo">Brevo / Sendinblue</option>
          <option value="substack">Substack</option>
        </select>
      </div>

      ${d.customStyleDescription ? `
      <div style="padding:.5rem;border:1px solid rgba(196,153,58,.3);background:rgba(196,153,58,.05)">
        <div style="font-size:.5rem;color:var(--gold);margin-bottom:.2rem">✓ Style personnel mémorisé</div>
        <div style="font-size:.48rem;color:var(--muted)">${d.customStyleDescription.substring(0, 100)}...</div>
        <button onclick="NEWSLETTER.clearStyle()" style="font-size:.44rem;color:var(--muted);background:transparent;border:none;cursor:pointer;margin-top:.2rem">Changer de style</button>
      </div>` : `
      <div style="border:1px solid var(--border);padding:.6rem">
        <div style="font-size:.54rem;color:var(--text);margin-bottom:.3rem">📸 Analyser mon univers visuel</div>
        <p style="font-size:.5rem;color:var(--muted);margin-bottom:.4rem">Prenez une photo de votre boutique, atelier ou univers créatif — Or Eille AI génère dans votre style.</p>
        <input type="file" accept="image/*" onchange="NEWSLETTER.handlePhotoUpload(this)" style="font-size:.5rem;color:var(--muted)"/>
      </div>`}

      <button class="btn btn-gold" onclick="NEWSLETTER.generate({
        subject: document.getElementById('nl-subject').value,
        format: document.getElementById('nl-format').value,
        culturalStyle: document.getElementById('nl-style').value,
        customStyle: document.getElementById('nl-custom-style').value,
        platform: document.getElementById('nl-platform').value,
      }, window.CFG?.CLAUDE_KEY)">✍ Générer la newsletter complète</button>

      ${d.history.length > 0 ? `
      <div class="sep"></div>
      <div class="sec-title">Newsletters récentes</div>
      ${d.history.slice(0,3).map((h,i) => `
        <div style="padding:.5rem;border:1px solid var(--border);cursor:pointer" onclick="if(window.addChatMsg)addChatMsg('assistant',${JSON.stringify(h.newsletter)})">
          <div style="font-size:.56rem;color:var(--text)">${h.subject}</div>
          <div style="font-size:.46rem;color:var(--muted)">${new Date(h.generatedAt).toLocaleDateString('fr-FR')} · ${this.FORMATS[h.format]||h.format}</div>
        </div>
      `).join('')}` : ''}
    </div>`;
  },

  async handlePhotoUpload(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (e) => {
      if (window.addChatMsg) addChatMsg('assistant', '🔍 Analyse de votre univers visuel en cours...');
      const analysis = await NEWSLETTER.analyzeBusinessPhoto(e.target.result, window.CFG?.CLAUDE_KEY);
      if (analysis) {
        if (window.addChatMsg) addChatMsg('assistant', `✅ Style mémorisé :\n\n${analysis}\n\nVos prochaines newsletters seront générées dans cet univers.`);
        document.getElementById('newsletterContent').innerHTML = NEWSLETTER.renderPanel();
      }
    };
    reader.readAsDataURL(file);
  },

  clearStyle() {
    const d = this.get();
    d.customStyleDescription = null;
    d.style = null;
    this.save(d);
    document.getElementById('newsletterContent').innerHTML = this.renderPanel();
  }
,

  // ─── Carnet d'adresses newsletter ─────────────
  MAIL_KEY: 'moe_nl_contacts',

  getContacts: function() {
    try { return JSON.parse(localStorage.getItem(this.MAIL_KEY) || '[]'); }
    catch { return []; }
  },

  saveContacts: function(list) {
    localStorage.setItem(this.MAIL_KEY, JSON.stringify(list));
  },

  addContact: function(email, name) {
    if (!email || email.indexOf('@') < 0) {
      if (window.addChatMsg) addChatMsg('assistant','Email invalide.');
      return;
    }
    const contacts = this.getContacts();
    if (contacts.find(function(c) { return c.email === email; })) {
      if (window.addChatMsg) addChatMsg('assistant','Cet email est deja dans ta liste.');
      return;
    }
    contacts.push({ email: email.trim(), name: name||'', addedAt: new Date().toISOString() });
    this.saveContacts(contacts);
    if (window.addChatMsg) addChatMsg('assistant','✅ ' + email + ' ajoute — ' + contacts.length + ' contact(s) au total.');
    document.getElementById('newsletterContent').innerHTML = NEWSLETTER.renderPanel();
  },

  removeContact: function(email) {
    const contacts = this.getContacts().filter(function(c) { return c.email !== email; });
    this.saveContacts(contacts);
    document.getElementById('newsletterContent').innerHTML = NEWSLETTER.renderPanel();
  },

  importContacts: function(text) {
    const re = /[a-zA-Z0-9._%+]+@[a-zA-Z0-9.]+\.[a-zA-Z]{2,}/g;
    const emails = text.match(re) || [];
    const contacts = this.getContacts();
    let added = 0;
    emails.forEach(function(email) {
      if (!contacts.find(function(c) { return c.email === email; })) {
        contacts.push({ email: email, name: '', addedAt: new Date().toISOString() });
        added++;
      }
    });
    this.saveContacts(contacts);
    if (window.addChatMsg) addChatMsg('assistant','✅ ' + added + ' email(s) importes. Total : ' + contacts.length + ' contacts.');
    document.getElementById('newsletterContent').innerHTML = NEWSLETTER.renderPanel();
  },

  sendViaGmail: function(subject, body) {
    const contacts = this.getContacts();
    if (contacts.length === 0) {
      if (window.addChatMsg) addChatMsg('assistant','Aucun contact. Ajoutes-en d abord.');
      return;
    }
    const to = contacts.map(function(c) { return c.email; }).join(',');
    const url = 'https://mail.google.com/mail/?view=cm&fs=1&to=' + encodeURIComponent(to) + '&su=' + encodeURIComponent(subject||'Newsletter') + '&body=' + encodeURIComponent(body||'');
    if (window.addChatMsg) addChatMsg('assistant','✅ Gmail s ouvre avec ' + contacts.length + ' destinataire(s). Tu n as plus qu a appuyer sur Envoyer.');
    window.open(url, '_blank');
  }
};


window.NEWSLETTER = NEWSLETTER;
