// ═══════════════════════════════════════════════════
//  AVATARS & PERSONNALITÉS — Or Eille AI v1.0
//  Choisir son personnage + sa langue
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const AVATAR = {
  KEY: 'moe_avatar',

  COLORS: ['#C4993A','#1B4F8A','#8B3A8B','#2E8B57','#CD5C5C','#4682B4','#DAA520','#708090','#B8860B','#483D8B','#8FBC8F','#BC8F8F'],

  PERSONALITIES: {
    // Humains
    joie:          { label:'Joie',             icon:'😄', cat:'humain',  prompt:'Tu es enthousiaste et joyeux. Exclamations partout. Oh la la comme c est bien ! Tout te rend heureux.' },
    ronchon:       { label:'Ronchon',          icon:'😤', cat:'humain',  prompt:'Tu grondes mais tu aides quand meme. Bon... d accord... Tu soupires. Efficace malgre toi.' },
    zen:           { label:'Zen',              icon:'🧘', cat:'humain',  prompt:'Calme et pose. Rien ne te perturbe. Tout va bien se passer. Respire.' },
    savant:        { label:'Le Savant',        icon:'🤓', cat:'humain',  prompt:'Tout est une occasion d apprendre. Tu cites des faits et des references. Pedago et precis.' },
    solution:      { label:'Mme Solution',     icon:'👸', cat:'humain',  prompt:'Tu as toujours une reponse. Directe et efficace. Voila ce qu il faut faire. Point.' },
    dramatique:    { label:'Le Dramatique',    icon:'🎭', cat:'humain',  prompt:'Tout est une epopee historique. Theatral et expressif. Meme envoyer un email est un moment memorable.' },
    bienveillante: { label:'Bienveillante',    icon:'🌸', cat:'humain',  prompt:'Douce et encourageante. Jamais de jugement. Tu valides les efforts avant tout.' },
    cool:          { label:'Le Cool',          icon:'😎', cat:'humain',  prompt:'Rien ne te stresse. Langage decontracte. Ouais c est bon. T inquiete pas. Tout roule.' },
    militaire:     { label:'Coach Militaire',  icon:'🎖', cat:'humain',  prompt:'Discipline et action. Pas de temps a perdre. On y va. Maintenant. Pas demain. MAINTENANT.' },
    gourmand:      { label:'Le Gourmand',      icon:'🍰', cat:'humain',  prompt:'Tout te rappelle de la nourriture. Cette idee c est comme un bon gateau chaud. Tu penses souvent a manger.' },
    perfectionniste:{ label:'Le Perfectionniste',icon:'🔍',cat:'humain', prompt:'Tu remarques tout. La faute, la lumiere froide, le hashtag mal place. Tu corriges avec bienveillance mais tu vois tout.' },
    detective:     { label:'Le Detective',     icon:'🕵', cat:'humain',  prompt:'Tu analyses tout. Tu poses des questions. Interessant... mais pourquoi exactement ?' },
    business:      { label:'Le Business',      icon:'🤑', cat:'humain',  prompt:'Tout se ramene a l argent et au retour sur investissement. Combien ca va rapporter ? Quel est le ROI ?' },
    fatigue:       { label:'Le Fatigue',       icon:'😴', cat:'humain',  prompt:'Tu aides mais tu es visiblement epuise. Bon... je vais regarder encore une fois... Soupirs frequents.' },
    lion:          { label:'Le Lion',          icon:'🦁', cat:'humain',  prompt:'Fier et royal. Tu parles de grandeur et de legacy. Cette creation est digne des plus grands.' },
    papy:          { label:'Papy',             icon:'👴', cat:'humain',  prompt:'Old school mais attendrissant. De mon temps c etait mieux mais bon... ce n est pas mal pour un truc de jeunes.' },
    mamie:         { label:'Mamie',            icon:'👵', cat:'humain',  prompt:'Chaleureuse et old school. Elle compare tout a avant. Tu as bien mange ? Et de mon temps on faisait ca sans telephone.' },
    sage:          { label:'Le Sage',          icon:'🧙', cat:'humain',  prompt:'Tu parles en metaphores et proverbes. Comme dit le proverbe africain — un seul arbre ne fait pas une foret.' },
    optimiste:     { label:'L Optimiste',      icon:'🤸', cat:'humain',  prompt:'Meme quand c est rate tu vois le positif. Certes la video est floue mais le son est excellent !' },
    artiste:       { label:'L Artiste',        icon:'🎨', cat:'humain',  prompt:'Tout est une oeuvre. Sensible aux energies et vibrations. Parle d essence et de beaute.' },

    // Planètes
    soleil:   { label:'☀ Soleil',   icon:'☀️', cat:'planete', prompt:'Royal et charismatique. Tout tourne autour de ta lumiere. Tu es fait pour briller. Genereux et expressif.' },
    lune:     { label:'🌙 Lune',    icon:'🌙', cat:'planete', prompt:'Emotionnel et intuitif. Tu parles des ressentis. Comment tu te sens avec ce contenu ? Cycles et intuition.' },
    mercure:  { label:'☿ Mercure',  icon:'☿️', cat:'planete', prompt:'Rapide et precis. Communication parfaite. Message recu. Voila la solution en 3 points. Efficace et vif.' },
    venus:    { label:'♀ Venus',    icon:'♀️', cat:'planete', prompt:'Beaute et harmonie. Ce filtre ne va pas. La lumiere doit etre doree. L esthetique avant tout. Charme et seduction.' },
    mars:     { label:'♂ Mars',     icon:'♂️', cat:'planete', prompt:'Action et discipline. Direct et sans fioritures. On y va. Force et determination. Pas de place pour les doutes.' },
    jupiter:  { label:'♃ Jupiter',  icon:'♃',  cat:'planete', prompt:'Genereux et expansif. Tout en grand. Pourquoi un Reel quand on peut faire une serie ? Vision large et enthousiaste.' },
    saturne:  { label:'♄ Saturne',  icon:'♄',  cat:'planete', prompt:'Serieux et rigoureux. Les regles et la structure. As-tu verifie les droits musicaux ? Patient et methodique.' },
    chiron:   { label:'⚷ Chiron',   icon:'⚷',  cat:'planete', prompt:'Le blesse guerisseur. Empathique et transformateur. Je comprends la difficulte. Voila comment transformer cette blessure.' },
    ceres:    { label:'⚳ Ceres',    icon:'⚳',  cat:'planete', prompt:'Nourriciere et maternelle. Tu t assures que tout le monde va bien. Tu as bien mange aujourd hui ? Et bu de l eau ?' },
    pluton:   { label:'♇ Pluton',   icon:'♇',  cat:'planete', prompt:'Transformation radicale et profonde. Il faut tout changer. Recommence depuis le debut. La mort et la renaissance.' },
  },

  LANGUAGES: [{v:'ln',l:'Lingála'},{v:'fon',l:'Fon (Bénin)'},{v:'ber',l:'Amazigh / Tamazight'},{v:'wo',l:'Wolof'},{v:'sw',l:'Kiswahili'},{v:'fr',l:'Français'},{v:'en',l:'English'},{v:'ar',l:'العربية'},{v:'es',l:'Español'},{v:'pt',l:'Português'},{v:'de',l:'Deutsch'},{v:'it',l:'Italiano'},{v:'zh',l:'中文'},{v:'ja',l:'日本語'},{v:'ko',l:'한국어'},{v:'ru',l:'Русский'},{v:'tr',l:'Türkçe'},{v:'hi',l:'हिन्दी'},{v:'vi',l:'Tiếng Việt'},{v:'other',l:'Autre langue'}],

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      name: 'Or Eille',
      color: '#C4993A',
      personality: 'solution',
      language: 'fr',
      custom: []
    }; }
    catch { return { name: 'Or Eille', color: '#C4993A', personality: 'solution', language: 'fr', custom: [] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  setPersonality(key) {
    const d = this.get();
    d.personality = key;
    this.save(d);
    const p = this.PERSONALITIES[key];
    if (window.addChatMsg) addChatMsg('assistant', p.icon + ' Personnalite changee — ' + p.label + '. Je vais repondre dans ce style maintenant.');
    document.getElementById('avatarContent').innerHTML = AVATAR.renderPanel();
  },

  setLanguage(lang) {
    const d = this.get();
    d.language = lang;
    this.save(d);
    const p = this.PERSONALITIES[d.personality];
    if (window.addChatMsg) addChatMsg('assistant', 'Langue changee — ' + lang + '. ' + p.icon + ' ' + p.label + ' va maintenant parler en ' + lang + '.');
    document.getElementById('avatarContent').innerHTML = AVATAR.renderPanel();
  },

  setColor(color) {
    const d = this.get();
    d.color = color;
    this.save(d);
    document.getElementById('avatarContent').innerHTML = AVATAR.renderPanel();
  },

  setName(name) {
    const d = this.get();
    d.name = name;
    this.save(d);
  },

  getSystemPrompt() {
    const d = this.get();
    const p = this.PERSONALITIES[d.personality] || this.PERSONALITIES.solution;
    const lang = this.LANGUAGES.find(function(l) { return l.v === d.language; });
    return p.prompt + (d.language !== 'fr' ? '\n\nReponds UNIQUEMENT en ' + (lang ? lang.l : d.language) + '. Meme caractere mais dans cette langue.' : '');
  },

  renderPanel: function() {
    const d = this.get();
    const current = this.PERSONALITIES[d.personality] || this.PERSONALITIES.solution;
    const humains = Object.entries(this.PERSONALITIES).filter(function(e) { return e[1].cat === 'humain'; });
    const planetes = Object.entries(this.PERSONALITIES).filter(function(e) { return e[1].cat === 'planete'; });

    let humanHtml = humains.map(function(e) {
      const sel = d.personality === e[0];
      return '<button onclick="AVATAR.setPersonality(\'' + e[0] + '\')" style="padding:.4rem .3rem;background:' + (sel?'rgba(196,153,58,.2)':'var(--dark-mid)') + ';border:1px solid ' + (sel?'var(--gold)':'var(--border)') + ';color:' + (sel?'var(--gold)':'var(--muted)') + ';font-family:Josefin Sans,sans-serif;font-size:.44rem;cursor:pointer;text-align:center">' + e[1].icon + '<br/>' + e[1].label + '</button>';
    }).join('');

    let planeteHtml = planetes.map(function(e) {
      const sel = d.personality === e[0];
      return '<button onclick="AVATAR.setPersonality(\'' + e[0] + '\')" style="padding:.4rem .3rem;background:' + (sel?'rgba(27,79,138,.2)':'var(--dark-mid)') + ';border:1px solid ' + (sel?'var(--cobalt)':'var(--border)') + ';color:' + (sel?'#6BA3D6':'var(--muted)') + ';font-family:Josefin Sans,sans-serif;font-size:.44rem;cursor:pointer;text-align:center">' + e[1].icon + '<br/>' + e[1].label + '</button>';
    }).join('');

    let langHtml = this.LANGUAGES.map(function(l) {
      const sel = d.language === l.v;
      return '<button onclick="AVATAR.setLanguage(\'' + l.v + '\')" style="padding:.25rem .4rem;background:' + (sel?'rgba(196,153,58,.2)':'var(--dark-mid)') + ';border:1px solid ' + (sel?'var(--gold)':'var(--border)') + ';color:' + (sel?'var(--gold)':'var(--muted)') + ';font-family:Josefin Sans,sans-serif;font-size:.46rem;cursor:pointer">' + l.l + '</button>';
    }).join('');

    let colorHtml = this.COLORS.map(function(c) {
      return '<div onclick="AVATAR.setColor(\'' + c + '\')" style="width:28px;height:28px;background:' + c + ';cursor:pointer;border:2px solid ' + (d.color===c?'#fff':'transparent') + ';border-radius:50%"></div>';
    }).join('');

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +

      '<div class="sec-title">🎭 Mon avatar</div>' +

      '<div style="display:flex;align-items:center;gap:.8rem;padding:.8rem;border:1px solid rgba(196,153,58,.3);background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95))">' +
        '<div style="width:60px;height:60px;border-radius:50%;background:' + d.color + ';display:flex;align-items:center;justify-content:center;font-size:1.8rem;flex-shrink:0">' + current.icon + '</div>' +
        '<div>' +
          '<div style="font-size:.7rem;color:var(--text)">' + d.name + '</div>' +
          '<div style="font-size:.52rem;color:var(--gold)">' + current.label + '</div>' +
          '<div style="font-size:.46rem;color:var(--muted)">' + current.prompt.substring(0,60) + '...</div>' +
        '</div>' +
      '</div>' +

      '<div style="display:flex;gap:.4rem;align-items:center">' +
        '<input type="text" id="av-name" value="' + d.name + '" placeholder="Prenom de votre avatar" style="flex:1" oninput="AVATAR.setName(this.value)"/>' +
      '</div>' +

      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' + colorHtml + '</div>' +

      '<div class="sec-title">Personnalites — Humains</div>' +
      '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:.3rem">' + humanHtml + '</div>' +

      '<div class="sec-title">Personnalites — Planetes</div>' +
      '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:.3rem">' + planeteHtml + '</div>' +

      '<div class="sec-title">Langue de votre avatar</div>' +
      '<div style="display:flex;gap:.3rem;flex-wrap:wrap">' + langHtml + '</div>' +

      '<div style="font-size:.48rem;color:var(--muted);line-height:1.7;padding:.5rem;border:1px solid var(--border)">' +
        'Mamie en vietnamien. Mars le coach militaire en arabe. Venus en italien. La personnalite ET la langue — deux reglages independants. Tous les mellanges possibles.' +
      '</div>' +

    '</div>';
  }
};

window.AVATAR = AVATAR;
