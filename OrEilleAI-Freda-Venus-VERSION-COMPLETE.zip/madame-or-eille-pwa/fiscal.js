// ═══════════════════════════════════════════════════
//  FISCALITÉ & COMPTABILITÉ — Or Eille AI v1.0
//  Aide à comprendre · rappels · formulaires
//  France · Belgique · Sénégal · Canada · Côte d Ivoire
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const FISCAL = {
  KEY: 'moe_fiscal',

  COUNTRIES: {
    france:      { label:'France',        currency:'EUR', tax_url:'impots.gouv.fr' },
    belgique:    { label:'Belgique',      currency:'EUR', tax_url:'finances.belgium.be' },
    senegal:     { label:'Sénégal',       currency:'XOF', tax_url:'impotsetdomaines.gouv.sn' },
    canada:      { label:'Canada',        currency:'CAD', tax_url:'canada.ca/impots' },
    cotedivoire: { label:'Côte d Ivoire', currency:'XOF', tax_url:'dgi.gouv.ci' },
    cameroun:    { label:'Cameroun',      currency:'XAF', tax_url:'impots.cm' },
    maroc:       { label:'Maroc',         currency:'MAD', tax_url:'tax.gov.ma' },
  },

  STATUTS: {
    salarie:      'Salarié',
    auto:         'Auto-entrepreneur / Freelance',
    createur:     'Créateur de contenu',
    commercant:   'Commerçant',
    etudiant:     'Étudiant',
    chomage:      'Demandeur d emploi',
    retraite:     'Retraité',
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      country:'france', statut:'createur', revenus:0
    }; }
    catch { return { country:'france', statut:'createur', revenus:0 }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async getAdvice(question, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const d = this.get();
    const country = this.COUNTRIES[d.country] || { label:'France' };
    const statut = this.STATUTS[d.statut] || '';
    if (window.addChatMsg) addChatMsg('assistant','Recherche fiscale pour ' + country.label + '...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:600,
          messages:[{ role:'user', content:
            'Question fiscale ou comptable : ' + (question||'quelles sont mes obligations fiscales') + '.\n' +
            'Pays : ' + country.label + '. Statut : ' + statut + '.\n\n' +
            'Reponds de facon claire et accessible. Pas de jargon inutile.\n' +
            'Si la question necessite un comptable ou un conseiller fiscal — dis-le honnêtement.\n' +
            'Termine par les demarches concretes a faire et les delais importants si applicable.\n' +
            'Note : ceci est une information generale, pas un conseil fiscal personnalise.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  renderPanel: function() {
    const d = this.get();
    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">💰 Fiscalité & Comptabilité</div>' +
      '<p class="note">Comprendre ses obligations fiscales. Gérer ses revenus simplement. Sans jargon. Adapté à ton pays et ton statut.</p>' +

      '<div style="background:rgba(196,153,58,.04);border:1px solid rgba(196,153,58,.15);padding:.7rem;font-size:.46rem;color:rgba(240,232,216,.4);line-height:1.8">' +
        '⚠ Or Eille AI fournit des informations générales. Pour ta situation précise, un comptable ou conseiller fiscal reste la meilleure option.' +
      '</div>' +

      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">' +
        '<div><span class="klabel">Mon pays</span>' +
        '<select id="fiscal-country" onchange="var d2=FISCAL.get();d2.country=this.value;FISCAL.save(d2)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.COUNTRIES).map(function(e){return '<option value="'+e[0]+'" '+(d.country===e[0]?'selected':'')+'>'+e[1].label+'</option>';}).join('') +
        '</select></div>' +
        '<div><span class="klabel">Mon statut</span>' +
        '<select id="fiscal-statut" onchange="var d2=FISCAL.get();d2.statut=this.value;FISCAL.save(d2)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.STATUTS).map(function(e){return '<option value="'+e[0]+'" '+(d.statut===e[0]?'selected':'')+'>'+e[1]+'</option>';}).join('') +
        '</select></div>' +
      '</div>' +

      '<input type="text" id="fiscal-question" placeholder="Ta question — ex: je dois déclarer mes revenus TikTok, comment faire ?"/>' +
      '<button class="btn btn-gold" onclick="FISCAL.getAdvice(document.getElementById(\'fiscal-question\').value,window.CFG&&window.CFG.CLAUDE_KEY)">💰 Réponse fiscale</button>' +

      '<div class="sec-title">Questions fréquentes</div>' +
      '<div style="display:flex;flex-direction:column;gap:.3rem">' +
        ['Je viens de commencer à gagner de l argent — que faire ?',
         'Comment déclarer mes revenus de créateur de contenu ?',
         'Auto-entrepreneur — quelles charges dois-je payer ?',
         'J ai des revenus dans plusieurs pays — comment ça marche ?',
         'Facture, reçu, comptabilité simple — par où commencer ?'].map(function(q) {
          return '<button onclick="FISCAL.getAdvice(\'' + q + '\',window.CFG&&window.CFG.CLAUDE_KEY)" style="padding:.5rem .7rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--muted);font-family:Josefin Sans,sans-serif;font-size:.48rem;cursor:pointer;text-align:left">' + q + '</button>';
        }).join('') +
      '</div>' +
    '</div>';
  }
};

window.FISCAL = FISCAL;
