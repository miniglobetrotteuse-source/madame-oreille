// ═══════════════════════════════════════════════════
//  CODE DE LA ROUTE — Or Eille AI v1.0
//  Apprendre à son rythme · par ce qu'on comprend
//  France · Belgique · Sénégal · Canada · Maroc
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const DRIVING = {
  KEY: 'moe_driving',

  COUNTRIES: {
    france:   { label:'France',   questions:40, pass:35 },
    belgique: { label:'Belgique', questions:50, pass:41 },
    senegal:  { label:'Sénégal',  questions:30, pass:24 },
    maroc:    { label:'Maroc',    questions:40, pass:32 },
    canada:   { label:'Canada',   questions:30, pass:24 },
  },


  LEARNING_CONTEXTS: {
    quotidien: 'Trajets du quotidien — gare, courses, travail',
    weekend:   'Sorties weekend — famille, amis, loisirs',
    ville:     'Circulation en ville — rues, carrefours, parkings',
    route:     'Grands trajets — nationale, autoroute',
    debutant:  'Je commence — tout est nouveau pour moi',
  },

  THEMES: {
    priorite:    'Priorités et intersections',
    panneaux:    'Panneaux de signalisation',
    vitesse:     'Vitesses et distances',
    alcool:      'Alcool et drogues au volant',
    securite:    'Sécurité et équipements',
    autoroute:   'Autoroute et voies rapides',
    pietons:     'Piétons et cyclistes',
    stationnement:'Stationnement',
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      country:'france', theme:'priorite', sessions:0, scores:[]
    }; }
    catch { return { country:'france', theme:'priorite', sessions:0, scores:[] }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async getLesson(claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const d = this.get();
    const country = this.COUNTRIES[d.country] || this.COUNTRIES.france;
    const theme = this.THEMES[d.theme] || '';
    if (window.addChatMsg) addChatMsg('assistant','Lecon code de la route — ' + theme + '...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:600,
          messages:[{ role:'user', content:
            'Cree une lecon de code de la route pour : ' + country.label + '. Theme : ' + theme + '.\n\n' +
            'Format :\n' +
            '1. Explique la regle clairement en 3-4 phrases simples\n' +
            '2. Donne un exemple concret de situation reelle\n' +
            '3. Pose 3 questions QCM avec les reponses A B C\n' +
            '4. Donne les bonnes reponses avec explication\n\n' +
            'Bienveillant. Encourageant. Jamais decourageant si on se trompe. ' +
            'Rappelle que tout le monde peut y arriver avec de la pratique reguliere.'
          }]
        })
      });
      const data = await r.json();
      d.sessions++;
      this.save(d);
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
      var self = this;
      setTimeout(function() { self.celebrate(d.sessions); }, 1500);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  async getExam(claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const d = this.get();
    const country = this.COUNTRIES[d.country] || this.COUNTRIES.france;
    if (window.addChatMsg) addChatMsg('assistant','Serie d entrainement — ' + country.questions + ' questions...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:1000,
          messages:[{ role:'user', content:
            'Cree une serie de ' + country.questions + ' questions d entrainement au code de la route pour ' + country.label + '. ' +
            'Mix de tous les themes comme a l examen reel. Format QCM avec A B C. ' +
            'Apres toutes les questions donne toutes les reponses avec explication courte. ' +
            'A la fin donne un score sur ' + country.questions + ' et dis si la personne aurait reussi (seuil : ' + country.pass + ' bonnes reponses). Bienveillant et encourageant.'
          }]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  celebrate: function(sessions) {
    var msgs = ['Bien joue !','Tu progresses !','Continue comme ca !','Bravo !'];
    var msg = msgs[Math.floor(Math.random() * msgs.length)];
    var milestone = '';
    if (sessions === 5)  milestone = ' 5 lecons deja — tu connais les bases !';
    if (sessions === 10) milestone = ' 10 lecons — tu es sur la bonne voie !';
    if (sessions === 20) milestone = ' 20 lecons — tu es pret pour l examen !';
    if (window.addChatMsg && milestone) addChatMsg('assistant', msg + milestone);
  },

  renderPanel: function() {
    const d = this.get();
    const country = this.COUNTRIES[d.country] || this.COUNTRIES.france;

    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🚗 Code de la route</div>' +
      '<p class="note">Apprendre à son rythme. Par thème. Avec des explications claires. Sans stress.</p>' +

      '<div style="background:linear-gradient(135deg,rgba(26,22,16,.98),rgba(44,35,24,.95));border:1px solid rgba(196,153,58,.3);padding:.8rem">' +
        '<p style="font-size:.54rem;color:rgba(240,232,216,.85);line-height:1.8">Le code de la route peut s apprendre. Avec la bonne methode, a son rythme, tout le monde peut y arriver.</p>' +
        '<p style="font-size:.42rem;color:rgba(196,153,58,.4);text-align:right;font-style:italic">— Madame Or Eille Studios</p>' +
      '</div>' +

      '<div><span class="klabel">Mon profil</span>' +
        '<select id="drv-context" onchange="var d2=DRIVING.get();d2.context=this.value;DRIVING.save(d2)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.LEARNING_CONTEXTS).map(function(e) { return '<option value="'+e[0]+'" '+(d.context===e[0]?'selected':'')+'>'+e[1]+'</option>'; }).join('') +
        '</select></div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">' +
        '<div><span class="klabel">Mon pays</span>' +
        '<select id="drv-country" onchange="var d2=DRIVING.get();d2.country=this.value;DRIVING.save(d2);document.getElementById(\'drivingContent\').innerHTML=DRIVING.renderPanel()" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.COUNTRIES).map(function(e) { return '<option value="'+e[0]+'" '+(d.country===e[0]?'selected':'')+'>'+e[1].label+'</option>'; }).join('') +
        '</select></div>' +

        '<div><span class="klabel">Thème</span>' +
        '<select id="drv-theme" onchange="var d2=DRIVING.get();d2.theme=this.value;DRIVING.save(d2)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.THEMES).map(function(e) { return '<option value="'+e[0]+'" '+(d.theme===e[0]?'selected':'')+'>'+e[1]+'</option>'; }).join('') +
        '</select></div>' +
      '</div>' +

      '<div style="padding:.5rem;border:1px solid rgba(196,153,58,.2);font-size:.48rem;color:var(--muted)">' +
        country.label + ' — ' + country.questions + ' questions à l examen · ' + country.pass + ' bonnes réponses requises' +
      '</div>' +

      '<button class="btn btn-gold" onclick="DRIVING.getLesson(window.CFG&&window.CFG.CLAUDE_KEY)">📖 Leçon du jour</button>' +
      '<button class="btn btn-ghost" onclick="DRIVING.getExam(window.CFG&&window.CFG.CLAUDE_KEY)">📝 Série d entrainement — 10 questions</button>' +

      (d.sessions > 0 ? '<div style="font-size:.48rem;color:rgba(240,232,216,.3);text-align:center">' + d.sessions + ' lecon(s) completee(s)</div>' : '') +

    '</div>';
  }
};

window.DRIVING = DRIVING;
