// ═══════════════════════════════════════════════════
//  AUTHENTIFICATION SUPABASE — Or Eille AI v1.0
//  Inscription · Connexion · Mémoire persistante
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const AUTH = {

  // Initialiser Supabase
  init: function() {
    if (!window.CFG || !window.CFG.SUPABASE_URL || !window.CFG.SUPABASE_KEY) {
      console.warn('Supabase non configuré');
      return null;
    }
    // Supabase client via CDN
    if (window.supabase) {
      this.client = window.supabase.createClient(
        window.CFG.SUPABASE_URL,
        window.CFG.SUPABASE_KEY
      );
    }
    return this.client;
  },

  client: null,

  // ─── Inscription ──────────────────────────────
  async signUp(email, password, displayName) {
    if (!this.client) this.init();
    if (!this.client) { this._msg('Supabase non configuré.'); return null; }
    try {
      const { data, error } = await this.client.auth.signUp({
        email: email,
        password: password,
        options: { data: { display_name: displayName || '' } }
      });
      if (error) { this._msg('Erreur inscription : ' + error.message); return null; }
      await this.saveProfile(data.user.id, { name: displayName, email: email });
      this._msg('Bienvenue ! Vérifie ton email pour confirmer ton compte.');
      return data.user;
    } catch(e) { this._msg('Erreur. Vérifie ta connexion.'); return null; }
  },

  // ─── Connexion ────────────────────────────────
  async signIn(email, password) {
    if (!this.client) this.init();
    if (!this.client) { this._msg('Supabase non configuré.'); return null; }
    try {
      const { data, error } = await this.client.auth.signInWithPassword({
        email: email,
        password: password
      });
      if (error) { this._msg('Email ou mot de passe incorrect.'); return null; }
      await this.loadProfile(data.user.id);
      return data.user;
    } catch(e) { this._msg('Erreur. Vérifie ta connexion.'); return null; }
  },

  // ─── Déconnexion ──────────────────────────────
  async signOut() {
    if (!this.client) return;
    await this.client.auth.signOut();
    localStorage.clear();
    window.location.reload();
  },

  // ─── Utilisateur actuel ───────────────────────
  async getCurrentUser() {
    if (!this.client) this.init();
    if (!this.client) return null;
    try {
      const { data } = await this.client.auth.getUser();
      return data.user || null;
    } catch(e) { return null; }
  },

  // ─── Sauvegarder le profil complet ───────────
  async saveProfile(userId, profileData) {
    if (!this.client) return;
    try {
      const { error } = await this.client
        .from('profiles')
        .upsert({
          id: userId,
          updated_at: new Date().toISOString(),
          name: profileData.name || '',
          email: profileData.email || '',
          culture: profileData.culture || '',
          country: profileData.country || '',
          diet: profileData.diet || 'tout',
          language: profileData.language || 'fr',
          sport_context: profileData.sport_context || 'appart_voisins',
          active_modules: JSON.stringify(profileData.active_modules || ['ma_langue','sport_maison','bonne_maniere']),
          kids_profile: JSON.stringify(profileData.kids_profile || {}),
          nutrition_profile: profileData.nutrition_profile || 'simple',
        });
      if (error) console.error('Erreur sauvegarde profil:', error.message);
    } catch(e) { console.error('Erreur Supabase:', e); }
  },

  // ─── Charger le profil depuis Supabase ────────
  async loadProfile(userId) {
    if (!this.client) return;
    try {
      const { data, error } = await this.client
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();
      if (error || !data) return;

      // Restaurer le profil dans localStorage pour tous les modules
      if (data.active_modules) {
        try {
          const modules = JSON.parse(data.active_modules);
          const methodData = JSON.parse(localStorage.getItem('moe_method') || '{}');
          methodData.activeModules = modules;
          localStorage.setItem('moe_method', JSON.stringify(methodData));
        } catch(e) {}
      }
      if (data.kids_profile) {
        try {
          localStorage.setItem('moe_kids', data.kids_profile);
        } catch(e) {}
      }
      if (data.diet) {
        const recipesData = JSON.parse(localStorage.getItem('moe_recipes') || '{}');
        recipesData.diet = data.diet;
        recipesData.nutritionProfile = data.nutrition_profile || 'simple';
        localStorage.setItem('moe_recipes', JSON.stringify(recipesData));
      }
      if (data.sport_context) {
        const sportData = JSON.parse(localStorage.getItem('moe_sport') || '{}');
        sportData.context = data.sport_context;
        localStorage.setItem('moe_sport', JSON.stringify(sportData));
      }
    } catch(e) { console.error('Erreur chargement profil:', e); }
  },

  // ─── Sync automatique toutes les 5 minutes ───
  startAutoSync: async function() {
    const user = await this.getCurrentUser();
    if (!user) return;
    setInterval(async function() {
      const method = JSON.parse(localStorage.getItem('moe_method') || '{}');
      const recipes = JSON.parse(localStorage.getItem('moe_recipes') || '{}');
      const sport = JSON.parse(localStorage.getItem('moe_sport') || '{}');
      await AUTH.saveProfile(user.id, {
        active_modules: method.activeModules || [],
        diet: recipes.diet || 'tout',
        nutrition_profile: recipes.nutritionProfile || 'simple',
        sport_context: sport.context || 'appart_voisins',
      });
    }, 5 * 60 * 1000);
  },

  // ─── Interface connexion ──────────────────────
  renderAuthPanel: function() {
    return '<div style="padding:1.5rem;display:flex;flex-direction:column;gap:.8rem;max-width:400px;margin:0 auto">' +
      '<div style="text-align:center;margin-bottom:1rem">' +
        '<div style="font-family:Cormorant Garamond,serif;font-style:italic;color:#C4993A;font-size:2rem">Or Eille AI</div>' +
        '<div style="font-size:.48rem;color:var(--muted);margin-top:.3rem">Connecte-toi pour retrouver ton profil sur tous tes appareils</div>' +
      '</div>' +

      '<input type="email" id="auth-email" placeholder="Ton email" style="padding:.6rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.54rem;outline:none"/>' +
      '<input type="password" id="auth-password" placeholder="Mot de passe" style="padding:.6rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.54rem;outline:none"/>' +

      '<button onclick="AUTH.signIn(document.getElementById(\'auth-email\').value,document.getElementById(\'auth-password\').value)" class="btn btn-gold">Se connecter</button>' +

      '<div style="text-align:center;font-size:.46rem;color:var(--muted)">Pas encore de compte ?</div>' +

      '<input type="text" id="auth-name" placeholder="Ton prénom (pour l inscription)" style="padding:.6rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.54rem;outline:none"/>' +
      '<button onclick="AUTH.signUp(document.getElementById(\'auth-email\').value,document.getElementById(\'auth-password\').value,document.getElementById(\'auth-name\').value)" class="btn btn-ghost">Créer mon compte</button>' +

      '<div style="font-size:.42rem;color:rgba(240,232,216,.25);text-align:center;font-style:italic;line-height:1.8">Tes données t appartiennent. Or Eille AI ne les partage jamais.</div>' +
    '</div>';
  },

  _msg: function(text) {
    if (window.addChatMsg) addChatMsg('assistant', text);
    else alert(text);
  }
};

// Initialiser au chargement
document.addEventListener('DOMContentLoaded', async function() {
  AUTH.init();
  const user = await AUTH.getCurrentUser();
  if (user) {
    await AUTH.loadProfile(user.id);
    AUTH.startAutoSync();
  }
});

window.AUTH = AUTH;
