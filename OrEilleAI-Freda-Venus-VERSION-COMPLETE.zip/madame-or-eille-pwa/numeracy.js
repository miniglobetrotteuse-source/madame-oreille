// ═══════════════════════════════════════════════════
//  APPRENDRE À COMPTER — Or Eille AI v1.0
//  Par ce qu'on aime · adapté à la monnaie locale
//  Sans étiquette · sans honte · à son rythme
//  © 2026 Madame Or Eille Studios
// ═══════════════════════════════════════════════════

const NUMERACY = {
  KEY: 'moe_numeracy',

  DOMAINS: {
    marche:   { label:'Le marché',        icon:'🛒', desc:'prix, monnaie, peser, rendre la monnaie' },
    cuisine:  { label:'Cuisine',          icon:'🍳', desc:'quantités, portions, temps de cuisson' },
    sport:    { label:'Sport',            icon:'⚽', desc:'scores, temps, distances, statistiques' },
    argent:   { label:'Gérer son argent', icon:'💰', desc:'budget, dépenses, économies simples' },
    famille:  { label:'Vie quotidienne',  icon:'🏠', desc:'dates, heures, partager équitablement' },
  },

  CURRENCIES: {
    eur: 'Euro — €',
    xof: 'Franc CFA — FCFA',
    usd: 'Dollar — $',
    gbp: 'Livre sterling — £',
    mad: 'Dirham — MAD',
    dzd: 'Dinar algérien — DA',
    cad: 'Dollar canadien — CAD',
    htg: 'Gourde haïtienne — HTG',
  },

  LEVELS: {
    chiffres: 'Je reconnais les chiffres',
    compter:  'Je compte jusqu à 20',
    operations:'J additionne et soustrais',
    monnaie:  'Je gère de la monnaie',
    budget:   'Je fais un budget simple',
  },

  get() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || {
      domain:'marche', level:'chiffres', currency:'eur', country:'', sessions:0
    }; }
    catch { return { domain:'marche', level:'chiffres', currency:'eur', country:'', sessions:0 }; }
  },
  save(d) { localStorage.setItem(this.KEY, JSON.stringify(d)); },

  async getLesson(claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    const d = this.get();
    const domain = this.DOMAINS[d.domain];
    const level = this.LEVELS[d.level];
    const currency = this.CURRENCIES[d.currency] || 'Euro';
    if (window.addChatMsg) addChatMsg('assistant','Lecon de calcul — ' + (domain?domain.label:'') + '...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:500,
          messages:[{ role:'user', content:
            'Exercice de calcul de 5 minutes. Niveau : ' + level + '. Domaine : ' + (domain?domain.label+' — '+domain.desc:'vie quotidienne') + '. Monnaie locale : ' + currency + (d.country ? '. Pays ou ville : ' + d.country : '') + '. Utilise des exemples concrets de la vie reelle de cette personne — prix du marche local, produits courants. Exercice progressif, bienveillant. On ne dit jamais qu on apprend a compter. Termine par un encouragement chaleureux.'
          }]
        })
      });
      const data = await r.json();
      d.sessions++;
      this.save(d);
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
      var self=this; setTimeout(function(){self.celebrate(d.sessions);},1000);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  async analyzeWriting(imageData, claudeKey) {
    if (!claudeKey) { if (window.addChatMsg) addChatMsg('assistant','Cle API requise.'); return; }
    if (window.addChatMsg) addChatMsg('assistant','Je regarde tes chiffres...');
    try {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method:'POST',
        headers:{'Content-Type':'application/json','x-api-key':claudeKey,'anthropic-version':'2023-06-01'},
        body: JSON.stringify({
          model:'claude-sonnet-4-20250514', max_tokens:400,
          messages:[{ role:'user', content:[
            { type:'image', source:{ type:'base64', media_type:'image/jpeg', data:imageData } },
            { type:'text', text:'Regarde les chiffres ecrits. Dis ce qui est bien forme. Indique doucement une seule chose a ameliorer. Encourage. Jamais de jugement.' }
          ]}]
        })
      });
      const data = await r.json();
      if (window.addChatMsg) addChatMsg('assistant', data.content[0].text);
    } catch(e) { if (window.addChatMsg) addChatMsg('assistant','Erreur. Verifiez votre connexion.'); }
  },

  startWritingAnalysis: function() {
    var f = document.getElementById('num-writing-photo');
    if (!f || !f.files[0]) { if (window.addChatMsg) addChatMsg('assistant','Prends une photo de tes chiffres.'); return; }
    var reader = new FileReader();
    reader.onload = function(e) { NUMERACY.analyzeWriting(e.target.result.split(',')[1], window.CFG && window.CFG.CLAUDE_KEY); };
    reader.readAsDataURL(f.files[0]);
  },

  renderPanel: function() {
    const d = this.get();
    return '<div style="padding:1.1rem;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:.8rem">' +
      '<div class="sec-title">🔢 Apprendre à compter</div>' +
      '<p class="note">Avec les prix de ton marché. Ta monnaie. Ta vie réelle. Sans honte. À ton rythme.</p>' +

      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.4rem">' +
        '<div><span class="klabel">Ce qui m interesse</span>' +
        '<select id="num-domain" onchange="var d2=NUMERACY.get();d2.domain=this.value;NUMERACY.save(d2)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.DOMAINS).map(function(e){return '<option value="'+e[0]+'" '+(d.domain===e[0]?'selected':'')+'>'+e[1].icon+' '+e[1].label+'</option>';}).join('') +
        '</select></div>' +

        '<div><span class="klabel">Mon niveau</span>' +
        '<select id="num-level" onchange="var d2=NUMERACY.get();d2.level=this.value;NUMERACY.save(d2)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.LEVELS).map(function(e){return '<option value="'+e[0]+'" '+(d.level===e[0]?'selected':'')+'>'+e[1]+'</option>';}).join('') +
        '</select></div>' +

        '<div><span class="klabel">Ma monnaie</span>' +
        '<select id="num-currency" onchange="var d2=NUMERACY.get();d2.currency=this.value;NUMERACY.save(d2)" style="width:100%;margin-top:.2rem;background:var(--dark-mid);border:1px solid var(--border);color:var(--text);font-family:Josefin Sans,sans-serif;font-size:.5rem;padding:.3rem;outline:none">' +
          Object.entries(this.CURRENCIES).map(function(e){return '<option value="'+e[0]+'" '+(d.currency===e[0]?'selected':'')+'>'+e[1]+'</option>';}).join('') +
        '</select></div>' +

        '<div><span class="klabel">Ma ville</span>' +
        '<input type="text" value="'+(d.country||'')+'" placeholder="Ex: Dakar, Paris, Kinshasa..." onchange="var d2=NUMERACY.get();d2.country=this.value;NUMERACY.save(d2)" style="margin-top:.2rem"/></div>' +
      '</div>' +

      '<button class="btn btn-gold" onclick="NUMERACY.getLesson(window.CFG&&window.CFG.CLAUDE_KEY)">🔢 Ma lecon du jour — 5 minutes</button>' +

      '<div class="sep"></div>' +
      '<div class="sec-title">📸 J ai écrit des chiffres — corrige-moi</div>' +
      '<p class="note">Sur du papier, du sable, une ardoise — prends une photo.</p>' +
      '<input type="file" accept="image/*" id="num-writing-photo" style="font-size:.5rem;color:var(--muted)"/>' +
      '<button class="btn btn-ghost" onclick="NUMERACY.startWritingAnalysis()">📸 Regarder mes chiffres</button>' +

    '</div>';
  }
};

NUMERACY.celebrate = function(sessions) {
  var msgs = ['Bravo !','Bien joue !','Tu avances !','Continue comme ca !'];
  var msg = msgs[Math.floor(Math.random() * msgs.length)];
  var milestone = '';
  if (sessions === 7)  milestone = ' Une semaine de calcul — tu geres ton quotidien mieux !';
  if (sessions === 15) milestone = ' Quinze jours — tu comptes des choses que tu ne comptais pas avant !';
  if (sessions === 30) milestone = ' Un mois — regarde tout ce chemin parcouru !';
  if (window.addChatMsg) addChatMsg('assistant', msg + milestone);
};


window.NUMERACY = NUMERACY;
