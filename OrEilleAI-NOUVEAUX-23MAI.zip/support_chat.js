// ============================================================
// SUPPORT CHAT — Or Eille AI v20
// Chatbot intelligent multilingue — propulsé par Claude
// "Votre assistant m'a contactée. Je suis là."
// © 2026 Madame Or Eille Studios
// ============================================================

const SUPPORT_CHAT = {

  // ── CONFIG ─────────────────────────────────────────────────
  config: {
    nomAssistant: 'votre assistant',   // Remplacé dynamiquement par le nom de l'assistant de l'utilisateur
    nomSupport:   'Or Eille',
    avatarSupport: '👂',
    couleur:       '#0288d1',
    maxMessages:   50,
    delaiReponse:  800,                // ms — légère pause pour sembler humain
  },

  // ── STATE ───────────────────────────────────────────────────
  state: {
    ouvert:       false,
    messages:     [],
    enAttente:    false,
    ticketEnvoye: false,
    langue:       'fr',
    sessionId:    null,
  },

  // ── SYSTÈME PROMPT CLAUDE ───────────────────────────────────
  buildSystemPrompt() {
    return `Tu es le service de support de Or Eille AI, une application multilingue et multiculturelle destinée principalement à la diaspora africaine et francophone dans le monde.

TON RÔLE :
- Tu t'appelles "Or Eille Support"
- Tu as été contactée par l'assistant personnel de l'utilisateur (${this.config.nomAssistant}) qui t'a signalé que l'utilisateur avait besoin d'aide
- Tu parles avec chaleur, simplicité et humanité — jamais comme un robot
- Tu détectes automatiquement la langue de l'utilisateur et tu réponds dans cette langue
- Tu essaies vraiment de résoudre le problème avant toute autre chose

PROBLÈMES QUE TU PEUX RÉSOUDRE SEULE :
- Mot de passe oublié → guide vers la réinitialisation
- Problème de connexion → vérifie email, navigateur, cache
- Module qui ne charge pas → vide le cache, recharge, essaie un autre navigateur
- Paiement refusé → vérifications courantes Stripe, carte, fonds
- Email non reçu → vérifie spams, whitelist l'adresse
- Question sur un module → explique son fonctionnement
- Abonnement → explique les options disponibles
- Traduction → explique comment changer de langue
- Problème d'affichage → guide le diagnostic

COMMENT TU TRAVAILLES :
1. Tu écoutes d'abord — tu laisses l'utilisateur tout expliquer avec ses mots
2. Tu reformules ce que tu as compris pour confirmer
3. Tu proposes une solution claire, étape par étape
4. Si la première solution ne marche pas, tu essaies une autre
5. Tu ne proposes un ticket humain QUE si vraiment aucune solution ne fonctionne après plusieurs tentatives
6. En cas de panne générale (tu le saurais via le statut système) — tu expliques calmement que ce n'est pas lié à l'utilisateur et que l'équipe est dessus

TON TON :
- Chaleureux, patient, jamais condescendant
- "Je t'entends", "On va régler ça ensemble", "C'est tout à fait normal"
- Jamais : "Erreur", "Non valide", "Ce n'est pas dans mes possibilités"
- Toujours : "Voilà ce qu'on peut essayer", "Est-ce que ça a changé quelque chose ?"

IMPORTANT :
- Ne jamais demander de mot de passe
- Ne jamais promettre ce que tu ne peux pas tenir
- Si tu ne sais pas — dis-le honnêtement et propose de transmettre à l'équipe
- Maximum de bienveillance, minimum de jargon technique`;
  },

  // ── MESSAGE D'ACCUEIL ───────────────────────────────────────
  messageAccueil() {
    const nom = this.config.nomAssistant;
    const messages = {
      fr: `${nom} m'a contactée — il·elle m'a dit que vous aviez besoin d'aide. Je suis là. Décrivez-moi avec vos mots ce qui se passe.`,
      en: `${nom} reached out to me — they told me you needed help. I'm here. Tell me in your own words what's happening.`,
      es: `${nom} me contactó — me dijo que necesitabas ayuda. Estoy aquí. Cuéntame con tus propias palabras qué está pasando.`,
      pt: `${nom} entrou em contato comigo — me disse que você precisava de ajuda. Estou aqui. Me conte com suas próprias palavras o que está acontecendo.`,
      ln: `${nom} azali koloba que ozali na nzela. Nazali awa. Tango ya koloba na ngai oyo ezali kosalema.`,
    };
    return messages[this.state.langue] || messages['fr'];
  },

  // ── INITIALISATION ──────────────────────────────────────────
  init() {
    this.state.sessionId = 'support_' + Date.now();
    // Récupérer le nom de l'assistant depuis l'app si disponible
    if(window.OREILLE_CONFIG?.nomAssistant) {
      this.config.nomAssistant = window.OREILLE_CONFIG.nomAssistant;
    }
    // Détecter la langue du navigateur
    const lang = navigator.language?.split('-')[0] || 'fr';
    this.state.langue = ['fr','en','es','pt','ln'].includes(lang) ? lang : 'fr';

    this.injectUI();
    console.log('✅ Support Chat — module chargé');
  },

  // ── INJECTION UI ────────────────────────────────────────────
  injectUI() {
    // Bouton flottant
    const btn = document.createElement('div');
    btn.id = 'sc-btn';
    btn.innerHTML = `<span class="sc-btn-icon">👂</span><span class="sc-btn-label">Aide</span>`;
    btn.addEventListener('click', () => this.toggle());
    document.body.appendChild(btn);

    // Fenêtre chat
    const win = document.createElement('div');
    win.id = 'sc-window';
    win.style.display = 'none';
    win.innerHTML = `
      <div class="sc-header">
        <div class="sc-header-left">
          <div class="sc-avatar">👂</div>
          <div>
            <div class="sc-titre">Or Eille Support</div>
            <div class="sc-statut" id="sc-statut">🟢 En ligne</div>
          </div>
        </div>
        <button class="sc-close" id="sc-close">✕</button>
      </div>
      <div class="sc-messages" id="sc-messages"></div>
      <div class="sc-saisie">
        <textarea class="sc-input" id="sc-input" placeholder="Décrivez votre problème..." rows="2" maxlength="2000"></textarea>
        <button class="sc-envoyer" id="sc-envoyer">→</button>
      </div>
      <div class="sc-footer">
        <span id="sc-ticket-link" class="sc-ticket-link" style="display:none">
          Toujours bloqué ? <span id="sc-ouvrir-ticket">Transmettre à l'équipe →</span>
        </span>
      </div>
    `;
    document.body.appendChild(win);

    document.getElementById('sc-close').addEventListener('click', () => this.fermer());
    document.getElementById('sc-envoyer').addEventListener('click', () => this.envoyer());
    document.getElementById('sc-input').addEventListener('keydown', (e) => {
      if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); this.envoyer(); }
    });
    document.getElementById('sc-ouvrir-ticket')?.addEventListener('click', () => this.ouvrirTicket());

    this.injectStyles();
  },

  // ── TOGGLE ──────────────────────────────────────────────────
  toggle() {
    this.state.ouvert ? this.fermer() : this.ouvrir();
  },

  ouvrir() {
    this.state.ouvert = true;
    const win = document.getElementById('sc-window');
    if(win) win.style.display = 'flex';
    // Premier message si conversation vide
    if(this.state.messages.length === 0) {
      setTimeout(() => {
        this.afficherMessage('support', this.messageAccueil());
      }, 400);
    }
    document.getElementById('sc-input')?.focus();
  },

  fermer() {
    this.state.ouvert = false;
    const win = document.getElementById('sc-window');
    if(win) win.style.display = 'none';
  },

  // ── ENVOI MESSAGE ───────────────────────────────────────────
  async envoyer() {
    const input = document.getElementById('sc-input');
    const texte = input?.value?.trim();
    if(!texte || this.state.enAttente) return;

    // Sanitisation basique
    const texteSafe = texte
      .replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .slice(0, 2000);

    input.value = '';
    this.afficherMessage('utilisateur', texteSafe);
    this.state.messages.push({ role: 'user', content: texte });

    // Afficher indicateur de frappe
    this.state.enAttente = true;
    this.afficherTyping();

    try {
      const reponse = await this.appelClaude();
      this.supprimerTyping();
      this.afficherMessage('support', reponse);
      this.state.messages.push({ role: 'assistant', content: reponse });

      // Après 3 échanges sans résolution, proposer le ticket
      if(this.state.messages.filter(m=>m.role==='user').length >= 3 && !this.state.ticketEnvoye) {
        const ticketLink = document.getElementById('sc-ticket-link');
        if(ticketLink) ticketLink.style.display = 'block';
      }

    } catch(err) {
      this.supprimerTyping();
      this.afficherMessage('support', this._msgErreur());
    }

    this.state.enAttente = false;
  },

  // ── APPEL API CLAUDE ────────────────────────────────────────
  async appelClaude() {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: this.buildSystemPrompt(),
        messages: this.state.messages,
      })
    });

    if(!response.ok) throw new Error('API error ' + response.status);
    const data = await response.json();
    return data.content?.[0]?.text || this._msgErreur();
  },

  // ── AFFICHAGE MESSAGES ──────────────────────────────────────
  afficherMessage(role, texte) {
    const container = document.getElementById('sc-messages');
    if(!container) return;

    const div = document.createElement('div');
    div.className = 'sc-message sc-message-' + role;

    if(role === 'support') {
      div.innerHTML = `<span class="sc-msg-avatar">👂</span><div class="sc-msg-bulle">${texte}</div>`;
    } else {
      div.innerHTML = `<div class="sc-msg-bulle sc-msg-bulle-user">${texte}</div>`;
    }

    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
  },

  afficherTyping() {
    const container = document.getElementById('sc-messages');
    if(!container) return;
    const div = document.createElement('div');
    div.className = 'sc-message sc-message-support';
    div.id = 'sc-typing';
    div.innerHTML = `<span class="sc-msg-avatar">👂</span><div class="sc-msg-bulle sc-typing"><span></span><span></span><span></span></div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
  },

  supprimerTyping() {
    document.getElementById('sc-typing')?.remove();
  },

  // ── TICKET ──────────────────────────────────────────────────
  ouvrirTicket() {
    if(this.state.ticketEnvoye) return;
    this.state.ticketEnvoye = true;

    // Résumé de la conversation pour Mahamadou
    const resume = this.state.messages
      .map(m => (m.role === 'user' ? '👤 ' : '👂 ') + m.content)
      .join('\n\n');

    console.log('[Or Eille Support] Ticket transmis — Session:', this.state.sessionId);
    console.log('[Résumé conversation]:\n', resume);

    const msg = {
      fr: "Votre problème a été transmis à notre équipe. Ils reviendront vers vous dans les meilleurs délais. Merci pour votre patience. 🫶",
      en: "Your issue has been forwarded to our team. They'll get back to you as soon as possible. Thank you for your patience. 🫶",
      es: "Su problema ha sido enviado a nuestro equipo. Le responderemos a la brevedad posible. Gracias por su paciencia. 🫶",
    };
    this.afficherMessage('support', msg[this.state.langue] || msg['fr']);
    const ticketLink = document.getElementById('sc-ticket-link');
    if(ticketLink) ticketLink.style.display = 'none';
  },

  // ── MESSAGE D'ERREUR ────────────────────────────────────────
  _msgErreur() {
    const msgs = {
      fr: "Je rencontre une petite difficulté technique de mon côté. Pouvez-vous réessayer dans quelques instants ?",
      en: "I'm experiencing a small technical issue on my end. Could you try again in a moment?",
      es: "Estoy experimentando un pequeño problema técnico. ¿Podría intentarlo de nuevo en un momento?",
    };
    return msgs[this.state.langue] || msgs['fr'];
  },

  // ── STATUT SYSTÈME ──────────────────────────────────────────
  // Appeler depuis l'admin en cas d'incident
  setStatut(niveau, message) {
    // niveau: 'ok' | 'perturbation' | 'panne'
    const icones = { ok:'🟢', perturbation:'🟠', panne:'🔴' };
    const messages = {
      ok:           'En ligne',
      perturbation: 'Perturbations en cours',
      panne:        'Notre oreille se soigne — de retour bientôt',
    };
    const statutEl = document.getElementById('sc-statut');
    if(statutEl) {
      statutEl.textContent = (icones[niveau] || '🟡') + ' ' + (message || messages[niveau] || niveau);
    }
    // En cas de panne — message automatique dans le chat
    if(niveau === 'panne') {
      this.state.messages = [];
      setTimeout(() => {
        this.afficherMessage('support',
          message || "Notre oreille est un peu bouchée en ce moment. On est chez l'ORL — on revient très vite pour mieux vous entendre. 🫶"
        );
      }, 500);
    }
  },

  // ── STYLES ──────────────────────────────────────────────────
  injectStyles() {
    const s = document.createElement('style');
    s.textContent = `
#sc-btn{position:fixed;bottom:24px;right:24px;z-index:9999;background:linear-gradient(135deg,#0288d1,#026da3);color:#fff;border-radius:50px;padding:12px 20px;display:flex;align-items:center;gap:8px;cursor:pointer;box-shadow:0 4px 20px rgba(2,136,209,.4);font-size:.9em;font-weight:700;transition:transform .2s}
#sc-btn:hover{transform:scale(1.05)}
.sc-btn-icon{font-size:1.2em}
#sc-window{position:fixed;bottom:90px;right:24px;z-index:9998;width:360px;max-height:520px;background:#1a1a2e;border:1px solid rgba(255,255,255,.1);border-radius:16px;box-shadow:0 8px 40px rgba(0,0,0,.5);flex-direction:column;overflow:hidden;font-family:inherit}
.sc-header{background:linear-gradient(135deg,#0288d1,#026da3);padding:14px 16px;display:flex;align-items:center;justify-content:space-between}
.sc-header-left{display:flex;align-items:center;gap:10px}
.sc-avatar{font-size:1.8em;background:rgba(255,255,255,.15);border-radius:50%;width:42px;height:42px;display:flex;align-items:center;justify-content:center}
.sc-titre{color:#fff;font-weight:700;font-size:.95em}
.sc-statut{color:rgba(255,255,255,.8);font-size:.75em;margin-top:2px}
.sc-close{background:transparent;border:none;color:rgba(255,255,255,.7);font-size:1.1em;cursor:pointer;padding:4px 8px;border-radius:4px}
.sc-close:hover{color:#fff;background:rgba(255,255,255,.1)}
.sc-messages{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:12px;min-height:200px;max-height:320px}
.sc-message{display:flex;align-items:flex-end;gap:8px}
.sc-message-utilisateur{justify-content:flex-end}
.sc-msg-avatar{font-size:1.3em;flex-shrink:0}
.sc-msg-bulle{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.1);border-radius:12px 12px 12px 0;padding:10px 14px;font-size:.88em;color:#ddd;line-height:1.5;max-width:260px}
.sc-msg-bulle-user{background:rgba(2,136,209,.25);border-color:rgba(2,136,209,.4);border-radius:12px 12px 0 12px;color:#fff;margin-left:auto}
.sc-typing{display:flex;gap:4px;align-items:center;padding:12px 14px}
.sc-typing span{width:7px;height:7px;background:#4fc3f7;border-radius:50%;animation:sc-bounce .9s infinite}
.sc-typing span:nth-child(2){animation-delay:.15s}
.sc-typing span:nth-child(3){animation-delay:.3s}
@keyframes sc-bounce{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-6px)}}
.sc-saisie{display:flex;gap:8px;padding:12px;border-top:1px solid rgba(255,255,255,.08);background:rgba(0,0,0,.2)}
.sc-input{flex:1;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);border-radius:8px;padding:9px 12px;color:#fff;font-size:.88em;font-family:inherit;resize:none;line-height:1.4}
.sc-input:focus{outline:none;border-color:#0288d1}
.sc-input::placeholder{color:#666}
.sc-envoyer{background:#0288d1;border:none;color:#fff;border-radius:8px;width:38px;cursor:pointer;font-size:1.1em;flex-shrink:0;transition:opacity .2s}
.sc-envoyer:hover{opacity:.85}
.sc-footer{padding:8px 14px;font-size:.78em;text-align:center;color:#666;border-top:1px solid rgba(255,255,255,.05)}
.sc-ticket-link{color:#aaa}
#sc-ouvrir-ticket{color:#4fc3f7;cursor:pointer;text-decoration:underline}
#sc-ouvrir-ticket:hover{color:#fff}
@media(max-width:400px){#sc-window{width:calc(100vw - 20px);right:10px}}
    `;
    document.head.appendChild(s);
  },

};

window.addEventListener('load', () => SUPPORT_CHAT.init());
