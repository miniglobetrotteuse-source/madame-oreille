// ============================================================
// AUTH SESSION — Or Eille AI v20
// Authentification inclusive — lien magique, emojis, hors ligne
// "Tout le monde mérite d'entrer sans barrière."
// © 2026 Madame Or Eille Studios
// ============================================================

const AUTH_SESSION = {

  // ── CONFIG ─────────────────────────────────────────────────
  config: {
    dureeSession:    90,          // jours — "se souvenir de moi"
    dureeSessionCourte: 1,        // jour — sans "se souvenir de moi"
    duréeLienMagique: 15,         // minutes — expiration lien magique
    cleStockage:     'oreille_session_v1',
    cleToken:        'oreille_token_v1',
    cleOffline:      'oreille_offline_v1',
  },

  // ── EMOJIS DE CONNEXION ─────────────────────────────────────
  // 3 emojis parmi 9 — universel, sans alphabet latin
  tousLesEmojis: ['🌙','⭐','🌍','🎵','🌺','🦋','🌊','🔥','🌿'],

  // ── STATE ───────────────────────────────────────────────────
  state: {
    connecte:      false,
    utilisateur:   null,
    token:         null,
    modeOffline:   false,
    seuvenir:      true,
    codeEmojis:    [],            // les 3 emojis générés pour cette session
  },

  // ── INIT ────────────────────────────────────────────────────
  init() {
    this.verifierSessionExistante();
    this.renderPanel();
    console.log('✅ Auth Session — module chargé');
  },

  // ── VÉRIFICATION SESSION EXISTANTE ─────────────────────────
  verifierSessionExistante() {
    try {
      const token = localStorage.getItem(this.config.cleToken);
      const session = localStorage.getItem(this.config.cleStockage);

      if(token && session) {
        const data = JSON.parse(session);
        const expiration = new Date(data.expiration);

        if(expiration > new Date()) {
          // Session valide
          this.state.connecte   = true;
          this.state.token      = token;
          this.state.utilisateur = data.utilisateur;
          console.log('[Auth] Session restaurée pour', data.utilisateur?.email || 'utilisateur');
          this.onConnexionReussie(data.utilisateur, false);
          return;
        } else {
          // Session expirée — nettoyage
          this.deconnecter(true);
        }
      }

      // Mode hors ligne — token offline
      const tokenOffline = localStorage.getItem(this.config.cleOffline);
      if(tokenOffline && !navigator.onLine) {
        const dataOff = JSON.parse(tokenOffline);
        this.state.connecte   = true;
        this.state.modeOffline = true;
        this.state.utilisateur = dataOff.utilisateur;
        console.log('[Auth] Mode hors ligne activé');
        this.onConnexionReussie(dataOff.utilisateur, false);
      }

    } catch(e) {
      console.warn('[Auth] Erreur lecture session:', e.message);
      this.deconnecter(true);
    }
  },

  // ── RENDER PANEL ────────────────────────────────────────────
  renderPanel() {
    const panel = document.getElementById('panel-auth');
    if(!panel) return;

    if(this.state.connecte) {
      panel.innerHTML = this.renderConnecte();
    } else {
      panel.innerHTML = this.renderFormConnexion();
    }
    this.attachEvents();
  },

  // ── FORMULAIRE DE CONNEXION ─────────────────────────────────
  renderFormConnexion() {
    return `
    <div class="auth-container">
      <div class="auth-logo">👂</div>
      <div class="auth-titre">Or Eille AI</div>
      <div class="auth-sous-titre">Entrez sans barrière</div>

      <div class="auth-tabs">
        <button class="auth-tab actif" id="tab-magique">📧 Lien magique</button>
        <button class="auth-tab" id="tab-emojis">🌙 Code emojis</button>
      </div>

      <!-- LIEN MAGIQUE -->
      <div class="auth-section" id="section-magique">
        <div class="auth-explication">
          Entrez votre email — on vous envoie un lien. Un clic et vous êtes connecté. Pas de mot de passe à retenir.
        </div>
        <input
          class="auth-input"
          id="auth-email"
          type="email"
          placeholder="votre@email.com"
          autocomplete="email"
          maxlength="200"
        />
        <label class="auth-souvenir">
          <input type="checkbox" id="auth-souvenir" checked/>
          <span>Se souvenir de moi pendant 90 jours</span>
        </label>
        <button class="auth-btn-principal" id="auth-envoyer-lien">
          Recevoir mon lien magique →
        </button>
        <div class="auth-confirmation" id="auth-conf-email" style="display:none">
          ✉️ Lien envoyé ! Vérifiez votre boîte mail — et les spams si besoin.
        </div>
      </div>

      <!-- CODE EMOJIS -->
      <div class="auth-section" id="section-emojis" style="display:none">
        <div class="auth-explication">
          Choisissez 3 emojis dans le bon ordre — votre code secret visuel. Universel, sans alphabet.
        </div>

        <div class="auth-emoji-sous-titre">Votre code :</div>
        <div class="auth-emoji-code" id="auth-emoji-choisi">
          <span class="auth-emoji-slot" id="slot-0">?</span>
          <span class="auth-emoji-slot" id="slot-1">?</span>
          <span class="auth-emoji-slot" id="slot-2">?</span>
        </div>

        <div class="auth-emoji-grille" id="auth-emoji-grille">
          ${this.tousLesEmojis.map(e =>
            `<button class="auth-emoji-btn" data-emoji="${e}">${e}</button>`
          ).join('')}
        </div>

        <button class="auth-btn-secondaire" id="auth-emoji-effacer">← Effacer</button>
        <button class="auth-btn-principal" id="auth-valider-emojis" style="display:none">
          Confirmer mon code →
        </button>
        <div class="auth-explication-petit">
          Première fois ? Ce code sera votre identifiant permanent. Mémorisez ces 3 emojis.
        </div>
      </div>

    </div>`;
  },

  // ── INTERFACE CONNECTÉ ──────────────────────────────────────
  renderConnecte() {
    const u = this.state.utilisateur;
    const email = u?.email || '';
    const offline = this.state.modeOffline;

    return `
    <div class="auth-container">
      <div class="auth-connecte-badge">
        ${offline ? '📴 Mode hors ligne' : '🟢 Connecté'}
      </div>
      <div class="auth-logo">👂</div>
      <div class="auth-titre">Bienvenue</div>
      ${email ? `<div class="auth-email-affiche">${this._masquerEmail(email)}</div>` : ''}
      ${offline ? `<div class="auth-offline-msg">Vous utilisez l'app hors ligne. Vos données se synchroniseront dès que vous aurez une connexion.</div>` : ''}
      <button class="auth-btn-secondaire" id="auth-deconnecter" style="margin-top:20px">
        Se déconnecter
      </button>
    </div>`;
  },

  // ── EVENTS ──────────────────────────────────────────────────
  attachEvents() {
    // Tabs
    document.getElementById('tab-magique')?.addEventListener('click', () => {
      this.switchTab('magique');
    });
    document.getElementById('tab-emojis')?.addEventListener('click', () => {
      this.switchTab('emojis');
      this.genererCodeEmojis();
    });

    // Lien magique
    document.getElementById('auth-envoyer-lien')?.addEventListener('click', () => {
      this.envoyerLienMagique();
    });
    document.getElementById('auth-email')?.addEventListener('keydown', (e) => {
      if(e.key === 'Enter') this.envoyerLienMagique();
    });

    // Emojis
    document.querySelectorAll('.auth-emoji-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.selectionnerEmoji(btn.dataset.emoji);
      });
    });
    document.getElementById('auth-emoji-effacer')?.addEventListener('click', () => {
      this.effacerDernierEmoji();
    });
    document.getElementById('auth-valider-emojis')?.addEventListener('click', () => {
      this.validerEmojis();
    });

    // Déconnexion
    document.getElementById('auth-deconnecter')?.addEventListener('click', () => {
      this.deconnecter();
    });
  },

  switchTab(tab) {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('actif'));
    document.getElementById('tab-' + tab)?.classList.add('actif');
    document.getElementById('section-magique').style.display = tab === 'magique' ? 'block' : 'none';
    document.getElementById('section-emojis').style.display  = tab === 'emojis'  ? 'block' : 'none';
  },

  // ── LIEN MAGIQUE ────────────────────────────────────────────
  envoyerLienMagique() {
    const emailEl = document.getElementById('auth-email');
    const email   = emailEl?.value?.trim().toLowerCase();

    if(!email || !this._validerEmail(email)) {
      emailEl?.classList.add('auth-input-erreur');
      setTimeout(() => emailEl?.classList.remove('auth-input-erreur'), 2000);
      return;
    }

    const souvenir = document.getElementById('auth-souvenir')?.checked;
    this.state.seuvenir = souvenir;

    // Générer token magique
    const token   = this._genererToken();
    const expMagique = new Date(Date.now() + this.config.duréeLienMagique * 60 * 1000);

    // Stocker temporairement en attente de validation
    try {
      localStorage.setItem('oreille_magic_pending', JSON.stringify({
        email, token, expiration: expMagique.toISOString(), souvenir
      }));
    } catch(e) { console.warn('[Auth] Stockage lien magique:', e.message); }

    // Simuler envoi email (Mahamadou branche sur son backend)
    console.log('[Auth] Lien magique généré pour:', email);
    console.log('[Auth] Token (à envoyer par email):', token);
    console.log('[Auth] Expiration:', expMagique.toISOString());

    // Afficher confirmation
    const conf = document.getElementById('auth-conf-email');
    const btn  = document.getElementById('auth-envoyer-lien');
    if(conf) conf.style.display = 'block';
    if(btn)  { btn.disabled = true; btn.textContent = 'Lien envoyé ✓'; }

    // NOTE MAHAMADOU: Appeler ici votre API d'envoi email
    // ex: fetch('/api/send-magic-link', { method:'POST', body: JSON.stringify({email, token}) })
  },

  // Appelé quand l'utilisateur clique sur le lien dans l'email
  validerLienMagique(token) {
    try {
      const pending = JSON.parse(localStorage.getItem('oreille_magic_pending') || '{}');
      if(!pending.token || pending.token !== token) {
        console.warn('[Auth] Token invalide');
        return false;
      }
      if(new Date(pending.expiration) < new Date()) {
        console.warn('[Auth] Lien magique expiré');
        localStorage.removeItem('oreille_magic_pending');
        return false;
      }

      // Connexion réussie
      const utilisateur = { email: pending.email, methode: 'lien_magique' };
      this.creerSession(utilisateur, pending.souvenir);
      localStorage.removeItem('oreille_magic_pending');
      return true;

    } catch(e) {
      console.warn('[Auth] Erreur validation lien:', e.message);
      return false;
    }
  },

  // ── CODE EMOJIS ─────────────────────────────────────────────
  genererCodeEmojis() {
    this.state.codeEmojis = [];
    this._updateAffichageEmojis();
  },

  selectionnerEmoji(emoji) {
    if(this.state.codeEmojis.length >= 3) return;
    this.state.codeEmojis.push(emoji);
    this._updateAffichageEmojis();

    if(this.state.codeEmojis.length === 3) {
      const btn = document.getElementById('auth-valider-emojis');
      if(btn) btn.style.display = 'block';
    }
  },

  effacerDernierEmoji() {
    this.state.codeEmojis.pop();
    this._updateAffichageEmojis();
    const btn = document.getElementById('auth-valider-emojis');
    if(btn) btn.style.display = 'none';
  },

  _updateAffichageEmojis() {
    for(let i = 0; i < 3; i++) {
      const slot = document.getElementById('slot-' + i);
      if(slot) slot.textContent = this.state.codeEmojis[i] || '?';
    }
  },

  validerEmojis() {
    if(this.state.codeEmojis.length !== 3) return;
    const codeStr = this.state.codeEmojis.join('');

    // Vérifier si code existant ou créer nouveau compte
    const compteExistant = this._trouverCompteEmoji(codeStr);

    if(compteExistant) {
      this.creerSession(compteExistant, true);
    } else {
      // Nouveau compte par emojis
      const utilisateur = {
        id:      'emoji_' + Date.now(),
        methode: 'emojis',
        code:    codeStr,
      };
      this._sauvegarderCompteEmoji(codeStr, utilisateur);
      this.creerSession(utilisateur, true);
    }
  },

  _trouverCompteEmoji(code) {
    try {
      const comptes = JSON.parse(localStorage.getItem('oreille_emoji_comptes') || '{}');
      return comptes[this._hasherCode(code)] || null;
    } catch(e) { return null; }
  },

  _sauvegarderCompteEmoji(code, utilisateur) {
    try {
      const comptes = JSON.parse(localStorage.getItem('oreille_emoji_comptes') || '{}');
      comptes[this._hasherCode(code)] = utilisateur;
      localStorage.setItem('oreille_emoji_comptes', JSON.stringify(comptes));
    } catch(e) { console.warn('[Auth] Erreur sauvegarde emoji:', e.message); }
  },

  // ── GESTION SESSION ─────────────────────────────────────────
  creerSession(utilisateur, souvenir) {
    const token      = this._genererToken();
    const duree      = souvenir ? this.config.dureeSession : this.config.dureeSessionCourte;
    const expiration = new Date(Date.now() + duree * 24 * 60 * 60 * 1000);

    const sessionData = {
      utilisateur,
      expiration: expiration.toISOString(),
      crée:       new Date().toISOString(),
    };

    try {
      localStorage.setItem(this.config.cleToken, token);
      localStorage.setItem(this.config.cleStockage, JSON.stringify(sessionData));

      // Token offline — fonctionne sans wifi
      localStorage.setItem(this.config.cleOffline, JSON.stringify({
        utilisateur,
        token,
        crée: new Date().toISOString(),
      }));

    } catch(e) {
      console.warn('[Auth] Erreur création session:', e.message);
    }

    this.state.connecte    = true;
    this.state.token       = token;
    this.state.utilisateur = utilisateur;

    this.onConnexionReussie(utilisateur, true);
  },

  deconnecter(silencieux) {
    try {
      localStorage.removeItem(this.config.cleToken);
      localStorage.removeItem(this.config.cleStockage);
      // On garde le token offline pour permettre l'accès hors ligne
    } catch(e) {}

    this.state.connecte    = false;
    this.state.token       = null;
    this.state.utilisateur = null;
    this.state.modeOffline = false;

    if(!silencieux) {
      this.renderPanel();
      console.log('[Auth] Déconnexion effectuée');
    }
  },

  // ── CALLBACK CONNEXION RÉUSSIE ──────────────────────────────
  onConnexionReussie(utilisateur, nouvelleConnexion) {
    console.log('[Auth] ✅ Connecté —', utilisateur?.email || utilisateur?.methode);

    // Notifier l'app principale
    if(window.OREILLE_APP?.onConnexion) {
      window.OREILLE_APP.onConnexion(utilisateur);
    }

    // Mise à jour UI si panel ouvert
    const panel = document.getElementById('panel-auth');
    if(panel) this.renderPanel();

    // Log pour Mahamadou
    this._logSession(utilisateur, nouvelleConnexion);
  },

  // ── LOGS ────────────────────────────────────────────────────
  _logSession(utilisateur, nouvelle) {
    const log = {
      timestamp:  new Date().toISOString(),
      action:     nouvelle ? 'nouvelle_connexion' : 'session_restauree',
      methode:    utilisateur?.methode || 'inconnue',
      langue:     navigator.language || 'inconnue',
      offline:    !navigator.onLine,
      sessionId:  this.state.token?.slice(0, 8) + '...',
    };
    // Stocker les 50 derniers logs
    try {
      const logs = JSON.parse(localStorage.getItem('oreille_auth_logs') || '[]');
      logs.unshift(log);
      localStorage.setItem('oreille_auth_logs', JSON.stringify(logs.slice(0, 50)));
    } catch(e) {}
    console.log('[Auth Log]', log);
  },

  // ── UTILITAIRES ─────────────────────────────────────────────
  _genererToken() {
    const arr = new Uint8Array(32);
    if(window.crypto?.getRandomValues) {
      window.crypto.getRandomValues(arr);
    } else {
      for(let i=0; i<32; i++) arr[i] = Math.floor(Math.random()*256);
    }
    return Array.from(arr).map(b => b.toString(16).padStart(2,'0')).join('');
  },

  _hasherCode(code) {
    // Hash simple — Mahamadou remplacera par bcrypt côté serveur
    let hash = 0;
    for(let i=0; i<code.length; i++) {
      hash = ((hash << 5) - hash) + code.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash).toString(36);
  },

  _validerEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 200;
  },

  _masquerEmail(email) {
    const [local, domain] = email.split('@');
    const masque = local.slice(0,2) + '***';
    return masque + '@' + domain;
  },

  // ── STYLES ──────────────────────────────────────────────────
  injectStyles() {
    const s = document.createElement('style');
    s.textContent = `
.auth-container{padding:30px 20px;max-width:420px;margin:0 auto;color:#fff;font-family:inherit;text-align:center}
.auth-logo{font-size:3em;margin-bottom:10px}
.auth-titre{font-size:1.6em;font-weight:700;color:#4fc3f7;margin-bottom:4px}
.auth-sous-titre{font-size:.9em;color:#aaa;margin-bottom:24px}
.auth-tabs{display:flex;gap:8px;justify-content:center;margin-bottom:24px}
.auth-tab{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:#aaa;padding:9px 18px;border-radius:8px;cursor:pointer;font-size:.88em;transition:all .2s}
.auth-tab:hover{border-color:#4fc3f7;color:#fff}
.auth-tab.actif{background:rgba(79,195,247,.15);border-color:#4fc3f7;color:#4fc3f7;font-weight:600}
.auth-section{text-align:left}
.auth-explication{font-size:.88em;color:#bbb;line-height:1.6;margin-bottom:16px;background:rgba(255,255,255,.04);padding:12px 14px;border-radius:8px}
.auth-explication-petit{font-size:.78em;color:#777;line-height:1.5;margin-top:12px;text-align:center}
.auth-input{width:100%;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);border-radius:10px;padding:13px 16px;color:#fff;font-size:1em;font-family:inherit;box-sizing:border-box;margin-bottom:14px;transition:border-color .2s}
.auth-input:focus{outline:none;border-color:#4fc3f7}
.auth-input-erreur{border-color:#e74c3c!important;animation:auth-shake .3s}
@keyframes auth-shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}
.auth-souvenir{display:flex;align-items:center;gap:8px;font-size:.85em;color:#bbb;margin-bottom:16px;cursor:pointer}
.auth-souvenir input{width:16px;height:16px;accent-color:#4fc3f7}
.auth-btn-principal{width:100%;background:linear-gradient(135deg,#0288d1,#026da3);color:#fff;border:none;padding:14px;border-radius:10px;font-size:1em;font-weight:700;cursor:pointer;transition:opacity .2s;margin-bottom:10px}
.auth-btn-principal:hover{opacity:.85}
.auth-btn-principal:disabled{opacity:.5;cursor:default}
.auth-btn-secondaire{width:100%;background:transparent;border:1px solid rgba(255,255,255,.2);color:#aaa;padding:11px;border-radius:10px;font-size:.9em;cursor:pointer;transition:all .2s}
.auth-btn-secondaire:hover{border-color:#fff;color:#fff}
.auth-confirmation{background:rgba(79,195,247,.1);border:1px solid rgba(79,195,247,.3);border-radius:8px;padding:12px 14px;font-size:.88em;color:#4fc3f7;line-height:1.5;margin-top:10px}
.auth-emoji-sous-titre{font-size:.82em;color:#aaa;text-transform:uppercase;letter-spacing:1px;margin-bottom:10px}
.auth-emoji-code{display:flex;gap:12px;justify-content:center;margin-bottom:20px}
.auth-emoji-slot{font-size:2.5em;background:rgba(255,255,255,.06);border:2px solid rgba(255,255,255,.1);border-radius:12px;width:64px;height:64px;display:flex;align-items:center;justify-content:center;transition:all .2s}
.auth-emoji-grille{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:14px}
.auth-emoji-btn{font-size:2em;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:12px;cursor:pointer;transition:all .2s}
.auth-emoji-btn:hover{background:rgba(79,195,247,.15);border-color:#4fc3f7;transform:scale(1.05)}
.auth-connecte-badge{display:inline-block;background:rgba(79,195,247,.1);border:1px solid rgba(79,195,247,.3);color:#4fc3f7;padding:6px 14px;border-radius:20px;font-size:.82em;margin-bottom:20px}
.auth-email-affiche{color:#aaa;font-size:.9em;margin-bottom:16px}
.auth-offline-msg{background:rgba(240,192,64,.08);border:1px solid rgba(240,192,64,.2);border-radius:8px;padding:12px;font-size:.85em;color:#f0c040;line-height:1.5;margin-bottom:16px}
    `;
    document.head.appendChild(s);
  },

};

window.addEventListener('load', () => {
  AUTH_SESSION.injectStyles();
  AUTH_SESSION.init();
});
