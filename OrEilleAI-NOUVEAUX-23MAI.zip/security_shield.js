// ============================================================
// SECURITY SHIELD — Or Eille AI v20
// "Toute vie a de la valeur. La vôtre. Celle des autres. Sans exception."
// Charte éthique — protection, dignité, conséquences
// © 2026 Madame Or Eille Studios
// ============================================================

const SECURITY_SHIELD = {

  // ── PHILOSOPHIE FONDATRICE ──────────────────────────────────
  charte: `Toute vie a de la valeur. La vôtre. Celle des autres. Sans exception.
Le monde est suffisamment grand pour tout le monde.
Madame Or Eille n'accepte pas et n'acceptera jamais de contenu qui blesse, humilie ou déshumanise.
Si d'autres plateformes l'acceptent, ce n'est pas notre choix.`,

  // ── CONFIG ─────────────────────────────────────────────────
  config: {
    niveaux: {
      1: { duree: 30,   label: '30 jours',  associations: 1, preuve: 'email_attestation' },
      2: { duree: 90,   label: '3 mois',    associations: 1, preuve: 'journee_sur_place' },
      3: { duree: -1,   label: 'définitif', associations: 0, preuve: null },
    },
    cleInfractions: 'oreille_infractions_v1',
    cleSuspensions: 'oreille_suspensions_v1',
  },

  // ── CONTENUS INTERDITS ──────────────────────────────────────
  // Détection intelligente — pas juste des mots-clés
  categoriesInterdites: [
    {
      id: 'pedophilie',
      label: 'Contenu pédopornographique ou de prédation',
      tolerance: 0,           // zéro tolérance — bannissement immédiat
      mots: ['pedo','loli','minor','underage','grooming','solicitation enfant'],
      association: null,      // aucune association — bannissement direct
    },
    {
      id: 'racism',
      label: 'Contenu raciste ou discriminatoire',
      tolerance: 3,
      associations: [
        { nom: 'SOS Racisme', url: 'sos-racisme.org', pays: 'France' },
        { nom: 'LICRA', url: 'licra.org', pays: 'France' },
        { nom: 'CRAN', url: 'le-cran.fr', pays: 'France' },
        { nom: 'NAACP', url: 'naacp.org', pays: 'États-Unis' },
      ],
    },
    {
      id: 'homophobie',
      label: 'Contenu homophobe ou transphobie',
      tolerance: 3,
      associations: [
        { nom: 'SOS Homophobie', url: 'sos-homophobie.org', pays: 'France' },
        { nom: 'Le Refuge', url: 'le-refuge.org', pays: 'France' },
        { nom: 'ILGA', url: 'ilga.org', pays: 'International' },
      ],
    },
    {
      id: 'islamophobie',
      label: 'Contenu islamophobe',
      tolerance: 3,
      associations: [
        { nom: 'CCIF', url: 'islamophobie.net', pays: 'France' },
        { nom: 'Collectif contre l\'islamophobie', url: 'ccif.eu', pays: 'Europe' },
      ],
    },
    {
      id: 'antisemitisme',
      label: 'Contenu antisémite',
      tolerance: 3,
      associations: [
        { nom: 'CRIF', url: 'crif.org', pays: 'France' },
        { nom: 'Mémorial de la Shoah', url: 'memorialdelashoah.org', pays: 'France' },
      ],
    },
    {
      id: 'sexisme',
      label: 'Contenu sexiste ou misogyne',
      tolerance: 3,
      associations: [
        { nom: 'Fondation des Femmes', url: 'fondationdesfemmes.org', pays: 'France' },
        { nom: 'Planning Familial', url: 'planning-familial.org', pays: 'France' },
      ],
    },
    {
      id: 'handicap',
      label: 'Contenu discriminatoire envers le handicap',
      tolerance: 3,
      associations: [
        { nom: 'APF France Handicap', url: 'apf-francehandicap.org', pays: 'France' },
        { nom: 'UNAPEI', url: 'unapei.org', pays: 'France' },
      ],
    },
    {
      id: 'pornographie',
      label: 'Contenu pornographique non consenti',
      tolerance: 1,
      associations: [],
    },
  ],

  // ── ÉTAT ────────────────────────────────────────────────────
  state: {
    suspendu:    false,
    banni:       false,
    niveauActuel: 0,
  },

  // ── INIT ────────────────────────────────────────────────────
  init() {
    this.verifierStatutCompte();
    console.log('✅ Security Shield — charte éthique active');
  },

  // ── VÉRIFICATION STATUT ─────────────────────────────────────
  verifierStatutCompte() {
    try {
      const suspension = JSON.parse(localStorage.getItem(this.config.cleSuspensions) || 'null');
      if(!suspension) return;

      if(suspension.niveau === 3) {
        this.state.banni = true;
        this.afficherBannissement(suspension);
        return;
      }

      const fin = new Date(suspension.fin);
      if(fin > new Date() && !suspension.levee) {
        this.state.suspendu = true;
        this.afficherSuspension(suspension);
      }
    } catch(e) { console.warn('[Shield] Erreur vérification statut:', e.message); }
  },

  // ── ANALYSE DE CONTENU ──────────────────────────────────────
  // Appelé avant toute publication ou création de contenu
  analyserContenu(texte, type) {
    if(!texte) return { ok: true };

    const texteLower = texte.toLowerCase();

    for(const categorie of this.categoriesInterdites) {

      // Pédophilie — détection et bannissement immédiat
      if(categorie.id === 'pedophilie') {
        const detecte = categorie.mots.some(mot => texteLower.includes(mot));
        if(detecte) {
          this.declencherInfraction(categorie, texte, true);
          return { ok: false, categorie: categorie.id, immediat: true };
        }
      }

      // Autres catégories — analyse contextuelle via Claude
      // (Mahamadou branche ici l'appel API pour analyse intelligente)
    }

    return { ok: true };
  },

  // ── DÉCLENCHEMENT INFRACTION ────────────────────────────────
  declencherInfraction(categorie, contenu, immediat) {
    try {
      const infractions = JSON.parse(localStorage.getItem(this.config.cleInfractions) || '[]');

      const infraction = {
        id:        'inf_' + Date.now(),
        categorie: categorie.id,
        label:     categorie.label,
        date:      new Date().toISOString(),
        contenu:   contenu.slice(0, 500), // garder trace sans exposer
        immediat,
      };

      infractions.push(infraction);
      localStorage.setItem(this.config.cleInfractions, JSON.stringify(infractions));

      // Compter les infractions de cette catégorie
      const nbInfractions = infractions.filter(i => i.categorie === categorie.id).length;
      const niveau = immediat ? 3 : Math.min(nbInfractions, 3);

      this.appliquerSanction(niveau, categorie, infraction);

    } catch(e) { console.warn('[Shield] Erreur infraction:', e.message); }
  },

  // ── APPLICATION DE LA SANCTION ──────────────────────────────
  appliquerSanction(niveau, categorie, infraction) {
    const config  = this.config.niveaux[niveau];
    const maintenant = new Date();
    const fin = niveau === 3 ? null : new Date(maintenant.getTime() + config.duree * 24 * 60 * 60 * 1000);

    const suspension = {
      niveau,
      categorie:    categorie.id,
      label:        categorie.label,
      debut:        maintenant.toISOString(),
      fin:          fin?.toISOString() || null,
      duree:        config.label,
      associations: categorie.associations || [],
      preuve:       config.preuve,
      levee:        false,
      rembourse:    false, // jamais — CGU acceptées
    };

    try {
      localStorage.setItem(this.config.cleSuspensions, JSON.stringify(suspension));
    } catch(e) {}

    if(niveau === 3) {
      this.state.banni = true;
      this.afficherBannissement(suspension);
    } else {
      this.state.suspendu = true;
      this.afficherSuspension(suspension);
    }

    // Effacer le contenu problématique
    this.effacerContenu();

    // Log pour Mahamadou
    console.warn('[Shield] Sanction niveau', niveau, '—', categorie.label);
  },

  // ── EFFACEMENT DU CONTENU ───────────────────────────────────
  effacerContenu() {
    // Effacer tous les champs de saisie actifs
    document.querySelectorAll('textarea, input[type="text"], [contenteditable]').forEach(el => {
      el.value = '';
      el.textContent = '';
    });
    // Notifier l'app principale
    if(window.OREILLE_APP?.onContenuEfface) {
      window.OREILLE_APP.onContenuEfface();
    }
  },

  // ── AFFICHAGE SUSPENSION ────────────────────────────────────
  afficherSuspension(suspension) {
    const modal = document.createElement('div');
    modal.className = 'shield-modal';
    modal.id = 'shield-suspension';

    const assocs = suspension.associations?.map(a =>
      `<a href="https://${a.url}" target="_blank" rel="noopener noreferrer" class="shield-assoc-lien">
        ${a.nom} <span class="shield-assoc-pays">${a.pays}</span>
      </a>`
    ).join('') || '';

    const preuveTexte = suspension.preuve === 'journee_sur_place'
      ? 'une journée sur place avec attestation de présence'
      : 'un email ou attestation de contact';

    modal.innerHTML = `
      <div class="shield-modal-contenu">

        <div class="shield-logo">👂</div>

        <div class="shield-titre">Votre compte est suspendu</div>

        <div class="shield-charte">${this.charte}</div>

        <div class="shield-infraction">
          <strong>Contenu retiré :</strong> ${suspension.label}
        </div>

        <div class="shield-duree">
          Durée de suspension : <strong>${suspension.duree}</strong>
        </div>

        <div class="shield-debloquer">
          <div class="shield-debloquer-titre">Pour débloquer votre compte :</div>
          <div class="shield-etapes">
            <div class="shield-etape">
              <span class="shield-etape-num">1</span>
              <span>Prenez contact avec l'une de ces associations — en personne ou par email :</span>
            </div>
            <div class="shield-assocs">${assocs}</div>
            <div class="shield-etape">
              <span class="shield-etape-num">2</span>
              <span>Fournissez une preuve de contact — ${preuveTexte}</span>
            </div>
            <div class="shield-etape">
              <span class="shield-etape-num">3</span>
              <span>Rédigez un message d'explication et d'excuse — avec vos propres mots, pas un formulaire</span>
            </div>
          </div>
        </div>

        <div class="shield-cgu">
          Ces conditions sont inscrites dans nos CGU que vous avez acceptées lors de votre inscription.
          Aucun remboursement ne sera effectué.
        </div>

        <button class="shield-btn-soumettre" id="shield-soumettre">
          Soumettre ma demande de déblocage →
        </button>

      </div>
    `;

    document.body.appendChild(modal);
    document.getElementById('shield-soumettre')?.addEventListener('click', () => {
      this.afficherFormDeblocage(suspension);
    });
  },

  // ── FORMULAIRE DE DÉBLOCAGE ─────────────────────────────────
  afficherFormDeblocage(suspension) {
    const existing = document.getElementById('shield-form-deblocage');
    if(existing) existing.remove();

    const form = document.createElement('div');
    form.id = 'shield-form-deblocage';
    form.className = 'shield-modal';
    form.innerHTML = `
      <div class="shield-modal-contenu">
        <div class="shield-titre">Demande de déblocage</div>

        <div class="shield-form-section">
          <label class="shield-label">Association contactée</label>
          <input class="shield-input" id="shield-assoc-nom" type="text" placeholder="Nom de l'association..." maxlength="200"/>
        </div>

        <div class="shield-form-section">
          <label class="shield-label">Preuve de contact (lien, référence, date)</label>
          <input class="shield-input" id="shield-preuve" type="text" placeholder="Date de visite, email reçu, attestation..." maxlength="500"/>
        </div>

        <div class="shield-form-section">
          <label class="shield-label">Votre message d'explication et d'excuse — avec vos propres mots</label>
          <textarea class="shield-textarea" id="shield-excuse" rows="6" maxlength="3000"
            placeholder="Expliquez ce que vous avez compris, ce que vous ressentez, pourquoi cela ne se reproduira pas..."></textarea>
          <div class="shield-hint">Minimum 200 caractères. Pas un formulaire — de vrais mots.</div>
        </div>

        <button class="shield-btn-soumettre" id="shield-envoyer-deblocage">
          Envoyer ma demande →
        </button>
        <div class="shield-confirmation" id="shield-conf-deblocage" style="display:none">
          ✅ Demande reçue. Notre équipe l'examinera dans les meilleurs délais.
        </div>
      </div>
    `;

    document.body.appendChild(form);

    document.getElementById('shield-envoyer-deblocage')?.addEventListener('click', () => {
      const assoc  = document.getElementById('shield-assoc-nom')?.value?.trim();
      const preuve = document.getElementById('shield-preuve')?.value?.trim();
      const excuse = document.getElementById('shield-excuse')?.value?.trim();

      if(!assoc)               { alert('Indiquez l\'association contactée.'); return; }
      if(!preuve)              { alert('Fournissez une preuve de contact.'); return; }
      if(!excuse || excuse.length < 200) { alert('Votre message doit faire au moins 200 caractères.'); return; }

      // Log pour Mahamadou — il traite manuellement
      console.log('[Shield] Demande déblocage:', { assoc, preuve, excuse: excuse.slice(0,100) + '...' });

      const conf = document.getElementById('shield-conf-deblocage');
      if(conf) conf.style.display = 'block';
      document.getElementById('shield-envoyer-deblocage').disabled = true;
    });
  },

  // ── BANNISSEMENT DÉFINITIF ──────────────────────────────────
  afficherBannissement(suspension) {
    const modal = document.createElement('div');
    modal.className = 'shield-modal';
    modal.innerHTML = `
      <div class="shield-modal-contenu shield-banni">
        <div class="shield-logo">👂</div>
        <div class="shield-titre">Accès définitivement retiré</div>

        <div class="shield-charte">${this.charte}</div>

        <div class="shield-banni-msg">
          Votre compte a été définitivement fermé suite à des infractions répétées à notre charte éthique.
          <br><br>
          Cette décision est irrévocable. Aucun remboursement ne sera effectué — ces conditions étaient inscrites dans nos CGU que vous avez acceptées.
          <br><br>
          <em>Madame Or Eille vous souhaite de trouver, ailleurs, le chemin vers plus de respect et d'humanité.</em>
        </div>

        <div class="shield-cgu">
          Conditions Générales d'Utilisation — article Éthique et Dignité
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    // Bloquer toute interaction avec l'app
    document.querySelectorAll('button, input, textarea, a').forEach(el => {
      if(!el.closest('.shield-modal')) el.disabled = true;
    });
  },

  // ── STYLES ──────────────────────────────────────────────────
  injectStyles() {
    const s = document.createElement('style');
    s.textContent = `
.shield-modal{position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.92);display:flex;align-items:center;justify-content:center;padding:20px}
.shield-modal-contenu{background:#1a1a2e;border:1px solid rgba(255,255,255,.1);border-top:4px solid #e74c3c;border-radius:16px;padding:32px;max-width:560px;width:100%;max-height:90vh;overflow-y:auto;text-align:center}
.shield-logo{font-size:2.5em;margin-bottom:16px}
.shield-titre{font-size:1.3em;font-weight:700;color:#fff;margin-bottom:20px}
.shield-charte{font-size:.88em;color:#4fc3f7;font-style:italic;line-height:1.7;background:rgba(79,195,247,.07);border-left:3px solid #4fc3f7;padding:14px 18px;border-radius:0 8px 8px 0;margin-bottom:20px;text-align:left}
.shield-infraction{background:rgba(231,76,60,.1);border:1px solid rgba(231,76,60,.3);border-radius:8px;padding:12px;font-size:.88em;color:#e74c3c;margin-bottom:12px}
.shield-duree{font-size:.9em;color:#aaa;margin-bottom:24px}
.shield-debloquer{text-align:left;margin-bottom:20px}
.shield-debloquer-titre{font-size:.9em;font-weight:700;color:#fff;margin-bottom:14px}
.shield-etapes{display:flex;flex-direction:column;gap:12px}
.shield-etape{display:flex;gap:10px;align-items:flex-start;font-size:.88em;color:#ccc;line-height:1.5}
.shield-etape-num{background:#0288d1;color:#fff;border-radius:50%;width:22px;height:22px;display:flex;align-items:center;justify-content:center;font-size:.8em;font-weight:700;flex-shrink:0;margin-top:1px}
.shield-assocs{display:flex;flex-direction:column;gap:8px;margin:8px 0 8px 32px}
.shield-assoc-lien{display:flex;justify-content:space-between;align-items:center;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:8px 12px;color:#4fc3f7;text-decoration:none;font-size:.85em;transition:all .2s}
.shield-assoc-lien:hover{border-color:#4fc3f7;background:rgba(79,195,247,.1)}
.shield-assoc-pays{font-size:.75em;color:#888}
.shield-cgu{font-size:.78em;color:#666;line-height:1.5;margin:16px 0;font-style:italic}
.shield-btn-soumettre{background:linear-gradient(135deg,#0288d1,#026da3);color:#fff;border:none;padding:13px 28px;border-radius:10px;font-size:.95em;font-weight:700;cursor:pointer;width:100%;margin-top:8px}
.shield-btn-soumettre:hover{opacity:.85}
.shield-btn-soumettre:disabled{opacity:.5;cursor:default}
.shield-form-section{text-align:left;margin-bottom:16px}
.shield-label{display:block;font-size:.85em;color:#bbb;margin-bottom:6px;font-weight:600}
.shield-input{width:100%;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);border-radius:8px;padding:11px 14px;color:#fff;font-size:.9em;font-family:inherit;box-sizing:border-box}
.shield-input:focus{outline:none;border-color:#4fc3f7}
.shield-textarea{width:100%;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);border-radius:8px;padding:11px 14px;color:#fff;font-size:.9em;font-family:inherit;resize:vertical;box-sizing:border-box}
.shield-textarea:focus{outline:none;border-color:#4fc3f7}
.shield-hint{font-size:.78em;color:#777;margin-top:6px;font-style:italic}
.shield-confirmation{background:rgba(79,195,247,.1);border:1px solid rgba(79,195,247,.3);border-radius:8px;padding:12px;font-size:.88em;color:#4fc3f7;margin-top:12px}
.shield-banni{border-top-color:#8e44ad}
.shield-banni-msg{font-size:.9em;color:#ccc;line-height:1.8;margin-bottom:20px}
    `;
    document.head.appendChild(s);
  },

};

window.addEventListener('load', () => {
  SECURITY_SHIELD.injectStyles();
  SECURITY_SHIELD.init();
});
