// ============================================================
// BACKUP MANAGER — Or Eille AI v20
// Mémoire bienveillante — rien ne disparaît vraiment
// "Il y a un mois, vous aviez commencé à nous dire quelque chose.
//  Votre petite pépite de ce jour-là... On reste à l'écoute."
// © 2026 Madame Or Eille Studios
// ============================================================

const BACKUP_MANAGER = {

  // ── CONFIG ─────────────────────────────────────────────────
  config: {
    intervalleSauvegarde:  10 * 60 * 1000,   // toutes les 10 minutes
    dureeCorbeille:        365,               // 1 an en jours
    maxVersionsParDoc:     50,                // 50 versions par document
    cleBackups:            'oreille_backups_v1',
    cleCorbeille:          'oreille_corbeille_v1',
    cleRappels:            'oreille_rappels_v1',
    cleVersions:           'oreille_versions_v1',
  },

  // ── RAPPELS DANS LE TEMPS ───────────────────────────────────
  echeancesRappel: [
    { jours: 30,   label: 'il y a un mois'  },
    { jours: 90,   label: 'il y a 3 mois'   },
    { jours: 180,  label: 'il y a 6 mois'   },
    { jours: 365,  label: 'il y a un an'    },
    { jours: 730,  label: 'il y a 2 ans'    },
    { jours: 1095, label: 'il y a 3 ans'    },
    { jours: 1825, label: 'il y a 5 ans'    },
  ],

  // ── MESSAGES BIENVEILLANTS ──────────────────────────────────
  // La voix de Madame Or Eille — jamais administrative
  messageRappel(pepite, echeance) {
    const titre  = pepite.titre || 'quelque chose';
    const extrait = pepite.extrait || '';
    const label  = echeance.label;

    const messages = [
      `${label}, vous aviez commencé à nous dire quelque chose. Votre petite pépite "${titre}"... On reste à l'écoute.`,
      `${label}, quelque chose prenait forme en vous. "${titre}" — cette vérité qui était en vous ce jour-là. On la garde précieusement.`,
      `Votre pépite de ${label} vous attend. "${titre}" — vous aviez commencé, peut-être que le moment est venu de continuer ?`,
      `${label}, vous nous aviez confié le début de quelque chose. "${titre}". Nous l'avons gardé. Nous sommes toujours là.`,
    ];

    const msg = messages[Math.floor(Math.random() * messages.length)];
    return {
      message: msg,
      extrait: extrait ? `"${extrait.slice(0, 120)}${extrait.length > 120 ? '...' : ''}"` : '',
    };
  },

  // ── STATE ───────────────────────────────────────────────────
  state: {
    intervalleId:  null,
    documentActif: null,
    derniereModif: null,
  },

  // ── INIT ────────────────────────────────────────────────────
  init() {
    this.demarrerSauvegardeAuto();
    this.verifierRappels();
    console.log('✅ Backup Manager — mémoire bienveillante activée');
  },

  // ── SAUVEGARDE AUTOMATIQUE ──────────────────────────────────
  demarrerSauvegardeAuto() {
    // Sauvegarde toutes les 10 minutes si l'utilisateur est actif
    this.state.intervalleId = setInterval(() => {
      if(this.state.documentActif && this.state.derniereModif) {
        const maintenant = Date.now();
        const depuisModif = maintenant - this.state.derniereModif;
        // Sauvegarder seulement si modifié dans les 15 dernières minutes
        if(depuisModif < 15 * 60 * 1000) {
          this.sauvegarderVersion(this.state.documentActif, 'auto');
        }
      }
    }, this.config.intervalleSauvegarde);

    // Sauvegarder avant fermeture
    window.addEventListener('beforeunload', () => {
      if(this.state.documentActif) {
        this.sauvegarderVersion(this.state.documentActif, 'fermeture');
      }
    });

    // Sauvegarder quand l'onglet devient invisible
    document.addEventListener('visibilitychange', () => {
      if(document.hidden && this.state.documentActif) {
        this.sauvegarderVersion(this.state.documentActif, 'onglet_cache');
      }
    });
  },

  // Appeler depuis l'app quand le document change
  signalerModification(document) {
    this.state.documentActif = document;
    this.state.derniereModif = Date.now();
  },

  // ── VERSIONS ────────────────────────────────────────────────
  sauvegarderVersion(doc, raison) {
    if(!doc || !doc.id || !doc.contenu) return;

    try {
      const versions = this._charger(this.config.cleVersions);
      if(!versions[doc.id]) versions[doc.id] = [];

      const version = {
        id:       'v_' + Date.now(),
        docId:    doc.id,
        titre:    doc.titre || 'Sans titre',
        contenu:  doc.contenu,
        extrait:  doc.contenu.slice(0, 200),
        raison,
        date:     new Date().toISOString(),
        taille:   doc.contenu.length,
      };

      // Éviter les doublons — pas de sauvegarde si contenu identique
      const derniere = versions[doc.id][0];
      if(derniere && derniere.contenu === doc.contenu) return;

      versions[doc.id].unshift(version);

      // Garder max 50 versions par document
      if(versions[doc.id].length > this.config.maxVersionsParDoc) {
        // Archiver les plus anciennes plutôt que les supprimer
        const aArchiver = versions[doc.id].splice(this.config.maxVersionsParDoc);
        this._archiverVersionsAnciennes(doc.id, aArchiver);
      }

      this._sauvegarder(this.config.cleVersions, versions);
      console.log('[Backup] Version sauvegardée —', doc.titre, '—', raison);

    } catch(e) {
      console.warn('[Backup] Erreur sauvegarde version:', e.message);
    }
  },

  // Récupérer toutes les versions d'un document
  obtenirVersions(docId) {
    try {
      const versions = this._charger(this.config.cleVersions);
      return versions[docId] || [];
    } catch(e) { return []; }
  },

  // Restaurer une version spécifique
  restaurerVersion(docId, versionId) {
    const versions = this.obtenirVersions(docId);
    const version  = versions.find(v => v.id === versionId);
    if(!version) return null;
    console.log('[Backup] Restauration version', versionId, 'pour doc', docId);
    return version;
  },

  // ── CORBEILLE ───────────────────────────────────────────────
  // "Supprimer" = mettre en corbeille, jamais vraiment effacer
  mettreEnCorbeille(doc) {
    if(!doc || !doc.id) return;

    try {
      const corbeille = this._charger(this.config.cleCorbeille);

      const element = {
        ...doc,
        dateSuppression:    new Date().toISOString(),
        dateExpirationInfo: this._dateExpiration(this.config.dureeCorbeille),
        extrait:            (doc.contenu || '').slice(0, 300),
        statut:             'corbeille',
      };

      corbeille[doc.id] = element;
      this._sauvegarder(this.config.cleCorbeille, corbeille);

      // Programmer le rappel à 1 an
      this._programmerRappel(doc.id, doc.titre, (doc.contenu || '').slice(0, 200));

      console.log('[Backup] Mis en corbeille — sera rappelé dans 1 an:', doc.titre);
      return true;

    } catch(e) {
      console.warn('[Backup] Erreur corbeille:', e.message);
      return false;
    }
  },

  // Restaurer depuis la corbeille
  restaurerDepuisCorbeille(docId) {
    try {
      const corbeille = this._charger(this.config.cleCorbeille);
      const doc       = corbeille[docId];
      if(!doc) return null;

      // Changer le statut
      doc.statut       = 'restaure';
      doc.dateRestaure = new Date().toISOString();
      delete corbeille[docId];

      this._sauvegarder(this.config.cleCorbeille, corbeille);
      console.log('[Backup] Restauré depuis corbeille:', doc.titre);
      return doc;

    } catch(e) {
      console.warn('[Backup] Erreur restauration:', e.message);
      return null;
    }
  },

  // Archiver en profondeur — "je ne veux plus le voir mais je le garde"
  archiverEnProfondeur(docId) {
    try {
      const corbeille = this._charger(this.config.cleCorbeille);
      if(corbeille[docId]) {
        corbeille[docId].statut      = 'archive_profond';
        corbeille[docId].dateArchive = new Date().toISOString();
        this._sauvegarder(this.config.cleCorbeille, corbeille);
        console.log('[Backup] Archivé en profondeur:', docId);
      }
      return true;
    } catch(e) { return false; }
  },

  // Lister la corbeille
  listerCorbeille(inclureArchivesProfond) {
    try {
      const corbeille = this._charger(this.config.cleCorbeille);
      return Object.values(corbeille).filter(d =>
        inclureArchivesProfond ? true : d.statut === 'corbeille'
      ).sort((a,b) => new Date(b.dateSuppression) - new Date(a.dateSuppression));
    } catch(e) { return []; }
  },

  // ── RAPPELS DANS LE TEMPS ───────────────────────────────────
  _programmerRappel(docId, titre, extrait) {
    try {
      const rappels = this._charger(this.config.cleRappels);
      const maintenant = Date.now();

      // Créer un rappel pour chaque échéance
      this.echeancesRappel.forEach(echeance => {
        const rappelId = `${docId}_${echeance.jours}j`;
        rappels[rappelId] = {
          docId,
          titre:       titre || 'Sans titre',
          extrait:     extrait || '',
          echeance:    echeance.jours,
          label:       echeance.label,
          datePrevue:  new Date(maintenant + echeance.jours * 24 * 60 * 60 * 1000).toISOString(),
          declenche:   false,
        };
      });

      this._sauvegarder(this.config.cleRappels, rappels);
    } catch(e) { console.warn('[Backup] Erreur programmation rappels:', e.message); }
  },

  // Vérifier les rappels à déclencher — appelé à chaque ouverture de l'app
  verifierRappels() {
    try {
      const rappels   = this._charger(this.config.cleRappels);
      const maintenant = new Date();
      const aDeclencher = [];

      Object.keys(rappels).forEach(id => {
        const rappel = rappels[id];
        if(!rappel.declenche && new Date(rappel.datePrevue) <= maintenant) {
          aDeclencher.push(rappel);
          rappels[id].declenche    = true;
          rappels[id].dateDeclenche = maintenant.toISOString();
        }
      });

      if(aDeclencher.length > 0) {
        this._sauvegarder(this.config.cleRappels, rappels);
        // Afficher les rappels avec un délai pour ne pas surcharger l'ouverture
        setTimeout(() => {
          aDeclencher.forEach((rappel, i) => {
            setTimeout(() => this.afficherRappel(rappel), i * 3000);
          });
        }, 2000);
      }

    } catch(e) { console.warn('[Backup] Erreur vérification rappels:', e.message); }
  },

  // ── AFFICHAGE RAPPEL ────────────────────────────────────────
  afficherRappel(rappel) {
    const echeance = this.echeancesRappel.find(e => e.jours === rappel.echeance)
      || { label: rappel.label };
    const pepite   = { titre: rappel.titre, extrait: rappel.extrait };
    const contenu  = this.messageRappel(pepite, echeance);

    // Créer la notification douce
    const notif = document.createElement('div');
    notif.className = 'bm-rappel';
    notif.innerHTML = `
      <div class="bm-rappel-icon">🌿</div>
      <div class="bm-rappel-corps">
        <div class="bm-rappel-message">${contenu.message}</div>
        ${contenu.extrait ? `<div class="bm-rappel-extrait">${contenu.extrait}</div>` : ''}
        <div class="bm-rappel-actions">
          <button class="bm-btn-consulter" data-docid="${rappel.docId}">Consulter →</button>
          <button class="bm-btn-garder" data-docid="${rappel.docId}">Garder encore un an</button>
          <button class="bm-btn-archiver" data-docid="${rappel.docId}">Archiver en profondeur</button>
        </div>
      </div>
      <button class="bm-rappel-fermer">✕</button>
    `;

    document.body.appendChild(notif);
    setTimeout(() => notif.classList.add('bm-visible'), 100);

    // Events
    notif.querySelector('.bm-rappel-fermer').addEventListener('click', () => {
      notif.classList.remove('bm-visible');
      setTimeout(() => notif.remove(), 400);
    });

    notif.querySelector('.bm-btn-garder')?.addEventListener('click', () => {
      this._prolongerRappel(rappel.docId, 365);
      notif.classList.remove('bm-visible');
      setTimeout(() => notif.remove(), 400);
    });

    notif.querySelector('.bm-btn-archiver')?.addEventListener('click', () => {
      this.archiverEnProfondeur(rappel.docId);
      notif.classList.remove('bm-visible');
      setTimeout(() => notif.remove(), 400);
    });

    notif.querySelector('.bm-btn-consulter')?.addEventListener('click', () => {
      const doc = this.listerCorbeille(true).find(d => d.id === rappel.docId);
      if(doc) this.afficherApercu(doc);
      notif.classList.remove('bm-visible');
      setTimeout(() => notif.remove(), 400);
    });

    // Auto-fermeture après 30 secondes
    setTimeout(() => {
      if(notif.parentNode) {
        notif.classList.remove('bm-visible');
        setTimeout(() => notif.remove(), 400);
      }
    }, 30000);
  },

  // ── APERÇU DOCUMENT ─────────────────────────────────────────
  afficherApercu(doc) {
    const modal = document.createElement('div');
    modal.className = 'bm-modal';
    modal.innerHTML = `
      <div class="bm-modal-contenu">
        <div class="bm-modal-header">
          <div class="bm-modal-titre">${doc.titre || 'Sans titre'}</div>
          <div class="bm-modal-date">Créé le ${this._formaterDate(doc.dateSuppression || doc.date)}</div>
          <button class="bm-modal-fermer">✕</button>
        </div>
        <div class="bm-modal-texte">${(doc.contenu || doc.extrait || '').slice(0, 2000)}</div>
        <div class="bm-modal-actions">
          <button class="bm-btn-restaurer" data-docid="${doc.id}">✊ Restaurer ce document</button>
          <button class="bm-btn-archiver-deep" data-docid="${doc.id}">📦 Archiver en profondeur</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);
    setTimeout(() => modal.classList.add('bm-modal-visible'), 100);

    modal.querySelector('.bm-modal-fermer').addEventListener('click', () => {
      modal.classList.remove('bm-modal-visible');
      setTimeout(() => modal.remove(), 300);
    });

    modal.querySelector('.bm-btn-restaurer')?.addEventListener('click', () => {
      const restaure = this.restaurerDepuisCorbeille(doc.id);
      if(restaure && window.OREILLE_APP?.onRestauration) {
        window.OREILLE_APP.onRestauration(restaure);
      }
      modal.classList.remove('bm-modal-visible');
      setTimeout(() => modal.remove(), 300);
    });

    modal.querySelector('.bm-btn-archiver-deep')?.addEventListener('click', () => {
      this.archiverEnProfondeur(doc.id);
      modal.classList.remove('bm-modal-visible');
      setTimeout(() => modal.remove(), 300);
    });
  },

  // ── UTILITAIRES ─────────────────────────────────────────────
  _prolongerRappel(docId, joursSupp) {
    try {
      const rappels = this._charger(this.config.cleRappels);
      Object.keys(rappels).forEach(id => {
        if(rappels[id].docId === docId && rappels[id].declenche) {
          rappels[id].declenche = false;
          rappels[id].datePrevue = new Date(
            Date.now() + joursSupp * 24 * 60 * 60 * 1000
          ).toISOString();
        }
      });
      this._sauvegarder(this.config.cleRappels, rappels);
    } catch(e) {}
  },

  _archiverVersionsAnciennes(docId, versions) {
    try {
      const archives = this._charger('oreille_archives_v1');
      if(!archives[docId]) archives[docId] = [];
      archives[docId].push(...versions);
      this._sauvegarder('oreille_archives_v1', archives);
    } catch(e) {}
  },

  _dateExpiration(jours) {
    const d = new Date();
    d.setDate(d.getDate() + jours);
    return d.toISOString();
  },

  _formaterDate(isoString) {
    if(!isoString) return '';
    const d = new Date(isoString);
    return d.toLocaleDateString('fr-FR', { day:'numeric', month:'long', year:'numeric' });
  },

  _charger(cle) {
    try {
      return JSON.parse(localStorage.getItem(cle) || '{}');
    } catch(e) { return {}; }
  },

  _sauvegarder(cle, data) {
    try {
      localStorage.setItem(cle, JSON.stringify(data));
    } catch(e) {
      console.warn('[Backup] Stockage plein — nettoyage nécessaire:', e.message);
    }
  },

  // ── STYLES ──────────────────────────────────────────────────
  injectStyles() {
    const s = document.createElement('style');
    s.textContent = `
.bm-rappel{position:fixed;bottom:24px;left:24px;z-index:9990;background:#1a1a2e;border:1px solid rgba(79,195,247,.25);border-left:4px solid #4fc3f7;border-radius:12px;padding:18px;max-width:380px;display:flex;gap:12px;align-items:flex-start;box-shadow:0 8px 32px rgba(0,0,0,.4);transform:translateY(20px);opacity:0;transition:all .4s ease}
.bm-rappel.bm-visible{transform:translateY(0);opacity:1}
.bm-rappel-icon{font-size:1.5em;flex-shrink:0;margin-top:2px}
.bm-rappel-corps{flex:1}
.bm-rappel-message{font-size:.88em;color:#ddd;line-height:1.6;margin-bottom:8px}
.bm-rappel-extrait{font-size:.8em;color:#888;font-style:italic;line-height:1.4;margin-bottom:12px;border-left:2px solid rgba(255,255,255,.1);padding-left:10px}
.bm-rappel-actions{display:flex;flex-wrap:wrap;gap:6px}
.bm-btn-consulter{background:rgba(79,195,247,.2);border:1px solid #4fc3f7;color:#4fc3f7;padding:6px 12px;border-radius:6px;cursor:pointer;font-size:.78em;font-weight:600}
.bm-btn-consulter:hover{background:rgba(79,195,247,.35)}
.bm-btn-garder{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:#aaa;padding:6px 12px;border-radius:6px;cursor:pointer;font-size:.78em}
.bm-btn-garder:hover{border-color:#fff;color:#fff}
.bm-btn-archiver{background:transparent;border:none;color:#666;padding:6px 8px;cursor:pointer;font-size:.75em;text-decoration:underline}
.bm-btn-archiver:hover{color:#aaa}
.bm-rappel-fermer{background:transparent;border:none;color:#555;cursor:pointer;font-size:.9em;padding:4px;flex-shrink:0}
.bm-rappel-fermer:hover{color:#fff}

.bm-modal{position:fixed;inset:0;z-index:9995;background:rgba(0,0,0,.7);display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .3s}
.bm-modal.bm-modal-visible{opacity:1}
.bm-modal-contenu{background:#1a1a2e;border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:28px;max-width:600px;width:90%;max-height:80vh;display:flex;flex-direction:column;gap:16px}
.bm-modal-header{display:flex;align-items:flex-start;gap:12px;flex-wrap:wrap}
.bm-modal-titre{font-size:1.1em;font-weight:700;color:#fff;flex:1}
.bm-modal-date{font-size:.8em;color:#888;align-self:center}
.bm-modal-fermer{background:transparent;border:none;color:#666;cursor:pointer;font-size:1.1em;padding:4px 8px;margin-left:auto}
.bm-modal-fermer:hover{color:#fff}
.bm-modal-texte{flex:1;overflow-y:auto;font-size:.88em;color:#ccc;line-height:1.7;background:rgba(255,255,255,.04);padding:16px;border-radius:8px;white-space:pre-wrap;max-height:300px}
.bm-modal-actions{display:flex;gap:10px;flex-wrap:wrap}
.bm-btn-restaurer{background:linear-gradient(135deg,#0288d1,#026da3);color:#fff;border:none;padding:11px 20px;border-radius:8px;cursor:pointer;font-size:.9em;font-weight:700}
.bm-btn-restaurer:hover{opacity:.85}
.bm-btn-archiver-deep{background:transparent;border:1px solid rgba(255,255,255,.2);color:#aaa;padding:11px 20px;border-radius:8px;cursor:pointer;font-size:.9em}
.bm-btn-archiver-deep:hover{border-color:#fff;color:#fff}

@media(max-width:480px){.bm-rappel{left:10px;right:10px;max-width:none}}
    `;
    document.head.appendChild(s);
  },

};

window.addEventListener('load', () => {
  BACKUP_MANAGER.injectStyles();
  BACKUP_MANAGER.init();
});
