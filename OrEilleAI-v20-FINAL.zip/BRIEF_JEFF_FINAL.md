# BRIEF JEFF — Or Eille AI v18
## Version finale — Mai 2026

---

## CONTEXTE

Ce projet s'appelle **Or Eille AI**. C'est une PWA — une application web progressive — créée par et pour **Madame Or Eille Studios**.

Au départ c'est un outil personnel. Un assistant IA complet pour la création de contenu, la gestion du quotidien, la sécurité, la santé, la traduction. Tout ce dont une créatrice de contenu indépendante a besoin au quotidien.

Si ça marche bien — et les bases sont solides — ça peut devenir quelque chose de plus grand. Mais pas de pression. Pas de date. On verra.

**Tous les comptes appartiennent à Judith — Madame Or Eille Studios.**
Tu es le prestataire technique qui déploie. Tous les accès te sont confiés temporairement. Tu ne gardes aucune clé, aucun accès après déploiement sauf si Judith te le demande explicitement.

---

## CE QUE TU REÇOIS

Un dossier `madame-or-eille-pwa/` — une PWA complète.
**50 fichiers JavaScript. Tout est codé. Rien à compléter. Rien à inventer.**

Tu mets les clés. Tu déploies. C'est tout.

**Temps estimé : 30 minutes maximum.**

---

## ÉTAPE 1 — LES CLÉS

Ouvre `index.html`. Cherche le bloc CFG tout en haut. Remplace les valeurs :

```javascript
const CFG = {
  // Images, voix, musique — replicate.com → Account → API tokens
  REPLICATE_KEY: 'ta_clé_replicate',

  // Cerveau IA — console.anthropic.com → API Keys
  CLAUDE_KEY: 'ta_clé_anthropic',

  // Paiements — dashboard.stripe.com → Developers → clé publique
  STRIPE_PUBLIC_KEY: 'ta_clé_stripe_publique',

  // Lien de paiement 18€/mois — créer dans Stripe → Payment Links
  STRIPE_CHECKOUT_URL: 'https://buy.stripe.com/...',

  // Sync multi-appareils — supabase.com → nouveau projet → Settings → API
  SUPABASE_URL: 'https://xxx.supabase.co',
  SUPABASE_KEY: 'ta_clé_supabase_anon',

  // URL page Madame Or Eille pour les renvois émotionnels
  MADAME_OR_EILLE_URL: 'https://madame-or-eille.com',
};
```

**Tu as déjà Stripe et Vercel** — tu les as configurés pour le Jardin Intérieur.
**Supabase** — créer un nouveau projet gratuit, copier l'URL et la clé anon. La table se crée automatiquement au premier démarrage. Rien d'autre à faire.

---

## ÉTAPE 2 — DÉPLOYER

```bash
cd madame-or-eille-pwa
vercel deploy --prod
```

C'est tout. L'appli est en ligne.

---

## CE QUE FAIT L'APPLI — EN RÉSUMÉ

**Pour la créatrice**
Génération d'images, vidéos, musique, jingles. Scripts podcast avec téléprompteur. Newsletter dans n'importe quel style culturel. Légendes Instagram/TikTok/YouTube. Sous-titres en 20 langues. Planificateur de contenu. Analyse niche et algorithmes.

**Pour le quotidien**
Gestion stock, liste de courses, GPS OpenStreetMap, caisse et facturation, comptabilité, contrats marques équitables.

**Pour la sécurité**
Mboka na biso — filtrage communautaire, archivage preuves 5 ans. Check-in sécurité femmes — confidentiel. Fiche médicale d'urgence — 4 tapes sur l'écran. Traducteur instantané toutes langues.

**Pour l'accessibilité**
Configurateur première ouverture guidé vocalement. Polices, contrastes, tailles, langue des signes. Accompagnement neurodivergent.

---

## MODÈLE ÉCONOMIQUE

- Version gratuite — 10 images + 2 vidéos + 3h/jour
- Version payante — **18€/mois** — illimité
- Lancement — 1er juin 2026

---

## IMPORTANT

- **Ne pas modifier le code** — tout est complet et intentionnel
- **Ne pas ajouter de fonctionnalités** sans accord de Judith
- **Tous les codes appartiennent à Judith** — Madame Or Eille Studios
- En cas de bug après déploiement — noter et remonter à Judith

---

*Or Eille AI — L'IA qui s'exécute au doigt et à l'œil*
*© 2026 Madame Or Eille Studios — Tous droits réservés*
